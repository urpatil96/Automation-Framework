# ruff: noqa: E501  (the embedded JavaScript DOM shim is kept compact on purpose)
"""Render every UI page in V8 (pip install mini-racer) against real API data - no browser, no Node.js.

    python source/tests/ui_smoke_v8.py            (uses this project's config/suites/results)

How: the ES modules are bundled into one script (import -> registry lookup), a tiny DOM shim stands in for
the browser, fetch() answers from responses captured with FastAPI's TestClient. Each page's render() is
awaited; then the New run wizard is clicked through to the last step. Any JavaScript exception fails.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]  # project root (config, suites)
WEB = ROOT / "source" / "bwtest" / "ui" / "web" / "js"

DOM_SHIM = r"""
var __log = [];
class Node { constructor(){ this.parentNode=null; this.childNodes=[]; } get isConnected(){ return true; }
  get firstChild(){ return this.childNodes[0] || null; }
  appendChild(c){ if(c.parentNode) c.parentNode.removeChild(c); c.parentNode=this; this.childNodes.push(c); return c; }
  removeChild(c){ const i=this.childNodes.indexOf(c); if(i>=0) this.childNodes.splice(i,1); c.parentNode=null; return c; }
  append(...cs){ cs.forEach(c => this.appendChild(typeof c === "string" ? new Text(c) : c)); }
  replaceChildren(...cs){ this.childNodes.slice().forEach(c=>this.removeChild(c)); this.append(...cs); }
  remove(){ if(this.parentNode) this.parentNode.removeChild(this); }
  get textContent(){ return this.childNodes.map(c=>c.textContent).join(""); }
  set textContent(v){ this.childNodes=[]; if(v!=="" && v!==null && v!==undefined) this.appendChild(new Text(String(v))); }
  cloneNode(){ return this; }
}
class Text extends Node { constructor(t){ super(); this.data=t; } get textContent(){ return this.data; } set textContent(v){ this.data=v; } }
class Element extends Node {
  constructor(tag){ super(); this.tagName=tag.toUpperCase(); this.attributes={}; this.listeners={}; this.style={}; this.dataset={};
    this.className=""; this.value=""; this.checked=false; this.disabled=false; this.scrollTop=0; this.scrollHeight=0;
    const self=this; this.classList={ add:(c)=>{ if(!self.classList.contains(c)) self.className=(self.className+" "+c).trim(); },
      remove:(c)=>{ self.className=self.className.split(" ").filter(x=>x!==c).join(" "); },
      toggle:(c,on)=>{ if(on===undefined) on=!self.classList.contains(c); on?self.classList.add(c):self.classList.remove(c); },
      contains:(c)=>self.className.split(" ").includes(c) }; }
  setAttribute(k,v){ this.attributes[k]=v; } getAttribute(k){ return this.attributes[k]; }
  addEventListener(t,fn){ (this.listeners[t] ||= []).push(fn); } removeEventListener(){}
  dispatch(t, extra){ const ev = { type:t, target:this, preventDefault(){}, stopPropagation(){}, ...(extra||{}) };
    return Promise.all((this.listeners[t]||[]).map(fn => fn(ev))); }
  click(){ return this.dispatch("click"); }
  focus(){} setRangeText(){} get children(){ return this.childNodes.filter(c=>c instanceof Element); }
  matches(sel){ return sel.split(",").some(s => { s=s.trim(); const [tag, ...cls]=s.split(".");
    return (!tag || tag==="*" || this.tagName===tag.toUpperCase()) && cls.every(c=>this.classList.contains(c)); }); }
  querySelectorAll(sel){ const out=[]; const walk=(n)=>{ for(const c of n.childNodes){ if(c instanceof Element){ if(c.matches(sel)) out.push(c); walk(c);} } }; walk(this); return out; }
  querySelector(sel){ return this.querySelectorAll(sel)[0] || null; }
}
var document = { createElement:(t)=>new Element(t), createTextNode:(t)=>new Text(t), body:new Element("body"),
  addEventListener(){}, removeEventListener(){}, title:"" };
var __timers = [];
var setTimeout = (fn, ms) => { __timers.push(fn); return __timers.length; };
var clearTimeout = () => {}; var setInterval = () => 0; var clearInterval = () => {};
var location = { hash: "#/" };
var window = { addEventListener(){}, removeEventListener(){}, scrollTo(){}, open(){} };
var navigator = { clipboard: { writeText: async () => {} } };
var localStorage = { _d: {}, getItem(k){ return this._d[k] ?? null; }, setItem(k, v){ this._d[k] = String(v); } };
class Event { constructor(type){ this.type = type; } }
window.dispatchEvent = () => true;
class URLSearchParams { constructor(init){ this.p = Array.isArray(init) ? init : typeof init === "string"
    ? init.replace(/^\?/, "").split("&").filter(Boolean).map(kv=>kv.split("=").map(decodeURIComponent)) : Object.entries(init||{}); }
  toString(){ return this.p.map(([k,v])=>encodeURIComponent(k)+"="+encodeURIComponent(v)).join("&"); }
  [Symbol.iterator](){ return this.p[Symbol.iterator](); }
  has(k){ return this.p.some(([x]) => x === k); } get(k){ const e = this.p.find(([x]) => x === k); return e ? e[1] : null; } }
var __ids = {};
document.getElementById = (id) => (__ids[id] ||= new Element("div"));
location.search = "";
var __responses = {};
var __requests = [];
async function fetch(url, opts) {
  const method = (opts && opts.method) || "GET";
  __requests.push(method + " " + url);
  const key = method + " " + url;
  const hit = __responses[key] ?? __responses[method + " " + url.split("?")[0]];
  if (hit === undefined) return { ok:false, status:404, statusText:"no fixture", text: async () => JSON.stringify({detail:"no fixture for " + key}) };
  return { ok:true, status:200, text: async () => JSON.stringify(hit) };
}
async function __flushTimers(){ for (let i=0;i<5;i++){ const t=__timers.splice(0); for (const fn of t){ try{ await fn(); }catch(e){ __log.push("timer error: "+e); } } await null; } }
function __text(n){ return n.textContent; }
function __find(root, tag, text){ return root.querySelectorAll(tag).find(e => e.textContent.includes(text)); }
"""


def bundle() -> str:
    parts = ["var __modules = {}; var __cache = {};",
             "function __require(name){ if(!__cache[name]) __cache[name] = __modules[name](); return __cache[name]; }"]
    for file in sorted(WEB.rglob("*.js")):
        name = file.relative_to(WEB).as_posix()
        src = file.read_text(encoding="utf-8")

        def resolve(rel: str, base: str = name) -> str:
            path = (Path(base).parent / rel).as_posix()
            stack = []
            for seg in path.split("/"):
                if seg == "..":
                    stack.pop()
                elif seg not in (".", ""):
                    stack.append(seg)
            return "/".join(stack)

        src = re.sub(r"^import\s*\{([^}]*)\}\s*from\s*\"([^\"]+)\";",
                     lambda m: f"const {{{' '.join(m.group(1).split())}}} = __require({json.dumps(resolve(m.group(2)))});"
                     + "\n" * m.group(0).count("\n"), src, flags=re.M)
        src = re.sub(r"import\(\"([^\"]+)\"\)", lambda m: f"Promise.resolve(__require({json.dumps(resolve(m.group(1)))}))", src)
        exports = re.findall(r"^export\s+(?:async\s+)?(?:function|const|let|class)\s+([A-Za-z_$][\w$]*)", src, flags=re.M)
        src = re.sub(r"^export default\s+", "const __default = ", src, flags=re.M)
        src = re.sub(r"^export\s+(?=(async\s+)?function|const|let|class)", "", src, flags=re.M)
        has_default = "const __default = " in src
        ret = ", ".join([*exports, *(["default: __default"] if has_default else [])])
        parts.append(f"__modules[{json.dumps(name)}] = function(){{\n{src}\nreturn {{{ret}}};\n}};")
    return "\n".join(parts)


def capture() -> tuple[dict, str, str]:
    from fastapi.testclient import TestClient

    from bwtest.ui.server import create_app

    c = TestClient(create_app(ROOT, ROOT / "config"))
    get = lambda url: c.get(url).json()  # noqa: E731
    suites = get("/api/suites")
    suite = next((s["name"] for s in suites if s["name"] == "bw-bat"), suites[0]["name"] if suites else "")
    runs = get("/api/runs?limit=300")
    run_id = runs["runs"][0]["id"] if runs["runs"] else ""
    responses = {
        "GET /api/overview": get("/api/overview"), "GET /api/profiles": get("/api/profiles"),
        "GET /api/suites": suites, "GET /api/selections": get("/api/selections"), "GET /api/tags": get("/api/tags"),
        "GET /api/runs": runs, "GET /api/preferences": get("/api/preferences"),
        **({f"GET /api/suites/{suite}": get(f"/api/suites/{suite}"),
            f"GET /api/suites/{suite}/source": get(f"/api/suites/{suite}/source")} if suite else {}),
        "GET /api/config": get("/api/config"),
        "POST /api/runs/preview": {"command": "bwtest run bw-bat"},
        # import dialog: fixed answers, so the list + result views are rendered even when nothing is pending
        "GET /api/import/pending": {"source": "C:/x/func", "source_exists": True, "suites": [
            {"name": "ftp", "folder": "migration/ftp"}, {"name": "jms", "folder": "migration/jms"}],
            "updates": [{"name": "jdbc_oracle19c", "file": "suites/x.suite.yaml", "new_tests": ["bw.9", "bw.10"],
                         "gone_tests": ["bw.1"]}]},
        "POST /api/import": {"imported": [{"name": "ftp", "tests": 5, "file": "suites/migration/ftp/ftp.suite.yaml",
                                           "bridged": 2}], "failed": [{"name": "jms", "error": "demo"}],
                             "added": [{"name": "jdbc_oracle19c", "tests": ["bw.9", "bw.10"]}], "gone": [],
                             "added_tests": 2, "tests": 5, "report": "suites/IMPORT_REPORT-x.md"},
    }
    if run_id:
        detail = get(f"/api/runs/{run_id}")
        detail.update(state="finished", gold_changes=2)  # so the Gold changes dialog can be clicked through
        responses[f"GET /api/runs/{run_id}"] = detail
        change = {"accepted": False, "kind": "text", "snapshot": "x/new.log", "gold": "C:/a/gold.log", "gold_exists": True,
                  "diff_text": "--- gold\n+++ output\n-a\n+b\n"}
        responses[f"GET /api/runs/{run_id}/gold-changes"] = {"changes": [
            {**change, "key": "s/bw.1", "suite": "s", "test": "bw.1"},
            {**change, "key": "s/bw.2", "suite": "s", "test": "bw.2"}]}
        responses[f"POST /api/runs/{run_id}/gold-changes/accept"] = {"accepted": ["s/bw.1"]}
        responses[f"GET /api/runs/{run_id}/console"] = get(f"/api/runs/{run_id}/console?offset=0")
    return responses, suite, run_id


def main() -> int:
    from py_mini_racer import MiniRacer

    responses, suite, run_id = capture()
    ctx = MiniRacer()
    ctx.eval(DOM_SHIM)
    ctx.eval(bundle())
    ctx.eval(f"__responses = {json.dumps(responses)};")

    pages = [("dashboard", {}, {}), ("runs", {}, {}), ("suites", {}, {}), *([("suiteDetail", {"name": suite}, {})] if suite else []),
             ("newSuite", {}, {}), ("preferences", {}, {}), ("doctor", {}, {}), ("help", {}, {}), ("notFound", {}, {}),
             ("newRun", {}, {"suite": suite})]
    if run_id:
        pages.append(("runDetail", {"id": run_id}, {}))
    failures = 0
    for page, params, query in pages:
        script = f"""
        (async () => {{
          const page = __require("pages/{page}.js").default;
          const view = {{ params: {json.dumps(params)}, query: {json.dumps(query)}, onCleanup(){{}}, navigate(){{}}, isCurrent: () => true }};
          const node = await page.render(view);
          await __flushTimers();
          if (!(node instanceof Element)) throw new Error("render() did not return an element");
          const title = typeof page.title === "function" ? page.title(view.params) : page.title;
          let extra = "";
          if ("{page}" === "newRun" && {str(bool(suite)).lower()}) {{   // click through the wizard: Next x3 -> review shows the command
            for (let i = 0; i < 3; i++) {{
              const next = __find(node, "button", "Next:");
              if (!next) throw new Error("wizard: no Next button at step " + (i + 1));
              await next.click(); await __flushTimers();
            }}
            if (!__find(node, "button", "Start run")) throw new Error("wizard: Start button missing on review step");
            extra = " | wizard reached review: " + (node.textContent.includes("bwtest run bw-bat") ? "command shown" : "NO COMMAND");
          }}
          if ("{page}" === "suites") {{   // Import t-tests suites dialog: list -> import -> result
            const open = __find(node, "button", "Sync with test folder");
            if (!open) throw new Error("suites: no Import button");
            await open.click(); await __flushTimers(); await __flushTimers();
            if (!document.body.textContent.includes("New suites (2)")) throw new Error("import dialog: no list");
            const go = __find(document.body, "button", "Sync selected (3)");
            if (!go) throw new Error("import dialog: no Sync button");
            await go.click(); await __flushTimers(); await __flushTimers();
            if (!document.body.textContent.includes("1 new suite (5 tests), 2 new test cases added")) throw new Error("import dialog: no result: " + document.body.textContent.slice(-400));
            extra = " | import dialog: list -> import -> result";
          }}
          if ("{page}" === "runDetail") {{   // Gold changes: accept ONE test, then the rest with the bottom button
            const open = __find(node, "button", "Gold changes (2)");
            if (!open) throw new Error("run: no Gold changes button");
            await open.click(); await __flushTimers(); await __flushTimers();
            const one = __find(document.body, "button", "Accept as gold");
            if (!one) throw new Error("gold dialog: no per-test Accept button");
            await one.click(); await __flushTimers();
            if (!document.body.textContent.includes("accepted as gold")) throw new Error("gold dialog: test not marked accepted");
            const rest = __find(document.body, "button", "Accept selected as gold (1)");
            if (!rest) throw new Error("gold dialog: bottom button should count 1 left: " + document.body.textContent.slice(-300));
            await (rest.onclick ? rest.onclick() : rest.click()); await __flushTimers();  // shim: no onclick dispatch
            if (__find(document.body, "button", "Accept as gold")) throw new Error("gold dialog: accepted test still has its button");
            extra = " | gold dialog: accept one -> accept selected";
          }}
          return title + " -> " + node.querySelectorAll("*").length + " elements" + extra;
        }})()
        """
        try:
            result = ctx.eval(script)
            text = result.get(timeout=20) if hasattr(result, "get") else result
            log = ctx.eval("__log.splice(0).join('; ')")
            print(f"OK   {page:<12} {text}" + (f"   [{log}]" if log else ""))
            if log:
                failures += 1
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"FAIL {page:<12} {str(exc).splitlines()[0][:400]}")
    print(f"{len(pages) - failures}/{len(pages)} pages render without JavaScript errors")

    # boot the whole app (app.js: route table, shell, first page) in browser and in desktop mode
    for mode, search in (("browser", ""), ("desktop", "?desktop=1")):
        boot = f"""
        (async () => {{
          __ids = {{}}; delete __cache["app.js"]; location.search = {json.dumps(search)}; location.hash = "#/";
          document.body.className = "";
          __require("app.js");
          for (let i = 0; i < 8; i++) {{ await __flushTimers(); await null; }}
          const outlet = document.getElementById("outlet"), side = document.getElementById("sidebar");
          if (outlet.querySelectorAll("*").length < 10) throw new Error("first page did not render");
          if (!side.querySelectorAll("*").length) throw new Error("sidebar / explorer empty");
          return "first page " + outlet.querySelectorAll("*").length + " elements, left pane " +
            side.querySelectorAll("*").length + " elements, body class '" + document.body.className + "'";
        }})()
        """
        try:
            result = ctx.eval(boot)
            print(f"OK   boot-{mode:<7} {result.get(timeout=20) if hasattr(result, 'get') else result}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"FAIL boot-{mode:<7} {str(exc).splitlines()[0][:400]}")

    # desktop application layout: toolbar + explorer tree + status bar, and Browse buttons on path fields
    desktop = """
    (async () => {
      const toolbar = new Element("div"), tree = new Element("aside"), statusbar = new Element("footer");
      __require("shell/desktop.js").initDesktop({ toolbar, tree, statusbar });
      for (let i = 0; i < 6; i++) { await __flushTimers(); await null; }
      const buttons = toolbar.querySelectorAll("button").map(b => b.textContent);
      if (!tree.textContent.includes("Test suites") || !tree.textContent.includes("Saved selections")) throw new Error("tree incomplete");
      if (!statusbar.textContent.includes("Profile")) throw new Error("status bar incomplete");
      const prefs = await __require("pages/preferences.js").default.render({ params: {}, query: {}, onCleanup(){} });
      const browse = prefs.querySelectorAll("button").filter(b => b.textContent === "Browse…").length;
      if (!browse) throw new Error("no Browse buttons in desktop mode");
      return buttons.length + " toolbar buttons (" + buttons.slice(0, 4).join(", ") + " …), tree " +
        tree.querySelectorAll("button").length + " nodes, " + browse + " Browse buttons on Preferences";
    })()
    """
    try:
        result = ctx.eval(desktop)
        print(f"OK   desktop      {result.get(timeout=20) if hasattr(result, 'get') else result}")
    except Exception as exc:  # noqa: BLE001
        failures += 1
        print(f"FAIL desktop     {str(exc).splitlines()[0][:400]}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
