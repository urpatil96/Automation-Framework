// Desktop layout (bwtest desktop / start-bwtest.bat) - modelled on the t-tests 4.0 window:
//   native menu bar (Python side) · toolbar · left tree (test suites, saved selections, recent runs)
//   · page area · status bar (profile/build, run in progress, counts).
import { api } from "../core/api.js";
import { h, mount } from "../core/dom.js";
import { since } from "../core/format.js";
import { confirmDialog, kv, modal, toast } from "../components/ui.js";

const STATE_ICON = { running: "◔", stopping: "◔", passed: "✔", failed: "✖", error: "⚠", stopped: "■", killed: "✖", aborted: "…", empty: "∅" };

export function initDesktop({ toolbar, tree, statusbar }) {
  document.body.classList.add("desktop");
  let overview = null;
  let suites = [];
  let selections = [];
  let runs = [];
  let active = null;
  let activeRuns = [];
  const open = new Set(JSON.parse(localStorage.getItem("bw.tree.open") || '["suites", "cmds", "runs"]'));
  let filter = "";

  // ------------------------------------------------------------------ toolbar
  const tb = (icon, label, title, onclick, cls = "") =>
    h("button", { class: `tb-btn ${cls}`, title, onclick }, h("span", { class: "tb-icon" }, icon), h("span", { class: "tb-label" }, label));
  const stopBtn = tb("■", "Stop", "Stop the run in progress after the current test", async () => {
    if (!active) return;
    if (!(await confirmDialog("Stop the run?", `Run ${active}: the current test finishes, then BW is cleaned up.`, "Stop run", "danger-solid"))) return;
    await api.stopRun(active);
    toast("Stop requested", "info");
  }, "danger");
  mount(toolbar,
    tb("▶", "New run", "Start a new run (File > New run)", () => go("#/run/new"), "primary"),
    tb("☑", "Select tests", "Choose suites / test cases (Edit > Select test cases)", () => go("#/run/new?step=2")),
    stopBtn,
    h("span", { class: "tb-sep" }),
    tb("☰", "Runs & reports", "Run history and HTML reports", () => go("#/runs")),
    tb("▤", "Suites", "Browse and edit suites", () => go("#/suites")),
    tb("+", "New suite", "Create a suite", () => go("#/suites/new")),
    h("span", { class: "tb-sep" }),
    tb("⚙", "Preferences", "Machine settings (old user profile + Preferences)", () => go("#/preferences")),
    tb("✚", "Doctor", "Check the BW build and the setup", () => go("#/doctor")),
    h("span", { class: "spacer" }),
    tb("◧", "Dashboard", "Overview", () => go("#/")),
    tb("?", "Help", "Guide for new users", () => go("#/help")));

  const go = (hash) => { location.hash = hash; };

  // ------------------------------------------------------------------ tree
  const search = h("input", { class: "input tree-search", placeholder: "Filter suites…",
    oninput: (e) => { filter = e.target.value.toLowerCase(); drawTree(); } });
  const treeBody = h("div", { class: "dtree" });
  mount(tree, h("div", { class: "pane-head" }, "Test explorer"), h("div", { class: "pane-search" }, search), treeBody);

  function folder(id, label, count, children) {
    const isOpen = open.has(id) || Boolean(filter);
    return h("div", { class: "dt-folder" },
      h("button", { class: "dt-row dt-folder-row", onclick: () => {
        if (open.has(id)) open.delete(id); else open.add(id);
        localStorage.setItem("bw.tree.open", JSON.stringify([...open]));
        drawTree();
      } }, h("span", { class: "dt-caret" }, isOpen ? "▾" : "▸"), h("span", { class: "dt-icon" }, isOpen ? "📂" : "📁"),
        h("span", { class: "dt-label" }, label), count !== undefined ? h("span", { class: "dt-count" }, count) : null),
      isOpen ? h("div", { class: "dt-children" }, children) : null);
  }

  function leaf(icon, label, title, onclick, ondblclick, extra, current) {
    return h("button", { class: ["dt-row dt-leaf", current && "current"], title, onclick, ondblclick },
      h("span", { class: "dt-icon" }, icon), h("span", { class: "dt-label" }, label), extra || null);
  }

  function drawTree() {
    const hash = location.hash;
    const visible = suites.filter((s) => !filter || `${s.name} ${s.description || ""} ${(s.tags || []).join(" ")}`.toLowerCase().includes(filter));
    // folders as on disk: engine > jdbc > oracle > jdbc_oracle19c (a suite's own folder is not an extra level)
    const root = { folders: new Map(), suites: [], count: 0 };
    for (const s of visible) {
      let node = root;
      node.count += 1;
      for (const part of (s.folder || s.category || "other").split("/")) {
        if (!node.folders.has(part)) node.folders.set(part, { folders: new Map(), suites: [], count: 0 });
        node = node.folders.get(part);
        node.count += 1;
      }
      node.suites.push(s);
    }
    const byName = (a, b) => a.localeCompare(b, undefined, { sensitivity: "base" });
    const children = (node, path) => [
      ...[...node.folders.keys()].sort(byName).map((name) => {
        const sub = node.folders.get(name);
        const id = path ? `${path}/${name}` : name;
        return folder(`cat:${id}`, name, sub.count, children(sub, id));
      }),
      ...node.suites.sort((a, b) => byName(a.name, b.name)).map((s) => suiteLeaf(s)),
    ];
    const suiteLeaf = (s) => leaf(s.error ? "⚠" : s.type === "bw_migration" ? "⇄" : "▤", s.name,
      `${s.description || ""}\n${s.tests} tests - click: open, double-click: run`,
      () => go(`#/suites/${encodeURIComponent(s.name)}`), () => go(`#/run/new?suite=${encodeURIComponent(s.name)}`),
      h("span", { class: "dt-count" }, s.tests), hash === `#/suites/${encodeURIComponent(s.name)}`);

    mount(treeBody,
      folder("suites", "Test suites", visible.length, children(root, "")),
      folder("cmds", "Saved selections", selections.length,
        selections.length ? selections.map((s) => leaf("☑", s.name, `${s.description || ""}\nclick: new run with this selection`,
          () => go(`#/run/new?selection=${encodeURIComponent(s.name)}`)))
          : h("div", { class: "dt-empty" }, "Save one on New run › Test cases (like .testcmd files)")),
      folder("runs", "Recent runs", runs.length,
        runs.map((r) => leaf(STATE_ICON[r.state] || "•", r.name || r.id, `${r.id} · ${r.state}`, () => go(`#/runs/${r.id}`), null,
          h("span", { class: `dt-count state-${r.state}` }, since(r.started)), hash === `#/runs/${r.id}`))));
  }

  // ------------------------------------------------------------------ status bar
  function drawStatus() {
    const cell = (text, cls = "", onclick) => h("span", { class: ["sb-cell", cls, onclick && "link"], onclick }, text);
    mount(statusbar,
      overview ? cell(`Profile ${overview.profile}`, "", () => go("#/preferences")) : cell("…"),
      overview ? cell(overview.bw_home, "mono dim") : null,
      active === undefined ? cell("● server not reachable", "bad")
        : activeRuns.length > 1 ? cell(h("span", {}, h("span", { class: "pulse" }), ` ${activeRuns.length} runs in progress`), "run", () => go("#/runs"))
        : active ? cell(h("span", {}, h("span", { class: "pulse" }), ` Run ${active} in progress`), "run", () => go(`#/runs/${active}`))
          : cell("No run in progress", "dim"),
      h("span", { class: "spacer" }),
      overview ? cell(`${overview.counts.suites} suites · ${overview.counts.tests.toLocaleString()} tests`, "dim") : null,
      overview ? cell(`T-Next ${overview.version}`, "dim") : null);
    stopBtn.disabled = !active;
  }

  // ------------------------------------------------------------------ data refresh
  async function loadStatic() {
    try {
      [overview, suites, selections] = await Promise.all([api.overview(), api.suites(), api.selections()]);
    } catch (e) { toast(e.message, "bad"); }
    drawTree();
    drawStatus();
  }
  async function poll() {
    try {
      const r = await api.runs(8);
      runs = r.runs;
      active = r.active;
      activeRuns = r.active_runs || (active ? [active] : []);
    } catch { active = undefined; }
    drawTree();
    drawStatus();
  }
  loadStatic();
  poll();
  setInterval(poll, 4000);
  window.addEventListener("hashchange", () => { drawTree(); if (/^#\/(suites|run\/new)/.test(location.hash)) loadStatic(); });
  window.addEventListener("bw:changed", loadStatic); // pages fire this after creating suites/tests/selections

  // ------------------------------------------------------------------ helpers for the native menu (desktop.py)
  window.bwDesktop = {
    openActive: () => (active ? go(`#/runs/${active}`) : toast("No run in progress", "info")),
    openResults: async () => {
      const o = overview || await api.overview();
      if (!(await window.pywebview?.api?.open_path(o.results_dir))) toast(o.results_dir, "info");
    },
    about: () => modal({ title: "About T-Next", body: kv([
      ["Application", "T-Next - BusinessWorks 6 regression framework"],
      ["Version", overview ? overview.version : ""],
      ["Successor of", "t-tests 4.0"], ["Engine", "Python · pytest · FastAPI · WebView2"],
      ["Project", overview ? overview.results_dir.replace(/\/results$/, "") : ""],
      ["Docs", "docs/README.md · docs/USER_GUIDE.md · docs/UI_REFERENCE.md"]]) }),
  };
}
