"""Several runs at the same time (slots.py): own domains + ports per run, same suite never twice at once."""

import json
import os
import subprocess
import sys

import pytest

from bwtest import slots
from bwtest.errors import ConfigError


def test_slot_0_keeps_the_old_names_and_ports():
    assert slots.domain_name("bwtest", 0, 1) == "bwtest-1"
    assert slots.port_index(0, 3) == 3
    assert slots.domain_name("bwtest", 2, 0) == "bwtest-s2-0"
    assert slots.port_index(1, 0) == slots.WORKERS_PER_SLOT


@pytest.fixture
def other_run(tmp_path):
    """A live process holding slot 0 with suite a.suite.yaml (what another `bwtest run` leaves behind)."""
    proc = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"])
    folder = tmp_path / slots.FOLDER
    folder.mkdir()
    suite_a = str((tmp_path / "a.suite.yaml").resolve())
    (folder / "slot-0.json").write_text(json.dumps({"slot": 0, "pid": proc.pid, "run": "R1", "workers": 2,
                                                    "suites": [suite_a]}))
    yield tmp_path, suite_a
    proc.kill()
    proc.wait()


def test_second_run_gets_the_next_slot_and_releases_it(other_run):
    home, _ = other_run
    claim = slots.claim(home, "R2", [str(home / "b.suite.yaml")], workers=2)
    assert claim.slot == 1
    data = json.loads((home / slots.FOLDER / "slot-1.json").read_text())
    assert data["pid"] == os.getpid() and data["run"] == "R2"
    claim.release()
    assert not (home / slots.FOLDER / "slot-1.json").exists()


@pytest.mark.parametrize("suites, workers, message", [
    ("same", 1, "already running in run R1"),
    (None, 1, "different suites"),
    ("other", 5, "at most 4 parallel workers"),
])
def test_runs_that_would_disturb_each_other_are_refused(other_run, suites, workers, message):
    home, suite_a = other_run
    chosen = {"same": [suite_a], "other": [str(home / "b.suite.yaml")], None: None}[suites]
    with pytest.raises(ConfigError, match=message):
        slots.claim(home, "R2", chosen, workers)


def test_slot_of_a_finished_or_killed_run_is_free_again(tmp_path):
    folder = tmp_path / slots.FOLDER
    folder.mkdir()
    proc = subprocess.Popen([sys.executable, "-c", "pass"])
    proc.wait()
    (folder / "slot-0.json").write_text(json.dumps({"slot": 0, "pid": proc.pid, "run": "old", "suites": None}))
    assert slots.claim(tmp_path, "R2", None, 0).slot == 0


def test_file_lock_is_exclusive(tmp_path):
    lock = tmp_path / "x.lock"
    with slots.file_lock(lock), pytest.raises(ConfigError, match="waited"), slots.file_lock(lock, timeout=0.5):
        pass
    assert not lock.exists()
