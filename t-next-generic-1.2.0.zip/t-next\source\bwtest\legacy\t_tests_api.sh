#!/usr/bin/env bash
# bwtest legacy bridge - minimal stand-in for t-tests 4.0 scripts/t_util.sh + t_tests_api.sh.
# Old t_setup.sh / t_action.sh / t_verify.sh source this file through ${TSI_SCRIPTS}/t_util.sh.
# Only the helpers that suite scripts actually call are provided; framework-internal ones are no-ops.

t_sleep() { sleep "${1:-1}"; }
t-testsSleep() { sleep "${1:-1}"; }
tu_init() { :; }
t_init() { :; }
t_util_init() { :; }
t_runtestcase_init() { :; }
t_set_errcode() { TSI_EXIT_CODE=$1; }
t_report_ln() { echo "$@"; }
t_report_separator() { echo "------------------------------------------------------------"; }

t_stripcr_file() { [ -f "$1" ] && sed -i 's/\r$//' "$1"; }

# t-tests command-line tools used inside suite scripts
t-stripcr() { local f; for f in "$@"; do t_stripcr_file "$f"; done; return 0; }
# XML compare (formatting / attribute order ignored). rc 0 = equal, 1 = different, 2 = missing / not XML.
t-xmldiff() { "${BWTEST_PYTHON:-python}" -m bwtest.legacy.xmldiff "$@"; }
t-sleep() { sleep "${1:-1}"; }
# default t-tests comparison: diff GOLD OUTPUT, differences appended to the diff file, rc = diff's rc
t-testsDefaultDiff() { diff "$1" "$2" >> "${TSI_TEST_DIFF_FILE:-/dev/stdout}" 2>&1; }
t_cond_stripcr_output_file() { t_stripcr_file "${TSI_TEST_OUTPUT_FILE}"; }
t_cond_stripcr_gold_file() { :; }
t_cond_set_goldfile_based_on_version() { :; }   # bwtest resolves version-specific gold files itself

# t-tests API calls used inside suite scripts: accepted and ignored (behaviour is now in bwtest).
for _fn in t-testsInitAPI t-testsInitTestCaseDefaults t-testsSetEngineJobCount t-testsSetEngineRunner \
           t-testsSetAdvanceVerify t-testsSetBWEngineOptions t-testsSetTRAJavaExtendedProperties \
           t-testsSetTRAJavaProperties t-testsSetTRAProperties t-testsSetRepoConvertGlobalVarOverride \
           t-testsSetStripCR t-testsSetLaunchProduct t-testsSetAutoStartEngine t-testsSetAutoKillEngine \
           t-testsSerializeEngineStart t-testsEnableMigration t-testsEnableValidateproject \
           t-testsGenerateTraFile t-testsUseRepoServer t-testsSetExternalLibPath t-testsPrependExternalLibPath; do
    eval "${_fn}() { :; }"
done
unset _fn
