"""Framework exceptions. Each one maps to a clear failure category in reports."""


class BwTestError(Exception):
    """Base class for all framework errors."""


class ConfigError(BwTestError):
    """Invalid or missing configuration (bad YAML, unknown key, missing BW home ...)."""


class BwCommandError(BwTestError):
    """A bwadmin / bwagent / bwinstall command failed."""

    def __init__(self, message: str, command: list[str] | None = None, output: str = ""):
        super().__init__(message)
        self.command = command or []
        self.output = output

    def __str__(self) -> str:
        text = super().__str__()
        if self.command:
            text += "\n  command: " + " ".join(self.command)
        if self.output:
            tail = "\n".join(self.output.strip().splitlines()[-25:])
            text += "\n  output (last lines):\n    " + tail.replace("\n", "\n    ")
        return text


class EnvironmentSetupError(BwTestError):
    """Domain / AppSpace / AppNode / driver / database setup failed (infrastructure, not product)."""


class ActionError(BwTestError):
    """An action step (http call, wait, shell ...) failed."""


class VerificationFailed(BwTestError):
    """Output did not match the expectation. This is a real test failure."""

    def __init__(self, message: str, details: str = ""):
        super().__init__(message)
        self.details = details
