"""Import t-tests 4.0 suites (.testset + t_setup.sh + t_action.sh + t_verify.sh + .cfg) into *.suite.yaml.

How it works
  1. The bash scripts are parsed into a small syntax tree (if / case / function / plain line).
  2. The tree is walked with a context = (which tests, which BW versions, which sequence):
        case ${TSI_TID} / ${TSI_TEST_ID}         -> narrows the set of tests (bash first-match rules)
        case ${TSI_TEST_SEQUENCE} / if seq == N  -> per-sequence variables
        if [ "${TSI_PROD_VERSION_3DIGIT}" == "681" ] ... -> gold_by_version
        if [ -d "${TIB_BW_HOME}/bin" ] ...      -> dropped (bwtest detects the version itself)
        helper functions (t_set_txt_output ...) -> inlined
  3. Each plain line becomes YAML (output/gold/input file, variable, wait) or, if it is a real command
     (tibemsadmin, java TcpClient ...), the affected tests are pointed at the original script through the
     legacy bridge and the command is listed in IMPORT_REPORT.md. Nothing is guessed.

Assets (EAR, projects, gold files) are referenced in place - nothing is copied.
"""

from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass, field
from pathlib import Path
from xml.etree import ElementTree as ET

import yaml

BINARY_EXT = {".jpg", ".jpeg", ".gif", ".png", ".pdf", ".zip", ".jar", ".ear", ".bin", ".doc", ".xls", ".class"}

VAR_MAP = {
    "TSI_TEST_ID": "id", "TSI_REPO_NAME": "project", "TSI_TID": "tid", "TSI_REPO_DIR": "case_dir",
    "TSI_LOG_DIR": "log_dir", "TSI_TESTPLAN_DIR": "suite_dir", "TSI_TEST_PRODUCT_ROOT": "assets_root",
    "TIB_BW_HOME": "bw_home", "TSI_COMPONENT": "suite", "TSI_TEST_SEQUENCE": "seq",
}
FILE_VARS = {"TSI_TEST_OUTPUT_FILE": "output", "TSI_TEST_GOLD_FILE": "gold", "TSI_TEST_INPUT_FILE": "input"}
IGNORED_VARS = {"TSI_TEST_DIFF_FILE", "TSI_TEST_ERROR_FILE", "TSI_EXIT_CODE", "TEST_DIFF_FILE", "TEST_ERROR_FILE"}

# Pure t-tests plumbing with a bwtest equivalent (or no meaning any more).
BOILERPLATE = [
    r"^echo\b", r"^TSI_EXIT_CODE=", r"^exit\b", r"^t_util=", r"^\.\s+\"?\$\{?t_util", r"^tu_init\b",
    r"^t_util_init\b", r"^t_init\b", r"^t-tests\w+", r"^t_cond_\w+", r"^:$", r"^export$", r"^then$",
    r"^cd\s+\"?\$\{?TSI_LOG_DIR", r"^pushd\b", r"^popd\b", r"^set\s+[-+]x", r"^unset\b", r"^//",
    # removing files inside the (now always fresh) per-test results folder
    r"^rm\s+(-\w+\s+)*\"?\$\{?(TSI_TEST_\w+|TEST_\w+|TSI_LOG_DIR)\b",
    r"^rm\s+(-\w+\s+)*\"?\$\{?TSI_TEST_OUTPUT",
    r"^chmod\s+\S+\s+\"?\$\{?TSI_LOG_DIR",
]
_BOILER_RES = [re.compile(p) for p in BOILERPLATE]
_WAIT_RE = re.compile(r"^(?:t_sleep|sleep|t-testsSleep)\s+(\d+(?:\.\d+)?)\s*$")
_ADVANCE_RE = re.compile(r"^t-testsSetAdvanceVerify\s+\"?(\w+)\"?\s*$")
_EXPORT_RE = re.compile(r"^(?:export\s+)?([A-Za-z_]\w*)=(.*)$")
_LABEL_RE = re.compile(r"^([^()#]+?)\s*\)\s*(.*)$")
_CASE_RE = re.compile(r"^case\s+\"?\$\{?(\w+)\}?\"?\s+in\b")
_FUNC_RE = re.compile(r"^(?:function\s+)?([A-Za-z_][\w-]*)\s*\(\)\s*(\{)?\s*$")
_VERSION_TEST_RE = re.compile(r"\[\s*\"?\$\{?TSI_PROD_VERSION_3DIGIT\}?\"?\s*==?\s*\"?(\d+)\"?\s*\]")
_SEQ_TEST_RE = re.compile(r"^\[\s*\"?\$\{?TSI_TEST_SEQUENCE\}?\"?\s*(?:=|==|-eq)\s*\"?(\d+)\"?\s*\]$")
_TID_TEST_RE = re.compile(r"^\[\s*\"?\$\{?(TSI_TID|TSI_TEST_ID)\}?\"?\s*==?\s*\"?([^\"\s\]]+)\"?\s*\]$")


def _wait_steps(waits: list[float], advance: bool) -> list[dict]:
    """t_action.sh sleeps -> action steps. With Advance Verify the whole action time is one early-exit wait."""
    if not waits:
        return []
    if advance:
        return [{"wait_for_output": sum(waits)}]
    return [{"wait": w} for w in waits]


# ---------------------------------------------------------------------------------------------
# testset XML
# ---------------------------------------------------------------------------------------------
def read_text(path: Path) -> str:
    data = path.read_bytes()
    for enc in ("utf-8", "cp1252", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def parse_testset(path: Path) -> dict:
    text = re.sub(r"^\s*<\?xml[^>]*\?>", "", read_text(path).lstrip("﻿"))
    root = ET.fromstring(text)
    ts = root if root.tag == "TestSet" else root.find("TestSet")
    if ts is None:
        raise ValueError(f"{path}: no <TestSet>")

    def txt(el, tag):
        child = el.find(tag)
        return " ".join((child.text or "").split()) if child is not None and child.text else ""

    tests, seen = [], set()
    for tc in ts.iter("TestCase"):
        raw_id = txt(tc, "ID")
        disabled = raw_id.startswith("#")
        tid = raw_id.lstrip("#").strip()
        if not tid or "<" in tid or "&lt;" in tid or tid.lower() in seen:
            continue
        seen.add(tid.lower())
        seq = txt(tc, "TestSequence")
        tests.append({
            "id": tid, "project": txt(tc, "Project") or tid.replace(".", "_"),
            "description": txt(tc, "Description"), "disabled": disabled,
            "known_to_fail": txt(tc, "KnownToFail").lower() == "true",
            "sequences": int(seq) if seq.isdigit() and int(seq) > 1 else 1,
            "setup": txt(tc, "SetupScript"), "action": txt(tc, "ActionScript"), "verify": txt(tc, "VerifyScript"),
        })
    return {"owner": txt(ts, "Owner"), "description": txt(ts, "Description"), "tests": tests}


# ---------------------------------------------------------------------------------------------
# bash -> syntax tree
# ---------------------------------------------------------------------------------------------
@dataclass
class Line:
    text: str


@dataclass
class Case:
    switch: str
    branches: list[tuple[list[str], list]]


@dataclass
class If:
    cond: str
    then: list
    orelse: list


@dataclass
class Func:
    name: str
    body: list


def _clean_lines(text: str) -> list[str]:
    out: list[str] = []
    for raw in text.replace("\r", "").split("\n"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("}"):
            line = "}"
        if line.endswith(";;") and line != ";;":
            out += [line[:-2].rstrip().rstrip(";").strip(), ";;"]
        else:
            out.append(line)
    return [ln for ln in out if ln]


def _is_stop(line: str, stops: set[str]) -> bool:
    word = re.split(r"[\s;]", line, maxsplit=1)[0]
    return (word in stops) or (line in stops) or ("}" in stops and line == "}")


def parse_script(text: str) -> list:
    lines = _clean_lines(text)
    nodes, _, _ = _parse(lines, 0, set())
    return nodes


def _parse(lines: list[str], i: int, stops: set[str]) -> tuple[list, int, str]:
    nodes: list = []
    n = len(lines)
    while i < n:
        line = lines[i]
        if stops and _is_stop(line, stops):
            return nodes, i, line
        if re.match(r"^if\b", line) and not re.search(r";\s*fi\s*$", line):
            node, i = _parse_if(lines, i)
            nodes.append(node)
            continue
        m = _CASE_RE.match(line)
        if m:
            node, i = _parse_case(lines, i + 1, m.group(1))
            nodes.append(node)
            continue
        m = _FUNC_RE.match(line)
        if m:
            i += 1
            if not m.group(2) and i < n and lines[i] == "{":
                i += 1
            body, i, _ = _parse(lines, i, {"}"})
            nodes.append(Func(m.group(1), body))
            i += 1
            continue
        nodes.append(Line(line))
        i += 1
    return nodes, i, ""


def _parse_if(lines: list[str], i: int) -> tuple[If, int]:
    head = re.sub(r"^(if|elif)\s+", "", lines[i])
    cond = re.sub(r";?\s*then\s*$", "", head).strip().rstrip(";").strip()
    i += 1
    if i < len(lines) and lines[i] == "then":
        i += 1
    then, i, stop = _parse(lines, i, {"fi", "else", "elif"})
    orelse: list = []
    if stop.startswith("elif"):
        nested, i = _parse_if(lines, i)  # consumes through the shared `fi`
        return If(cond, then, [nested]), i
    if stop == "else" or stop.startswith("else"):
        orelse, i, _ = _parse(lines, i + 1, {"fi"})
    return If(cond, then, orelse), i + 1


def _parse_case(lines: list[str], i: int, switch: str) -> tuple[Case, int]:
    branches: list[tuple[list[str], list]] = []
    n = len(lines)
    while i < n:
        line = lines[i]
        if re.match(r"^esac\b", line):
            return Case(switch, branches), i + 1
        m = _LABEL_RE.match(line)
        if not m:
            i += 1
            continue
        labels = [lb.strip().strip('"').strip("'") for lb in m.group(1).split("|") if lb.strip()]
        rest = m.group(2).strip()
        if rest:
            lines.insert(i + 1, rest)
        body, i, stop = _parse(lines, i + 1, {";;", "esac"})
        branches.append((labels, body))
        if stop == ";;":
            i += 1
    return Case(switch, branches), i


# ---------------------------------------------------------------------------------------------
# tree -> YAML data
# ---------------------------------------------------------------------------------------------
def translate_value(value: str, known: set[str]) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        value = value[1:-1]

    def repl(m: re.Match) -> str:
        name = m.group(1) or m.group(2)
        if name in VAR_MAP:
            return "${" + VAR_MAP[name] + "}"
        if name in FILE_VARS:
            return "${" + FILE_VARS[name] + "}"
        if name in known:
            return "${" + name + "}"
        if re.fullmatch(r"\d", name):
            return m.group(0)
        return "${env:" + name + ":-}"

    value = re.sub(r"\$\{(\w+)\}|\$([A-Za-z_]\w*)", repl, value)
    # $TSI_TESTS/$TSI_COMPONENT_DIR = the suite's folder in the test tree (t-tests sets both) = ${assets_dir}
    return value.replace("${env:TSI_TESTS:-}/${env:TSI_COMPONENT_DIR:-}", "${assets_dir}")


def _relative_file(value: str, base: str) -> str:
    prefix = "${" + base + "}/"
    return value[len(prefix):] if value.startswith(prefix) else value


@dataclass
class Bucket:
    files: dict[str, str] = field(default_factory=dict)
    vars: dict[str, str] = field(default_factory=dict)
    waits: list[float] = field(default_factory=list)
    gold_by_version: dict[str, str] = field(default_factory=dict)
    seq_vars: dict[int, dict[str, str]] = field(default_factory=dict)
    untranslated: list[str] = field(default_factory=list)
    advance_verify: bool | None = None  # t-testsSetAdvanceVerify true|false (None = not set)


@dataclass(frozen=True)
class Ctx:
    tests: tuple[str, ...] | None = None  # None = every test (suite level)
    versions: frozenset[str] | None = None
    seq: int | None = None


# Values known at import time. Old suites switch on these for the platform / suite name.
# NOTE: the platform constants assume the suites run on Windows (as in t-tests win.cfg).
PLATFORM_CONSTANTS = {"NPORT": "i86-winnt50", "PORT": "i86_winnt50", "OS_PLATFORM": "Windows"}
_CONST_TEST_RE = re.compile(r"^\[\s*\"?\$\{?(\w+)\}?\"?\s*(=|==|!=)\s*\"?([^\"\s\]]*)\"?\s*\]$")


class Translator:
    def __init__(self, tests: list[dict], constants: dict[str, str] | None = None):
        self.constants = {**PLATFORM_CONSTANTS, **(constants or {})}
        self.tests = tests
        self.suite = Bucket()
        self.per_test: dict[str, Bucket] = {t["id"]: Bucket() for t in tests}
        self.funcs: dict[str, Func] = {}
        self.known: set[str] = set()

    # -- targets ---------------------------------------------------------------------------
    def _buckets(self, ctx: Ctx) -> list[Bucket]:
        return [self.suite] if ctx.tests is None else [self.per_test[t] for t in ctx.tests]

    def _untranslated(self, ctx: Ctx, text: str) -> None:
        for b in self._buckets(ctx):
            b.untranslated.append(text)

    def _set(self, ctx: Ctx, kind: str, key: str, value: str) -> None:
        for b in self._buckets(ctx):
            if ctx.versions is not None:
                if kind == "file" and key == "gold":
                    for v in ctx.versions:
                        b.gold_by_version[v] = value
                else:
                    b.untranslated.append(f"[version-specific] {key}={value}")
            elif ctx.seq is not None and kind == "var":
                b.seq_vars.setdefault(ctx.seq, {})[key] = value
            else:
                (b.files if kind == "file" else b.vars)[key] = value
        if ctx.tests is None and ctx.versions is None and ctx.seq is None:
            # a later top-level assignment overrides earlier per-test ones (bash order)
            for b in self.per_test.values():
                (b.files if kind == "file" else b.vars).pop(key, None)

    # -- walking ---------------------------------------------------------------------------
    def walk(self, nodes: list, ctx: Ctx = Ctx()) -> None:
        for node in nodes:
            if isinstance(node, Func):
                self.funcs[node.name] = node
            elif isinstance(node, Line):
                self._line(node.text, ctx)
            elif isinstance(node, Case):
                self._case(node, ctx)
            elif isinstance(node, If):
                self._if(node, ctx)

    def _line(self, line: str, ctx: Ctx) -> None:
        wait = _WAIT_RE.match(line)
        if wait:
            for b in self._buckets(ctx):
                b.waits.append(float(wait.group(1)))
            return
        advance = _ADVANCE_RE.match(line)
        if advance:
            for b in self._buckets(ctx):
                b.advance_verify = advance.group(1).lower() == "true"
            return
        if any(r.match(line) for r in _BOILER_RES):
            return
        parts = line.split()
        if parts and parts[0] in self.funcs:  # inline helper functions, $1.. = arguments
            body = self.funcs[parts[0]].body
            self.walk(_substitute_args(body, parts[1:]), ctx)
            return
        m = _EXPORT_RE.match(line)
        if m:
            name, raw = m.group(1), m.group(2)
            if name in IGNORED_VARS or name.startswith("t_"):
                return
            if "`" in raw or "$(" in raw:
                self._untranslated(ctx, line)
                return
            value = translate_value(raw, self.known)
            self.known.add(name)
            if name in FILE_VARS:
                kind = FILE_VARS[name]
                self._set(ctx, "file", kind, _relative_file(value, "log_dir" if kind == "output" else "case_dir"))
            else:
                self._set(ctx, "var", name, value)
            return
        self._untranslated(ctx, line)

    def _select(self, ctx: Ctx, label: str, taken: set[str]) -> list[str]:
        pool = [t for t in self.tests if ctx.tests is None or t["id"] in ctx.tests]
        if label == "*":
            return [t["id"] for t in pool if t["id"] not in taken]
        lb = label.lower()
        # labels may be the TID (bw.645), the old TSI_TEST_ID (bw_645 - derived from the ID, not the project!)
        # or the BW project name (petstore_sample)
        return [t["id"] for t in pool if t["id"] not in taken and
                (fnmatch.fnmatchcase(t["id"].lower(), lb) or fnmatch.fnmatchcase(t["id"].replace(".", "_").lower(), lb)
                 or fnmatch.fnmatchcase(t["project"].lower(), lb))]

    def _case(self, node: Case, ctx: Ctx) -> None:
        if node.switch in ("TSI_TID", "TSI_TEST_ID", "TSI_REPO_NAME"):
            taken: set[str] = set()
            for labels, body in node.branches:
                selected: list[str] = []
                for label in labels:
                    for tid in self._select(ctx, label, taken | set(selected)):
                        selected.append(tid)
                taken |= set(selected)
                if selected and body:
                    self.walk(body, Ctx(tuple(selected), ctx.versions, ctx.seq))
            return
        if node.switch == "TSI_TEST_SEQUENCE":
            for labels, body in node.branches:
                for label in labels:
                    if label.isdigit():
                        self.walk(body, Ctx(ctx.tests, ctx.versions, int(label)))
            return
        if node.switch in self.constants:  # evaluate now: first matching branch wins (bash semantics)
            value = self.constants[node.switch]
            for labels, body in node.branches:
                if any(fnmatch.fnmatchcase(value, lb) for lb in labels):
                    self.walk(body, ctx)
                    return
            return
        if any(_has_content(b) for _, b in node.branches):
            self._untranslated(ctx, f"case ${{{node.switch}}} in ... esac")

    def _if(self, node: If, ctx: Ctx) -> None:
        cond = node.cond
        if re.search(r"-d\s+\"?\$\{?TIB_BW_HOME\}?/bin", cond):
            return  # version detection - bwtest does this itself
        versions = _VERSION_TEST_RE.findall(cond)
        leftover = _VERSION_TEST_RE.sub("", cond).replace("||", "").strip()
        if versions and not leftover:
            self.walk(node.then, Ctx(ctx.tests, frozenset(versions), ctx.seq))
            if _has_content(node.orelse):
                self._untranslated(ctx, f"else-branch of: if {cond}")
            return
        m = _SEQ_TEST_RE.match(cond)
        if m:
            self.walk(node.then, Ctx(ctx.tests, ctx.versions, int(m.group(1))))
            if _has_content(node.orelse):
                self._untranslated(ctx, f"else-branch of: if {cond}")
            return
        m = _TID_TEST_RE.match(cond)
        if m:
            selected = self._select(ctx, m.group(2), set())
            others = [t["id"] for t in self.tests if (ctx.tests is None or t["id"] in ctx.tests)
                      and t["id"] not in selected]
            if selected:
                self.walk(node.then, Ctx(tuple(selected), ctx.versions, ctx.seq))
            if others and node.orelse:
                self.walk(node.orelse, Ctx(tuple(others), ctx.versions, ctx.seq))
            return
        m = _CONST_TEST_RE.match(cond)
        if m and m.group(1) in self.constants:
            equal = self.constants[m.group(1)] == m.group(3)
            self.walk(node.then if equal == (m.group(2) != "!=") else node.orelse, ctx)
            return
        if _has_content(node.then) or _has_content(node.orelse):
            self._untranslated(ctx, f"if {cond} ... fi")


def _has_content(nodes: list) -> bool:
    for node in nodes:
        if isinstance(node, Line):
            if not any(r.match(node.text) for r in _BOILER_RES):
                return True
        elif isinstance(node, Case):
            if any(_has_content(b) for _, b in node.branches):
                return True
        elif isinstance(node, If) and (_has_content(node.then) or _has_content(node.orelse)):
            return True
    return False


def _substitute_args(nodes: list, args: list[str]) -> list:
    def sub(text: str) -> str:
        for idx, arg in enumerate(args, start=1):
            text = re.sub(rf"\$\{{?{idx}\}}?", arg.strip("\"'"), text)
        return text

    out: list = []
    for node in nodes:
        if isinstance(node, Line):
            out.append(Line(sub(node.text)))
        elif isinstance(node, Case):
            out.append(Case(node.switch, [(lb, _substitute_args(b, args)) for lb, b in node.branches]))
        elif isinstance(node, If):
            out.append(If(sub(node.cond), _substitute_args(node.then, args), _substitute_args(node.orelse, args)))
        else:
            out.append(node)
    return out


# ---------------------------------------------------------------------------------------------
# t_verify.sh -> verify specs
# ---------------------------------------------------------------------------------------------
# Lines that do not influence the comparison (logging, bookkeeping, CR stripping - bwtest normalises CRLF).
_VERIFY_IGNORE = re.compile(
    r"^(#|echo\b|printf\b|[A-Za-z_]\w*=|exit\b|return\b|\.\s|source\b|tu_init\b|t_init\b|t_report|t_set_errcode"
    r"|rm\b|t-stripcr\b|t_stripcr|t_cond_stripcr|cd\b|:|true\b|false\b|fi\b|else\b|then\b|cat\s.*>>?\s*\"?\$\{?TSI_TEST_"
    r"(DIFF|ERROR)_FILE)")
_OUT = re.compile(r"^\"?\$\{?(TSI_TEST_OUTPUT_FILE|TEST_OUTPUT_FILE)\}?\"?$")
_GOLD = re.compile(r"^\"?\$\{?(TSI_TEST_GOLD_FILE|TEST_GOLD_FILE)\}?\"?$")


def _flatten(nodes: list, funcs: dict[str, list] | None = None, depth: int = 0) -> list[str] | None:
    """All command lines of a branch, including both sides of if/else and the bodies of functions defined in
    the same script (`new_verify`, `t_local_init` ...). None if it contains a nested case."""
    funcs = funcs or {}
    lines: list[str] = []
    for node in nodes:
        if isinstance(node, Line):
            text = node.text.strip()
            name = text.split()[0] if text else ""
            if name in funcs and depth < 5:
                sub = _flatten(funcs[name], funcs, depth + 1)
                if sub is None:
                    return None
                lines += sub
            else:
                lines.append(text)
        elif isinstance(node, If):
            for side in (node.then, node.orelse):
                sub = _flatten(side, funcs, depth)
                if sub is None:
                    return None
                lines += sub
        elif isinstance(node, Case):
            return None
    return [ln for ln in lines if ln]


def _operands(cmd: str) -> list[str]:
    words = cmd.split(">")[0].replace("2>&1", "").split()
    return [w for w in words[1:] if not w.startswith("-")]


def _verify_from_nodes(nodes: list, funcs: dict[str, list] | None = None) -> dict | None:
    """Recognised comparison of one t_verify.sh branch as a bwtest verify spec, or None (keep old script)."""
    lines = _flatten(nodes, funcs)
    if lines is None:
        return None
    spec: dict | None = None
    sorted_from: dict[str, str] = {}  # temp file -> original (sort GOLD -o f1.txt)
    for ln in lines:
        if _VERIFY_IGNORE.match(ln):
            continue
        if re.match(r"sort\b", ln):
            ops = _operands(ln.replace(" -o ", " > "))
            target = re.search(r"(?:-o\s+|>\s*)(\S+)", ln)
            if not ops or not target:
                return None
            sorted_from[target.group(1)] = ops[0]
            continue
        diff = re.match(r"(t-xmldiff|t-testsDefaultDiff|diff)\b", ln)
        if not diff:
            return None  # any other command (java, grep, cmp, custom function ...) - not translated
        ops = [sorted_from.get(o, o) for o in _operands(ln)][:2]
        if len(ops) != 2 or not (any(_OUT.match(o) for o in ops) and any(_GOLD.match(o) for o in ops)):
            return None  # compares other files than output vs gold
        if spec is not None:
            return None  # several comparisons in one branch - keep the script
        if diff.group(1) == "t-xmldiff":
            spec = {"type": "xml"}
        else:
            spec = {"type": "text"}
            flags = "".join(w.lstrip("-") for w in ln.split() if w.startswith("-") and not w.startswith("--"))
            if "b" in flags or "w" in flags:
                spec["ignore_whitespace"] = True
            if "i" in flags:
                spec["ignore_case"] = True
            if any(o in sorted_from for o in _operands(ln)):
                spec["sort_lines"] = True
    return spec


def _verify_plan(nodes: list, tests: list[dict]) -> tuple[dict | None, dict[str, dict], set[str]]:
    """(suite default, {test id: own spec}, {test ids that keep the old script})"""
    funcs = {n.name: n.body for n in nodes if isinstance(n, Func)}
    cases = [n for n in nodes if isinstance(n, Case) and n.switch in ("TSI_TID", "TSI_TEST_ID")]
    if not cases:
        body = [n for n in nodes if not (isinstance(n, If) and "t_util" in n.cond) and not isinstance(n, Func)]
        return _verify_from_nodes(body, funcs), {}, set()
    tr = Translator(tests)
    default: dict | None = {"type": "text"}
    per_test: dict[str, dict] = {}
    legacy: set[str] = set()
    taken: set[str] = set()
    for labels, body in cases[0].branches:
        spec = _verify_from_nodes(body, funcs)
        if "*" in labels:
            default = spec
            continue
        for label in labels:
            for tid in tr._select(Ctx(), label, taken):
                taken.add(tid)
                if spec is None:
                    legacy.add(tid)
                else:
                    per_test[tid] = spec
    return default, per_test, legacy


# ---------------------------------------------------------------------------------------------
# suite import
# ---------------------------------------------------------------------------------------------
@dataclass
class ImportResult:
    suite_name: str
    source: Path
    target: Path
    tests: int
    bridged_suite: list[str]
    bridged_tests: dict[str, list[str]]
    notes: list[str]


def _translate_script(path: Path, tests: list[dict], suite_name: str) -> Translator | None:
    if not path.is_file():
        return None
    tr = Translator(tests, {"TSI_COMPONENT": suite_name})
    tr.walk(parse_script(read_text(path)))
    return tr


def import_testset(testset: Path, out_root: Path, assets_root: Path | None = None,
                   driver_map: dict[str, list[str]] | None = None,
                   db_map: dict[str, list[str]] | None = None, target: Path | None = None) -> ImportResult:
    """target: write here instead of <out_root>/<category>/<t-tests folder> (re-import of a suite that was moved)."""
    testset = testset.resolve()
    suite_dir = testset.parent
    name = testset.stem
    data = parse_testset(testset)
    tests = data["tests"]
    notes: list[str] = []
    bridged_suite: list[str] = []
    bridged_tests: dict[str, list[str]] = {}

    parts = suite_dir.parts
    category = "migration" if "migration" in parts else "engine"
    rel_dir = Path(*parts[parts.index(category) + 1:]) if category in parts else Path(name)
    if assets_root and str(suite_dir).lower().startswith(str(Path(assets_root).resolve()).lower()):
        assets_dir = "${assets_root}/" + suite_dir.relative_to(Path(assets_root).resolve()).as_posix()
    else:
        assets_dir = suite_dir.as_posix()

    suite: dict = {"suite": name}
    if category == "migration":
        suite["type"] = "bw_migration"
    if data["owner"]:
        suite["owner"] = data["owner"]
    suite["description"] = data["description"] or f"Imported from {testset.name}"
    suite["assets_dir"] = assets_dir
    suite["tags"] = sorted({category, re.split(r"[_.-]", name)[0].lower()})

    cfgs = [p for p in (suite_dir / f"{name}.cfg",) if p.is_file()]
    if not cfgs:
        all_cfg = sorted(suite_dir.glob("*.cfg"))
        if len(all_cfg) == 1:
            cfgs = all_cfg
        elif all_cfg:
            notes.append(f"several .cfg files ({', '.join(p.name for p in all_cfg)}), none named {name}.cfg - "
                         f"add the right one(s) to client_vars_files")
    if cfgs:
        suite["client_vars_files"] = [p.name for p in cfgs]
    if (suite_dir / f"{name}.ini").is_file():
        suite["appspace_config_ini"] = f"{name}.ini"
    for key, mapping in (("drivers", driver_map or {}), ("databases", db_map or {})):
        needed = [n for n, suites in mapping.items() if name in suites]
        if needed:
            suite[key] = needed

    setup = _translate_script(suite_dir / "t_setup.sh", tests, name)
    action = _translate_script(suite_dir / "t_action.sh", tests, name)

    defaults: dict = {}
    suite_vars: dict = {}
    if setup:
        defaults.update(setup.suite.files)
        suite_vars.update(setup.suite.vars)
        if setup.suite.gold_by_version:
            defaults["gold_by_version"] = setup.suite.gold_by_version
        if setup.suite.untranslated:
            bridged_suite.append("setup")
            suite.setdefault("legacy", {})["setup"] = "t_setup.sh"
            notes.append("t_setup.sh (all tests) still runs through the legacy bridge because of: "
                         + " | ".join(setup.suite.untranslated[:5]))
    # t-testsSetAdvanceVerify true: t-tests stops waiting as soon as output >= gold size (else after the action)
    advance_suite = bool(setup and setup.suite.advance_verify)
    suite_waits = action.suite.waits if action else []
    if action:
        if suite_waits:
            defaults["action"] = _wait_steps(suite_waits, advance_suite)
        if action.suite.untranslated:
            bridged_suite.append("action")
            suite.setdefault("legacy", {})["action"] = "t_action.sh"
            notes.append("t_action.sh (all tests) still runs through the legacy bridge because of: "
                         + " | ".join(action.suite.untranslated[:5]))

    # t_verify.sh: converted branch by branch. The `*)` branch (or the script without a case) gives the suite
    # default; every test-specific branch becomes that test's own verify spec. Only branches doing something
    # not recognisable (custom java/grep checks ...) keep running the old script through the bridge.
    verify_path = suite_dir / "t_verify.sh"
    verify_default, verify_per_test, verify_legacy = (
        _verify_plan(parse_script(read_text(verify_path)), tests) if verify_path.is_file()
        else ({"type": "text"}, {}, set()))
    if verify_default is None:  # the default branch itself is not recognisable
        suite.setdefault("legacy", {})["verify"] = "t_verify.sh"
        notes.append("t_verify.sh default branch still runs through the legacy bridge")
    elif verify_default != {"type": "text"}:
        defaults["verify"] = verify_default

    out_tests = []
    default_output = defaults.get("output", "${id}_output.log")
    for t in tests:
        tid = t["id"]
        entry: dict = {"id": tid}
        if t["project"] != tid.replace(".", "_"):
            entry["project"] = t["project"]
        if t["description"]:
            entry["description"] = t["description"]
        if t["disabled"]:
            entry["skip"] = "disabled in legacy testset (# before the ID)"
        if t["known_to_fail"]:
            entry["known_to_fail"] = "KnownToFail=true in legacy testset"
        if t["sequences"] > 1:
            entry["sequences"] = t["sequences"]

        sb = setup.per_test[tid] if setup else Bucket()
        ab = action.per_test[tid] if action else Bucket()
        for key in ("output", "gold", "input"):
            if key in sb.files and sb.files[key] != defaults.get(key):
                entry[key] = sb.files[key]
        if Path(entry.get("output", default_output)).suffix.lower() in BINARY_EXT:
            entry["verify"] = "binary"
        if sb.gold_by_version:
            entry["gold_by_version"] = dict(sorted(sb.gold_by_version.items()))
        if sb.vars:
            entry["vars"] = sb.vars
        seq_vars = {**(setup.suite.seq_vars if setup else {})}
        for seq, values in sb.seq_vars.items():
            seq_vars[seq] = {**seq_vars.get(seq, {}), **values}
        if seq_vars:
            if t["sequences"] > 1:
                entry["sequence_vars"] = {k: seq_vars[k] for k in sorted(seq_vars) if k <= t["sequences"]}
            elif 1 in seq_vars:
                entry["vars"] = {**seq_vars[1], **entry.get("vars", {})}
        advance = sb.advance_verify if sb.advance_verify is not None else advance_suite
        if ab.waits or advance != advance_suite:
            # bash order: the test's own `t_sleep` (inside the case) AND the common ones outside it both run
            entry["action"] = _wait_steps([*ab.waits, *suite_waits], advance)

        legacy: dict = {}
        if sb.untranslated and "setup" not in bridged_suite:
            legacy["setup"] = "t_setup.sh"
            bridged_tests.setdefault(tid, []).append("setup: " + " | ".join(sb.untranslated[:3]))
        if ab.untranslated and "action" not in bridged_suite:
            legacy["action"] = "t_action.sh"
            bridged_tests.setdefault(tid, []).append("action: " + " | ".join(ab.untranslated[:3]))
        if tid in verify_legacy and "verify" not in suite.get("legacy", {}):
            legacy["verify"] = "t_verify.sh"
            bridged_tests.setdefault(tid, []).append("verify: test-specific branch in t_verify.sh")
        elif tid in verify_per_test and verify_per_test[tid] != (verify_default or {"type": "text"}) \
                and "verify" not in entry:
            spec = verify_per_test[tid]
            entry["verify"] = spec["type"] if list(spec) == ["type"] else spec
        for script_key, default_name in (("setup", "t_setup.sh"), ("action", "t_action.sh"),
                                         ("verify", "t_verify.sh")):
            custom = t[script_key]
            if custom and custom != default_name:
                legacy[script_key] = custom
                bridged_tests.setdefault(tid, []).append(f"{script_key}: custom script {custom}")
        if legacy:
            entry["legacy"] = legacy
        if not t["disabled"] and not (suite_dir / tid).is_dir():
            entry["notes"] = f"case folder {tid} not found in {suite_dir.name}"
        out_tests.append(entry)

    if suite_vars:
        suite["vars"] = suite_vars
    if defaults:
        suite["defaults"] = defaults
    if notes:
        suite["notes"] = "\n".join(notes)
    suite["tests"] = out_tests

    target = target or out_root / category / placement(Path(out_root) / category, rel_dir, name) / f"{name}.suite.yaml"
    target.parent.mkdir(parents=True, exist_ok=True)
    header = (f"# Imported from {testset.as_posix()}\n"
              f"# by `bwtest import`. Review `notes:` and `legacy:` entries, then edit freely.\n")
    target.write_text(header + _dump(suite), encoding="utf-8")
    return ImportResult(name, testset, target, len(out_tests), bridged_suite, bridged_tests, notes)


class _Dumper(yaml.SafeDumper):
    pass


def _str_presenter(dumper, value):
    return dumper.represent_scalar("tag:yaml.org,2002:str", value, style="|" if "\n" in value else None)


_Dumper.add_representer(str, _str_presenter)


def _dump(data: dict) -> str:
    return yaml.dump(data, Dumper=_Dumper, sort_keys=False, allow_unicode=True, width=110,
                     default_flow_style=False, indent=2)


def import_tree(legacy_root: Path, out_root: Path, assets_root: Path | None = None,
                driver_map=None, db_map=None) -> list:
    results: list = []
    for testset in sorted(Path(legacy_root).rglob("*.testset")):
        try:
            results.append(import_testset(testset, out_root, assets_root, driver_map, db_map))
        except Exception as exc:  # report and continue with the other suites
            results.append((testset, f"{type(exc).__name__}: {exc}"))
    return results


_AREA_ALIAS = {"https": "http"}
_DB_ALIAS = {"postgresql": "postgres", "ora19c": "oracle", "ora21c": "oracle", "ora23c": "oracle"}


def placement(category_dir: Path, rel_dir: Path, name: str) -> Path:
    """Folder (below suites/<category>) for a newly imported suite, grouped like the existing suites:

        func/engine/jdbc/jdbc_oracle_xyz/  -> jdbc/oracle            (one folder per database)
        func/engine/http_URLencoded/       -> http/http_URLencoded   (when suites/engine/http/ exists)
        anything else                      -> the t-tests folder, as before
    """
    parts = rel_dir.parts
    if len(parts) >= 2 and parts[0].lower() == "jdbc":
        db = parts[1].lower().removeprefix("jdbc_").split("_")[0]
        return Path(parts[0], _DB_ALIAS.get(db, db))
    area = re.split(r"[_.-]", name)[0].lower()
    area = _AREA_ALIAS.get(area, area)
    group = next((d for d in category_dir.iterdir() if d.is_dir() and d.name.lower() == area), None) \
        if category_dir.is_dir() else None
    if group is not None and (not parts or parts[0].lower() != group.name.lower()) and area != name.lower():
        return Path(group.name, *parts)
    return rel_dir


def import_new(source: Path, out_root: Path, assets_root: Path | None = None,
               driver_map=None, db_map=None, overwrite: bool = False) -> tuple[list, list[tuple[Path, Path]]]:
    """Import a .testset or every .testset under a folder, skipping suites already in out_root (same name anywhere).

    Returns (results, skipped). results: ImportResult or (testset, error). skipped: (testset, existing suite file).
    With overwrite=True existing suites are re-imported into their current file (a moved suite stays where it is).
    """
    source = Path(source)
    testsets = [source] if source.is_file() else sorted(source.rglob("*.testset"))
    suite_files = sorted(Path(out_root).rglob("*.suite.yaml")) if Path(out_root).is_dir() else []
    existing = {f.name.removesuffix(".suite.yaml").lower(): f for f in suite_files}
    results: list = []
    skipped: list[tuple[Path, Path]] = []
    for testset in testsets:
        known = existing.get(testset.stem.lower())
        if known and not overwrite:
            skipped.append((testset, known))
            continue
        try:
            result = import_testset(testset, out_root, assets_root, driver_map, db_map, target=known)
            existing[testset.stem.lower()] = result.target  # same name twice in the source: import once
            results.append(result)
        except Exception as exc:  # report and continue with the other suites
            results.append((testset, f"{type(exc).__name__}: {exc}"))
    return results, skipped


def report_path(out_root: Path, skipped: list) -> Path:
    """Full import -> IMPORT_REPORT.md; adding suites to an existing set -> its own dated report (keeps the first)."""
    import time

    name = "IMPORT_REPORT.md" if not skipped else f"IMPORT_REPORT-{time.strftime('%Y%m%d-%H%M%S')}.md"
    return Path(out_root) / name


def write_report(results: list, path: Path) -> None:
    ok = [r for r in results if isinstance(r, ImportResult)]
    failed = [r for r in results if not isinstance(r, ImportResult)]
    native = [r for r in ok if not r.bridged_suite and not r.bridged_tests]
    total = sum(r.tests for r in ok)
    bridged = sum(r.tests if r.bridged_suite else len(r.bridged_tests) for r in ok)
    lines = [
        "# Import report: t-tests 4.0 -> bwtest", "",
        f"* suites imported: **{len(ok)}**  ({total} test cases)",
        f"* suites fully native (no legacy bridge): **{len(native)}**",
        f"* test cases fully native: **{total - bridged}**  /  via legacy bridge: **{bridged}**",
        f"* failed to import: **{len(failed)}**", "",
        "*Legacy bridge* = that part still runs the original bash script (via Git Bash). The test works; "
        "rewrite the listed command as a YAML step when convenient (docs/WRITING_TESTS.md).", "",
    ]
    for r in sorted(ok, key=lambda r: (bool(r.bridged_suite), len(r.bridged_tests), r.suite_name)):
        lines.append(f"## {r.suite_name}  ({r.tests} tests)")
        lines.append(f"* source: `{r.source.as_posix()}`")
        lines.append(f"* suite file: `{r.target.as_posix()}`")
        for note in r.notes:
            lines.append(f"* {note}")
        for tid, reasons in sorted(r.bridged_tests.items())[:40]:
            lines.append(f"* `{tid}` bridged - " + "; ".join(reasons))
        if len(r.bridged_tests) > 40:
            lines.append(f"* ... {len(r.bridged_tests) - 40} more bridged tests")
        lines.append("")
    if failed:
        lines.append("## Failed")
        lines += [f"* `{p.as_posix()}`: {err}" for p, err in failed]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
