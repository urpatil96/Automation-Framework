"""Legacy bridge: run old t-tests bash scripts (t_setup.sh / t_action.sh / t_verify.sh) unchanged.

Use it while migrating complex suites: the suite runs in bwtest (new lifecycle, reports, parallel)
but keeps its old script logic until someone rewrites it as YAML steps.

    legacy:                 # suite level - applies to every test
      setup: t_setup.sh     # sourced; every variable it exports becomes a test variable
    tests:
      - id: bw.617
        legacy: {action: t_action.sh}

Needs bash: Git Bash on Windows (auto-detected) or paths.bash in config.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

from ..bwcli import NO_CONSOLE
from ..errors import ConfigError

SHIM_DIR = Path(__file__).parent


@dataclass
class ScriptResult:
    returncode: int
    output: str
    exported: dict[str, str]


def find_bash(configured: str = "") -> str:
    if configured:
        if Path(configured).is_file() or shutil.which(configured):
            return configured
        raise ConfigError(f"paths.bash = {configured} does not exist. Fix it in config/local.yaml, or remove it "
                          "to find Git Bash automatically")
    if os.name == "nt":
        for candidate in (
            r"C:\Program Files\Git\bin\bash.exe",
            r"C:\Program Files (x86)\Git\bin\bash.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Programs\Git\bin\bash.exe"),
        ):
            if Path(candidate).is_file():
                return candidate
        found = shutil.which("bash")
        # C:\Windows\System32\bash.exe is WSL - it cannot see Windows env vars / paths the same way.
        if found and "system32" not in found.lower():
            return found
        raise ConfigError("Git Bash not found. Install Git for Windows or set paths.bash in config/local.yaml")
    found = shutil.which("bash")
    if not found:
        raise ConfigError("bash not found on PATH")
    return found


def console_python() -> str:
    """python.exe next to the running interpreter (also when running under pythonw.exe)."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe" and exe.with_name("python.exe").is_file():
        return str(exe.with_name("python.exe"))
    return str(exe)


def _posix(path: str | Path) -> str:
    return str(path).replace("\\", "/")


def run_script(script: Path, env: dict[str, str], *, bash: str, cwd: Path, timeout: int = 900,
               capture_exports: bool = False) -> ScriptResult:
    """Run `script` with the TSI_* environment. If capture_exports, also return the variables it
    exported (only new or changed ones)."""
    if not script.is_file():
        raise ConfigError(f"Legacy script not found: {script}")
    env = {**os.environ, **env, "TSI_SCRIPTS": _posix(SHIM_DIR),
           "BWTEST_PYTHON": _posix(console_python())}  # used by the shim's t-xmldiff
    with tempfile.TemporaryDirectory() as tmp:
        dump = Path(tmp) / "env.out"
        wrapper = (
            f"trap 'env -0 > \"{_posix(dump)}\"' EXIT\n"
            f". \"{_posix(SHIM_DIR / 't_util.sh')}\"\n"
            f"cd \"{_posix(cwd)}\"\n"
            f". \"{_posix(script)}\"\n"
        ) if capture_exports else (
            f"cd \"{_posix(cwd)}\"\n"
            f". \"{_posix(SHIM_DIR / 't_util.sh')}\"\n"
            f". \"{_posix(script)}\"\n"  # sourced so shim functions (t_sleep ...) are visible
        )
        proc = subprocess.run([bash, "-c", wrapper], env=env, capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=timeout, check=False, **NO_CONSOLE)
        exported: dict[str, str] = {}
        if capture_exports and dump.is_file():
            env_upper = {k.upper() for k in env}
            for item in dump.read_text(encoding="utf-8", errors="replace").split("\0"):
                key, sep, value = item.partition("=")
                if not sep or not key or env.get(key) == value:
                    continue
                # Bash/MSYS rewrite PATH, TEMP ... - keep only variables the script itself created
                # or test variables it changed.
                is_new = key.upper() not in env_upper
                if (is_new or key.startswith(("TSI_", "TEST_"))) and not key.startswith(("BASH", "_")) \
                        and key not in ("SHLVL", "PWD", "OLDPWD", "TSI_EXIT_CODE"):
                    exported[key] = value
    return ScriptResult(proc.returncode, (proc.stdout or "") + (proc.stderr or ""), exported)
