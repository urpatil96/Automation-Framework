"""Unit tests: templating, config, substvar, verifiers, gold resolution, version parsing."""

import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from bwtest.bwcli import parse_version
from bwtest.config import load_settings
from bwtest.errors import ConfigError, VerificationFailed
from bwtest.models import load_suite
from bwtest.substvar import build_profile, parse_properties, split_cfg
from bwtest.templating import render
from bwtest.verify import resolve_gold, run_verifications


# ---------------------------------------------------------------- templating
def test_render_vars_env_and_escape(monkeypatch):
    monkeypatch.setenv("BWT_X", "secret")
    assert render("${id}_gold.log", {"id": "bw_1"}) == "bw_1_gold.log"
    assert render("${var.HOST}", {"var": {"HOST": "h"}}) == "h"
    assert render("${env:BWT_X}") == "secret"
    assert render("${env:BWT_MISSING:-dflt}") == "dflt"
    assert render("$${literal}") == "${literal}"
    with pytest.raises(ConfigError):
        render("${nope}", {})
    assert render("${nope}", {}, strict=False) == "${nope}"


# ---------------------------------------------------------------- config
def _config(tmp_path: Path, text: str, profile: str | None = None) -> Path:
    cfg = tmp_path / "config"
    (cfg / "profiles").mkdir(parents=True)
    (cfg / "bwtest.yaml").write_text(text)
    if profile:
        (cfg / "profiles" / "6.13.0.yaml").write_text(profile)
    return cfg


def test_config_layers_profile_env(tmp_path, monkeypatch):
    cfg = _config(tmp_path, "bw: {home: C:/a}\npaths: {assets_root: assets}\n", "bw: {home: C:/b}\n")
    assert load_settings(cfg).bw.home == Path("C:/a")
    assert load_settings(cfg, "6.13.0").bw.home == Path("C:/b")
    monkeypatch.setenv("BWTEST__BW__HOME", "C:/c")
    s = load_settings(cfg, "6.13.0")
    assert s.bw.home == Path("C:/c")
    assert s.paths.assets_root == (tmp_path / "assets").resolve()  # relative -> project root


def test_config_unknown_key_and_profile(tmp_path):
    with pytest.raises(ConfigError, match="unknown key"):
        load_settings(_config(tmp_path, "bw: {hom: x}\n"))
    with pytest.raises(ConfigError, match="Profile"):
        load_settings(_config(tmp_path / "2", "{}\n"), "9.9.9")


def test_database_secret_is_lazy(tmp_path):
    cfg = _config(tmp_path, "{}\n")
    (cfg / "databases.yaml").write_text("_anchor: &x 1\ndb1: {password: '${env:NOT_SET_ANYWHERE}'}\n")
    s = load_settings(cfg)  # must not fail although the secret is missing
    assert s.databases["db1"].password == "${env:NOT_SET_ANYWHERE}"
    assert "_anchor" not in s.databases


# ---------------------------------------------------------------- cfg / substvar
def test_properties_and_client_vars():
    props = parse_properties(
        '# c\napp.clientVar.HOST=10.0.0.1\napp.clientVar.Q="a=b"\nbw.plugin.x: true\nlong=a\\\n  b\n')
    client, engine = split_cfg(props)
    assert client == {"HOST": "10.0.0.1", "Q": '"a=b"'}
    assert engine == {"bw.plugin.x": "true", "long": "ab"}


def test_build_profile_overrides_matching_names():
    from tests.conftest import SUBSTVAR

    xml, applied, unset = build_profile(SUBSTVAR.format(p="bw_1").encode(), {"TSI_TEST_OUTPUT_FILE": "o.log"})
    assert applied == {"TSI_TEST_OUTPUT_FILE": "o.log"}
    assert unset == ["HOST_NAME"]
    assert b"o.log" in xml and b"default" in xml


# ---------------------------------------------------------------- verifiers
class Ctx(SimpleNamespace):
    update_gold = False

    def render(self, text):
        return text

    def write_artifact(self, name, text, append=False):
        self.artifacts[name] = text

    def appnode_log_slice(self):
        return self.log


def _ctx(tmp_path, output: str | bytes, gold: str | bytes, log: str = "") -> Ctx:
    out, gld = tmp_path / "out.txt", tmp_path / "gold.txt"
    for path, data in ((out, output), (gld, gold)):
        path.write_bytes(data if isinstance(data, bytes) else data.encode())
    return Ctx(output_file=out, gold_file=gld, artifacts={}, log=log)


def test_text_pass_with_crlf_and_fail_with_diff(tmp_path):
    run_verifications("text", _ctx(tmp_path, "a\r\nb\r\n", "a\nb\n"))
    ctx = _ctx(tmp_path, "a\nX\n", "a\nb\n")
    with pytest.raises(VerificationFailed) as exc:
        run_verifications({"type": "text"}, ctx)
    assert "-b" in exc.value.details and "+X" in exc.value.details
    assert "diff.txt" in ctx.artifacts


def test_text_options(tmp_path):
    spec = {"type": "text", "sort_lines": True, "ignore_whitespace": True,
            "ignore_lines": ["^Date:"], "masks": [{"pattern": r"id=\d+", "replace": "id=N"}]}
    run_verifications(spec, _ctx(tmp_path, "b  2\nDate: today\na id=7\n", "a id=1\nb 2\nDate: x\n"))


def test_xml_json_binary_contains_log(tmp_path):
    run_verifications("xml", _ctx(tmp_path, '<a y="2" x="1"><b>t</b></a>', '<a x="1" y="2">\n <b>t</b>\n</a>'))
    with pytest.raises(VerificationFailed):
        run_verifications("xml", _ctx(tmp_path, "<a><b>t</b></a>", "<a><b>u</b></a>"))
    run_verifications({"type": "json", "ignore_keys": ["ts"]},
                      _ctx(tmp_path, json.dumps({"a": 1, "ts": 5}), json.dumps({"ts": 9, "a": 1})))
    with pytest.raises(VerificationFailed):
        run_verifications("binary", _ctx(tmp_path, b"\x00\x01", b"\x00\x02"))
    run_verifications({"type": "contains", "patterns": ["hel+o"], "absent": ["ERROR"]},
                      _ctx(tmp_path, "hello", ""))
    with pytest.raises(VerificationFailed, match="forbidden"):
        run_verifications({"type": "log", "absent": [r"BW-\S+-5\d{5}"]},
                          _ctx(tmp_path, "", "", log="BW-PALETTE-500001 boom"))


def test_missing_output_message(tmp_path):
    ctx = _ctx(tmp_path, "", "x")
    ctx.output_file.unlink()
    with pytest.raises(VerificationFailed, match="output file not found"):
        run_verifications("text", ctx)


def test_version_specific_gold(tmp_path):
    gold = tmp_path / "bw_1_gold.log"
    gold.write_text("g")
    assert resolve_gold(gold, "6121").path == gold
    (tmp_path / "bw_1_gold_6121.log").write_text("v")
    info = resolve_gold(gold, "6121")
    assert info.version_specific and info.path.name == "bw_1_gold_6121.log"


def test_parse_version_banner():
    v = parse_version("ActiveMatrix BusinessWorks version 6.12.1, build V12, 2026-10-28")
    assert (v.dotted, v.build, v.three_digit) == ("6.12.1", "V12", "6121")
    assert (v.hotfix, str(v)) == (0, "6.12.1 build V12")


def test_parse_version_banner_hotfix_build():
    # real banner of C:/D/6.12.0/GA_3 (hotfix builds add ", hotfix N")
    v = parse_version("ActiveMatrix BusinessWorks version 6.12.0, hotfix 5, build V188, 2026-11-06\n"
                      "Command not found: version")
    assert (v.dotted, v.hotfix, v.build, v.three_digit) == ("6.12.0", 5, "V188", "6120")
    assert str(v) == "6.12.0 HF5 build V188"


# ---------------------------------------------------------------- suite model
def test_suite_defaults_and_validation(tmp_path):
    f = tmp_path / "s.suite.yaml"
    f.write_text("suite: s\ndefaults: {output: '${id}.txt', vars: {A: '1'}}\n"
                 "tests:\n - bw.1\n - {id: bw.2, vars: {B: '2'}, known_to_fail: BUG-1, sequences: 3}\n")
    s = load_suite(f)
    t1, t2 = s.tests
    assert (t1.project, t1.output, t1.vars) == ("bw_1", "${id}.txt", {"A": "1"})
    assert (t2.vars, t2.known_to_fail, t2.sequences) == ({"A": "1", "B": "2"}, "BUG-1", 3)
    f.write_text("suite: s\ntests: [{id: bw.1, oops: 1}]\n")
    with pytest.raises(ConfigError, match="oops"):
        load_suite(f)
