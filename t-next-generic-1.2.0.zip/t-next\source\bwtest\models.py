"""Suite and test-case definitions (`*.suite.yaml`).

Replaces: <suite>.testset XML + the per-test `case` blocks of t_setup.sh / t_action.sh +
          <suite>.cfg + the per-suite `case ${TSI_COMPONENT}` blocks inside BW_ENGINE.sh.

Example (minimal):

    suite: http_components
    assets_dir: ${assets_root}/func/engine/http_components
    client_vars_files: [http_components.cfg]
    tests:
      - id: bw.645
        description: Simple HTTP request, ASCII response
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .errors import ConfigError
from .templating import render

SUITE_GLOB = "*.suite.yaml"

_SUITE_KEYS = {
    "suite", "type", "owner", "description", "assets_dir", "tags", "client_vars_files", "vars",
    "appnode_properties", "appspace_config_ini", "drivers", "databases", "defaults", "tests", "legacy",
    "migration", "notes", "enabled",
}
_TEST_KEYS = {
    "id", "project", "description", "tags", "known_to_fail", "skip", "output", "gold", "input", "ear",
    "case_dir", "action", "verify", "vars", "legacy", "timeout", "notes", "app_name", "gold_by_version",
    "sequences", "sequence_vars",
}

DEFAULT_TEST = {
    "output": "${id}_output.log",
    "gold": "${id}_gold.log",
    "input": "${id}_input.log",
    "ear": "${project}.application.ear",
    "verify": {"type": "text"},
}


@dataclass
class TestSpec:
    id: str  # legacy TID, e.g. "bw.645"
    project: str  # BW project / TSI_TEST_ID, e.g. "bw_645"
    description: str = ""
    tags: list[str] = field(default_factory=list)
    known_to_fail: str | None = None  # reason / Jira key. Reported as xfail.
    skip: str | None = None
    output: str = DEFAULT_TEST["output"]  # relative to the test's results dir
    gold: str = DEFAULT_TEST["gold"]  # relative to case_dir
    input: str = DEFAULT_TEST["input"]  # relative to case_dir
    ear: str = DEFAULT_TEST["ear"]  # relative to case_dir
    case_dir: str = "${assets_dir}/${tid}"
    app_name: str = "${project}.application"
    action: list[Any] = field(default_factory=list)
    verify: Any = field(default_factory=lambda: dict(DEFAULT_TEST["verify"]))
    vars: dict[str, str] = field(default_factory=dict)
    legacy: dict[str, str] = field(default_factory=dict)  # {setup|action|verify: script} via bash bridge
    timeout: int | None = None
    notes: str = ""
    # {"681": "${id}_gold_681.txt"} - gold file for specific BW versions (3-digit, like TSI_PROD_VERSION_3DIGIT)
    gold_by_version: dict[str, str] = field(default_factory=dict)
    # old TestSequence: run the test N times; ${seq} = 1..N; extra vars per sequence
    sequences: int = 1
    sequence_vars: dict[int, dict[str, str]] = field(default_factory=dict)

    @property
    def safe_id(self) -> str:
        return self.id.replace("/", "_")

    @property
    def test_id(self) -> str:
        """Old TSI_TEST_ID: the ID with '.' -> '_' (bw.6983 -> bw_6983), independent of the project name."""
        return self.id.replace(".", "_").replace("/", "_")


@dataclass
class SuiteSpec:
    name: str  # old TSI_COMPONENT (= AppSpace / AppNode name)
    file: Path
    type: str = "bw_engine"  # bw_engine | bw_migration
    owner: str = ""
    description: str = ""
    assets_dir: Path = Path(".")
    tags: list[str] = field(default_factory=list)
    client_vars_files: list[Path] = field(default_factory=list)
    vars: dict[str, str] = field(default_factory=dict)
    appnode_properties: dict[str, str] = field(default_factory=dict)
    appspace_config_ini: Path | None = None
    drivers: list[str] = field(default_factory=list)
    databases: list[str] = field(default_factory=list)
    legacy: dict[str, str] = field(default_factory=dict)
    migration: dict[str, Any] = field(default_factory=dict)
    notes: str = ""
    enabled: bool = True
    tests: list[TestSpec] = field(default_factory=list)


def _as_list(value: Any) -> list:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _str_dict(value: Any, where: str) -> dict[str, str]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ConfigError(f"{where} must be a mapping")
    return {str(k): "" if v is None else str(v).lower() if isinstance(v, bool) else str(v)
            for k, v in value.items()}


def _kfail(value: Any) -> str | None:
    if value in (None, False, "", "false", "False"):
        return None
    return "known to fail" if value is True else str(value)


def load_suite(path: Path, assets_root: Path | str = "") -> SuiteSpec:
    path = Path(path).resolve()
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise ConfigError(f"{path}: invalid YAML: {exc}") from exc
    if not isinstance(raw, dict):
        raise ConfigError(f"{path}: top level must be a mapping")
    unknown = set(raw) - _SUITE_KEYS
    if unknown:
        raise ConfigError(f"{path}: unknown suite key(s) {sorted(unknown)}")
    if not raw.get("suite"):
        raise ConfigError(f"{path}: 'suite' (the suite name) is required")

    base_vars = {"assets_root": str(assets_root).replace("\\", "/"), "suite_file_dir": path.parent.as_posix(),
                 "suite": raw["suite"]}
    assets_dir = Path(render(str(raw.get("assets_dir") or path.parent), base_vars))
    if not assets_dir.is_absolute():
        assets_dir = (path.parent / assets_dir).resolve()
    suite_vars = {**base_vars, "assets_dir": assets_dir.as_posix(), "suite_dir": assets_dir.as_posix()}

    def resolve(p: str) -> Path:
        q = Path(render(str(p), suite_vars))
        return q if q.is_absolute() else (assets_dir / q)

    suite = SuiteSpec(
        name=str(raw["suite"]),
        file=path,
        type=str(raw.get("type", "bw_engine")),
        owner=str(raw.get("owner", "") or ""),
        description=str(raw.get("description", "") or ""),
        assets_dir=assets_dir,
        tags=[str(t) for t in _as_list(raw.get("tags"))],
        client_vars_files=[resolve(p) for p in _as_list(raw.get("client_vars_files"))],
        vars=_str_dict(raw.get("vars"), f"{path}: vars"),
        appnode_properties=_str_dict(raw.get("appnode_properties"), f"{path}: appnode_properties"),
        appspace_config_ini=resolve(raw["appspace_config_ini"]) if raw.get("appspace_config_ini") else None,
        drivers=[str(d) for d in _as_list(raw.get("drivers"))],
        databases=[str(d) for d in _as_list(raw.get("databases"))],
        legacy=_str_dict(raw.get("legacy"), f"{path}: legacy"),
        migration=dict(raw.get("migration") or {}),
        notes=str(raw.get("notes", "") or ""),
        enabled=bool(raw.get("enabled", True)),
    )
    if suite.type not in ("bw_engine", "bw_migration"):
        raise ConfigError(f"{path}: type must be bw_engine or bw_migration, not '{suite.type}'")

    defaults = dict(raw.get("defaults") or {})
    unknown = set(defaults) - _TEST_KEYS
    if unknown:
        raise ConfigError(f"{path}: unknown key(s) in defaults: {sorted(unknown)}")

    seen: set[str] = set()
    for index, entry in enumerate(_as_list(raw.get("tests"))):
        where = f"{path}: tests[{index}]"
        if isinstance(entry, str):
            entry = {"id": entry}
        if not isinstance(entry, dict) or not entry.get("id"):
            raise ConfigError(f"{where}: each test needs an 'id'")
        unknown = set(entry) - _TEST_KEYS
        if unknown:
            raise ConfigError(f"{where} ({entry['id']}): unknown key(s) {sorted(unknown)}")
        merged = {**defaults, **entry}
        merged["vars"] = {**_str_dict(defaults.get("vars"), where), **_str_dict(entry.get("vars"), where)}
        test_id = str(merged["id"])
        if test_id.lower() in seen:
            raise ConfigError(f"{where}: duplicate test id '{test_id}'")
        seen.add(test_id.lower())

        verify = merged.get("verify", DEFAULT_TEST["verify"])
        if isinstance(verify, str):
            verify = {"type": verify}
        suite.tests.append(
            TestSpec(
                id=test_id,
                project=str(merged.get("project") or test_id.replace(".", "_")),
                description=" ".join(str(merged.get("description", "") or "").split()),
                tags=[str(t) for t in _as_list(merged.get("tags"))],
                known_to_fail=_kfail(merged.get("known_to_fail")),
                skip=str(merged["skip"]) if merged.get("skip") else None,
                output=str(merged.get("output", DEFAULT_TEST["output"])),
                gold=str(merged.get("gold", DEFAULT_TEST["gold"])),
                input=str(merged.get("input", DEFAULT_TEST["input"])),
                ear=str(merged.get("ear", DEFAULT_TEST["ear"])),
                case_dir=str(merged.get("case_dir", "${assets_dir}/${tid}")),
                app_name=str(merged.get("app_name", "${project}.application")),
                action=_as_list(merged.get("action")),
                verify=verify,
                vars=merged["vars"],
                legacy=_str_dict(merged.get("legacy"), where),
                timeout=int(merged["timeout"]) if merged.get("timeout") else None,
                notes=str(merged.get("notes", "") or ""),
                gold_by_version={str(k): str(v) for k, v in (merged.get("gold_by_version") or {}).items()},
                sequences=max(1, int(merged.get("sequences", 1) or 1)),
                sequence_vars={int(k): _str_dict(v, f"{where}.sequence_vars.{k}")
                               for k, v in (merged.get("sequence_vars") or {}).items()},
            )
        )
    return suite


def discover_suites(root: Path, assets_root: Path | str = "") -> list[SuiteSpec]:
    return [load_suite(p, assets_root) for p in sorted(Path(root).rglob(SUITE_GLOB))]
