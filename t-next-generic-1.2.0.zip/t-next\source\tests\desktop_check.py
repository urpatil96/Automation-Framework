"""Open the real desktop window (WebView2), visit every page, report what rendered, close it again.

    python source/tests/desktop_check.py

The window appears on screen for ~20 seconds. Checks: the app shell (toolbar / explorer tree / status bar)
is built and every page renders without the "Something went wrong" error panel or a JavaScript error.
"""

from __future__ import annotations

import json
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]  # project root (config, suites)
ROUTES = ["#/", "#/run/new?step=2", "#/runs", "#/suites", "#/suites/bw-bat", "#/suites/new",
          "#/preferences", "#/doctor", "#/help"]

PROBE = """
(() => {
  const outlet = document.getElementById('outlet');
  return JSON.stringify({
    desktop: document.body.classList.contains('desktop'),
    toolbar: document.querySelectorAll('.tb-btn').length,
    tree: document.querySelectorAll('.dt-row').length,
    status: (document.getElementById('statusbar') || {}).textContent || '',
    title: document.title,
    shellError: document.body.dataset.shellError || '',
    elements: outlet ? outlet.querySelectorAll('*').length : 0,
    loading: !!(outlet && outlet.querySelector('.loading') && outlet.querySelectorAll('*').length < 6),
    error: [...document.querySelectorAll('.callout.tone-bad')].map(e => e.textContent).join(' | ').slice(0, 300),
    jsErrors: window.__errors || [],
  });
})()
"""


def main() -> int:
    import uvicorn
    import webview

    from bwtest.desktop import DesktopApi, _free_port
    from bwtest.ui.server import create_app

    app = create_app(ROOT, ROOT / "config")
    port = _free_port(8799)
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    threading.Thread(target=server.run, daemon=True).start()
    while not server.started:
        time.sleep(0.1)

    api = DesktopApi()
    window = webview.create_window("bwtest - self check", f"http://127.0.0.1:{port}/?desktop=1", js_api=api,
                                   width=1300, height=850)
    api._window = window
    results: list[tuple[str, dict]] = []
    start: dict = {}

    def drive() -> None:
        window.events.loaded.wait(30)
        for _ in range(60):  # the first page must appear on its own, without any navigation
            time.sleep(0.25)
            start.update(json.loads(window.evaluate_js(PROBE)))
            if start["elements"] > 8 and start["tree"] > 0:
                break
        window.evaluate_js("window.__errors = []; window.addEventListener('error', e => window.__errors.push("
                           "String(e.message))); window.addEventListener('unhandledrejection', e => "
                           "window.__errors.push(String(e.reason)));")
        for route in ROUTES:
            window.evaluate_js(f"location.hash = {route!r}")
            data: dict = {}
            for _ in range(40):  # up to ~10 s per page (suites list etc.)
                time.sleep(0.25)
                data = json.loads(window.evaluate_js(PROBE))
                if data["elements"] > 8 and not data["loading"]:
                    break
            time.sleep(0.4)
            results.append((route, json.loads(window.evaluate_js(PROBE))))
        window.destroy()

    webview.start(drive, private_mode=True)
    server.should_exit = True

    shell_ok = bool(start.get("desktop") and start.get("toolbar") and start.get("tree")
                    and start.get("elements", 0) > 8)
    failures = 0 if shell_ok else 1
    print(f"{'OK  ' if shell_ok else 'FAIL'} start-up: desktop layout={start.get('desktop')} toolbar buttons="
          f"{start.get('toolbar')} tree rows={start.get('tree')} first page={start.get('elements')} elements "
          f"status='{start.get('status', '')[:80]}' {start.get('shellError', '')}")
    for route, data in results:
        bad = data["error"] or data["jsErrors"] or data["elements"] <= 8
        failures += bool(bad)
        print(f"{'FAIL' if bad else 'OK  '} {route:<22} {data['title']:<28} {data['elements']:>5} elements"
              + (f"  ERROR: {data['error'] or data['jsErrors']}" if bad else ""))
    print(f"{len(results) - failures}/{len(ROUTES)} pages OK in the real desktop window")
    return 1 if failures or len(results) != len(ROUTES) else 0


if __name__ == "__main__":
    sys.exit(main())
