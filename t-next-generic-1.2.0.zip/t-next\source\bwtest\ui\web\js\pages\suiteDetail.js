// One suite: overview, its test cases, the YAML file (edit + validate), and "Add test case".
import { api } from "../core/api.js";
import { h, mount } from "../core/dom.js";
import {
  button, callout, card, confirmDialog, empty, field, grid, input, kv, linkButton, modal, notifyChanged, pageHeader,
  pathInput, pill, select, tabs, toast,
} from "../components/ui.js";

export default {
  title: (p) => `Suite ${p.name}`,
  async render(view) {
    const name = view.params.name;
    let suite = await api.suite(name);
    const root = h("div", { class: "stack" });
    let dirty = false;
    const leaveGuard = (e) => { if (dirty) { e.preventDefault(); e.returnValue = ""; } };
    window.addEventListener("beforeunload", leaveGuard);
    view.onCleanup(() => window.removeEventListener("beforeunload", leaveGuard));

    function header() {
      return pageHeader(h("span", {}, suite.name, "  ", suite.type === "bw_migration" ? pill("info", "migration") : pill("muted", "engine")),
        suite.description,
        button("+ Add test case", () => addTestDialog(), ""),
        linkButton("▶  Run suite", `#/run/new?suite=${encodeURIComponent(suite.name)}`, "primary"));
    }

    // ---------------------------------------------------------------- overview
    const overview = () => grid(2,
      card({ title: "About this suite" }, kv([
        ["File", h("span", { class: "mono" }, suite.file)], ["Owner", suite.owner || "—"],
        ["Tests", `${suite.tests} (${suite.known_to_fail} known to fail, ${suite.skipped} skipped)`],
        ["Test case folders", h("span", {}, h("span", { class: "mono" }, suite.assets_dir), suite.assets_exist === false ? pill("warn", "missing") : null)],
        ["Tags", (suite.tags || []).map((t) => h("span", { class: "tag" }, t))],
        [".sh script steps", suite.bridged ? `${suite.bridged} test(s) have one step that is a .sh script - bwtest runs it itself (Git Bash)` : "none - every step is YAML"],
        ["Notes", suite.notes || "—"]])),
      card({ title: "Environment for every test", help: "Module properties (vars) reach the BW application through the deploy profile. Drivers/databases are prepared before the suite starts." },
        kv([
          ["Variables (module properties)", Object.keys(suite.vars || {}).length
            ? h("table", { class: "table" }, h("tbody", {}, Object.entries(suite.vars).map(([k, v]) => h("tr", {}, h("td", { class: "mono" }, k), h("td", { class: "mono" }, v)))))
            : "—"],
          [".cfg files", (suite.client_vars_files || []).map((f) => h("div", { class: "mono small" }, f))],
          ["Drivers", (suite.drivers || []).join(", ") || "—"], ["Databases reset", (suite.databases || []).join(", ") || "—"],
          ["AppNode properties", Object.keys(suite.appnode_properties || {}).length
            ? Object.entries(suite.appnode_properties).map(([k, v]) => h("div", { class: "mono small" }, `${k}=${v}`)) : "—"],
          ["Legacy scripts", Object.keys(suite.legacy || {}).length ? Object.entries(suite.legacy).map(([k, v]) => h("div", { class: "mono small" }, `${k}: ${v}`)) : "—"]])));

    // ---------------------------------------------------------------- tests
    function testsView() {
      let q = "";
      const host = h("div", { class: "table-wrap" });
      const draw = () => {
        const rows = suite.test_list.filter((t) => !q || `${t.id} ${t.description} ${t.tags.join(" ")}`.toLowerCase().includes(q));
        mount(host, rows.length ? h("table", { class: "table" },
          h("thead", {}, h("tr", {}, ["Test", "Description", "Verify", "Action", "Flags", ""].map((x) => h("th", {}, x)))),
          h("tbody", {}, rows.map((t) => h("tr", {},
            h("td", { class: "mono nowrap" }, t.id, t.case_exists ? null : h("div", {}, pill("warn", "no folder"))),
            h("td", { class: "desc" }, t.description, h("div", {}, t.tags.map((x) => h("span", { class: "tag" }, x)))),
            h("td", { class: "small" }, t.verify),
            h("td", { class: "small" }, t.action.length ? t.action.join(" → ") : h("span", { class: "muted" }, "wait for output")),
            h("td", {}, h("div", { class: "row", style: { gap: "4px" } },
              t.known_to_fail ? pill("known", t.known_to_fail) : null, t.skip ? pill("muted", `skip: ${t.skip}`) : null,
              t.legacy ? pill("info", ".sh step", "one step of the test is a .sh script - T-Next runs it itself (Git Bash)") : null, t.sequences > 1 ? pill("info", `×${t.sequences}`) : null)),
            h("td", { class: "right" }, linkButton("Run", `#/run/new?suite=${encodeURIComponent(suite.name)}&test=${encodeURIComponent(t.id)}`, "small"))))))
          : empty("No tests", suite.test_list.length ? "Nothing matches the search." : "Add the first test case.", button("+ Add test case", addTestDialog, "primary")));
      };
      draw();
      return card({ class: "flush" }, h("div", { style: { padding: "12px 14px" } },
        h("div", { class: "row", style: { marginBottom: "10px" } },
          input({ class: "input search", placeholder: "Search test id, description, tag…", oninput: (e) => { q = e.target.value.toLowerCase(); draw(); } }),
          h("span", { class: "spacer" }), button("+ Add test case", addTestDialog, "small")),
        host));
    }

    // ---------------------------------------------------------------- YAML editor
    async function yamlView() {
      const src = await api.suiteSource(name);
      let original = src.text;
      const status = h("div");
      const editor = h("textarea", { class: "code-edit", spellcheck: "false", value: src.text,
        oninput: () => { dirty = editor.value !== original; mount(status, dirty ? callout("info", "Unsaved changes.") : null); } });
      editor.addEventListener("keydown", (e) => { // Tab inserts two spaces instead of leaving the editor
        if (e.key === "Tab") { e.preventDefault(); editor.setRangeText("  ", editor.selectionStart, editor.selectionEnd, "end"); }
        if ((e.ctrlKey || e.metaKey) && e.key === "s") { e.preventDefault(); save(); }
      });
      const validate = async () => {
        const r = await api.validateSuite(name, editor.value);
        mount(status, r.ok ? callout("ok", "Valid.", `Suite '${r.suite}' with ${r.tests} test(s).`) : callout("bad", "Not valid:", r.error));
        return r.ok;
      };
      const save = async () => {
        if (!(await validate())) return;
        await api.saveSuite(name, editor.value);
        original = editor.value;
        dirty = false;
        toast("Suite saved");
        suite = await api.suite(name);
        notifyChanged();
      };
      return card({ title: "Suite file", subtitle: src.file,
        help: "Edited text is checked with the same parser a run uses before it is saved. Ctrl+S saves. Docs: docs/WRITING_TESTS.md",
        actions: [button("Validate", validate), button("Save", save, "primary"),
          button("Revert", async () => {
            if (dirty && !(await confirmDialog("Revert", "Discard your changes?", "Discard", "danger-solid"))) return;
            editor.value = original; dirty = false; mount(status);
          }, "ghost")] }, status, editor);
    }

    // ---------------------------------------------------------------- add test dialog
    function addTestDialog() {
      const v = { test_id: nextId(), description: "", tags: "", ear: "", project_dir: "", known_to_fail: "", skip: "", verify: "" };
      const bind = (k) => (e) => { v[k] = e.target.value; };
      const error = h("div");
      const body = h("div", {},
        callout("info", "How it works:", "the test gets a folder ", h("code", {}, `${suite.assets_dir}/<id>/`),
          " with the EAR. Run it once with “Update gold” to create the expected result, review it, then run normally."),
        h("div", { class: "form-grid", style: { marginTop: "14px" } },
          field("Test id", input({ value: v.test_id, oninput: bind("test_id") }), "e.g. bw.9001 - BW project name becomes bw_9001", null, { required: true }),
          field("Description", input({ oninput: bind("description"), placeholder: "what the test checks" })),
          field("EAR file", pathInput({ kind: "file", patterns: "EAR files (*.ear)", placeholder: "C:/work/bw_9001.application.ear",
            onchange: (x) => { v.ear = x; } }), "Exported from Studio. Copied into the test folder as <project>.application.ear."),
          field("Studio project folder (optional)", pathInput({ kind: "folder", placeholder: "C:/work/bw_9001",
            onchange: (x) => { v.project_dir = x; } }), "Copied for reference."),
          field("Tags", input({ oninput: bind("tags"), placeholder: "smoke, http" }), "Comma separated - used for tag filters."),
          field("Verify as", select([["", "suite default"], ["text", "text"], ["xml", "xml"], ["json", "json"], ["binary", "binary"], ["exists", "file exists"]], "",
            { onchange: bind("verify") })),
          field("Known to fail (optional)", input({ oninput: bind("known_to_fail"), placeholder: "BUG-12345" }), "Reported as known failure, not as failed."),
          field("Skip (optional)", input({ oninput: bind("skip"), placeholder: "reason" }))),
        error);
      const dlg = modal({ title: `Add test case to ${suite.name}`, body, wide: true, actions: [
        h("button", { class: "btn", onclick: () => dlg.close() }, "Cancel"),
        button("Add test case", async () => {
          try {
            const r = await api.addTest(name, { ...v, tags: v.tags.split(",").map((t) => t.trim()).filter(Boolean) });
            dlg.close();
            suite = await api.suite(name);
            draw("tests");
            notifyChanged();
            nextSteps(v.test_id, r);
          } catch (e) { mount(error, callout("bad", "Could not add:", e.message)); }
        }, "primary")] });
    }

    function nextSteps(testId, r) {
      const dlg = modal({ title: `${testId} added`, body: h("div", {},
        kv([["Case folder", h("span", { class: "mono" }, r.case_dir)], ["Copied", r.copied.join(", ") || "nothing (put the EAR into the folder)"]]),
        h("h3", {}, "Next steps"),
        h("ol", {}, h("li", {}, "Make sure the EAR writes its result to the module property ", h("code", {}, "TSI_TEST_OUTPUT_FILE"), "."),
          h("li", {}, "Run it once with ", h("b", {}, "Update gold files"), " ticked (step 3 of New run) - this creates the expected result."),
          h("li", {}, "Open the new gold file and check it is correct."),
          h("li", {}, "Run again normally - it must pass. Commit the suite file and the case folder."))),
      actions: [h("button", { class: "btn", onclick: () => dlg.close() }, "Close"),
        linkButton("Create gold now ▶", `#/run/new?suite=${encodeURIComponent(suite.name)}&test=${encodeURIComponent(testId)}`, "primary",
          { onclick: () => dlg.close() })] });
    }

    function nextId() {
      const nums = suite.test_list.map((t) => /^bw\.(\d+)$/.exec(t.id)).filter(Boolean).map((m) => Number(m[1]));
      return nums.length ? `bw.${Math.max(...nums) + 1}` : "bw.9001";
    }

    function draw(tab) {
      mount(root, header(),
        suite.error ? callout("bad", "This suite file is not valid:", suite.error) : null,
        tabs([
          { id: "tests", label: "Test cases", badge: suite.tests, render: testsView },
          { id: "overview", label: "Overview", render: overview },
          { id: "yaml", label: "Edit YAML", render: yamlView },
        ], tab || view.query.tab || "tests"));
    }
    draw();
    return root;
  },
};
