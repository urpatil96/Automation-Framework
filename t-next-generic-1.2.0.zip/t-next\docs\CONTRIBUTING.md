# Contributing to T-Next

bwtest is used by the whole BW QA team, so every change must keep existing suites and runs working.

## Golden rules

1. **Never change the BW execution steps** (create domain → AppSpace → AppNode → start → upload → deploy →
   stop → undeploy → delete archive → stop AppNode → delete AppSpace → delete domain) or their arguments
   without agreement from the team. They match t-tests 4.0 on purpose. The self-test
   `test_shell_runs_exactly_the_same_bw_steps_as_one_jvm_per_command` guards the order.
2. **Suite files are data.** Changes to the YAML format must stay backward compatible (or bump the MAJOR version
   and provide a migration).
3. **No secrets in git**: passwords go to `.env` / Jenkins credentials and are referenced as `${env:NAME}`.
4. **No personal paths** in shared files (`config/bwtest.yaml`, profiles, suites, docs). Personal settings go to
   `config/local.yaml` (ignored by git) through Preferences.

## Before you push

```bat
cd C:\D\bw6-autotest
.venv\Scripts\activate
ruff check source --no-cache         :: must say "All checks passed!" (CI runs the same)
python -m pytest source/tests -q     :: framework self-tests, ~30 s, no BW needed
python source\tests\js_syntax_check.py :: if you changed the UI (needs: pip install mini-racer)
bwtest run <suite> --dry-run         :: if you changed suites: shows the commands without BW
```

For changes to the runtime (bwadmin, deploy, verify), also run one real suite, for example bw-bat, and compare
the result and **Run page → Details → Where the time went** with a previous run.

## Change checklist

- [ ] Self-tests added or updated (`source/tests/`). Tests use `source/tests/fake_bw/bwadmin.py`, a stand-in for `bwadmin` so the
      framework can be tested without BW. Real runs always use the real `bwadmin` from the BW installation.
- [ ] `ruff check source --no-cache` passes.
- [ ] Docs updated (see [README.md](README.md) for which file covers what).
- [ ] `CHANGELOG.md` entry; version in `source/pyproject.toml` and `source/bwtest/__init__.py` bumped for a release.

## Where things are

| Change | File |
|---|---|
| A bwadmin command / BW lifecycle | `source/bwtest/runtime.py`, `source/bwtest/bwcli.py` |
| One test's flow (prepare → deploy → action → cleanup → verify) | `source/bwtest/executor.py` |
| New action step / verifier | `source/bwtest/actions.py`, `source/bwtest/verify.py` (`@action`, `@verifier`) |
| t-tests import | `source/bwtest/legacy/importer.py` |
| Desktop / web UI | `source/bwtest/ui/` (see [docs/UI.md](UI.md) → Code layout) |
| Settings and their defaults | `source/bwtest/config.py`, `config/bwtest.yaml` |
| Preferences page fields | `FIELDS` in `source/bwtest/ui/services/preferences.py` |

## Code style

Python 3.11+, type hints, line length 120 (ruff). Comments explain **why**, not what. Keep functions small and
each module focused on one job (see [docs/ARCHITECTURE.md](ARCHITECTURE.md)). No new dependency without a reason
written in the pull request: the QA machines install offline more often than not.
