// Preferences - old t-tests user profile + Preferences dialog. Saved to config/local.yaml.
// The list of fields comes from the server (ui/services/preferences.py FIELDS), so adding a field there
// adds it here automatically.
import { api } from "../core/api.js";
import { h, mount } from "../core/dom.js";
import {
  button, callout, card, checkbox, field, input, linkButton, pageHeader, pathInput, select, toast,
} from "../components/ui.js";

export default {
  title: "Preferences",
  async render() {
    const [prefs, profiles] = await Promise.all([api.preferences(), api.profiles()]);
    const values = {};
    const status = h("div");
    const groups = [...new Set(prefs.fields.map((f) => f.group))];

    function control(f) {
      const current = f.value ?? "";
      const set = (v) => { values[f.key] = v; };
      const placeholder = f.effective !== null && f.effective !== undefined && f.effective !== "" ? `default: ${f.effective}` : "";
      if (f.kind === "bool") {
        const on = f.value ?? f.effective;
        return checkbox(on ? "Yes" : "No", Boolean(on), (v) => set(v));
      }
      if (f.kind === "select") return select([["", `default (${f.effective})`], ...f.options], current, { onchange: (e) => set(e.target.value) });
      if (f.kind === "profile") {
        return select([["", `default (${f.effective})`], ...profiles.profiles.map((p) => p.name)], current, { onchange: (e) => set(e.target.value) });
      }
      if (f.kind === "path") {
        return pathInput({ value: current, placeholder, kind: f.key === "paths.bash" ? "file" : "folder",
          patterns: f.key === "paths.bash" ? "Programs (*.exe)" : "", onchange: set });
      }
      return input({ value: current, placeholder, type: f.kind === "number" ? "number" : "text", oninput: (e) => set(e.target.value) });
    }

    const save = async () => {
      if (!Object.keys(values).length) { toast("Nothing changed.", "info"); return; }
      try {
        await api.savePreferences(values);
        toast("Preferences saved to config/local.yaml");
        mount(status, callout("ok", "Saved.", "New runs use these values. Run Doctor to check them."));
        for (const k of Object.keys(values)) delete values[k];
      } catch (e) { mount(status, callout("bad", "Not saved:", e.message)); }
    };

    return h("div", { class: "stack" },
      pageHeader("Preferences", "Settings of this machine - like the t-tests user profile and Preferences dialog. "
        + "Empty fields use the project default shown in grey.",
        linkButton("Check with Doctor", "#/doctor"), button("Save", save, "primary")),
      callout("info", "Where is this stored?", h("span", { class: "mono" }, prefs.file),
        " (personal, not in git). Team-wide defaults are in config/bwtest.yaml, BW-version defaults in config/profiles/<version>.yaml."),
      status,
      groups.map((g) => card({ title: g },
        h("div", { class: "form-grid" }, prefs.fields.filter((f) => f.group === g).map((f) =>
          field(f.label, control(f), f.help, f.old))))),
      h("div", { class: "row" }, button("Save", save, "primary")));
  },
};
