# T-Next user guide: from installation to the result
> **T-Next** is the name of the framework (the next generation of t-tests). The command, the Python package and file names stay `bwtest` (`bwtest run …`, `config/bwtest.yaml`, domains `bwtest-N`).


This guide walks through bwtest from start to finish: installing it on a new machine, running a suite,
reading the results, and adding new tests. bwtest replaces t-tests 4.0 (`t-tests.bat`).

For every button and field in the desktop app, see [UI_REFERENCE.md](UI_REFERENCE.md).

---

## Contents

1. [What bwtest does in one picture](#1-what-bwtest-does-in-one-picture)
2. [One-time installation](#2-one-time-installation)
3. [One-time configuration (Preferences)](#3-one-time-configuration-preferences)
4. [Check the environment (Doctor)](#4-check-the-environment-doctor)
5. [Start a run: the 4-step wizard](#5-start-a-run-the-4-step-wizard)
6. [What happens during a run (domain → AppSpace → AppNode → tests)](#6-what-happens-during-a-run)
7. [Follow the run live](#7-follow-the-run-live)
8. [Read the results](#8-read-the-results)
9. [Re-run, stop, clean up](#9-re-run-stop-clean-up)
10. [Add a new test case or suite](#10-add-a-new-test-case-or-suite)
11. [Running from the command line / Jenkins](#11-running-from-the-command-line--jenkins)
12. [Troubleshooting](#12-troubleshooting)
13. [t-tests 4.0 → bwtest cheat sheet](#13-t-tests-40--bwtest-cheat-sheet)

---

## 1. What bwtest does in one picture

```
 You choose:  BW version + build   +   suites / test cases   +   report details
                       │
                       ▼
 bwtest:  create domain bwtest-0
            └─ per suite:  create AppSpace + AppNode → start AppNode
                 └─ per test:  write t-tests.substvar → upload + deploy EAR
                               → wait for the output → stop + undeploy app
                               → compare output with the gold file → PASS / FAIL
            └─ stop AppNode, delete AppSpace
          delete domain
                       │
                       ▼
 You get:  results/<run-id>/ report.html · junit.xml · commands.log · one folder per test
```

A **suite** is one `*.suite.yaml` file. It becomes one AppSpace and one AppNode.
A **test case** (for example `bw.3647`) is one BW application (EAR) plus an expected output (the **gold file**).

---

## 2. One-time installation

**Needed first:** Windows 10/11, **Python 3.12 or 3.13** (tick *Add python.exe to PATH*), **Git for Windows**,
your BW installs (e.g. `C:\D\6.12.1\V12\bw\6.12`) and the test case folder (e.g. `C:\D\Automation\tests\bw`).

**Easiest:** double-click **`setup\setup-bwtest.bat`**. It asks where to install (default `C:\D\bw6-autotest`),
checks Python and Git Bash, installs everything, asks for your BW installs folder, default build, test case
location, domain home and name, and runs Doctor. Run it again any time to repair or update.

| `setup\` file | Use |
|---|---|
| `setup-bwtest.bat` | install / repair on this machine |
| `make-share-zip.bat` | clean zip for a colleague (no `.venv`, results, personal settings or passwords); `--with-wheels` adds all packages for an install without internet |
| `backup-bwtest.bat` | full backup in one zip (incl. your settings, `.env`, results) to `..\bwtest-backups\` - keep it private |

**By hand** (same result), in a Command Prompt:

```bat
cd C:\D\bw6-autotest
python -m venv .venv
.venv\Scripts\pip install -e "source[report,parallel,desktop]"
copy config\local.yaml.example config\local.yaml
copy config\.env.example .env
```

| File | What to put in it |
|---|---|
| `config\local.yaml` | Your machine's paths: BW installs folder, test case location (can also be set later in **Preferences**) |
| `.env` | Database / EMS passwords, only for suites that need them (jdbc, jms …). Never commit this file. |

If PyPI is slow, add `--timeout 60` to the `pip install` command.

**Start the application:** double-click **`C:\D\bw6-autotest\start-bwtest.bat`**.
A window titled *bwtest - BusinessWorks 6 regression* opens. This is the new `t-tests.bat`.

> If `start-bwtest.bat` says *"bwtest is not installed yet"*, the `.venv` folder is missing. Run the install
> commands above.

---

## 3. One-time configuration (Preferences)

Toolbar **⚙ Preferences** (or menu **Edit → Preferences…**). Fill in at least the fields marked ★ and
click **Save**. Values go to `config/local.yaml`. Empty fields use the project default shown in grey.

| Field | Example | Why |
|---|---|---|
| ★ Default profile (BW version) | `6.12.1` | Preselected BW version on New run |
| ★ BW installs folder | `C:/D` | Builds are found as `C:/D/<version>/<build>/bw/<x.y>`, e.g. `C:/D/6.12.1/V12/bw/6.12` |
| ★ Test case location | `C:/D/Automation/tests/bw` | Folder with the EARs and gold files (old *Test Case Location by Product*) |
| Driver jars folder | `C:/D/Automation/tests/bw/lib` | JDBC/JMS drivers for jdbc / jms suites |
| Domain home | `C:/domains` | Where the temporary domain `bwtest-N` is created |
| Tibrv location | `C:/bw6/tibrv/8.8` | For RV suites (`rvd` / `tibrvsend`) |
| Default tester name | `jdoe` (your name) | Prefilled in the report details |

The **Dashboard** has a *Getting started* checklist. Every item should show a green ✓.

---

## 4. Check the environment (Doctor)

Toolbar **✚ Doctor** → choose **Profile** and **Build** → **Run checks**.

| Check | If it fails |
|---|---|
| BW home has bin/bwadmin | Wrong build folder. Fix *BW installs folder* in Preferences. |
| bwadmin version | BW install broken or blocked. Run `bwadmin version` by hand. |
| bwagent.ini present | Incomplete BW install |
| Test assets folder exists | Fix *Test case location* |
| Bash for legacy bridge | Install Git for Windows, or set *Bash for old scripts* |
| Domain home writable | Choose another *Domain home* |
| HTML report plugin / Parallel run plugin | `pip install -e "source[report,parallel]"` |
| N suite files are valid | Open the suite named in the message and fix its YAML |

All green means you are ready. The **Effective configuration** tab shows the final settings and the order in which the config files override each other.

---

## 5. Start a run: the 4-step wizard

Toolbar **▶ New run**, or **double-click a suite** in the Test explorer on the left.

### Step 1 – Product & build
1. Click a **profile card** (for example *BW 6.12.1*).
2. Click a **build card** (for example *V12 – C:/D/6.12.1/V12/bw/6.12*).
   For a build outside the installs folder, tick **Use another BW home folder** and type or **Browse…** for the folder that contains `bin/bwadmin`.
3. Optional: **Check this build**. It runs `bwadmin version` and shows *"bwadmin reports: …"*.
4. **Next: Test cases →**

### Step 2 – Test cases
- Tick a **suite** to run all of its tests.
- Click **▶** in front of a suite to open it and tick **single tests**.
- **Search** box: type `http` or `bw.3647`.
- **Type** filter: *Engine (BW_ENGINE)* or *Migration (BW_MIGRATION)*.
- **Load a saved selection** (the old `.testcmd`), or **Save as selection…** to store the current choice.
- The **Your selection** box shows how many test cases will run.
- Suites come from **your** test folder: the setup takes all of them. New suites or test cases added there
  later: **Suites → ⇩ Sync with test folder…** (Doctor tells you when something is new).

### Step 3 – Report details & options
- **Run name**, **Tester**, **Jira**, **Notes**. These appear in the run list and in `report.html`.
- **Parallel workers**: 1 by default (safe). 2–4 workers each get their own domain and ports, but need one AppNode's worth of RAM per worker.
- **Dry run**: shows the BW commands but runs nothing. Use it to check a new suite.
- **Update gold files**: copies the output over the gold file. Use it only for new tests or intended behaviour changes.
  After a normal run you can also accept changed output afterwards, without running again: see *Output changed because of a feature change* in section 8.
- **Keep the BW domain after the run**: lets you inspect the AppSpace and AppNode afterwards.

### Step 4 – Review & start
Check the summary. The box **Same run from a terminal** shows the equivalent `bwtest run …` command. Use **Copy** to reuse it in Jenkins.
Click **▶ Start run**. The run page opens.

---

## 6. What happens during a run

This is the same sequence t-tests used (BW_ENGINE.sh / DefaultEngineRun). Every command is logged in
`results/<run>/commands.log`, so you can copy and replay it (old `setupCommands.bat` / `appCommands.bat`).

### Once per run
| Step | Command / action |
|---|---|
| Detect BW version | `bwadmin version` → e.g. *6.12.0 HF5 build V188* (picks version-specific gold files) |
| Create domain | `bwadmin create -home C:/domains domain bwtest-0` |

### Once per suite
| Step | What |
|---|---|
| Drivers / databases | install JDBC/JMS drivers (`bwinstall`), reset databases (if the suite asks) |
| Create AppSpace | `create -d bwtest-0 appspace <suite>` |
| Create AppNode | `create … appnode <suite> -httpPort <port> -osgiPort <port>`. Each suite gets its own ports. |
| Patch AppNode config.ini | adds `bw.plugin.http.handleAllMimePartsAsAttachment=false` and the suite's `appnode_properties` |
| Start AppNode | `start appnode` → bwtest polls until the status is **Running** (can take ~3 min on Windows) |

### Per test case
| # | Step | Details |
|---|---|---|
| 1 | Prepare | Resolves the files: **input** `<case>/<id>_input.txt`, **output** `<log>/<id>_output.log`, **gold** `<case>/<id>_gold.log`. If a version-specific gold exists (`…_gold_6120.log`), it is used. A legacy `t_setup.sh` may override any of them. |
| 2 | Profile | Copies the app's `default.substvar` and fills in the test variables (`TSI_TEST_OUTPUT_FILE`, `.cfg` client vars …) → `t-tests.substvar`. See `module_properties.txt`. |
| 3 | Deploy | `upload` the EAR → `deploy -pf t-tests.substvar -as` → wait until the app is Running |
| 4 | Action | Default: wait for the output file. Imported suites use `wait_for_output: N`: wait up to N s, but continue as soon as the output is as big as the gold file (t-tests *Advance Verify*). |
| 5 | Cleanup | `stop application` → `undeploy` → delete archive. Saves this test's part of `bwappnode.log`. |
| 6 | Verify | Compares output with gold (text / xml / json / binary / legacy `t_verify.sh`). CR characters are ignored. Pass = all checks match. |

### At the end of the suite / run
`stop appnode` (waits until Stopped) → delete AppSpace → uninstall drivers → delete domain (unless *Keep the BW domain* is ticked).

---

## 7. Follow the run live

The run page shows:
- **Progress bar** and the **current test** (*Running bw.3647 (http_Attachments_comp) … for 12s*).
- Before the first test of a suite: *"Preparing suite X: installing drivers, creating AppSpace and starting the AppNode."*
- Counters: **Passed / Failed / Errors / Known failures / Remaining**.
- Tab **Console**: the same text `bwtest run` prints in a terminal. Tick **Follow** to auto-scroll.

The status bar at the bottom shows **● Run … in progress**. Click it to return to the run.
You can close the window: the run continues, and when you open bwtest again it is shown.

---

## 8. Read the results

### Result meanings
| Result | Meaning | What to do |
|---|---|---|
| **Passed** | output = gold | nothing |
| **Failed** | output differs from gold, or output missing | open the test → `diff.txt` |
| **Error** | environment / setup problem (bwadmin failed, AppNode did not start, EAR missing) | see the failure message, `commands.log` |
| **Known failure** | test has `known_to_fail: BW-xxxxx` and failed as expected | nothing |
| **Fixed? (XPASS)** | a known failure now passes | check the Jira, remove `known_to_fail` |
| **Skipped / Not run** | `skip:` in the suite, or the run was stopped | — |

### Look at one test
Tab **Tests** → set the filter to *Failed + errors* → click a row. The dialog shows:

| File | Content |
|---|---|
| Failure message | short reason + diff |
| `diff.txt` | unified diff gold ↔ output |
| `test.log` | timeline of this test (deploy, action, waits, verify) |
| `bwappnode.log` | only the AppNode log lines written during this test |
| `module_properties.txt` | every module property the app received |
| `t-tests.substvar` | the deploy profile |
| `<id>_output.*` | the actual output |

**Run this test again** opens New run with only this test selected.

### Whole run
- **Open HTML report** → `report.html` (send it to the team or attach it to Jira).
- Tab **Files**: the whole run folder. Tab **Details**: run name, command, BW version detected, domain.
- On disk: `C:\D\bw6-autotest\results\<run-id>\` (menu **File → Open results folder**).

```
results/20261119-101500/
├─ report.html        HTML report          ├─ junit.xml        for Jenkins
├─ summary.json       counts               ├─ commands.log     every bwadmin call + rc + duration
├─ console.log        console output       ├─ run_info.json    name, tester, Jira, options
└─ http_Attachments_comp/bw.3647/  test.log · diff.txt · bwappnode.log · module_properties.txt · output
```

### Output changed because of a feature change (accept new output as gold)
When a test fails only because its output differs from the gold file, bwtest keeps the new output
(`new-output/` in the test's result folder). If the difference is expected, for example after a feature change,
make it the new gold file **without running the test again**:

- **In the app:** the run page shows *"N failed test(s): the output differs from the gold file"* and a
  **Gold changes (N)** button. It lists every changed test with its diff. Click **Accept as gold** on a single test,
  or tick several (**Select all / Select none**) and click **Accept selected as gold**. For one test: open the test → **Accept new output as gold…**.
- **Command line:** `bwtest accept-gold <run-id>` (or `LATEST`) shows the diff of each test and asks
  `y` / `n` / `a` (yes to all) / `q`. Add `-t bw.618` for one test, or `--yes` to accept all without asking.
  At the end of a `bwtest run` that has gold changes, this command is printed.

The old gold file is kept in `gold-backup/` in the test's result folder. Known failures (tests with a Jira) are
never offered: their output is wrong because of the bug. Works for native checks and for the old `t_verify.sh`
(it compares `TSI_TEST_OUTPUT_FILE` with `TSI_TEST_GOLD_FILE`). Run the tests again afterwards to confirm they pass.

---

## 9. Re-run, stop, clean up

| Want to | Button (run page) |
|---|---|
| Stop safely: current test finishes, then BW is cleaned up | **Stop after current test** (or toolbar **■ Stop**) |
| Stop immediately (last resort) | **Force kill**. Afterwards, end `bwappnode-<suite>.exe` in Task Manager and delete `C:\domains\bwtest-N`. |
| Run only the failed/error tests again | **Re-run failed** |
| Same selection again | **Run again** |
| Upload results to the QA results DB (old t-tests `.sql`) | **t-tests .sql**, then upload `results/<id>/ttests-report/t_func_engine_report_<time>.sql` as before |
| Remove a run folder | **Delete** |

**Several runs at the same time.** Several runs can go at the same time (up to 4), like several t-tests jobs: each run gets its own *slot* = its own domains (`bwtest-0` for the first run, `bwtest-s1-0` for the second …) and its own ports. Two runs may not run the **same suite** at the same time (they would share its database tables / mailbox) - bwtest refuses that with a clear message. With another run going, use at most 4 parallel workers. Every run needs RAM for its AppNodes. Tip: for one job, *Parallel workers* in one run is still the simplest way to run suites side by side.

---

## 10. Add a new test case or suite

### New test case
1. Export the EAR from BW Studio. The app must write its result to the module property `TSI_TEST_OUTPUT_FILE`.
2. **Suites** → open the suite → **+ Add test case**. Fill in **Test id** (e.g. `bw.9001`) and **EAR file** (Browse…), then click **Add test case**.
3. In the *Next steps* dialog, click **Create gold now ▶**. This opens New run with the test selected. Tick **Update gold files** in step 3 and start.
4. Open the new gold file and check it.
5. Run again normally. It must pass. Commit the suite YAML and the case folder.

### New suite
**+ New suite** → **Name** (= AppSpace/AppNode name), **Category**, **Type**, **Default verification**,
**Test case folders** → **Create suite**. Then add test cases as above. Variables, `.cfg` files, drivers:
**Edit YAML** tab (see [WRITING_TESTS.md](WRITING_TESTS.md)).

---

## 11. Running from the command line / Jenkins

```bat
cd C:\D\bw6-autotest
.venv\Scripts\activate
bwtest doctor
bwtest run bw-bat --name "6.12.0 HF5 V188 bat" --tester jdoe
bwtest run http_Attachments_comp -k "bw.3647 or bw.3648"
bwtest run --profile 6.12.1 --bw-home C:/D/6.12.1/V12/bw/6.12 -m "http and not known_to_fail" -n 2
bwtest run --lf                        # only the tests that failed last time
bwtest run bw-bat --dry-run          # show commands only
```

Runs started from the command line also show up in **Runs & reports** in the UI.

---

## 12. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `OSError: [WinError 6] The handle is invalid` | Fixed in bwtest (child processes get an empty stdin). Restart the app with `start-bwtest.bat`. |
| Run ends right away with **Error** on every test | AppNode did not start. Open the run → Tests → first error → `commands.log`. Check RAM (each AppNode needs ~1–2 GB), and raise *AppNode start timeout* in Preferences. |
| Run disappears / *Incomplete* | Process ended without a summary (window closed during startup, reboot, Windows low-memory kill). Close other apps and run again. |
| Every test **Failed: output file was not created** | The app did not write `TSI_TEST_OUTPUT_FILE`. Check `bwappnode.log` of the test for `BW-…-5xxxxx` errors, and `module_properties.txt` for the output path. |
| JMS tests (bw.617, bw.1654) fail | The EMS server is not running, or the setup script points to a missing `E:/EMS840`. These also fail in old t-tests. |
| HTTP tests fail on header order (bw.3921) | Product behaviour on 6.12.x. Also fails in t-tests. Mark it `known_to_fail`. |
| Port already in use | Leftover AppNode from a killed run. End `bwappnode-*.exe` in Task Manager, or change *First HTTP port*. |
| Windows Security pop-up **"Java Launcher"** during a run | Windows Firewall asks once per AppNode program path (each suite × domain has its own `bwappnode-<suite>.exe`). *Allow* or *Cancel*: tests on localhost work either way; only connections from other machines into the AppNode need *Allow*. To stop the pop-ups for good, run `setup\allow-firewall.bat` once as Administrator (or ask IT). |
| Leftover `C:\domains\bwtest-N` | Created by a killed run. Delete the folder once no bwappnode process is running. |
| *Browse… is only available in the desktop app* | You opened the browser UI (`bwtest ui`). Type the path instead, or use `start-bwtest.bat`. |

Useful files: `results/<run>/commands.log` (replay any bwadmin call), `console.log`, and the AppNode
log at `C:\domains\bwtest-0\appnodes\<suite>\<suite>\log\bwappnode.log`.

---

## 13. t-tests 4.0 → bwtest cheat sheet

| t-tests 4.0 | bwtest |
|---|---|
| `t-tests\4.0\bin\t-tests.bat` | `start-bwtest.bat` |
| User profile (JRE, Tibrv, BW5 HOME) | Preferences → Tools |
| Preferences → Test Case Location by Product | Preferences → Test case location |
| Product profile (`6.12.1.profile`, INSTALL_HOME) | New run → step 1 (profile + build) |
| Edit → Select test cases | New run → step 2 |
| `.testcmd` file | Saved selection (`config/selections/*.yaml`) |
| Preferences → Report | New run → step 3 |
| Run button | New run → step 4 → Start run |
| `reports/i86-winnt50/<run>/index.html` | Runs & reports → Open HTML report |
| `setupCommands.bat` / `appCommands.bat` | `commands.log` |
| `<id>_diff.log` / `<id>_error.log` | `diff.txt` / failure message |
| `bwdomain-0` | `bwtest-0` |
| `t_sleep 40` + Advance Verify | `wait_for_output: 40` |
| `.testset` + `t_setup.sh` / `t_action.sh` / `t_verify.sh` | one `*.suite.yaml`; where a step could not be translated, bwtest runs the original `.sh` script itself (no t-tests needed) |

More: [UI_REFERENCE.md](UI_REFERENCE.md) · [WRITING_TESTS.md](WRITING_TESTS.md) ·
[MIGRATING_FROM_TTESTS.md](MIGRATING_FROM_TTESTS.md) · [ARCHITECTURE.md](ARCHITECTURE.md)
