// New run wizard - the old t-tests main page as 4 guided steps:
//   1 Product & build   (old: product profile / INSTALL_HOME)
//   2 Test cases        (old: Select test cases dialog + .testcmd files)
//   3 Report details    (old: Preferences > Report: product, version, build)
//   4 Review & start    (shows the equivalent `bwtest run` command)
//
// Pre-fill from links:  #/run/new?suite=http_Attachments_comp&test=bw.3647&profile=6.12.1
import { api } from "../core/api.js";
import { h, mount } from "../core/dom.js";
import { plural } from "../core/format.js";
import {
  button, callout, card, checkbox, confirmDialog, empty, field, input, kv, loading, notifyChanged, pageHeader, pathInput,
  pill, promptDialog, select, stepper, textarea, toast,
} from "../components/ui.js";

const STEPS = [
  { title: "Product & build", sub: "BW version and build" },
  { title: "Test cases", sub: "suites or single tests" },
  { title: "Report details", sub: "name, tester, options" },
  { title: "Review & start", sub: "check and run" },
];

export default {
  title: "New run",
  async render(view) {
    const [profilesData, suites, selections] = await Promise.all([
      api.profiles(), api.suites(), api.selections()]);

    const state = {
      step: 0,
      profile: view.query.profile || profilesData.default,
      bw_home: "",
      customHome: "",
      useCustom: false,
      type: "all",
      search: "",
      suites: new Set(),
      tests: new Set(),
      expanded: new Set(),
      openFolders: new Set(),
      name: "", tester: profilesData.default_tester || "", notes: "", jira: "",
      workers: 0, dry_run: false, update_gold: false, keep_domain: false,
      buildCheck: null,
    };
    const details = new Map(); // suite name -> detail (loaded when expanded)
    const suiteByName = new Map(suites.map((s) => [s.name, s]));
    const folderOf = (s) => s.folder || s.category || "other";
    suites.forEach((s) => state.openFolders.add(folderOf(s).split("/")[0]));

    const profileOf = (name) => profilesData.profiles.find((p) => p.name === name);
    const defaultBuild = (p) => (p && (p.builds.find((b) => b.is_profile_default) || p.builds[0])) || null;
    state.bw_home = defaultBuild(profileOf(state.profile))?.bw_home || "";

    // pre-selection from the URL (Run buttons on the suite pages)
    if (view.query.suite) {
      const s = suiteByName.get(view.query.suite);
      if (s && view.query.test) {
        state.tests.add(`${s.name}::${view.query.test}`);
        state.expanded.add(s.name);
      } else if (s) state.suites.add(s.name);
      state.step = 0;
    }
    // explorer tree "Saved selections" and menu Edit > Select test cases open the wizard at step 2
    if (view.query.selection) {
      const sel = selections.find((x) => x.name === view.query.selection);
      if (sel) {
        sel.suites.filter((n) => suiteByName.has(n)).forEach((n) => state.suites.add(n));
        sel.tests.forEach((t) => state.tests.add(t));
        state.step = 1;
      }
    }
    if (view.query.step && state.bw_home) state.step = Math.min(3, Math.max(0, Number(view.query.step) - 1)) || 0;

    const root = h("div", { class: "stack" });
    const stepperHost = h("div");
    const body = h("div");
    const nav = h("div", { class: "wizard-nav" });
    root.append(
      pageHeader("New run", "Pick the BW build, choose test cases, add report details and start. "
        + "Everything you choose here is also shown as a command line, so you can repeat it in a terminal or Jenkins."),
      stepperHost, body, nav);

    const homeOk = () => Boolean((state.useCustom ? state.customHome : state.bw_home).trim());
    const hasSelection = () => state.suites.size || state.tests.size;
    const canGo = (step) => (step >= 1 ? homeOk() : true) && (step >= 2 ? hasSelection() : true);

    function go(step) {
      if (!canGo(step)) {
        toast(step >= 2 && !hasSelection() ? "Select at least one suite or test first." : "Select a build first.", "warn");
        return;
      }
      state.step = step;
      render();
      window.scrollTo(0, 0);
    }

    function render() {
      mount(stepperHost, stepper(STEPS, state.step, (i) => go(i)));
      const views = [stepBuild, stepTests, stepReport, stepReview];
      mount(body, views[state.step]());
      const back = state.step > 0 ? h("button", { class: "btn", onclick: () => go(state.step - 1) }, "← Back") : h("span");
      const next = state.step < 3
        ? h("button", { class: "btn primary", onclick: () => go(state.step + 1) }, `Next: ${STEPS[state.step + 1].title} →`)
        : null;
      mount(nav, back, next);
    }

    // ------------------------------------------------------------------ step 1: product & build
    function stepBuild() {
      const profile = profileOf(state.profile);
      const result = h("div");
      const showCheck = () => {
        const c = state.buildCheck;
        if (!c) return mount(result);
        const failed = c.checks.filter((x) => !x.ok && !x.label.includes("suite files"));
        const version = c.checks.find((x) => x.label === "bwadmin version");
        mount(result, callout(failed.length ? "warn" : "ok", failed.length ? "Build check found problems:" : "Build looks good.",
          version ? h("div", {}, `bwadmin reports: ${version.detail}`) : null,
          failed.map((f) => h("div", {}, `✗ ${f.label}: ${f.detail}${f.hint ? ` → ${f.hint}` : ""}`))));
      };
      showCheck();
      const customInput = pathInput({ value: state.customHome, placeholder: "C:/D/6.12.1/V13/bw/6.12", kind: "folder",
        onchange: (v) => { state.customHome = v; } });

      return h("div", { class: "stack" },
        card({ title: "1. Product profile (BW version)",
               help: "A profile = one BW version. It sets version-specific defaults. Files: config/profiles/<version>.yaml (old *.profile)." },
          h("div", { class: "choices" }, profilesData.profiles.map((p) =>
            h("button", { type: "button", class: ["choice", p.name === state.profile && "selected"], onclick: () => {
              state.profile = p.name;
              state.bw_home = defaultBuild(p)?.bw_home || "";
              state.useCustom = false;
              state.buildCheck = null;
              render();
            } },
              p.name === profilesData.default ? h("span", { class: "badge-default" }, pill("info", "default")) : null,
              h("div", { class: "choice-title" }, `BW ${p.name}`),
              h("div", { class: "choice-sub" }, p.error ? `⚠ ${p.error}` : plural(p.builds.length, "build") + " found"))))),
        card({ title: "2. Build to test",
               help: `Builds are found automatically below ${profilesData.builds_root || "ui.builds_root"} (any layout, e.g. 6.12.1/V12/bw/6.12 or BW6121/bw/6.12). `
                 + "Change the folder on the Preferences page. Old t-tests: INSTALL_HOME in the product profile." },
          profile && profile.builds.length
            ? h("div", { class: "choices" }, profile.builds.map((b) =>
              h("button", { type: "button", class: ["choice", !state.useCustom && b.bw_home === state.bw_home && "selected"],
                onclick: () => { state.bw_home = b.bw_home; state.useCustom = false; state.buildCheck = null; render(); } },
                b.is_profile_default ? h("span", { class: "badge-default" }, pill("muted", "profile default")) : null,
                h("div", { class: "choice-title" }, b.label, !b.has_bwadmin ? h("span", { class: "muted small" }, "  (no bwadmin!)") : ""),
                h("div", { class: "choice-sub" }, b.bw_home))))
            : empty("No builds found for this profile",
              `Install the build below ${profilesData.builds_root} or type its folder below.`),
          h("div", { style: { marginTop: "14px" } },
            checkbox("Use another BW home folder", state.useCustom, (v) => { state.useCustom = v; state.buildCheck = null; render(); }),
            state.useCustom ? field("BW home (folder that contains bin/bwadmin - INSTALL_HOME works too)", customInput, "Example: C:/D/6.12.1/V13/bw/6.12 or C:/bw6/BW6121") : null),
          h("div", { class: "row", style: { marginTop: "10px" } },
            button("Check this build", async () => {
              state.buildCheck = await api.doctor({ profile: state.profile, bw_home: currentHome(), detect_version: true });
              showCheck();
            }),
            h("span", { class: "muted small" }, "Optional - runs `bwadmin version` (takes a few seconds).")),
          result));
    }

    const currentHome = () => (state.useCustom ? state.customHome.trim().replace(/\\/g, "/") : state.bw_home);

    // ------------------------------------------------------------------ step 2: tests
    function stepTests() {
      const tree = h("div", { class: "tree" });
      const summary = h("div");
      const selectionSelect = select([["", "— load a saved selection —"], ...selections.map((s) => [s.name, s.name])], "");

      const visible = () => suites.filter((s) => !s.error
        && (state.type === "all" || s.type === state.type)
        && (!state.search || matches(s)));
      const matches = (s) => {
        const q = state.search.toLowerCase();
        if (`${s.name} ${s.description} ${(s.tags || []).join(" ")} ${folderOf(s)}`.toLowerCase().includes(q)) return true;
        const d = details.get(s.name);
        return d ? d.test_list.some((t) => `${t.id} ${t.description}`.toLowerCase().includes(q)) : false;
      };

      function suiteState(s) {
        if (state.suites.has(s.name)) return "all";
        for (const key of state.tests) if (key.startsWith(`${s.name}::`)) return "some";
        return "none";
      }

      async function toggleExpand(s) {
        if (state.expanded.has(s.name)) state.expanded.delete(s.name);
        else {
          state.expanded.add(s.name);
          if (!details.has(s.name)) {
            drawTree();
            details.set(s.name, await api.suite(s.name));
          }
        }
        drawTree();
      }

      function setSuite(s, on) {
        state.suites.delete(s.name);
        for (const key of [...state.tests]) if (key.startsWith(`${s.name}::`)) state.tests.delete(key);
        if (on) state.suites.add(s.name);
      }

      function toggleSuite(s, on) {
        setSuite(s, on);
        drawTree();
      }

      function toggleFolder(id) {
        if (state.openFolders.has(id)) state.openFolders.delete(id); else state.openFolders.add(id);
        drawTree();
      }

      // folders that hold selected suites / tests are opened, so the selection is visible
      const selectedNames = new Set([...state.suites, ...[...state.tests].map((t) => t.split("::")[0])]);
      for (const name of selectedNames) {
        const s = suiteByName.get(name);
        const parts = s ? folderOf(s).split("/") : [];
        parts.forEach((_, i) => state.openFolders.add(parts.slice(0, i + 1).join("/")));
      }

      function toggleTest(s, testId, on) {
        const d = details.get(s.name);
        if (state.suites.has(s.name)) { // switch from "whole suite" to single tests
          state.suites.delete(s.name);
          d.test_list.forEach((t) => state.tests.add(`${s.name}::${t.id}`));
        }
        const key = `${s.name}::${testId}`;
        if (on) state.tests.add(key); else state.tests.delete(key);
        if (d && d.test_list.every((t) => state.tests.has(`${s.name}::${t.id}`))) { // all picked = whole suite
          d.test_list.forEach((t) => state.tests.delete(`${s.name}::${t.id}`));
          state.suites.add(s.name);
        }
        drawTree();
      }

      const byName = (a, b) => a.localeCompare(b, undefined, { sensitivity: "base" });
      const allSuites = (node) => [...node.suites, ...[...node.folders.values()].flatMap(allSuites)];

      function folderTree(list) { // engine > jdbc > oracle > suites (as the folders under suites/)
        const root = { folders: new Map(), suites: [] };
        for (const s of list) {
          let node = root;
          for (const part of folderOf(s).split("/")) {
            if (!node.folders.has(part)) node.folders.set(part, { folders: new Map(), suites: [] });
            node = node.folders.get(part);
          }
          node.suites.push(s);
        }
        return root;
      }

      function folderRows(node, path) {
        return [
          ...[...node.folders.keys()].sort(byName).map((name) => {
            const sub = node.folders.get(name);
            const id = path ? `${path}/${name}` : name;
            const inside = allSuites(sub);
            const states = inside.map(suiteState);
            const all = states.every((x) => x === "all");
            const open = Boolean(state.search) || state.openFolders.has(id);
            return h("div", { class: "tree-folder" },
              h("div", { class: "tree-row tree-folder-row" },
                h("button", { class: "tree-toggle", onclick: () => toggleFolder(id), title: open ? "Close folder" : "Open folder" },
                  open ? "▼" : "▶"),
                h("input", { type: "checkbox", checked: all, indeterminate: !all && states.some((x) => x !== "none"),
                  title: `Tick all ${inside.length} suites in ${name}`, "aria-label": `select folder ${id}`,
                  onchange: (e) => { inside.forEach((s) => setSuite(s, e.target.checked)); drawTree(); } }),
                h("span", { class: "tree-name", style: { cursor: "pointer" }, onclick: () => toggleFolder(id) }, `${open ? "📂" : "📁"} ${name}`),
                h("span", { class: "tree-meta" },
                  h("span", {}, plural(inside.length, "suite")),
                  h("span", {}, plural(inside.reduce((n, s) => n + (s.tests || 0), 0), "test")))),
              open ? h("div", { class: "tree-folder-children" }, folderRows(sub, id)) : null);
          }),
          ...node.suites.sort((a, b) => byName(a.name, b.name)).map(suiteRow),
        ];
      }

      function drawTree() {
        const list = visible();
        const scroll = tree.scrollTop;
        mount(tree, list.length ? folderRows(folderTree(list), "") : empty("No suites match", "Change the filter or the search text."));
        tree.scrollTop = scroll;
        drawSummary();
      }

      function suiteRow(s) {
          const st = suiteState(s);
          const open = state.expanded.has(s.name);
          const d = details.get(s.name);
          const box = h("input", { type: "checkbox", checked: st === "all", indeterminate: st === "some",
            onchange: (e) => toggleSuite(s, e.target.checked), "aria-label": `select suite ${s.name}` });
          return h("div", { class: "tree-suite" },
            h("div", { class: "tree-row" },
              h("button", { class: "tree-toggle", onclick: () => toggleExpand(s), title: open ? "Hide tests" : "Show tests" }, open ? "▼" : "▶"),
              box,
              h("span", { class: "tree-name", style: { cursor: "pointer" }, onclick: () => toggleExpand(s) }, s.name),
              h("span", { class: "muted small" }, s.description && s.description.length > 70 ? `${s.description.slice(0, 70)}…` : s.description),
              h("span", { class: "tree-meta" },
                s.type === "bw_migration" ? pill("info", "migration") : null,
                s.bridged ? h("span", { title: "one step of the test is a .sh script - T-Next runs it itself (Git Bash)" }, `${s.bridged} with .sh step`) : null,
                s.known_to_fail ? pill("known", `${s.known_to_fail} known`) : null,
                h("span", {}, plural(s.tests, "test")))),
            open ? h("div", { class: "tree-tests" }, !d ? loading("Loading tests…") : d.test_list
              .filter((t) => !state.search || `${t.id} ${t.description}`.toLowerCase().includes(state.search.toLowerCase())
                || `${s.name} ${s.description}`.toLowerCase().includes(state.search.toLowerCase()))
              .map((t) => h("label", { class: "tree-row" },
                h("input", { type: "checkbox", checked: st === "all" || state.tests.has(`${s.name}::${t.id}`),
                  onchange: (e) => toggleTest(s, t.id, e.target.checked) }),
                h("span", { class: "mono" }, t.id),
                h("span", { class: "muted small" }, t.description),
                h("span", { class: "tree-meta" },
                  t.known_to_fail ? pill("known", t.known_to_fail) : null,
                  t.skip ? pill("muted", "skip") : null,
                  t.legacy ? h("span", { title: "one step of the test is a .sh script - T-Next runs it itself (Git Bash)" }, ".sh step") : null)))) : null);
      }

      function drawSummary() {
        let count = 0;
        for (const name of state.suites) count += suiteByName.get(name)?.tests || 0;
        count += state.tests.size;
        mount(summary,
          kv([["Whole suites", state.suites.size ? [...state.suites].join(", ") : "—"],
              ["Single tests", state.tests.size ? [...state.tests].map((t) => t.split("::")[1]).join(", ") : "—"],
              ["Test cases", h("b", {}, count.toLocaleString())]]),
          count > 300 ? callout("warn", "Large run.", `${count.toLocaleString()} tests can take many hours. Consider parallel workers in the next step.`) : null,
          h("div", { class: "row", style: { marginTop: "12px" } },
            button("Clear", () => { state.suites.clear(); state.tests.clear(); drawTree(); }, "small"),
            button("Save as selection…", saveSelection, "small")));
      }

      async function saveSelection() {
        if (!hasSelection()) { toast("Nothing selected yet.", "warn"); return; }
        const name = await promptDialog("Save selection", "Name", "",
          "Saved in config/selections/<name>.yaml (like the old .testcmd files) - share it through git.");
        if (!name) return;
        await api.saveSelection(name, { suites: [...state.suites], tests: [...state.tests] });
        selections.push({ name, suites: [...state.suites], tests: [...state.tests] });
        toast(`Selection '${name}' saved.`);
        notifyChanged();
        render();
      }

      async function loadSelection(name) {
        const sel = selections.find((s) => s.name === name);
        if (!sel) return;
        state.suites = new Set(sel.suites.filter((n) => suiteByName.has(n)));
        state.tests = new Set(sel.tests);
        const missing = sel.suites.filter((n) => !suiteByName.has(n));
        if (missing.length) toast(`Unknown suites ignored: ${missing.join(", ")}`, "warn");
        render();
      }

      async function deleteSelection(name) {
        if (!name || !(await confirmDialog("Delete selection", `Delete saved selection '${name}'?`, "Delete", "danger-solid"))) return;
        await api.deleteSelection(name);
        selections.splice(selections.findIndex((s) => s.name === name), 1);
        notifyChanged();
        render();
      }

      const searchBox = input({ class: "input search", placeholder: "Search suites or test ids (e.g. http, bw.3647)", value: state.search,
        oninput: (e) => { state.search = e.target.value; clearTimeout(searchBox._t); searchBox._t = setTimeout(drawTree, 200); } });
      const typeSel = select([["all", "All test types"], ["bw_engine", "Engine (BW_ENGINE)"], ["bw_migration", "Migration (BW_MIGRATION)"]],
        state.type, { style: { width: "auto" }, onchange: (e) => { state.type = e.target.value; drawTree(); } });
      selectionSelect.addEventListener("change", (e) => loadSelection(e.target.value));

      drawTree();
      return h("div", { class: "grid grid-side" },
        card({ title: "Select test cases", subtitle: "Tick a suite to run all its tests, or open it (▶) to pick single tests.",
               help: "Old t-tests: Edit > Select test cases. Engine/Migration = the old 'Types of testing'." },
          h("div", { class: "picker-toolbar" }, searchBox, typeSel, h("span", { class: "spacer" }),
            selectionSelect, selections.length ? h("button", { class: "btn small ghost", title: "Delete the selected saved selection",
              onclick: () => deleteSelection(selectionSelect.value) }, "Delete") : null),
          tree),
        h("div", { class: "stack selection-summary" },
          card({ title: "Your selection" }, summary)));
    }

    // ------------------------------------------------------------------ step 3: report + options
    function stepReport() {
      const bind = (key) => (e) => { state[key] = e.target.value; };
      return h("div", { class: "grid grid-2" },
        card({ title: "Report details", help: "Shown in the run list and in report.html. Old t-tests: Preferences > Report." },
          field("Run name", input({ value: state.name, placeholder: `e.g. ${state.profile} ${buildLabel()} HTTP regression`, oninput: bind("name") }),
            "Helps you find the run later."),
          field("Tester", input({ value: state.tester, placeholder: "your name", oninput: bind("tester") }),
            "Default from Preferences > Default tester name."),
          field("Jira", input({ value: state.jira, placeholder: "e.g. BUG-58468", oninput: bind("jira") }), "Ticket(s) this run verifies (optional)."),
          field("Notes", textarea({ value: state.notes, rows: 3, placeholder: "anything worth knowing about this run", oninput: bind("notes") }))),
        card({ title: "Run options" },
          field("Parallel workers", select([["0", "1 - one suite after the other (safe default)"], ["2", "2 workers"], ["3", "3 workers"], ["4", "4 workers"]],
            String(state.workers), { onchange: (e) => { state.workers = Number(e.target.value); } }),
            "Each worker gets its own BW domain and ports. Needs RAM: one AppNode per worker."),
          checkbox("Dry run - only show the BW commands, run nothing", state.dry_run, (v) => { state.dry_run = v; },
            "Good for checking a new suite without BW."),
          checkbox("Update gold files with the new output", state.update_gold, (v) => { state.update_gold = v; },
            "Only for new tests or intended behaviour changes. Review the changed gold files afterwards!"),
          checkbox("Keep the BW domain after the run", state.keep_domain, (v) => { state.keep_domain = v; },
            "To inspect AppSpace/AppNode after the run. Delete it yourself later.")));
    }

    function buildLabel() {
      const p = profileOf(state.profile);
      const b = p && p.builds.find((x) => x.bw_home === currentHome());
      return b ? b.label : "";
    }

    function requestBody() {
      return { profile: state.profile, bw_home: currentHome(), suites: [...state.suites], tests: [...state.tests],
               workers: state.workers, dry_run: state.dry_run,
               update_gold: state.update_gold, keep_domain: state.keep_domain,
               name: state.name.trim(), tester: state.tester.trim(), notes: state.notes.trim(), jira: state.jira.trim() };
    }

    // ------------------------------------------------------------------ step 4: review
    function stepReview() {
      const cmd = h("div", { class: "cmd" }, h("code", {}, "…"));
      api.previewRun(requestBody()).then((r) => {
        mount(cmd, h("code", {}, r.command), h("button", { class: "btn small", onclick: async () => {
          await navigator.clipboard.writeText(r.command); toast("Command copied");
        } }, "Copy"));
      }).catch((e) => mount(cmd, h("code", {}, `⚠ ${e.message}`)));
      let count = 0;
      for (const name of state.suites) count += suiteByName.get(name)?.tests || 0;
      count += state.tests.size;
      const start = button("▶  Start run", async () => {
        const { id } = await api.startRun(requestBody());
        toast(`Run ${id} started`);
        view.navigate(`/runs/${id}`);
      }, "primary big");

      return h("div", { class: "stack" },
        card({ title: "Review" },
          kv([
            ["Profile", `BW ${state.profile}`],
            ["Build", h("span", {}, h("b", {}, buildLabel() || "custom"), "  ", h("span", { class: "mono muted" }, currentHome()))],
            ["Suites", state.suites.size ? [...state.suites].join(", ") : "—"],
            ["Single tests", state.tests.size ? [...state.tests].join(", ") : "—"],
            ["Test cases", `about ${count.toLocaleString()}`],
            ["Run name", state.name || "—"], ["Tester", state.tester || "—"], ["Jira", state.jira || "—"],
            ["Options", [state.workers > 1 && `${state.workers} parallel workers`, state.dry_run && "dry run",
              state.update_gold && "UPDATE GOLD", state.keep_domain && "keep domain"]
              .filter(Boolean).join(", ") || "defaults"],
          ])),
        state.update_gold ? callout("warn", "Update gold is on.", "Current outputs will overwrite the expected results. Review them before committing.") : null,
        state.dry_run ? callout("info", "Dry run.", "No BW command is executed; you will see what would run.") : null,
        card({ title: "Same run from a terminal", help: "Run this in C:\\D\\bw6-autotest with the venv active - handy for Jenkins." }, cmd),
        h("div", { class: "row" }, start,
          h("span", { class: "muted" }, "The first suite needs ~3 minutes to start its AppNode. You can follow everything live.")));
    }

    render();
    return root;
  },
};
