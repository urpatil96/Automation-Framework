"""Saved test selections - the successor of t-tests `.testcmd` files (File > New TestCmd).

Stored as small YAML files in config/selections/<name>.yaml so they can be shared through git:

    description: HTTP smoke for every new build
    suites: [http_components]
    tests: ["http_components::bw.1499", "http_components::bw.1500"]
    marker: ""
    keyword: ""

Run one from the command line with the same values, or pick it on the New run page.
"""

from __future__ import annotations

import re
from pathlib import Path

import yaml

from ...errors import ConfigError

_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _.\-]{0,80}$")
KEYS = ("description", "suites", "tests", "marker", "keyword")


def _folder(config_dir: Path) -> Path:
    return config_dir / "selections"


def _file(config_dir: Path, name: str) -> Path:
    if not _NAME.match(name or ""):
        raise ConfigError("selection name: letters, digits, space, '_', '-', '.' (max 80)")
    return _folder(config_dir) / f"{name}.yaml"


def list_all(config_dir: Path) -> list[dict]:
    result = []
    for path in sorted(_folder(config_dir).glob("*.yaml")):
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError as exc:
            data = {"description": f"invalid YAML: {exc}"}
        result.append({"name": path.stem, **{k: data.get(k, [] if k in ("suites", "tests") else "")
                                             for k in KEYS}})
    return result


def save(config_dir: Path, name: str, data: dict) -> None:
    path = _file(config_dir, name)
    clean = {
        "description": str(data.get("description") or ""),
        "suites": [str(s) for s in data.get("suites") or []],
        "tests": [str(t) for t in data.get("tests") or []],
        "marker": str(data.get("marker") or ""),
        "keyword": str(data.get("keyword") or ""),
    }
    if not (clean["suites"] or clean["tests"] or clean["marker"] or clean["keyword"]):
        raise ConfigError("a selection needs at least one suite, test, tag or keyword")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(clean, sort_keys=False, allow_unicode=True), encoding="utf-8")


def delete(config_dir: Path, name: str) -> None:
    path = _file(config_dir, name)
    if not path.is_file():
        raise ConfigError(f"selection '{name}' not found")
    path.unlink()
