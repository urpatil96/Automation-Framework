"""State shared by all API routes of one UI server."""

from __future__ import annotations

from pathlib import Path

from ..config import Settings, load_settings
from .services.catalog import SuiteCatalog
from .services.runs import RunManager


class UiContext:
    def __init__(self, project_root: Path, config_dir: Path):
        self.root = Path(project_root).resolve()
        config_dir = Path(config_dir)
        self.config_dir = (config_dir if config_dir.is_absolute() else self.root / config_dir).resolve()
        base = self.settings()
        self.catalog = SuiteCatalog(self.root / "suites", base.paths.assets_root)
        self.runs = RunManager(self.root, self.config_dir, base.paths.results_dir)

    def settings(self, profile: str | None = None, bw_home: str | None = None) -> Settings:
        """Read fresh on every call: edits to config files show up without restarting the UI."""
        overrides = {"bw": {"home": bw_home}} if bw_home else None
        return load_settings(self.config_dir, profile or None, overrides)

    def suite_files(self) -> dict[str, str]:
        """suite name -> path relative to the project root (what `bwtest run` accepts)."""
        return {e.suite.name.lower(): self.catalog.rel(e.file) for e in self.catalog.entries() if e.suite}
