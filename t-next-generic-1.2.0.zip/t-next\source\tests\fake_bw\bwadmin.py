"""Fake bwadmin for the framework's self-tests (no BusinessWorks needed).

Understands the subset of commands bwtest uses. On `deploy` it "runs" the application: it reads the
module-properties profile (-pf) and writes the content of `fake_output.txt` from inside the EAR to the
path given by the TSI_TEST_OUTPUT_FILE property - exactly what a real BW test application does.
"""

import contextlib
import io
import json
import shlex
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

NS = "{*}"  # any namespace (ElementPath wildcard)


def main(argv: list[str], banner: bool = True) -> int:
    args = list(argv)
    state_dir = Path.cwd()
    if "-config" in args:
        i = args.index("-config")
        state_dir = Path(args[i + 1]).parent
        del args[i:i + 2]
    state_file = state_dir / "fake_bw_state.json"
    state = json.loads(state_file.read_text()) if state_file.exists() else {"archives": {}}

    def save():
        state_file.write_text(json.dumps(state))

    def opt(name):
        return args[args.index(name) + 1] if name in args else None

    if banner:
        print("ActiveMatrix BusinessWorks version 6.99.1, build V1, 2026-01-01")
    if not args or args[0] == "version":
        return 0
    cmd = args[0]
    if cmd not in ("create", "show", "start", "stop", "upload", "deploy", "undeploy", "delete"):
        print(f"Command not found: {cmd}")  # same text as the real bwadmin
        return 1
    if cmd == "create" and args[-2] == "domain":
        state["domain_home"] = opt("-home")
        Path(state["domain_home"], args[-1]).mkdir(parents=True, exist_ok=True)
    elif cmd == "create" and args[-2] == "appnode":
        node = Path(state["domain_home"], opt("-d"), "appnodes", opt("-a"), args[-1])
        (node / "log").mkdir(parents=True, exist_ok=True)
        (node / "config.ini").write_text("logback.configurationFile=logback.xml\n")
        (node / "log" / "bwappnode.log").write_text("BW-FRWK-300006 AppNode started\n")
        state["appnode_log"] = str(node / "log" / "bwappnode.log")
        state.setdefault("running", []).append(args[-1])
    elif cmd == "show":
        print("Name   Status   AppSpace")
        stopped = state.get("stopped", [])
        for name in state.get("running", []):
            print(f"{name}  {'Stopped' if name in stopped else 'Running'}  x")
    elif cmd == "stop" and args[-2] == "appnode":
        state.setdefault("stopped", []).append(args[-1])
    elif cmd == "upload":
        state["archives"][Path(args[-1]).name] = args[-1]
    elif cmd == "deploy":
        ear = state["archives"][args[-1]]
        profile = ET.parse(opt("-pf")).getroot()
        props = {gv.find(f"{NS}name").text.split("//")[-1]: (gv.find(f"{NS}value").text or "")
                 for gv in profile.iterfind(f".//{NS}globalVariable")}
        with zipfile.ZipFile(ear) as zf:
            content = zf.read("fake_output.txt").decode()
        for key, value in props.items():  # applications echo module properties into their output
            content = content.replace("{" + key + "}", value)
        Path(props["TSI_TEST_OUTPUT_FILE"]).write_text(content)
        state.setdefault("running", []).append(Path(ear).stem)
        with open(state["appnode_log"], "a") as fh:
            fh.write(f"BW-FRWK-300021 Started application {Path(ear).stem}\n")
    elif cmd == "start" and args[-2] == "appnode" and state.get("fail_start"):
        print("BW-ADMIN-CLI-500001: cannot start appnode")
        return 1
    save()
    return 0


def shell(config: list[str]) -> int:
    """Interactive mode, like `bwadmin` without a command: prompt, one command per line, `exit` ends."""
    print("ActiveMatrix BusinessWorks version 6.99.1, build V1, 2026-01-01")
    print("BusinessWorks Administration Console\n")
    while True:
        sys.stdout.write("bwadmin[admin]> ")
        sys.stdout.flush()
        line = sys.stdin.readline()
        if not line or line.strip() == "exit":
            return 0
        print(line.rstrip("\n"))  # echo, as the real shell does
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            main(config + shlex.split(line, posix=True), banner=False)
        sys.stdout.write(out.getvalue())


if __name__ == "__main__":
    argv = sys.argv[1:]
    config = argv[:2] if argv[:1] == ["-config"] else []
    if len(argv) == len(config):  # no command -> interactive shell
        sys.exit(shell(config))
    sys.exit(main(argv))
