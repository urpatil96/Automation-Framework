"""pytest integration.

    *.suite.yaml file      ->  pytest File   (setup = AppSpace/AppNode, teardown = stop + logs)
    each entry in tests:   ->  pytest Item   (runtest = TestExecutor.run)
    whole run / worker     ->  BwSession     (domain), created lazily on the first suite

So every pytest feature works out of the box:
    -k bw.645               select by id          -m "smoke and not jdbc"  select by tag
    -n 4 --dist loadfile    parallel suites (pytest-xdist; each worker gets its own domain + ports)
    --junitxml / --html     Jenkins / HTML reports
    --lf                    re-run only the last failures
"""

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path

import pytest

from . import events
from .config import Settings, load_settings
from .errors import BwTestError, VerificationFailed
from .executor import TestContext, TestExecutor
from .models import SuiteSpec, TestSpec, load_suite
from .runtime import BwSession, SuiteEnvironment

_SETTINGS = pytest.StashKey[Settings]()
_SESSION = pytest.StashKey[BwSession]()
_RUN_DIR = pytest.StashKey[Path]()
_SUITE_COUNTER = pytest.StashKey[list]()


# ----------------------------------------------------------------------------------------------
# options
# ----------------------------------------------------------------------------------------------
def pytest_addoption(parser: pytest.Parser) -> None:
    g = parser.getgroup("bwtest", "BusinessWorks regression framework")
    g.addoption("--bw-config", default=None, help="config directory (default: <rootdir>/config)")
    g.addoption("--bw-profile", default=None, help="profile name from config/profiles, e.g. 6.12.1")
    g.addoption("--bw-home", default=None, help="override bw.home (TIB_BW_HOME)")
    g.addoption("--bw-assets-root", default=None, help="override paths.assets_root (old tests/bw)")
    g.addoption("--bw-results", default=None, help="override paths.results_dir")
    g.addoption("--bw-dry-run", action="store_true", help="log all BW commands without executing them")
    g.addoption("--bw-keep-domain", action="store_true", help="do not delete the domain at the end")
    g.addoption("--update-gold", action="store_true",
                help="accept current outputs as new gold files (review with git diff before committing!)")


def _settings(config: pytest.Config) -> Settings:
    if _SETTINGS not in config.stash:
        opt = config.getoption
        overrides: dict = {}
        if opt("--bw-home"):
            overrides.setdefault("bw", {})["home"] = opt("--bw-home")
        if opt("--bw-assets-root"):
            overrides.setdefault("paths", {})["assets_root"] = opt("--bw-assets-root")
        if opt("--bw-results"):
            overrides.setdefault("paths", {})["results_dir"] = opt("--bw-results")
        overrides.update(dry_run=bool(opt("--bw-dry-run")), update_gold=bool(opt("--update-gold")),
                         keep_domain=bool(opt("--bw-keep-domain")))
        config_dir = opt("--bw-config") or os.environ.get("BWTEST_CONFIG") or Path(config.rootpath) / "config"
        config.stash[_SETTINGS] = load_settings(config_dir, opt("--bw-profile"), overrides)
    return config.stash[_SETTINGS]


def _run_dir(config: pytest.Config) -> Path:
    if _RUN_DIR not in config.stash:
        # Shared by xdist workers: the controller exports it before workers start.
        existing = os.environ.get("BWTEST_RUN_DIR")
        if existing:
            run_dir = Path(existing)
        else:
            settings = _settings(config)
            run_dir = settings.paths.results_dir / time.strftime("%Y%m%d-%H%M%S")
            os.environ["BWTEST_RUN_DIR"] = str(run_dir)
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir.parent / "LATEST").write_text(str(run_dir), encoding="utf-8")
        config.stash[_RUN_DIR] = run_dir
    return config.stash[_RUN_DIR]


def _worker_index(config: pytest.Config) -> int:
    worker = getattr(config, "workerinput", {}).get("workerid", "gw0")
    match = re.search(r"(\d+)$", worker)
    return int(match.group(1)) if match else 0


def _session(config: pytest.Config) -> BwSession:
    if _SESSION not in config.stash:
        session = BwSession(_settings(config), _run_dir(config), _worker_index(config))
        config.stash[_SESSION] = session  # stored before start() so a partial start is cleaned up
        session.start()
        v = session.version
        events.emit("environment", session.run_dir, worker=session.instance, domain=session.domain,
                    bw_home=str(session.settings.bw.home), profile=session.settings.profile,
                    bw_version=v.label if v else None, bw_build=v.build if v else None)
    return config.stash[_SESSION]


def pytest_configure(config: pytest.Config) -> None:
    config.stash[_SUITE_COUNTER] = [0]
    _IS_WORKER[0] = hasattr(config, "workerinput")
    config.addinivalue_line("markers", "known_to_fail: expected failure (old KnownToFail)")
    _add_report_metadata(config)


def _add_report_metadata(config: pytest.Config) -> None:
    """'Environment' table of report.html: only the run details entered in the UI / CLI (tester, build, notes ...).

    pytest-metadata fills it with Python, Platform, Packages, Plugins and env vars such as JAVA_HOME - not wanted.
    Cleared in every process: xdist workers send their table back to the main process at the end.
    """
    try:
        from pytest_metadata.plugin import metadata_key  # installed together with pytest-html
    except ImportError:
        return
    if metadata_key in config.stash:
        config.stash[metadata_key].clear()
    else:
        config.stash[metadata_key] = {}
    run_dir = events.run_dir_from_env()
    if run_dir is None or hasattr(config, "workerinput"):
        return
    info = events.read_run_info(run_dir)
    labels = {"name": "Run name", "tester": "Tester", "build": "Build", "profile": "Profile",
              "bw_home": "BW home", "jira": "Jira", "notes": "Notes", "targets": "Suites"}
    for key, label in labels.items():
        value = info.get(key)
        if value:
            config.stash[metadata_key][label] = ", ".join(value) if isinstance(value, list) else str(value)


@pytest.hookimpl(optionalhook=True)
def pytest_html_report_title(report) -> None:
    """Heading of report.html (pytest-html): 'T-Next - <run name>' instead of the file name."""
    run_dir = events.run_dir_from_env()
    name = events.read_run_info(run_dir).get("name") if run_dir else ""
    report.title = f"T-Next - {name}" if name else "T-Next - BusinessWorks 6 regression report"


def pytest_unconfigure(config: pytest.Config) -> None:
    session = config.stash.get(_SESSION, None)
    if session is not None:
        session.stop()


# ----------------------------------------------------------------------------------------------
# collection: *.suite.yaml -> SuiteFile -> BwCaseItem
# ----------------------------------------------------------------------------------------------
def pytest_collect_file(parent: pytest.Collector, file_path: Path):
    if file_path.name.endswith(".suite.yaml"):
        return SuiteFile.from_parent(parent, path=file_path)
    return None


def _marker_name(tag: str) -> str:
    return re.sub(r"\W", "_", tag).strip("_") or "tag"


class SuiteFile(pytest.File):
    spec: SuiteSpec
    runtime: SuiteEnvironment | None = None
    executor: TestExecutor | None = None

    def collect(self):
        settings = _settings(self.config)
        self.spec = load_suite(self.path, settings.paths.assets_root)
        for test in self.spec.tests:
            item = BwCaseItem.from_parent(self, name=test.id, spec=test)
            for tag in [*self.spec.tags, *test.tags, self.spec.type]:
                name = _marker_name(tag)
                self.config.addinivalue_line("markers", f"{name}: bwtest tag")
                item.add_marker(name)
            if not self.spec.enabled:
                item.add_marker(pytest.mark.skip(reason="suite disabled (enabled: false)"))
            if test.skip:
                item.add_marker(pytest.mark.skip(reason=test.skip))
            if test.known_to_fail:
                item.add_marker(pytest.mark.known_to_fail)
                item.add_marker(pytest.mark.xfail(reason=test.known_to_fail, raises=VerificationFailed,
                                                  strict=False))
            yield item

    def setup(self) -> None:
        if not self.spec.enabled:
            return
        counter = self.config.stash[_SUITE_COUNTER]
        counter[0] += 1
        session = _session(self.config)
        events.emit("suite", session.run_dir, suite=self.spec.name, phase="setup")
        setup_started = time.monotonic()
        self.runtime = SuiteEnvironment(session, self.spec, session.run_dir / self.spec.name, counter[0])
        try:
            self.runtime.start()
        except BaseException as exc:
            events.emit("suite", session.run_dir, suite=self.spec.name, phase="failed", message=str(exc)[:2000])
            self.runtime.stop()  # remove half-created AppSpace / drivers
            raise
        events.emit("suite", session.run_dir, suite=self.spec.name, phase="ready",
                    http_port=self.runtime.http_port, setup_s=round(time.monotonic() - setup_started, 1))
        self.executor = TestExecutor(self.runtime, self.runtime.client_vars)

    def teardown(self) -> None:
        if self.runtime is not None:
            events.emit("suite", self.runtime.session.run_dir, suite=self.spec.name, phase="teardown")
            self.runtime.stop()


class BwCaseItem(pytest.Item):
    def __init__(self, *, spec: TestSpec, **kwargs):
        super().__init__(**kwargs)
        self.spec = spec
        self.ctx: TestContext | None = None
        self.user_properties.append(("description", spec.description))

    def runtest(self) -> None:
        executor = self.parent.executor  # type: ignore[attr-defined]
        start = time.monotonic()
        try:
            self.ctx = executor.run(self.spec)
        finally:
            self.user_properties.append(("duration_s", round(time.monotonic() - start, 1)))
            self._attach_artifacts()

    def _attach_artifacts(self) -> None:
        last = self.parent.executor.last_ctx  # type: ignore[attr-defined]
        log_dir = last.log_dir if last else self.parent.runtime.dir / self.spec.safe_id  # type: ignore
        self.user_properties.append(("artifacts", str(log_dir)))
        if last is not None and last.timings:
            self.user_properties.append(("phases", dict(last.timings)))
        for name in ("diff.txt", "module_properties.txt", "bwappnode.log", "test.log"):
            path = log_dir / name
            if path.is_file() and path.stat().st_size:
                text = path.read_text(encoding="utf-8", errors="replace")
                self.add_report_section("call", name, text[-20000:])

    def repr_failure(self, excinfo, style=None):
        exc = excinfo.value
        if isinstance(exc, VerificationFailed):
            return f"FAILED  {self.spec.id}: {exc}\n\n{exc.details}".rstrip()
        if isinstance(exc, BwTestError):
            return f"ERROR   {self.spec.id}: {type(exc).__name__}: {exc}"
        return super().repr_failure(excinfo, style=style)

    def reportinfo(self):
        return self.path, self._yaml_line(), f"{self.parent.spec.name}::{self.spec.id}"  # type: ignore

    def _yaml_line(self) -> int:
        """0-based line of `id: <test>` in the suite file - shown in reports and used for skip locations."""
        pattern = re.compile(rf"id:\s*['\"]?{re.escape(self.spec.id)}['\"]?\s*(,|}}|$)")
        for number, line in enumerate(self.path.read_text(encoding="utf-8").splitlines()):
            if pattern.search(line) or line.strip() in (f"- {self.spec.id}", f"- '{self.spec.id}'"):
                return number
        return 0


# ----------------------------------------------------------------------------------------------
# live progress for the web UI (events.jsonl) and graceful stop (STOP file) - see events.py
# ----------------------------------------------------------------------------------------------
def pytest_collection_finish(session: pytest.Session) -> None:
    worker = getattr(session.config, "workerinput", {}).get("workerid")
    if worker not in (None, "gw0"):  # with xdist every worker collects the same items: report once
        return
    tests = []
    for item in session.items:
        if isinstance(item, BwCaseItem):
            spec = item.spec
            tests.append({"nodeid": item.nodeid, "suite": item.parent.spec.name, "id": spec.id,  # type: ignore
                          "description": spec.description, "known_to_fail": spec.known_to_fail,
                          "skip": spec.skip})
        else:  # hand-written Python tests
            doc = (getattr(getattr(item, "function", None), "__doc__", "") or "").strip().splitlines()
            tests.append({"nodeid": item.nodeid, "suite": item.path.stem, "id": item.name,
                          "description": doc[0] if doc else "", "known_to_fail": None, "skip": None})
    events.emit("collected", tests=tests)


@pytest.hookimpl(tryfirst=True)
def pytest_runtest_setup(item: pytest.Item) -> None:
    # Runs before the suite environment of this item is created, so a stop never leaves a half-started
    # AppNode behind. Suites that are already running are torn down normally.
    if events.stop_requested():
        item.session.shouldstop = "stop requested (STOP file in the run folder)"
        pytest.skip("run stopped by user")
    # Fail fast - BEFORE AppSpace/AppNode/deploy - when a test needs an old .sh script and Git Bash is missing
    if isinstance(item, BwCaseItem) and _needs_bash(item):
        settings = _settings(item.config)
        if not settings.dry_run:
            problem = _bash_problem(settings.paths.bash)
            if problem:
                pytest.fail(f"{problem}\nThis test has an old t-tests .sh step. Install Git for Windows "
                            "(https://git-scm.com/download/win, 'Only for me' needs no admin), then restart T-Next.",
                            pytrace=False)


_BASH_PROBLEM: dict[str, str] = {}  # configured path -> "" (found) or the error, looked up once per process


def _bash_problem(configured: str) -> str:
    if configured not in _BASH_PROBLEM:
        from .legacy.bridge import find_bash

        try:
            find_bash(configured)
            _BASH_PROBLEM[configured] = ""
        except BwTestError as exc:
            _BASH_PROBLEM[configured] = str(exc)
    return _BASH_PROBLEM[configured]


def _needs_bash(item: BwCaseItem) -> bool:
    """Does this test run an old .sh script (legacy setup / action / verify, or a `legacy:` action step)?"""
    suite = getattr(item.parent, "spec", None)
    test = item.spec
    if test.legacy or (suite is not None and suite.legacy):
        return True
    verify = test.verify
    if (isinstance(verify, dict) and verify.get("type") == "legacy") or verify == "legacy":
        return True
    return any(isinstance(step, dict) and "legacy" in step for step in test.action or [])


_IS_WORKER = [False]  # xdist workers forward reports to the controller, which writes the events


def pytest_runtest_logstart(nodeid: str, location) -> None:
    if not _IS_WORKER[0]:
        events.emit("start", nodeid=nodeid)


def pytest_runtest_logreport(report: pytest.TestReport) -> None:
    outcome = _outcome(report)
    if outcome is None or _IS_WORKER[0]:
        return
    props = dict(report.user_properties)
    message = ""
    if outcome in ("failed", "error", "teardown_error"):
        message = report.longreprtext[-6000:]
    elif outcome == "xfailed":
        message = str(getattr(report, "wasxfail", ""))
    elif outcome == "skipped":
        message = str(report.longrepr[2] if isinstance(report.longrepr, tuple) else report.longrepr or "")
    events.emit("result", nodeid=report.nodeid, when=report.when, outcome=outcome,
                duration=props.get("duration_s", round(report.duration, 1)), message=message,
                artifacts=props.get("artifacts", ""), phases=props.get("phases"))


def _outcome(report: pytest.TestReport) -> str | None:
    """One final outcome per test: a setup problem, the call result, or a teardown error."""
    xfail = hasattr(report, "wasxfail")
    if report.when == "setup":
        if report.failed:
            return "error"
        if report.skipped:
            return "xfailed" if xfail else "skipped"
        return None
    if report.when == "call":
        if xfail:
            return "xpassed" if report.passed else "xfailed"
        return report.outcome  # passed | failed | skipped
    if report.when == "teardown" and report.failed:
        return "teardown_error"
    return None


# ----------------------------------------------------------------------------------------------
# summary
# ----------------------------------------------------------------------------------------------
def pytest_terminal_summary(terminalreporter, exitstatus, config: pytest.Config) -> None:
    if hasattr(config, "workerinput"):
        return
    # The run folder exists once a suite started; if every test was skipped/stopped before that, use the
    # folder given by `bwtest run` so the summary is still written.
    run_dir = config.stash.get(_RUN_DIR, None) or events.run_dir_from_env()
    if run_dir is None or not run_dir.is_dir():
        return
    stats = {k: len(v) for k, v in terminalreporter.stats.items() if k}
    (run_dir / "summary.json").write_text(json.dumps({"exit": int(exitstatus), **stats}, indent=2))
    events.emit("finished", run_dir, exit=int(exitstatus), stats=stats, stopped=events.stop_requested(run_dir))
    terminalreporter.write_sep("-", "T-Next")
    terminalreporter.write_line(f"results : {run_dir}")
    terminalreporter.write_line(f"commands: {run_dir}/worker-*/commands.log  (replayable bwadmin calls)")


# ----------------------------------------------------------------------------------------------
# fixtures for hand-written Python tests (see suites/examples/test_python_style.py)
# ----------------------------------------------------------------------------------------------
@pytest.fixture(scope="session")
def bw_settings(pytestconfig) -> Settings:
    return _settings(pytestconfig)


@pytest.fixture(scope="session")
def bw_session(pytestconfig) -> BwSession:
    return _session(pytestconfig)


@pytest.fixture(scope="module")
def bw_suite(pytestconfig, request):
    """Factory: start an AppSpace/AppNode from a suite file and get an executor for its tests.

        def test_x(bw_suite):
            suite = bw_suite("suites/engine/http/http_components/http_components.suite.yaml")
            ctx = suite.run("bw.645")
    """
    started: list[SuiteEnvironment] = []

    class _Handle:
        def __init__(self, runtime: SuiteEnvironment):
            self.runtime = runtime
            self.executor = TestExecutor(runtime, runtime.client_vars)

        def run(self, test_id: str) -> TestContext:
            spec = next(t for t in self.runtime.suite.tests if t.id == test_id)
            return self.executor.run(spec)

    def factory(path: str | Path) -> _Handle:
        settings = _settings(pytestconfig)
        spec = load_suite(Path(pytestconfig.rootpath) / path, settings.paths.assets_root)
        session = _session(pytestconfig)
        runtime = SuiteEnvironment(session, spec, session.run_dir / f"py-{spec.name}", 40 + len(started))
        started.append(runtime)
        runtime.start()
        return _Handle(runtime)

    yield factory
    for runtime in reversed(started):
        runtime.stop()
