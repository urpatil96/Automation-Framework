"""BW runtime lifecycle: Domain -> AppSpace -> AppNode -> Application.

Replaces BW_ENGINE.sh (t_start_bwagent, t_create_domain, t_create_appspace, t_create_appnode,
t_start_appnode, t_deploy_application, t_undeploy_application, t_stop_appnode, t_delete_domain) and
removes its per-suite `case` statements: drivers and databases are now declared in
config/drivers.yaml + config/databases.yaml and referenced by name from the suite file.

Scopes (= pytest scopes):
    BwSession         one per test run / xdist worker   -> domain (+ bwagent in enterprise mode)
    SuiteEnvironment  one per suite file                -> drivers, DB reset, AppSpace, AppNode
    deploy()/undeploy one per test case                 -> upload EAR, deploy with profile, undeploy
"""

from __future__ import annotations

import glob
import re
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

from . import slots
from .bwcli import NO_CONSOLE, BwCli, BwVersion, CommandLog
from .config import DatabaseSpec, DriverSpec, Settings
from .errors import BwCommandError, ConfigError, EnvironmentSetupError
from .models import SuiteSpec
from .substvar import load_cfg_files
from .templating import render_deep

_STATUSES = {"running", "stopped", "starting", "stopping", "impaired", "degraded", "unreachable",
             "deployed", "preparing", "undeployed"}
OWNER_MARKER = ".bwtest-owned"  # only domains carrying this file are ever deleted by bwtest


def _is_set(path: Path) -> bool:
    return str(path) not in ("", ".")


class BwSession:
    """Domain (and bwagent) shared by all suites of one run / one parallel worker."""

    def __init__(self, settings: Settings, run_dir: Path, instance: int = 0):
        self.settings = settings
        self.instance = instance
        self.run_dir = run_dir
        self.work_dir = run_dir / f"worker-{instance}"
        self.work_dir.mkdir(parents=True, exist_ok=True)
        # slot = which of several runs at the same time this is (slots.py); slot 0 = the old names/ports
        self.slot = slots.current()
        self.domain = slots.domain_name(settings.bw.domain_prefix, self.slot, instance)
        self.port_index = slots.port_index(self.slot, instance)
        self.agent_ini = self.work_dir / "bwagent.ini"
        self.cli = BwCli(settings, CommandLog(self.work_dir / "commands.log"), self.agent_ini, self.work_dir)
        self.version: BwVersion | None = None
        self._agent: subprocess.Popen | None = None
        self._started = False
        self.keep_for_inspection = False  # set when something could not be stopped cleanly

    # ------------------------------------------------------------------------------------------
    def start(self) -> None:
        if self._started:
            return
        s = self.settings
        if not s.dry_run and not (s.bw.home / "bin").is_dir() and "bwadmin" not in s.bw.tool_overrides:
            raise ConfigError(f"bw.home '{s.bw.home}' has no bin/ folder. Set bw.home in config/local.yaml, "
                              f"BWTEST__BW__HOME or --bw-home.")
        self._prepare_agent_ini()  # before the first bwadmin command: the shared bwadmin shell reads it
        self.version = self.cli.version(self.work_dir / "version")
        if s.bw.admin_mode == "enterprise":
            self._start_agent()
        domain_dir = s.bw.domain_home / self.domain
        if not s.dry_run and domain_dir.exists():
            if not (domain_dir / OWNER_MARKER).exists():
                raise EnvironmentSetupError(
                    f"Domain folder {domain_dir} exists but was not created by T-Next - refusing to touch it. "
                    f"Delete it yourself or set bw.domain_prefix to another name.")
            # Leftover from a crashed bwtest run: remove so we always start clean.
            self.cli.bwadmin("delete", "-force", "domain", self.domain, check=False, note="remove stale domain")
            shutil.rmtree(domain_dir, ignore_errors=True)
        self.cli.bwadmin("create", "-home", str(s.bw.domain_home), "domain", self.domain, note="create domain")
        if not s.dry_run and domain_dir.is_dir():
            (domain_dir / OWNER_MARKER).write_text("created by bwtest - safe to delete", encoding="utf-8")
        self._started = True

    def stop(self) -> None:
        if not self._started:
            self.cli.close()
            return
        from . import events

        events.emit("bwadmin", self.run_dir, worker=self.instance, shell=self.cli.stats["shell_calls"] > 0,
                    **self.cli.stats)
        try:
            if self.settings.bw.cleanup_domain and not self.settings.keep_domain and not self.keep_for_inspection:
                self.cli.bwadmin("delete", "-force", "domain", self.domain, check=False, note="delete domain")
        finally:
            self.cli.close()
            if self._agent is not None:
                self._agent.terminate()
                try:
                    self._agent.wait(timeout=60)
                except subprocess.TimeoutExpired:
                    self._agent.kill()
            self._started = False

    # ------------------------------------------------------------------------------------------
    def _prepare_agent_ini(self) -> None:
        source = self.settings.bw.home / "config" / "bwagent.ini"
        text = source.read_text(encoding="utf-8") if source.is_file() else ""
        if self.settings.bw.admin_mode == "enterprise":
            datastore = self.work_dir / ".datastore"
            shutil.rmtree(datastore, ignore_errors=True)
            datastore.mkdir(parents=True)
            import socket

            text = _set_ini(text, "bw.admin.mode", "enterprise")
            text = _set_ini(text, "bw.agent.memberName", socket.gethostname())
            text = _set_ini(text, "bw.agent.technology.as.dataStoreLocation", datastore.as_posix())
        self.agent_ini.write_text(text, encoding="utf-8")

    def _start_agent(self) -> None:
        log_file = self.work_dir / "bwagent.out.log"
        self._agent = self.cli.start_agent(log_file)
        if self._agent is None:
            return
        # Old framework slept a fixed 60s. We poll for the "agent started" message instead.
        deadline = time.monotonic() + self.settings.bw.agent_start_timeout
        while time.monotonic() < deadline:
            if self._agent.poll() is not None:
                raise EnvironmentSetupError(f"bwagent exited with code {self._agent.returncode}; see {log_file}")
            if "BW-FRWK-ENGDEP-300002" in log_file.read_text(encoding="utf-8", errors="replace") or \
                    self.cli.bwadmin("show", "agents", check=False, note="poll agent").ok:
                return
            time.sleep(3)
        raise EnvironmentSetupError(f"bwagent did not start within {self.settings.bw.agent_start_timeout}s")


def _same_file(src: Path, dest: Path) -> bool:
    """Already copied (copy2 keeps the modification time): same size and time."""
    try:
        a, b = src.stat(), dest.stat()
    except OSError:
        return False
    return a.st_size == b.st_size and abs(a.st_mtime - b.st_mtime) < 2


def _set_ini(text: str, key: str, value: str) -> str:
    pattern = re.compile(rf"^{re.escape(key)}\s*=.*$", re.M)
    line = f"{key}={value}"
    return pattern.sub(line.replace("\\", "/"), text) if pattern.search(text) else text + f"\n{line}\n"


# ==============================================================================================
@dataclass
class Deployment:
    app_name: str
    version: str
    ear_name: str


class SuiteEnvironment:
    """AppSpace + AppNode for one suite (old TSI_COMPONENT), plus its drivers and DB reset."""

    def __init__(self, session: BwSession, suite: SuiteSpec, suite_dir: Path, suite_index: int = 0):
        self.session = session
        self.settings = session.settings
        self.cli = session.cli
        self.suite = suite
        self.dir = suite_dir
        self.dir.mkdir(parents=True, exist_ok=True)
        self.appspace = suite.name
        self.appnode = suite.name
        base = self.settings.ports.stride * session.port_index + (suite_index % 50) * 2
        self.http_port = self.settings.ports.http_base + base
        self.osgi_port = self.settings.ports.osgi_base + base
        if self.osgi_port > 65535 or self.http_port > 65535:
            raise ConfigError(f"port {max(self.http_port, self.osgi_port)} is out of range - use fewer parallel "
                              "workers or lower ports.http_base / ports.osgi_base")
        # Suite .cfg files: app.clientVar.X -> module properties, everything else -> appnode config.ini
        self.client_vars, cfg_engine_props = load_cfg_files(suite.client_vars_files)
        self.appnode_properties = {**self.settings.bw.appnode_properties, **cfg_engine_props,
                                   **suite.appnode_properties}
        self._installed_drivers: list[str] = []
        self._started = False

    @property
    def appnode_dir(self) -> Path:
        return (self.settings.bw.domain_home / self.session.domain / "appnodes" / self.appspace
                / self.appnode)

    @property
    def appnode_log(self) -> Path:
        return self.appnode_dir / "log" / "bwappnode.log"

    # ------------------------------------------------------------------------------------------
    def start(self) -> None:
        d = self.session.domain
        for name in self.suite.drivers:
            self._install_driver(name)
        for name in self.suite.databases:
            self._reset_database(name)

        self.cli.bwadmin("create", "-d", d, "appspace", self.appspace, note=f"create appspace {self.appspace}")
        if self.suite.appspace_config_ini:
            target = self.settings.bw.domain_home / d / "appspaces" / self.appspace / "config.ini"
            if not self.settings.dry_run:
                shutil.copyfile(self.suite.appspace_config_ini, target)

        self.cli.bwadmin("create", "-d", d, "-a", self.appspace, "-osgiPort", str(self.osgi_port),
                         "-httpPort", str(self.http_port), *self._agent_args(), "appnode", self.appnode,
                         note=f"create appnode {self.appnode}")
        self._patch_appnode_config()
        # `bwadmin start` has its own short internal wait and may report "did not start" while the node is
        # still booting (slow disk / antivirus). So: ignore its verdict and poll the real status ourselves.
        self._started = True
        self.cli.bwadmin("start", "-d", d, "-a", self.appspace, "appnode", self.appnode, check=False,
                         note=f"start appnode {self.appnode}", timeout=self.settings.timeouts.appnode_start)
        if not self._wait_status("appnodes", self.appnode, {"running"}, self.settings.timeouts.appnode_start):
            tail = ""
            if self.appnode_log.is_file():
                tail = "\n".join(self.appnode_log.read_text(errors="replace").splitlines()[-30:])
            raise EnvironmentSetupError(
                f"AppNode {self.appnode} not Running after {self.settings.timeouts.appnode_start}s "
                f"(timeouts.appnode_start). Last bwappnode.log lines:\n{tail}")

    def stop(self) -> None:
        d = self.session.domain
        try:
            if self._started:
                args = ["stop", "-d", d, "-a", self.appspace, "appnode", self.appnode]
                self.cli.bwadmin(*args, check=False, note=f"stop appnode {self.appnode}")
                stopped = self._wait_status("appnodes", self.appnode, {"stopped", "notfound"},
                                            self.settings.timeouts.appnode_start)
                if stopped:
                    self.cli.bwadmin("delete", "-force", "-d", d, "appspace", self.appspace, check=False,
                                     note=f"delete appspace {self.appspace}")
                else:
                    # Never delete the AppSpace/domain under a live process: that would orphan it.
                    self.session.keep_for_inspection = True
                    msg = (f"AppNode {self.appnode} did not stop; AppSpace and domain {d} were left in place. "
                           f"Stop it with: bwadmin stop -d {d} -a {self.appspace} appnode {self.appnode}")
                    with (self.dir / "warnings.log").open("a") as fh:
                        fh.write(msg + "\n")
        finally:
            self._collect_logs()
            for name in reversed(self._installed_drivers):
                spec = self._driver(name)
                if spec.uninstall and spec.install_target:
                    try:
                        self.cli.bwinstall(spec.install_target, uninstall=True)
                    except BwCommandError as exc:  # never hide the real test result
                        (self.dir / "teardown-errors.log").open("a").write(f"{exc}\n")

    # ------------------------------------------------------------------------------------------
    def deploy(self, ear: Path, profile: Path, app_name: str, version: str) -> Deployment:
        d = self.session.domain
        if not ear.is_file() and not self.settings.dry_run:
            raise EnvironmentSetupError(f"EAR not found: {ear}")
        self.cli.bwadmin("upload", "-d", d, str(ear), note=f"upload {ear.name}")
        self.cli.bwadmin("deploy", "-d", d, "-a", self.appspace, "-pf", str(profile), "-as", ear.name,
                         note=f"deploy {ear.name}", timeout=self.settings.timeouts.app_start)
        dep = Deployment(app_name, version, ear.name)
        if not self._wait_status("applications", app_name, {"running"}, self.settings.timeouts.app_start):
            # Not fatal: the verify step gives the verdict (some apps finish and stop on their own).
            with (self.dir / "warnings.log").open("a") as fh:
                fh.write(f"{app_name} not reported Running\n")
        return dep

    def undeploy(self, dep: Deployment) -> None:
        d = self.session.domain
        self.cli.bwadmin("stop", "-d", d, "-a", self.appspace, "-n", self.appnode, "application",
                         dep.app_name, dep.version, check=False, note=f"stop {dep.app_name}")
        self.cli.bwadmin("undeploy", "-d", d, "-a", self.appspace, "application", dep.app_name, dep.version,
                         check=False, note=f"undeploy {dep.app_name}")
        self.cli.bwadmin("delete", "-d", d, "archive", dep.ear_name, check=False, note=f"delete {dep.ear_name}")

    # ------------------------------------------------------------------------------------------
    def _agent_args(self) -> list[str]:
        if self.settings.bw.admin_mode == "enterprise":
            import socket

            return ["-agent", socket.gethostname()]
        return []

    def status(self, kind: str, name: str) -> str:
        """Status of `name` from `bwadmin show appnodes|applications` (lower case) or 'notfound'.

        BW 6.12 output:  Name  Status  AppSpace ...   e.g.  'http_components   Running   http_components ...'"""
        d = self.session.domain
        args = ["show", "-d", d, "appnodes"] if kind == "appnodes" else \
            ["show", "-d", d, "-a", self.appspace, "applications"]
        result = self.cli.bwadmin(*args, check=False, note=f"poll {kind} {name}")
        for line in result.output.splitlines():
            parts = line.split()
            if len(parts) >= 2 and parts[0] == name:
                for token in parts[1:]:  # applications have Version/AppSpace/Profile before Status
                    if token.lower() in _STATUSES:
                        return token.lower()
        return "notfound"

    def _wait_status(self, kind: str, name: str, wanted: set[str], timeout: int) -> bool:
        if self.settings.dry_run:
            return True
        deadline = time.monotonic() + timeout
        while True:
            if self.status(kind, name) in wanted:
                return True
            if time.monotonic() >= deadline:
                return False
            # a status check in the shared bwadmin shell costs milliseconds: check often (one-shot: a JVM each)
            time.sleep(1 if self.cli.uses_shell else 3)

    def _patch_appnode_config(self) -> None:
        props = self.appnode_properties
        config = self.appnode_dir / "config.ini"
        if self.settings.dry_run or not props:
            return
        if not config.is_file():
            raise EnvironmentSetupError(f"AppNode config not found: {config}")
        text = config.read_text(encoding="utf-8")
        for key, value in props.items():
            text = _set_ini(text, key, value)
        config.write_text(text, encoding="utf-8")

    def _collect_logs(self) -> None:
        if self.settings.dry_run:
            return
        for src in (self.appnode_log,):
            if src.is_file():
                shutil.copyfile(src, self.dir / src.name)

    # -- drivers ------------------------------------------------------------------------------
    def _driver(self, name: str) -> DriverSpec:
        spec = self.settings.drivers.get(name)
        if spec is None:
            raise ConfigError(f"Suite '{self.suite.name}' needs driver '{name}', not defined in config/drivers.yaml")
        return spec

    def _install_driver(self, name: str) -> None:
        spec = self._driver(name)
        target = self.settings.bw.home / spec.target
        if "*" in spec.target:  # e.g. plugins/*.bw.jdbc.datasourcefactory.oracle/lib - the folder inside BW
            found = sorted(self.settings.bw.home.glob(spec.target))
            target = found[0] if found else target
        root = self.settings.paths.driver_jars_root
        if self.settings.dry_run:
            self.cli.log.write(["copy", *spec.jars, "->", str(target)], note=f"driver {name}")
            if spec.install_target:
                self.cli.bwinstall(spec.install_target)
            self._installed_drivers.append(name)
            return
        # The BW installation is shared by all runs at the same time (slots.py): one driver install at a time,
        # and jars another run's AppNode has open (Windows locks them) are left alone when they are identical.
        lock_dir = self.settings.bw.domain_home / slots.FOLDER
        lock_dir.mkdir(parents=True, exist_ok=True)
        with slots.file_lock(lock_dir / "driver-install.lock", timeout=1800):
            target.mkdir(parents=True, exist_ok=True)
            wanted = {Path(f).name for pattern in spec.jars for f in glob.glob(str(root / pattern))}
            for old in spec.remove:
                for f in glob.glob(str(target / old)):
                    if Path(f).name in wanted:
                        continue  # replaced by the copy below (or already the right file)
                    try:
                        Path(f).unlink(missing_ok=True)
                    except PermissionError:
                        self.cli.log.write(["keep", f], note="in use by another AppNode - not removed")
            copied = 0
            for pattern in spec.jars:
                for f in glob.glob(str(root / pattern)):
                    copied += 1
                    dest = target / Path(f).name
                    if _same_file(Path(f), dest):
                        continue
                    try:
                        shutil.copy2(f, dest)
                    except PermissionError:
                        raise EnvironmentSetupError(
                            f"Driver '{name}': {dest} is in use (an AppNode of another run has it open) and differs "
                            f"from {f}. Run suites that need different versions of this driver one after the other."
                        ) from None
            if spec.jars and copied == 0:
                raise EnvironmentSetupError(f"Driver '{name}': no jars matched {spec.jars} under {root}")
            self.cli.log.write(["copy", *spec.jars, "->", str(target)], note=f"driver {name}")
            if spec.install_target:
                self.cli.bwinstall(spec.install_target)
        self._installed_drivers.append(name)

    # -- databases ----------------------------------------------------------------------------
    def _reset_database(self, name: str) -> None:
        raw = self.settings.databases.get(name)
        if raw is None:
            raise ConfigError(f"Suite '{self.suite.name}' needs database '{name}', not in config/databases.yaml")
        spec = DatabaseSpec(**render_deep(vars(raw), {}))  # resolves ${env:...} secrets only now
        root = self.settings.paths.driver_jars_root
        main = ["-jar", str(root / spec.runner_jar)]  # same call as old BW_ENGINE.sh: java -jar cleanDB.jar
        install = self.settings.bw.home.parent.parent  # the JRE that comes with BW: <install>/<..jre..>/<ver>
        java_exe = next(iter(sorted(install.glob("*jre*/*/bin/java*"))), None) if install.is_dir() else None
        for script in spec.scripts:
            sql = self.settings.bw.home / spec.scripts_dir / script
            args = [str(java_exe or "java"), *main, spec.driver_class, spec.url, str(sql), spec.user, spec.password]
            shown = args[:-1] + ["****"]
            self.cli.log.write(shown, note=f"db reset {name}: {script}")
            if self.settings.dry_run:
                continue
            proc = subprocess.run(args, capture_output=True, text=True, timeout=300, check=False, **NO_CONSOLE)
            if proc.returncode != 0 and not script.startswith("drop"):
                raise EnvironmentSetupError(f"DB reset '{name}' failed on {script}:\n{proc.stdout}{proc.stderr}")
