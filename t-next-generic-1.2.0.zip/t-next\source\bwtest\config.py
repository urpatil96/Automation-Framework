"""Framework settings.

Replaces: t_usrdef.sh, config/win.cfg (lnx.cfg ...), *.profile XML and the hard-coded values
inside BW_ENGINE.sh (DB URLs, passwords, driver jars).

Load order (later wins):
    1. config/bwtest.yaml                 defaults, checked into git
    2. config/profiles/<profile>.yaml     per BW version / build (old *.profile)
    3. config/local.yaml                  personal overrides, git-ignored
    4. .env file + environment variables  BWTEST__BW__HOME=... (double underscore = nesting)
    5. command-line options               --bw-home, --bw-profile ...

Secrets are never stored in YAML: use ${env:NAME} and put the value in .env / CI secrets.
"""

from __future__ import annotations

import os
import platform
from dataclasses import dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any, get_type_hints

import yaml

from .errors import ConfigError
from .templating import render_deep


# ----------------------------------------------------------------------------------------------
# Typed settings. Unknown keys in YAML raise an error (catches typos early).
# ----------------------------------------------------------------------------------------------
@dataclass
class BwSettings:
    home: Path = Path("")  # TIB_BW_HOME, e.g. C:/D/6.12.1/V12/bw/6.12
    admin_mode: str = "local"  # local | enterprise   (old win.cfg AdminMode)
    domain_home: Path = Path("C:/domains")  # old win.cfg DomainHome
    domain_prefix: str = "bwtest"  # domain name = <prefix>-<instance> (not bwdomain: avoids t-tests domains)
    cleanup_domain: bool = True  # old CleanUpDomain
    appnode_properties: dict[str, str] = field(default_factory=dict)  # appended to appnode config.ini
    agent_start_timeout: int = 120
    tool_overrides: dict[str, list[str]] = field(default_factory=dict)  # e.g. fake bwadmin for self-tests
    error_patterns: list[str] = field(default_factory=lambda: [r"BW-ADMIN-CLI-5\d{5}"])
    app_version: str = ""  # force application version for stop/undeploy; empty = read from MANIFEST
    # Run all bwadmin commands in ONE long-running bwadmin shell instead of a new JVM per command (3-8 s each).
    # Falls back to one call per command automatically if the shell cannot be used.
    admin_shell: bool = True
    # Names under which old .sh scripts get the install folder (<install>/bw/<x.y> -> <install>). Add the name
    # your old scripts read, e.g. in config/local.yaml:  bw: {install_home_vars: [INSTALL_HOME, MY_HOME]}
    install_home_vars: list[str] = field(default_factory=lambda: ["INSTALL_HOME"])
    # Rendezvous installs (<rv_root>/<version>/bin/rvd); empty = next to the BW install (<install>/tibrv)
    rv_root: str = ""
    # Folder with Unix tools (cat, ls, sort ...) put first on the PATH of bwadmin/bwagent - and so of the AppNode -
    # because test apps run External Commands like `cat -n file` (t-tests had Cygwin on the PATH).
    # "auto" = Git for Windows usr/bin, "" = do not change PATH, or an explicit folder.
    unix_tools: str = "auto"


@dataclass
class PathSettings:
    assets_root: Path = Path("")  # old TSI_TEST_PRODUCT_ROOT (tests/bw) - EARs, gold files
    results_dir: Path = Path("results")
    driver_jars_root: Path = Path("")  # where JDBC/JMS jars live (old ${TSI_TEST_PRODUCT_ROOT}/lib)
    bash: str = ""  # bash used by the legacy bridge; empty = auto-detect (Git Bash on Windows)
    legacy_scripts: Path = Path("")  # old t-tests/4.0/scripts (only for the legacy bridge)


@dataclass
class PortSettings:
    http_base: int = 50000
    osgi_base: int = 60000
    stride: int = 250  # each parallel worker gets its own port block


@dataclass
class TimeoutSettings:
    command: int = 600  # any single bwadmin call
    appnode_start: int = 300
    app_start: int = 180
    output_file: int = 60  # default wait for the output file when a test defines no action
    stable_for: float = 2.0  # file must stop growing for this long


@dataclass
class DriverSpec:
    """A third-party driver installed into BW before a suite runs (old BW_ENGINE.sh case block)."""

    jars: list[str] = field(default_factory=list)  # globs relative to paths.driver_jars_root
    target: str = ""  # dir relative to bw.home
    remove: list[str] = field(default_factory=list)  # jars to delete from target first
    install_target: str = ""  # argument for `bwinstall`, e.g. oracle-driver ("" = copy only)
    uninstall: bool = True  # run `bwinstall --uninstall`-equivalent after the suite
    suites: list[str] = field(default_factory=list)  # legacy suite names that need it (importer)


@dataclass
class DatabaseSpec:
    """A database reset before a suite (old cleanDB.jar calls)."""

    driver_class: str = ""
    url: str = ""
    user: str = ""
    password: str = ""  # use ${env:NAME}
    scripts_dir: str = ""  # relative to bw.home, e.g. config/dbscripts/engine/oracle
    scripts: list[str] = field(
        default_factory=lambda: ["drop.sql", "drop-scp.sql", "drop-dcp.sql", "create.sql", "create-scp.sql",
                                 "create-dcp.sql"]
    )
    runner_jar: str = "cleanDB.jar"  # relative to paths.driver_jars_root (old ${TSI_TEST_PRODUCT_ROOT}/lib)
    suites: list[str] = field(default_factory=list)


@dataclass
class UiSettings:
    """Web UI (`bwtest ui`)."""

    host: str = "127.0.0.1"  # 0.0.0.0 = reachable from other machines (no login - use with care)
    port: int = 8765
    # Where BW installs live, laid out as <builds_root>/<version>/<build>/bw/<x.y>  (C:/D/6.12.1/V12/bw/6.12).
    # The UI lists the builds of the selected profile from here, like the old main page's build field.
    builds_root: Path = Path("")
    open_browser: bool = True
    default_tester: str = ""  # prefilled "Tester" on the New run page (old Preferences > Report)


@dataclass
class TtestsReportSettings:
    """Old t-tests .sql report (upload to the QA results DB), made on demand from a finished run.
    Values that are not part of a run - same meaning as in t-tests Preferences > Report."""

    product: str = "bw"  # PRODUCT_NAME / report.label.product (also TSI_TEST_PRODUCT for old scripts)
    platform: str = "i86-winnt50"  # PLATFORM / reporting.platform
    db_user: str = "superuser"  # USER_NAME (boolean.report.use.super.user)
    t_tests_version: str = "4.0"  # T_TESTS_VERSION
    hostname: str = ""  # HOSTNAME / test machine; empty = this computer's name


@dataclass
class Settings:
    profile: str = "default"
    bw: BwSettings = field(default_factory=BwSettings)
    paths: PathSettings = field(default_factory=PathSettings)
    ports: PortSettings = field(default_factory=PortSettings)
    timeouts: TimeoutSettings = field(default_factory=TimeoutSettings)
    drivers: dict[str, DriverSpec] = field(default_factory=dict)
    databases: dict[str, DatabaseSpec] = field(default_factory=dict)
    vars: dict[str, str] = field(default_factory=dict)  # global client vars for every test
    ui: UiSettings = field(default_factory=UiSettings)
    ttests_report: TtestsReportSettings = field(default_factory=TtestsReportSettings)
    dry_run: bool = False
    update_gold: bool = False
    keep_domain: bool = False
    config_dir: Path = Path("config")

    @property
    def is_windows(self) -> bool:
        return platform.system() == "Windows"


# ----------------------------------------------------------------------------------------------
# dict -> dataclass conversion with validation
# ----------------------------------------------------------------------------------------------
def _convert(tp: Any, value: Any, where: str) -> Any:
    origin = getattr(tp, "__origin__", None)
    if is_dataclass(tp):
        if not isinstance(value, dict):
            raise ConfigError(f"{where}: expected a mapping, got {type(value).__name__}")
        return _build(tp, value, where)
    if tp is Path:
        return Path(str(value)) if value not in (None, "") else Path("")
    if tp is bool:
        if isinstance(value, str):
            return value.strip().lower() in ("1", "true", "yes", "on")
        return bool(value)
    if tp in (int, float):
        try:
            return tp(value)
        except (TypeError, ValueError):
            raise ConfigError(f"{where}: expected {tp.__name__}, got {value!r}") from None
    if tp is str:
        return "" if value is None else str(value)
    if origin is list:
        (item_tp,) = tp.__args__
        if value is None:
            return []
        if not isinstance(value, list):
            value = [value]
        return [_convert(item_tp, v, f"{where}[{i}]") for i, v in enumerate(value)]
    if origin is dict:
        _, val_tp = tp.__args__
        if value is None:
            return {}
        if not isinstance(value, dict):
            raise ConfigError(f"{where}: expected a mapping")
        return {str(k): _convert(val_tp, v, f"{where}.{k}") for k, v in value.items()}
    return value


def _build(cls: type, data: dict, where: str) -> Any:
    hints = get_type_hints(cls)
    known = {f.name for f in fields(cls)}
    unknown = set(data) - known
    if unknown:
        raise ConfigError(f"{where}: unknown key(s) {sorted(unknown)}. Allowed: {sorted(known)}")
    kwargs = {k: _convert(hints[k], v, f"{where}.{k}") for k, v in data.items()}
    return cls(**kwargs)


def deep_merge(base: dict, override: dict) -> dict:
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _read_yaml(path: Path) -> dict:
    if not path.is_file():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise ConfigError(f"{path}: invalid YAML: {exc}") from exc
    if not isinstance(data, dict):
        raise ConfigError(f"{path}: top level must be a mapping")
    return data


def load_dotenv(path: Path) -> None:
    """Minimal .env loader (KEY=VALUE). Existing environment variables win."""
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def _env_overrides(prefix: str = "BWTEST__") -> dict:
    """BWTEST__BW__HOME=C:/bw  ->  {"bw": {"home": "C:/bw"}}"""
    result: dict = {}
    for key, value in os.environ.items():
        if not key.startswith(prefix):
            continue
        parts = [p.lower() for p in key[len(prefix):].split("__") if p]
        node = result
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        if parts:
            node[parts[-1]] = value
    return result


def load_settings(
    config_dir: Path | str = "config",
    profile: str | None = None,
    overrides: dict | None = None,
) -> Settings:
    config_dir = Path(config_dir).resolve()
    load_dotenv(config_dir.parent / ".env")

    data = _read_yaml(config_dir / "bwtest.yaml")
    profile = profile or os.environ.get("BWTEST_PROFILE") or data.pop("profile", None) or "default"
    data.pop("profile", None)

    profile_file = config_dir / "profiles" / f"{profile}.yaml"
    if profile != "default" and not profile_file.is_file():  # BW6121 / BW 6.12.1 / 6.12.1.000 -> 6.12.1
        from .bwhome import normalize_version

        known = [p.stem for p in (config_dir / "profiles").glob("*.yaml")]
        profile = normalize_version(profile, known) or profile
        profile_file = config_dir / "profiles" / f"{profile}.yaml"
    if profile != "default" and not profile_file.is_file():
        available = sorted(p.stem for p in (config_dir / "profiles").glob("*.yaml"))
        raise ConfigError(f"Profile '{profile}' not found in {profile_file.parent}. Available: {available}")
    data = deep_merge(data, _read_yaml(profile_file))

    for extra in ("drivers", "databases"):  # registries live in their own files for readability
        registry = {k: v for k, v in _read_yaml(config_dir / f"{extra}.yaml").items()
                    if not k.startswith("_")}  # "_name" keys are YAML anchors / shared snippets
        data = deep_merge(data, {extra: registry})

    data = deep_merge(data, _read_yaml(config_dir / "local.yaml"))
    data = deep_merge(data, _env_overrides())
    data = deep_merge(data, overrides or {})

    # Render ${env:...} and cross references like ${paths.assets_root}; secrets stay lazy for
    # drivers/databases (rendered when used) so a missing password only fails the suite needing it.
    lazy = {k: data.pop(k, {}) for k in ("drivers", "databases")}
    data = render_deep(data, {"config_dir": str(config_dir)}, strict=False)
    data = render_deep(data, {**data, "config_dir": str(config_dir)}, strict=True)
    data.update(lazy)
    data["profile"] = profile
    data["config_dir"] = str(config_dir)

    settings: Settings = _build(Settings, data, "config")
    from .bwhome import resolve_bw_home

    settings.bw.home = resolve_bw_home(settings.bw.home)  # INSTALL_HOME / .../bw / .../bin -> <..>/bw/<x.y>

    base = config_dir.parent
    for attr in ("results_dir", "assets_root", "driver_jars_root", "legacy_scripts"):
        value: Path = getattr(settings.paths, attr)
        if str(value) not in ("", ".") and not value.is_absolute():
            setattr(settings.paths, attr, (base / value).resolve())
    return settings
