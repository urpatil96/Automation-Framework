# T-Next — BusinessWorks 6 regression framework
> **T-Next** is the name of the framework (the next generation of t-tests). The command, the Python package and file names stay `bwtest` (`bwtest run …`, `config/bwtest.yaml`, domains `bwtest-N`).


`bwtest` is the successor of **t-tests 4.0**. It runs the same BW test assets (EARs, BW projects,
gold files) with a modern stack: **Python 3.11+, pytest, YAML suites, typed config, HTML/JUnit
reports, parallel runs**. Bash/Cygwin and the Java `t-tests.jar` core are no longer needed.

```
            your existing assets (unchanged)                 new framework
   C:/D/Automation/tests/bw/func/engine/http_Attachments_comp     suites/engine/http/http_Attachments_comp/
        bw.3647/ bw_3647.application.ear  bw_645_gold.log   <──   http_Attachments_comp.suite.yaml
```

## Start the desktop application (easiest - replaces t-tests.bat)

Double-click **`start-bwtest.bat`** (or run `bwtest desktop`) → the bwtest window opens, laid out like
t-tests 4.0: menu bar (File · Edit · Run · View · Help), toolbar (New run, Select tests, Stop, Runs & reports,
Suites, Preferences, Doctor), **Test explorer** tree on the left (suites by category, saved selections,
recent runs), status bar at the bottom (profile, BW home, run in progress). Path fields have native
**Browse…** buttons. The same screens also run in a browser with `bwtest ui`.

```
Dashboard ─► New run:  1 Product & build  ─►  2 Test cases  ─►  3 Report details  ─►  4 Review & start
                       (6.12.1 / V12)         (suites/tests)     (name, tester, Jira)    (shows the CLI command)
          ─► Run page: live progress · console · stop safely · diff / app log per test · HTML report
```

Also: browse and edit suites, add test cases and suites with forms, Preferences (old user profile +
Preferences dialog), Doctor, and a Help page for new users. Details: [docs/UI.md](UI.md).

## Quick start (Windows, command line)

Easiest: double-click `setup\setup-bwtest.bat` (asks where to install and for your settings). By hand:

```powershell
cd C:\D\bw6-autotest
python -m venv .venv
.venv\Scripts\activate
pip install -e "source[report,parallel,desktop]"  # see "Offline / proxy install" if PyPI is slow

copy config\local.yaml.example config\local.yaml   # set bw.home + assets_root for your machine
copy config\.env.example .env                              # DB passwords (only for suites that need them)

bwtest doctor                                   # checks BW home, version, bash, assets, suite files
bwtest list --suite http                        # what is there
bwtest run http_Attachments_comp -k "bw.3647 or bw.3648"
bwtest run --profile 6.13.0 -m "smoke and not jdbc" -n 4
```

Results: `results/<timestamp>/` → `report.html`, `junit.xml`, `commands.log` (every bwadmin call,
copy-paste-able), and one folder per test with `output`, `diff.txt`, `module_properties.txt`,
`bwappnode.log` (only the lines written during *that* test).

## Everyday commands

| Goal | Command |
|---|---|
| Open the desktop app | double-click `start-bwtest.bat` or `bwtest desktop` |
| Open the UI in a browser | `bwtest ui` |
| Run one suite | `bwtest run http_Attachments_comp` |
| Run with report details | `bwtest run http_Attachments_comp --name "V12 smoke" --tester jdoe --jira BUG-58468` |
| One exact test | `bwtest run suites/engine/http/http_Attachments_comp/http_Attachments_comp.suite.yaml::bw.3647` |
| Run some tests | `bwtest run http_Attachments_comp -k "bw.3647 or bw.3648"` |
| By tag | `bwtest run -m "http and not known_to_fail"` |
| Other BW version / build | `bwtest run --profile 6.13.0`  or  `--bw-home C:/D/6.13.0/V50/bw/6.13` |
| Parallel (each worker = own domain + ports) | `bwtest run -n 4` |
| Re-run last failures | `bwtest run --lf` |
| Accept new output as gold | `bwtest run -k bw.3647 --update-gold` then review `git diff` |
| See what would run, no BW | `bwtest run http_Attachments_comp --dry-run` |
| Add a suite | `bwtest new-suite engine/rest_json` |
| Add a test | `bwtest new-test suites/engine/rest_json/rest_json.suite.yaml bw.9001 --ear X.ear` |
| Convert old suites | `bwtest import C:/D/Automation/tests/bw/func` |
| t-tests `.sql` for the QA results DB | `bwtest ttests-report <run-id>` (or Run page → **t-tests .sql**) |
| Plain pytest also works | `pytest -c config/pytest.ini suites/engine/http/http_Attachments_comp -k bw.3647 --bw-profile 6.12.1` |

## Documentation

Start at **[README.md](README.md)**: it tells each role (new user, test author, manager, maintainer) what to read. Changes: [CHANGELOG.md](CHANGELOG.md) · Rules for changing the framework: [CONTRIBUTING.md](CONTRIBUTING.md).

* [docs/USER_GUIDE.md](USER_GUIDE.md) — **start here**: install → configure → run → results → add tests, troubleshooting
* [docs/UI_REFERENCE.md](UI_REFERENCE.md) — every menu, button and field of the desktop app
* [docs/UI.md](UI.md) — the web UI: pages, **how every field is configured**, old t-tests → UI
* [docs/ARCHITECTURE.md](ARCHITECTURE.md) — how it works, diagrams, **how to explain it**
* [docs/WRITING_TESTS.md](WRITING_TESTS.md) — add test cases and suites, all YAML options
* [docs/MIGRATING_FROM_TTESTS.md](MIGRATING_FROM_TTESTS.md) — old → new mapping, legacy bridge
* [suites/IMPORT_REPORT.md](../suites/IMPORT_REPORT.md) — result of importing the 129 t-tests suites (history)

## Repository layout

```
bw6-autotest/
├─ start-bwtest.bat        start the app (the only file at the top)
├─ suites/                 *.suite.yaml - the test suites · examples/
├─ config/                 bwtest.yaml (defaults) · profiles/<version>.yaml · drivers.yaml · databases.yaml
│                          pytest.ini (how suites run) · .env.example (password template)
├─ docs/                   all documentation (start: docs/README.md) · CHANGELOG · CONTRIBUTING
├─ setup/                  setup-bwtest.bat · make-share-zip.bat · backup-bwtest.bat
├─ source/                 ALL code - open this project in VS Code
│  ├─ bwtest/              the framework (≈6,400 lines of Python + ≈2,100 lines of JavaScript for the UI)
│  ├─ tests/               self-tests of the framework (bwadmin stand-in, no BW needed)
│  ├─ tools/               developer tools (code map generator)
│  ├─ ci/Jenkinsfile       Jenkins pipeline (.github/workflows/ci.yml: self-tests + lint)
│  ├─ docker/              docker-compose for test dependencies (DBs, mail, LDAP, HTTP echo)
│  └─ pyproject.toml       package definition
└─ results/                run output and backups (git-ignored)
```

## Offline / proxy install

PyPI timed out from this machine with default settings. Use longer timeouts:
`pip install --timeout 60 -e "source[report,parallel]"`. On Python 3.15 PyYAML has no wheel yet and needs a
compiler; build the pure-Python version instead:
`set PYYAML_FORCE_LIBYAML=0 && pip install --no-build-isolation pyyaml`.
