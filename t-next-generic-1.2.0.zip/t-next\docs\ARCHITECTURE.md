# T-Next architecture — and how to explain it

## 30-second pitch

> A data-driven regression framework for BusinessWorks 6, built on **pytest**. Each test case is a
> BW application (EAR) plus an expected result (gold file). Suites are **YAML** files. The framework
> creates a BW Domain → AppSpace → AppNode, deploys each EAR with test-specific **module properties**,
> waits for the output, **verifies** it (text / XML / JSON / binary / log checks) and produces HTML,
> JUnit reports. It runs suites **in parallel**, reuses the legacy t-tests cases (all 129 suites were imported) through
> an automatic **importer**, and keeps secrets out of the repository.

## The three ideas to put on a whiteboard

### 1. Hierarchy (what is a suite, what is a test)

```
config/profiles/6.12.1.yaml        which BW install (bw.home), replaces 6.12.1.profile
        │
suites/<category>/<suite>.suite.yaml      = old .testset + .cfg + case blocks of t_setup/t_action
        │   suite: http_Attachments_comp         → AppSpace + AppNode "http_Attachments_comp"
        │   client_vars_files, vars        → module properties for every test
        │   drivers / databases            → installed / reset before the suite
        │
        ├── test bw.3647  ─────────────►  assets/.../bw.3647/
        │     output, gold, action,          bw_3647/                  BW project (for Studio)
        │     verify, tags, known_to_fail    bw_3647.application.ear   deployable
        │                                    bw_645_gold.log          expected output
        └── test bw.3648 ...
```

### 2. Execution flow (one run)

```
bwtest run / pytest
   │
   ├─ pytest collects *.suite.yaml  →  1 File per suite, 1 Item per test   (pytest_plugin.py)
   │
   ├─ BwSession (once per run / per parallel worker)                         (runtime.py)
   │     detect BW version · prepare bwagent.ini · [start bwagent] · create domain bwtest-<worker>
   │
   ├─ SuiteEnvironment (once per suite)
   │     install drivers · reset DBs · create AppSpace · create AppNode (own ports)
   │     patch AppNode config.ini · start AppNode · poll until "Running"
   │
   ├─ TestExecutor.run(test)  (per test, per sequence)                      (executor.py)
   │     1 prepare   resolve paths & variables (global < suite cfg < suite < test < framework)
   │                 pick version-specific gold (bw_645_gold_6121.log / gold_by_version)
   │     2 profile   default.substvar of the app + test variables → t-tests.substvar
   │     3 deploy    bwadmin upload + deploy -pf profile · poll app "Running"
   │     4 action    wait_for_file (default) | wait | wait_for_output | http | wait_for_log | shell | legacy | python
   │     5 cleanup   stop + undeploy app · delete archive · save the app's slice of bwappnode.log
   │     6 verify    text | xml | json | binary | contains | log | exists | legacy | python
   │                 (after the undeploy, as t-tests did: output files are closed and final)
   │
   ├─ teardown: stop AppNode (wait until Stopped) · delete AppSpace · uninstall drivers
   └─ delete domain · reports: junit.xml · report.html · summary.json · commands.log
```

### 3. Layers (each file has one job)

```
 ui/ ────────────── web UI (bwtest ui): FastAPI REST API + browser app; starts `bwtest run` as a child
                    process and follows it through results/<run>/events.jsonl   (see docs/UI.md)
 cli.py ─────────── bwtest run/list/import/new-suite/new-test/doctor/ui
 pytest_plugin.py ─ YAML → pytest items, markers, xfail/skip, fixtures, report attachments
 executor.py ────── one test: prepare → profile → deploy → action → verify → cleanup
 actions.py · verify.py ─ pluggable registries (@action("x"), @verifier("y"))
 runtime.py ─────── Domain / AppSpace / AppNode / App lifecycle, drivers, DB reset
 bwcli.py ───────── every bwadmin/bwagent/bwinstall call: no shell, timeout, error check, logged
 models.py · config.py · templating.py · substvar.py ─ data: suites, settings, ${..}, .cfg/.substvar
 legacy/importer.py · legacy/bridge.py ─ t-tests import + run old bash scripts unchanged
```

## Old vs new

| Concern | t-tests 4.0 | bwtest |
|---|---|---|
| Runner | Java `t-tests.jar` + Bash + Cygwin | pytest (Python), no Cygwin |
| Suite definition | `.testset` XML + `case` blocks in 3 bash scripts + `.cfg` | one `*.suite.yaml` |
| BW version / install | `*.profile` XML per version | `config/profiles/<ver>.yaml`, `--bw-home` per run |
| Drivers / DB reset | ~600 lines of `case ${TSI_COMPONENT}` in BW_ENGINE.sh | `drivers.yaml`, `databases.yaml`, referenced by name |
| Secrets | passwords in plain text in BW_ENGINE.sh | `${env:NAME}` → `.env` / CI secrets |
| Waiting | `t_sleep 40` (fixed) | `wait_for_file` / `wait_for_log` (event-based) + timeouts |
| Verify | `diff output gold`, exit code | typed verifiers, masks for timestamps, readable unified diff |
| Hidden errors | not detected if output matched | `log` verifier: no `BW-*-5xxxxx` / `THOR-*-5xxxxx` during the test |
| AppNode start | `bwadmin start` result trusted | real status polled (`bwadmin show`), safe teardown |
| Per-test log | one big bwappnode.log | slice of bwappnode.log for each test |
| Parallel | no | `-n 4`: domain + port block per worker |
| Select tests | `.testcmd` XML files | `-k`, `-m tag`, `--lf`, suite names |
| Update gold | copy files by hand | `--update-gold` + `git diff` review |
| Reports | XSLT HTML + SQL inserts | pytest-html, JUnit (Jenkins), summary.json |
| Debugging | setupCommands.bat | `commands.log` with every command + rc + duration, `--dry-run` |
| Framework tests | none | 43 self-tests with a bwadmin stand-in (run in CI without BW); real runs use the real bwadmin |
| Domain safety | `bwdomain-N`, deleted unconditionally | `bwtest-N`, only deleted if it carries bwtest's marker |

## Design decisions (the "why" questions)

* **Why pytest, not a custom runner?** Selection, parallelism (xdist), re-run of failures, reporting
  plugins, fixtures and IDE integration come for free. The framework is only the BW-specific part.
* **Why YAML suites?** Adding a test is data, not code — the same strength t-tests had — but in one
  readable file instead of XML + three bash `case` statements. Python tests remain possible for complex
  logic (`suites/examples/test_python_style.py`).
* **Why keep the assets where they are?** Thousands of cases, gigabytes of EARs. The importer *references*
  them (`assets_dir: ${assets_root}/...`), so both frameworks can run side by side during the migration.
* **Why a legacy bridge?** ~1/3 of the old tests call real tools in their scripts (tibemsadmin,
  tibrvsend, Java TCP clients). Guessing a translation would silently change tests. The bridge runs the
  original script unchanged; IMPORT_REPORT.md lists what to rewrite later.
* **Why poll status instead of trusting `bwadmin start`?** On Windows with antivirus the AppNode can take
  90 s+ to boot; `bwadmin start` gives up earlier and reports failure although the node comes up.
  Deleting the AppSpace in that state leaves an orphan process. bwtest waits for the real state, and
  never deletes an AppSpace under a running node.
* **Why one long-running bwadmin shell?** Every `bwadmin` call starts a JVM: 3 s idle, 5-8 s while an AppNode
  runs. A test needs ~6-10 calls (upload, deploy, status checks, stop, undeploy, delete): on bw-bat that was
  28 of 38 minutes. `bwadmin` without a command is an interactive shell; bwtest keeps one per worker open
  (`bwcli.AdminShell`) and sends every command to it - milliseconds each. Errors are detected from the output
  (BW-ADMIN-CLI-5xxxxx / "Command not found"); a hanging shell is killed and restarted, and after
  repeated problems bwtest falls back to one JVM per command. `bw.admin_shell: false` switches it off.
* **Why forward slashes for bwadmin paths?** bwadmin writes the domain home into a Java `.properties`
  file where `\` is an escape: `C:\domains` became `C:domains` (found during the first real run).

## Extending the framework

* New verifier: in any imported module
  ```python
  from bwtest.verify import verifier
  @verifier("csv")
  def verify_csv(opts, ctx): ...      # raise VerificationFailed(msg, details) to fail
  ```
* New action step: `@action("send_jms")` in `bwtest.actions` style, used as `- send_jms: {...}`.
* Without touching the framework: `verify: {type: python, function: mypkg.checks:fn}` and
  `action: [{python: mypkg.steps:fn}]`.

## Likely questions

* *How is pass/fail decided?* All configured verifiers must pass; the first failing one produces a
  unified diff in the report and `diff.txt`.
* *Output differs per BW version?* `gold_by_version: {"6121": ...}` or a file named
  `<gold>_<3-digit-version>.<ext>` next to the gold file (same rule as t-tests).
* *How do values get into the BW app?* Module properties: the app's `default.substvar` is copied and every
  property whose name matches a test variable (`TSI_TEST_OUTPUT_FILE`, `.cfg` client vars, `vars:`) is
  replaced; deployed with `bwadmin deploy -pf`. See `module_properties.txt` per test.
* *Engine vs migration?* `type: bw_migration` runs `bwmigrator` on the BW5 project and builds the EAR with
  `bwdesign` before the same deploy/verify steps.
* *Known failures?* `known_to_fail: BUG-12345` → reported as xfail; if it starts passing it shows as
  XPASS, so fixed defects are noticed.
* *Flaky environment vs real failure?* Infrastructure problems raise `EnvironmentSetupError` /
  `BwCommandError` (reported as ERROR); product mismatches raise `VerificationFailed` (FAILED).
