# T-Next documentation
> **T-Next** is the name of the framework (the next generation of t-tests). The command, the Python package and file names stay `bwtest` (`bwtest run …`, `config/bwtest.yaml`, domains `bwtest-N`).


Start with the row for your role.

| You are | Read | What you get |
|---|---|---|
| **Everyone** | [OVERVIEW.md](OVERVIEW.md) | What bwtest is, quick start, everyday commands |
| **New user** (QA engineer) | [USER_GUIDE.md](USER_GUIDE.md) | Install → configure → run → read results → add tests → troubleshooting |
| **Daily user** | [UI_REFERENCE.md](UI_REFERENCE.md) | Every menu, button and field of the desktop app |
| **Test author** | [WRITING_TESTS.md](WRITING_TESTS.md) | Suite YAML format, actions, verifiers, all options |
| **Coming from t-tests** | [MIGRATING_FROM_TTESTS.md](MIGRATING_FROM_TTESTS.md) | Old → new mapping, legacy bridge, what the importer did |
| **Developer / maintainer** | [CODE_MAP.md](CODE_MAP.md) (folder tree + every file), [ARCHITECTURE.md](ARCHITECTURE.md), [UI.md](UI.md), [../CONTRIBUTING.md](CONTRIBUTING.md) | How it works, design decisions, UI code layout and REST API, change rules |

Also: [../CHANGELOG.md](CHANGELOG.md) (what changed in each version) ·
[../suites/IMPORT_REPORT.md](../suites/IMPORT_REPORT.md) (result of importing the t-tests suites).

## Quick facts

| | |
|---|---|
| Install / share / backup | `setup\setup-bwtest.bat` · `setup\make-share-zip.bat` · `setup\backup-bwtest.bat` (see `setup\README.txt`) |
| Start the app | `C:\D\bw6-autotest\start-bwtest.bat` |
| Version | `bwtest --version` · desktop app status bar · Help → About |
| Suites | 23 suites, 1,665 test cases = the .testset files in tests/bw/func (engine: bw-bat, http_Attachments_comp, mail, 14 jdbc suites (db2 11.5, mariaDB 11.2, mssql 2019/2022, mysql 8/9, oracle 19c/21c/23c, oracle obj-coll 19c/19c_DD/21c, postgres 15/16) · migration: bat); live numbers: Dashboard |
| Results | `results\<run-id>\` → `report.html`, `junit.xml`, `commands.log`, one folder per test |
| t-tests `.sql` for the QA DB | Run page → **t-tests .sql**, or `bwtest ttests-report <run-id>` |
| Settings | team: `config/bwtest.yaml` · BW version: `config/profiles/<version>.yaml` · your machine: Preferences (`config/local.yaml`) |
