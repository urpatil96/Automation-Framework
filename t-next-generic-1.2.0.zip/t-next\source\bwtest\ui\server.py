"""FastAPI application: JSON API under /api, the single-page app under /.

Start with `bwtest ui` (see cli.py). API docs are generated automatically at /docs (Swagger UI) - useful
if someone later builds another frontend (e.g. Angular) on the same API.
"""

from __future__ import annotations

import threading
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .. import __version__
from ..errors import BwTestError
from .context import UiContext
from .routes import runs, suites, system

WEB = Path(__file__).parent / "web"


def create_app(project_root: Path | str = ".", config_dir: Path | str = "config") -> FastAPI:
    app = FastAPI(title="T-Next UI", version=__version__,
                  description="BusinessWorks 6 regression framework - web API")
    app.state.ctx = UiContext(Path(project_root), Path(config_dir))
    # Parse the ~130 suite files in the background so the first page load is fast.
    threading.Thread(target=app.state.ctx.catalog.entries, daemon=True).start()

    @app.exception_handler(BwTestError)
    async def framework_error(_: Request, exc: BwTestError) -> JSONResponse:
        # Configuration / validation problems are shown to the user as a message, not as a crash.
        return JSONResponse(status_code=400, content={"detail": str(exc)})

    for module in (system, suites, runs):
        app.include_router(module.router)

    @app.get("/api/health")
    def health() -> dict:
        return {"ok": True, "version": __version__}

    app.mount("/static", StaticFiles(directory=WEB), name="static")

    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(WEB / "index.html", headers={"Cache-Control": "no-cache"})

    return app
