"""Action steps - what happens after the app is deployed and before verification.

Replaces t_action.sh (mostly `t_sleep N`). The big improvement: instead of a blind sleep, the default
action is `wait_for_file` - continue as soon as the output file exists and has stopped growing.

In a suite file (steps run in order):

    action:
      - wait: 5                                     # seconds (old t_sleep)
      - wait_for_file: {timeout: 60}                # default when no action is given
      - wait_for_output: 40                         # t-tests "Advance Verify": up to 40 s, or until output >= gold size
      - http: {url: 'http://localhost:${http_port}/hello', expect_status: 200, save_to: '${output}'}
      - wait_for_log: {pattern: 'BW-.*Started', timeout: 60}
      - shell: {cmd: ['tibemsadmin', '-script', '${suite_dir}/purge.scr']}
      - legacy: t_action.sh                         # run the old bash script unchanged
      - python: mypackage.steps:send_jms            # custom Python step

Add your own with the @action("name") decorator.
"""

from __future__ import annotations

import importlib
import os
import subprocess
import time
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .bwcli import NO_CONSOLE
from .errors import ActionError, ConfigError

if TYPE_CHECKING:
    from .executor import TestContext

_ACTIONS: dict[str, Callable[[Any, TestContext], None]] = {}


def action(name: str):
    def register(fn: Callable[[Any, TestContext], None]):
        _ACTIONS[name] = fn
        return fn

    return register


def available() -> list[str]:
    return sorted(_ACTIONS)


def run_actions(steps: list[Any], ctx: TestContext) -> None:
    if not steps:
        steps = [{"wait_for_file": {}}]
    for index, step in enumerate(steps):
        if isinstance(step, str):
            step = {step: {}}
        if not isinstance(step, dict) or len(step) != 1:
            raise ConfigError(f"action[{index}] must be a single-key mapping like '- wait: 5', got {step!r}")
        (kind, arg), = step.items()
        fn = _ACTIONS.get(kind)
        if fn is None:
            raise ConfigError(f"Unknown action '{kind}'. Available: {available()}")
        ctx.log(f"action[{index}] {kind}: {arg}")
        if ctx.dry_run:
            continue
        fn(arg, ctx)


# ---------------------------------------------------------------------------------------------
@action("wait")
def act_wait(seconds: Any, ctx: TestContext) -> None:
    time.sleep(float(seconds))


def _file_ready(path: Path, stable_for: float, deadline: float) -> bool:
    last_size = -1
    stable_since = 0.0
    while time.monotonic() < deadline:
        if path.exists():
            size = path.stat().st_size if path.is_file() else 0
            if size != last_size:
                last_size, stable_since = size, time.monotonic()
            elif time.monotonic() - stable_since >= stable_for:
                return True
        time.sleep(0.5)
    return path.exists()


@action("wait_for_file")
def act_wait_for_file(arg: Any, ctx: TestContext) -> None:
    arg = arg if isinstance(arg, dict) else {"timeout": arg} if arg else {}
    path = Path(ctx.render(arg.get("path", str(ctx.output_file))))
    timeout = float(arg.get("timeout", ctx.settings.timeouts.output_file))
    stable = float(arg.get("stable_for", ctx.settings.timeouts.stable_for))
    if not _file_ready(path, stable, time.monotonic() + timeout) and arg.get("required", False):
        raise ActionError(f"{path} was not created within {timeout:.0f}s")
    # Not required by default: the verify step reports a missing output with a better message.


def _stripped_size(path: Path) -> int:
    """Size without CR bytes (t-tests DefaultEngineRun.getStrippedLength). -1 = not a readable file."""
    try:
        data = path.read_bytes()
    except OSError:  # missing, a folder, or still locked by the writer
        return -1
    return len(data) - data.count(b"\r")


@action("wait_for_output")
def act_wait_for_output(arg: Any, ctx: TestContext) -> None:
    """t-tests 'Advance Verify' (t-testsSetAdvanceVerify true): wait at most `timeout` seconds (the old t_action.sh
    sleeps), but continue as soon as the output file - CR stripped - is at least as big as the gold file.
    Folders (OUTPUT vs golden_output) cannot be measured: the full timeout is waited, as in t-tests."""
    arg = arg if isinstance(arg, dict) else {"timeout": arg}
    timeout = float(arg.get("timeout", ctx.settings.timeouts.output_file))
    output = Path(ctx.render(arg["path"])) if arg.get("path") else ctx.output_file
    gold = Path(ctx.render(arg["gold"])) if arg.get("gold") else ctx.gold_file
    deadline = time.monotonic() + timeout
    gold_size = _stripped_size(gold) if gold.is_file() else -1
    while time.monotonic() < deadline:
        if gold_size >= 0 and output.is_file() and _stripped_size(output) >= gold_size:
            ctx.log(f"output reached gold size ({gold_size} bytes) - continuing early")
            # let the writer finish (t-tests stopped the app right away; a short settle is safer)
            _file_ready(output, min(ctx.settings.timeouts.stable_for, 2.0), deadline)
            return
        time.sleep(0.5)
    ctx.log(f"waited the full {timeout:.0f}s")


@action("wait_for_log")
def act_wait_for_log(arg: dict, ctx: TestContext) -> None:
    import re

    pattern = re.compile(ctx.render(arg["pattern"]))
    timeout = float(arg.get("timeout", 60))
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if pattern.search(ctx.appnode_log_slice()):
            return
        time.sleep(1)
    raise ActionError(f"'{arg['pattern']}' did not appear in bwappnode.log within {timeout:.0f}s")


@action("http")
def act_http(arg: dict, ctx: TestContext) -> None:
    import httpx

    arg = ctx.render_deep(arg)
    body = arg.get("body")
    if arg.get("body_file"):
        body = Path(arg["body_file"]).read_bytes()
    retries = int(arg.get("retries", 10))  # app may still be starting
    last_exc: Exception | None = None
    response = None
    for _ in range(retries):
        try:
            response = httpx.request(
                arg.get("method", "GET"), arg["url"], headers=arg.get("headers"),
                content=body.encode() if isinstance(body, str) else body,
                json=arg.get("json"), timeout=float(arg.get("timeout", 30)),
                verify=arg.get("verify_tls", False), auth=tuple(arg["auth"]) if arg.get("auth") else None,
            )
            break
        except httpx.TransportError as exc:
            last_exc = exc
            time.sleep(2)
    if response is None:
        raise ActionError(f"HTTP {arg.get('method', 'GET')} {arg['url']} failed: {last_exc}")
    ctx.write_artifact("http_response.txt", f"HTTP {response.status_code}\n{response.headers}\n\n{response.text}")
    expected = arg.get("expect_status")
    if expected is not None and response.status_code != int(expected):
        raise ActionError(f"{arg['url']} returned HTTP {response.status_code}, expected {expected}")
    if arg.get("save_to"):
        Path(arg["save_to"]).write_bytes(response.content)


@action("shell")
def act_shell(arg: Any, ctx: TestContext) -> None:
    arg = arg if isinstance(arg, dict) else {"cmd": arg}
    arg = ctx.render_deep(arg)
    cmd = arg["cmd"]
    env = {**os.environ, **ctx.env_vars(), **(arg.get("env") or {})}
    proc = subprocess.run(cmd, shell=isinstance(cmd, str), cwd=arg.get("cwd") or ctx.log_dir, env=env,
                          capture_output=True, text=True, timeout=float(arg.get("timeout", 300)), check=False,
                          **NO_CONSOLE)
    ctx.write_artifact("shell.log", f"$ {cmd}\nrc={proc.returncode}\n{proc.stdout}\n{proc.stderr}", append=True)
    expected = arg.get("expect_rc", 0)
    if expected is not None and proc.returncode != int(expected):
        raise ActionError(f"shell command exited {proc.returncode}: {cmd}\n{proc.stderr[-2000:]}")


@action("copy")
def act_copy(arg: dict, ctx: TestContext) -> None:
    import shutil

    shutil.copy2(ctx.render(arg["src"]), ctx.render(arg["dst"]))


@action("legacy")
def act_legacy(script: Any, ctx: TestContext) -> None:
    script = script or "t_action.sh"
    result = ctx.run_legacy_script(str(script))
    if result.returncode != 0:
        raise ActionError(f"legacy {script} exited {result.returncode}\n{result.output[-3000:]}")


@action("python")
def act_python(target: Any, ctx: TestContext) -> None:
    args: dict = {}
    if isinstance(target, dict):
        args, target = target.get("args") or {}, target["function"]
    module_name, _, func_name = str(target).partition(":")
    getattr(importlib.import_module(module_name), func_name)(ctx, **args)
