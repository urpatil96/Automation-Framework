"""Run slots: several bwtest runs at the same time on one PC (t-tests: one instance ID per job).

Every BW name and port of a run is derived from its slot, so runs never touch each other:

    slot 0 (first run)     domains bwtest-0, bwtest-1 ...     ports 50000 / 60000 + 250 * worker   (as before)
    slot 1 (second run)    domains bwtest-s1-0 ...            ports + 250 * (4 * slot + worker)
    slot 2, 3              the same pattern

The BW steps themselves (create domain / AppSpace / AppNode, deploy ...) are unchanged.

Slots are claimed by `bwtest run` with a small file per slot in <domain_home>/.bwtest-slots/ (pid, run, suites)
- the domain home is what the runs share, so the files live next to the domains. A slot whose process has ended
(finished, killed, crashed) is free again. Two runs may not run the same suite at the same time: they would use
the same database tables / mailbox / HTTP endpoints and spoil each other's results.
"""

from __future__ import annotations

import json
import os
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

from .errors import ConfigError

MAX_SLOTS = 4
WORKERS_PER_SLOT = 4  # port blocks per slot; a run with more workers cannot share the PC with other runs
ENV = "BWTEST_SLOT"   # passed to pytest and its parallel workers
FOLDER = ".bwtest-slots"


def current() -> int:
    """Slot of this process (set by `bwtest run`); 0 when started any other way (plain pytest, self-tests)."""
    try:
        return max(0, int(os.environ.get(ENV, "0") or 0))
    except ValueError:
        return 0


def domain_name(prefix: str, slot: int, worker: int) -> str:
    return f"{prefix}-{worker}" if slot == 0 else f"{prefix}-s{slot}-{worker}"


def port_index(slot: int, worker: int) -> int:
    """Which port block (x ports.stride) a worker uses. Slot 0 keeps the old numbering."""
    return worker if slot == 0 else slot * WORKERS_PER_SLOT + worker


@dataclass
class Claim:
    slot: int
    file: Path | None  # None = nothing claimed (dry run)

    def release(self) -> None:
        if self.file is None:
            return
        try:
            data = json.loads(self.file.read_text(encoding="utf-8"))
            if data.get("pid") == os.getpid():
                self.file.unlink(missing_ok=True)
        except (OSError, json.JSONDecodeError):
            pass


def active(domain_home: Path) -> list[dict]:
    """Runs holding a slot right now (their process is still alive)."""
    from .ui.services.runs import pid_alive

    folder = Path(domain_home) / FOLDER
    found = []
    for f in sorted(folder.glob("slot-*.json")) if folder.is_dir() else []:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if data.get("pid") and data["pid"] != os.getpid() and pid_alive(int(data["pid"])):
            found.append(data)
    return found


def check(domain_home: Path, suites: list[str] | None, workers: int, admin_mode: str = "local",
          pending: list[dict] | None = None) -> None:
    """Raise ConfigError if a new run with these suites (resolved suite files; None = all) cannot start now.
    `pending`: runs just started by the UI that may not have claimed their slot yet (same fields as a slot file)."""
    claimed = active(domain_home)
    others = claimed + [p for p in pending or [] if p.get("run") not in {c.get("run") for c in claimed}]
    if not others:
        return
    if admin_mode == "enterprise":
        raise ConfigError(f"run {others[0].get('run')} is still running. Runs at the same time need "
                          "bw.admin_mode: local (enterprise mode starts one bwagent per run on the same ports).")
    if len(others) >= MAX_SLOTS:
        raise ConfigError(f"{len(others)} runs are already going (maximum {MAX_SLOTS}) - wait for one to finish.")
    if workers > WORKERS_PER_SLOT:
        raise ConfigError(f"run {others[0].get('run')} is still running: with another run going, use at most "
                          f"{WORKERS_PER_SLOT} parallel workers (each run gets {WORKERS_PER_SLOT} port blocks).")
    mine = None if suites is None else {_key(s) for s in suites}
    for other in others:
        if int(other.get("workers") or 0) > WORKERS_PER_SLOT:
            raise ConfigError(f"run {other.get('run')} uses {other.get('workers')} parallel workers - wait until it "
                              "finishes (it needs all port blocks).")
        theirs = None if other.get("suites") is None else {_key(s) for s in other["suites"]}
        if mine is None or theirs is None:
            what = "all suites" if theirs is None else "the selected suites"
            raise ConfigError(f"run {other.get('run')} is still running ({what}). Runs at the same time must have "
                              "different suites - select the suites to run instead of all.")
        same = mine & theirs
        if same:
            names = ", ".join(sorted(_name(s) for s in same))
            raise ConfigError(f"suite {names} is already running in run {other.get('run')}. The same suite twice at "
                              "the same time would share its database tables / mailbox / endpoints - wait for that "
                              "run or pick other suites.")


def claim(domain_home: Path, run: str, suites: list[str] | None, workers: int, admin_mode: str = "local") -> Claim:
    """Check, then take the lowest free slot for this process."""
    folder = Path(domain_home) / FOLDER
    folder.mkdir(parents=True, exist_ok=True)
    with file_lock(folder / "slots.lock", timeout=30):
        check(domain_home, suites, workers, admin_mode)
        taken = {int(o.get("slot", -1)) for o in active(domain_home)}
        slot = next(i for i in range(MAX_SLOTS) if i not in taken)
        file = folder / f"slot-{slot}.json"
        file.write_text(json.dumps({"slot": slot, "pid": os.getpid(), "run": run, "workers": workers,
                                    "suites": suites, "started": time.strftime("%Y-%m-%d %H:%M:%S")}, indent=2),
                        encoding="utf-8")
    return Claim(slot, file)


@contextmanager
def file_lock(path: Path, timeout: float = 30, stale_after: float = 3600) -> Iterator[None]:
    """Cross-process lock: a file created exclusively. A lock older than `stale_after` s is from a dead process."""
    deadline = time.monotonic() + timeout
    while True:
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
            break
        except FileExistsError:
            try:
                if time.time() - path.stat().st_mtime > stale_after:
                    path.unlink(missing_ok=True)
                    continue
            except OSError:
                continue
            if time.monotonic() > deadline:
                raise ConfigError(f"waited {timeout:.0f}s for {path} - another bwtest run holds it. If no other run "
                                  "is going, delete the file.") from None
            time.sleep(0.5)
    try:
        yield
    finally:
        path.unlink(missing_ok=True)


def _key(suite_file: str) -> str:
    return str(Path(suite_file).resolve()).lower()


def _name(suite_file: str) -> str:
    return Path(suite_file).name.removesuffix(".yaml").removesuffix(".suite")
