"""Create suites and test cases - used by `bwtest new-suite` / `bwtest new-test` and by the web UI."""

from __future__ import annotations

import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .errors import ConfigError
from .models import load_suite

SUITE_TEMPLATE = """\
# {name} - created by bwtest. Docs: docs/WRITING_TESTS.md
suite: {name}
type: {type}
owner: {owner}
description: {description}
assets_dir: {assets_dir}       # folder holding one sub-folder per test case (EAR + gold)
tags: [{tags}]

# app.clientVar.X=... files (old <suite>.cfg) - optional
# client_vars_files: [{name}.cfg]

# variables passed to the BW application as module properties (and usable as ${{NAME}} below)
vars: {{}}

# defaults for every test below (each test can override)
defaults:
  output: ${{id}}_output.log      # written by the BW process into the test's results folder
  gold: ${{id}}_gold.log          # expected result inside the case folder
  verify: {{type: {verify}}}

tests: []
"""

_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-]*$")


def _check_name(value: str, what: str) -> None:
    if not _NAME_RE.match(value or ""):
        raise ConfigError(f"{what} '{value}' may only contain letters, digits, '_', '-', '.'")


@dataclass
class NewSuite:
    path: str  # "category/name", e.g. engine/rest_json
    owner: str = ""
    description: str = "TODO describe what this suite covers"
    assets_dir: str = ""  # empty = case folders next to the suite file
    tags: list[str] = field(default_factory=list)
    type: str = ""  # empty = bw_migration for migration/*, else bw_engine
    verify: str = "text"


def create_suite(suites_root: Path, req: NewSuite) -> Path:
    category, _, name = req.path.replace("\\", "/").strip("/").rpartition("/")
    category = category or "engine"
    _check_name(name, "suite name")
    for part in category.split("/"):
        _check_name(part, "category")
    folder = suites_root / category / name
    target = folder / f"{name}.suite.yaml"
    if target.exists():
        raise ConfigError(f"{target} already exists")
    suite_type = req.type or ("bw_migration" if category.startswith("migration") else "bw_engine")
    if suite_type not in ("bw_engine", "bw_migration"):
        raise ConfigError("type must be bw_engine or bw_migration")
    tags = [category.split("/")[0], *[t for t in req.tags if t]]
    folder.mkdir(parents=True, exist_ok=True)
    target.write_text(SUITE_TEMPLATE.format(
        name=name, owner=req.owner or "", type=suite_type,
        description=_yaml_scalar(req.description or "TODO describe what this suite covers"),
        assets_dir=_yaml_scalar(req.assets_dir or "${suite_file_dir}"),
        tags=", ".join(dict.fromkeys(tags)), verify=req.verify or "text"), encoding="utf-8")
    load_suite(target)  # validate what we wrote
    return target


@dataclass
class NewTest:
    test_id: str  # e.g. bw.9001
    description: str = ""
    tags: list[str] = field(default_factory=list)
    ear: Path | None = None  # EAR exported from Studio - copied into the case folder
    project_dir: Path | None = None  # Studio project folder - copied (optional)
    known_to_fail: str = ""
    skip: str = ""
    verify: str = ""  # empty = suite default
    timeout: int | None = None


@dataclass
class NewTestResult:
    suite_file: Path
    case_dir: Path
    copied: list[str]


def add_test(suite_file: Path, req: NewTest, assets_root: Path | str = "") -> NewTestResult:
    _check_name(req.test_id, "test id")
    suite = load_suite(suite_file, assets_root)
    if any(t.id.lower() == req.test_id.lower() for t in suite.tests):
        raise ConfigError(f"{req.test_id} already exists in {suite_file.name}")
    if req.ear and not Path(req.ear).is_file():
        raise ConfigError(f"EAR not found: {req.ear}")
    if req.project_dir and not Path(req.project_dir).is_dir():
        raise ConfigError(f"project folder not found: {req.project_dir}")

    project = req.test_id.replace(".", "_")
    case_dir = suite.assets_dir / req.test_id
    case_dir.mkdir(parents=True, exist_ok=True)
    copied = []
    if req.ear:
        shutil.copy2(req.ear, case_dir / f"{project}.application.ear")
        copied.append(f"{project}.application.ear")
    if req.project_dir:
        shutil.copytree(req.project_dir, case_dir / Path(req.project_dir).name, dirs_exist_ok=True)
        copied.append(Path(req.project_dir).name + "/")

    entry: dict = {"id": req.test_id}
    if req.description:
        entry["description"] = req.description
    tags = [t.strip() for t in req.tags if t.strip()]
    if tags:
        entry["tags"] = tags
    if req.known_to_fail:
        entry["known_to_fail"] = req.known_to_fail
    if req.skip:
        entry["skip"] = req.skip
    if req.verify:
        entry["verify"] = req.verify
    if req.timeout:
        entry["timeout"] = int(req.timeout)

    original = suite_file.read_text(encoding="utf-8")
    text = original.rstrip()
    item = yaml.safe_dump([entry], sort_keys=False, default_flow_style=False, allow_unicode=True)
    if text.endswith("tests: []"):
        text = text[: -len("[]")].rstrip()
    text += "\n" + "".join(f"  {ln}\n" for ln in item.splitlines())
    suite_file.write_text(text, encoding="utf-8")
    try:
        load_suite(suite_file, assets_root)
    except ConfigError:
        suite_file.write_text(original, encoding="utf-8")  # never leave a broken suite file behind
        raise
    return NewTestResult(suite_file, case_dir, copied)


def _yaml_scalar(value: str) -> str:
    """Quote a value for the template only when YAML would misread it."""
    dumped = yaml.safe_dump(value, default_flow_style=True, allow_unicode=True).strip()
    return dumped.removesuffix("\n...").removesuffix("...").strip()
