"""Shared helpers for the framework self-tests."""

import sys
import zipfile
from pathlib import Path

import pytest

pytest_plugins = ["pytester"]

FAKE_BWADMIN = Path(__file__).parent / "fake_bw" / "bwadmin.py"

SUBSTVAR = """<?xml version="1.0" encoding="UTF-8"?>
<repository xmlns="http://example.com/xmlns/repo/types/2002">
  <globalVariables>
    <globalVariable><name>//{p}//TSI_TEST_OUTPUT_FILE</name><value>c:/temp/x.log</value></globalVariable>
    <globalVariable><name>//{p}//GREETING</name><value>default</value></globalVariable>
    <globalVariable><name>//{p}//HOST_NAME</name><value/></globalVariable>
  </globalVariables>
</repository>
"""


def make_case(assets: Path, tid: str, output_template: str, gold: str | None) -> Path:
    """Create a legacy-style case folder: bw.X/ with EAR (+ fake output) and gold file."""
    project = tid.replace(".", "_")
    case = assets / tid
    (case / f"{project}.application" / "META-INF").mkdir(parents=True)
    (case / f"{project}.application" / "META-INF" / "default.substvar").write_text(SUBSTVAR.format(p=project))
    (case / f"{project}.application" / "META-INF" / "MANIFEST.MF").write_text("Bundle-Version: 1.0.0.qualifier\n")
    with zipfile.ZipFile(case / f"{project}.application.ear", "w") as zf:
        zf.writestr("fake_output.txt", output_template)
    if gold is not None:
        (case / f"{project}_gold.log").write_text(gold)
    return case


@pytest.fixture
def fake_project(tmp_path: Path) -> Path:
    """A complete bwtest project (config + suites + assets) wired to the fake bwadmin."""
    root = tmp_path / "proj"
    (root / "config").mkdir(parents=True)
    bw_home = root / "bw"
    (bw_home / "bin").mkdir(parents=True)
    (bw_home / "config").mkdir()
    (bw_home / "config" / "bwagent.ini").write_text("bw.admin.mode=local\n")
    (root / "config" / "bwtest.yaml").write_text(
        f"""
bw:
  home: {bw_home.as_posix()}
  domain_home: {(root / 'domains').as_posix()}
  tool_overrides:
    bwadmin: ["{Path(sys.executable).as_posix()}", "{FAKE_BWADMIN.as_posix()}"]
paths:
  assets_root: {(root / 'assets').as_posix()}
  results_dir: {(root / 'results').as_posix()}
timeouts: {{output_file: 5, stable_for: 0.2, app_start: 5, appnode_start: 5}}
"""
    )
    (root / "pytest.ini").write_text("[pytest]\ntestpaths = suites\n")
    return root
