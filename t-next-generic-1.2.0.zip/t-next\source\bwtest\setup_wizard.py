"""`bwtest setup` - asks for the machine settings once and writes config/local.yaml.

Used by setup-bwtest.bat on a new machine; can be run again any time (Enter keeps the shown value).
Every value is validated the same way as on the Preferences page (ui/services/preferences.py).
"""

from __future__ import annotations

import os
import shutil
from collections.abc import Callable
from pathlib import Path

import yaml

from .config import load_settings
from .errors import BwTestError


def _clean(path: str) -> str:
    return path.strip().strip('"').replace("\\", "/").rstrip("/")


def run_setup(config_dir: Path, ask: Callable[[str], str] = input, out: Callable[[str], None] = print) -> Path:
    """Ask the questions, write config/local.yaml, return its path."""
    from .bwhome import find_bw_homes, guess_version, normalize_version, resolve_bw_home
    from .ui.services import preferences
    from .ui.services.builds import discover_builds

    config_dir = Path(config_dir).resolve()
    local = config_dir / "local.yaml"
    if not local.is_file() and (config_dir / "local.yaml.example").is_file():
        shutil.copyfile(config_dir / "local.yaml.example", local)
    try:
        current = load_settings(config_dir)
    except BwTestError:
        current = None

    def question(text: str, default: str) -> str:
        try:
            answer = ask(f"  {text}\n  [{default}]: " if default else f"  {text}: ")
        except EOFError:  # no console (e.g. started from a script): keep the default
            answer = ""
        return _clean(answer) if answer.strip() else default

    def folder(text: str, default: str, must_exist: bool, check: Callable[[Path], bool] | None = None,
               hint: str = "") -> str:
        while True:
            value = question(text, default)
            path = Path(value)
            if not value:
                out("  Please enter a folder.")
                continue
            if path.is_dir() and (check is None or check(path)):
                out(f"  [OK] {value}\n")
                return value
            reason = "does not exist" if not path.is_dir() else hint
            if must_exist:
                out(f"  [X] {value} {reason}. Try again.\n")
                continue
            out(f"  [!] {value} {reason} - you can fix it later in the app (Preferences).\n")
            return value

    out("")
    out("  bwtest settings for this machine  (press Enter to keep the value in [brackets])")
    out("  ------------------------------------------------------------------------------")
    out("")

    # 1. BW installs + default build
    root_default = current.ui.builds_root.as_posix() if current and str(current.ui.builds_root) not in ("", ".") \
        else "C:/D"
    builds_root = folder("Folder that contains your BW installs  (any layout, e.g. C:/D with C:/D/6.12.1/V12/bw/6.12, "
                         "or C:/bw6 with C:/bw6/BW6121/bw/6.12)", root_default, must_exist=False)
    versions = sorted((p.stem for p in (config_dir / "profiles").glob("*.yaml")), reverse=True)
    found = [(v, b) for v in versions for b in discover_builds(Path(builds_root), v, known=versions)]
    if found:
        out("  BW builds found:")
        for i, (version, build) in enumerate(found, 1):
            out(f"    {i}) BW {version}  {build.label:<10} {build.bw_home}")
        while True:
            choice = question("Default build (number)", "1")
            if choice.isdigit() and 1 <= int(choice) <= len(found):
                break
            out(f"  Please enter a number from 1 to {len(found)}.")
        profile, bw_home = found[int(choice) - 1][0], found[int(choice) - 1][1].bw_home
        out(f"  [OK] BW {profile}  {bw_home}\n")
    else:
        out(f"  No BW builds of a known version ({', '.join(versions)}) found under {builds_root}.")
        entered = folder("BW folder of the build to use  (INSTALL_HOME like C:/bw6/BW6121, or its bw/<x.y> folder)",
                         current.bw.home.as_posix() if current else "", must_exist=False,
                         check=lambda p: len(find_bw_homes(p, max_depth=2)) == 1,
                         hint="has no BW install with bin/bwadmin.exe (or more than one - enter the one to use)")
        bw_home = resolve_bw_home(Path(entered)).as_posix()
        if bw_home != entered:
            out(f"  [OK] BW home: {bw_home}")
        guess = guess_version(Path(bw_home), versions) or (current.profile if current else "")
        profile = question(f"BW version of that build  (one of: {', '.join(versions)}; 6.12.1, BW6121 ... all work)",
                           guess)
        profile = normalize_version(profile, versions) or profile
        if profile not in versions:
            out(f"  [!] '{profile}' is not a known version - using {versions[0]}.")
            profile = versions[0]

    # 2. test cases, domain home, name
    assets = folder("Test case location  (folder with func/engine/... : EARs and gold files)",
                    current.paths.assets_root.as_posix() if current else "C:/D/Automation/tests/bw",
                    must_exist=False, check=lambda p: (p / "func").is_dir(), hint="has no func/ sub-folder")
    domain_home = question("Domain home  (where bwtest creates its temporary BW domain bwtest-N)",
                           current.bw.domain_home.as_posix() if current else "C:/domains")
    try:
        Path(domain_home).mkdir(parents=True, exist_ok=True)
        out(f"  [OK] {domain_home}\n")
    except OSError as exc:
        out(f"  [!] cannot create {domain_home}: {exc}\n")
    tester = question("Your name  (shown as Tester in reports)",
                      (current.ui.default_tester if current else "") or os.environ.get("USERNAME", ""))

    # 3. write: bw.home is not a Preferences field -> set it directly, then save + validate the rest
    data = yaml.safe_load(local.read_text(encoding="utf-8")) if local.is_file() else None
    data = data if isinstance(data, dict) else {}
    data.setdefault("bw", {})["home"] = bw_home
    local.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")
    preferences.save(config_dir, {"profile": profile, "ui.builds_root": builds_root, "paths.assets_root": assets,
                                  "bw.domain_home": domain_home, "ui.default_tester": tester})
    out(f"  [OK] saved to {local}")
    out("       (change any of it later in the app: Preferences)")
    return local
