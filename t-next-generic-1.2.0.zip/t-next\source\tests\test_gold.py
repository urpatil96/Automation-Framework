"""Gold changes: a failed gold comparison keeps the new output, and it can be accepted as gold later
(run page "Gold changes" / `bwtest accept-gold`) without running the test again."""

from pathlib import Path
from types import SimpleNamespace

import pytest

from bwtest import gold
from bwtest.errors import ConfigError, VerificationFailed
from bwtest.verify import run_verifications


def _ctx(run_dir: Path, output: Path, gold_file: Path, update_gold: bool = False):
    log_dir = run_dir / "bw-bat" / "bw.1"
    log_dir.mkdir(parents=True, exist_ok=True)
    ctx = SimpleNamespace(output_file=output, gold_file=gold_file, update_gold=update_gold, render=lambda s: s,
                          log_dir=log_dir, gold_candidates=[], suite=SimpleNamespace(name="bw-bat"),
                          test=SimpleNamespace(id="bw.1"), log=lambda m: None)
    ctx.write_artifact = lambda name, text, **_: (log_dir / name).write_text(text)
    ctx.bless = lambda out, g: g.write_bytes(out.read_bytes())
    return ctx


def _files(tmp_path, out_text="new line\n", gold_text="old line\n"):
    case = tmp_path / "assets" / "bw.1"
    case.mkdir(parents=True)
    out, g = tmp_path / "run" / "out.log", case / "bw_1_gold.log"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(out_text)
    if gold_text is not None:
        g.write_text(gold_text)
    return tmp_path / "run", out, g


def _fail_and_save(ctx, spec="text"):
    with pytest.raises(VerificationFailed):
        run_verifications(spec, ctx)
    gold.save(ctx)


def test_changed_output_can_be_accepted_as_gold_without_rerun(tmp_path):
    run_dir, out, g = _files(tmp_path)
    ctx = _ctx(run_dir, out, g)
    _fail_and_save(ctx)

    [change] = gold.changes(run_dir)
    assert (change.suite, change.test, change.kind, change.accepted) == ("bw-bat", "bw.1", "text", "")
    assert "+new line" in gold.diff_text(run_dir, change)
    out.write_text("overwritten by a later test\n")  # the kept copy is what gets accepted

    gold.accept(run_dir, change.key)
    assert g.read_text() == "new line\n"
    assert (ctx.log_dir / gold.BACKUP_DIR / f"0-{g.name}").read_text() == "old line\n"
    assert gold.changes(run_dir, include_accepted=False) == []
    assert gold.changes(run_dir)[0].accepted


def test_missing_gold_file_is_created_on_accept(tmp_path):
    run_dir, out, g = _files(tmp_path, gold_text=None)
    ctx = _ctx(run_dir, out, g)
    _fail_and_save(ctx)
    [change] = gold.changes(run_dir)
    assert not change.gold_exists
    gold.accept(run_dir, change.key)
    assert g.read_text() == "new line\n"


def test_only_the_failing_gold_check_is_offered(tmp_path):
    """Output equals gold, another check fails -> nothing to accept (accepting would not fix the test)."""
    run_dir, out, g = _files(tmp_path, gold_text="new line\n")
    ctx = _ctx(run_dir, out, g)
    with pytest.raises(VerificationFailed):
        run_verifications(["text", {"type": "exists", "files": [str(tmp_path / "missing.txt")]}], ctx)
    assert ctx.gold_candidates == []


def test_legacy_check_offers_output_and_update_gold_saves_it(tmp_path):
    run_dir, out, g = _files(tmp_path)
    ctx = _ctx(run_dir, out, g)
    ctx.run_legacy_script = lambda script: SimpleNamespace(returncode=1, output="diff found")
    _fail_and_save(ctx, {"type": "legacy", "script": "t_verify.sh"})
    assert gold.changes(run_dir)[0].kind == "legacy"

    ctx2 = _ctx(tmp_path / "run2", out, g, update_gold=True)
    ctx2.run_legacy_script = lambda script: pytest.fail("update gold must not run the old script")
    run_verifications({"type": "legacy", "script": "t_verify.sh"}, ctx2)
    assert g.read_text() == out.read_text()


def test_accept_rejects_keys_outside_the_run(tmp_path):
    run_dir, out, g = _files(tmp_path)
    _fail_and_save(_ctx(run_dir, out, g))
    with pytest.raises(ConfigError):
        gold.accept(run_dir, "../../assets/bw.1#0")
    with pytest.raises(ConfigError):
        gold.accept(run_dir, "bw-bat/bw.1#7")


def test_executor_keeps_the_output_only_when_verify_fails(monkeypatch, tmp_path):
    import bwtest.executor as ex

    saved = []
    monkeypatch.setattr(ex, "run_actions", lambda steps, ctx: None)
    monkeypatch.setattr(ex, "save_gold_changes", lambda ctx: saved.append(ctx))

    def failing(spec, ctx):
        ctx.gold_candidates.append({"output": tmp_path, "gold": tmp_path, "kind": "text"})
        raise VerificationFailed("output differs")

    monkeypatch.setattr(ex, "run_verifications", failing)
    ctx = SimpleNamespace(case_dir=tmp_path, render=lambda s: s, vars={}, log=lambda m: None, mark_log=lambda: None,
                          timings={}, gold_candidates=[], update_gold=False,
                          write_artifact=lambda *a, **k: None, appnode_log_slice=lambda: "")
    (tmp_path / "app.ear").write_bytes(b"")
    executor = ex.TestExecutor.__new__(ex.TestExecutor)
    executor.runtime = SimpleNamespace(deploy=lambda *a: "dep", undeploy=lambda dep: None)
    executor.last_ctx = None
    executor.settings = SimpleNamespace(dry_run=False, bw=SimpleNamespace(app_version="1.0"))
    executor.suite = SimpleNamespace(type="bw_engine", legacy={}, name="s")
    executor.prepare = lambda test, seq: ctx
    executor.write_profile = lambda *a: tmp_path / "p.substvar"
    test = SimpleNamespace(id="bw.1", description="", ear="app.ear", app_name="app", action=[], legacy={},
                           verify={"type": "text"})
    with pytest.raises(VerificationFailed):
        executor.run_once(test)
    assert saved == [ctx]
