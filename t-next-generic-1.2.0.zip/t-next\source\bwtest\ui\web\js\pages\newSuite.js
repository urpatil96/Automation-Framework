// Create a suite file from a form (same template as `bwtest new-suite`).
import { api } from "../core/api.js";
import { h, mount } from "../core/dom.js";
import {
  button, callout, card, field, input, notifyChanged, pageHeader, pathInput, select, textarea, toast,
} from "../components/ui.js";

export default {
  title: "New suite",
  async render(view) {
    const [suites, overview] = await Promise.all([api.suites(), api.overview()]);
    const categories = [...new Set(suites.map((s) => s.category).filter(Boolean))].sort();
    const v = { category: "engine", name: "", owner: overview.default_tester || "", description: "", assets_dir: "", tags: "", type: "", verify: "text" };
    const preview = h("div", { class: "cmd" });
    const error = h("div");
    const bind = (k) => (e) => { v[k] = e.target.value; update(); };

    function update() {
      const name = v.name.trim() || "<name>";
      mount(preview, h("code", {}, `suites/${v.category || "engine"}/${name}/${name}.suite.yaml`));
    }
    update();

    const create = async () => {
      mount(error);
      try {
        const r = await api.createSuite({ ...v, name: v.name.trim(), tags: v.tags.split(",").map((t) => t.trim()).filter(Boolean) });
        toast(`Suite ${r.name} created`);
        notifyChanged();
        view.navigate(`/suites/${encodeURIComponent(r.name)}`);
      } catch (e) { mount(error, callout("bad", "Could not create:", e.message)); }
    };

    return h("div", { class: "stack" },
      pageHeader("New suite", "A suite groups test cases that share one AppSpace/AppNode, variables and drivers. You add the test cases next."),
      h("div", { class: "grid grid-side" },
        card({ title: "Suite" },
          h("div", { class: "form-grid" },
            field("Name", input({ placeholder: "e.g. rest_json", oninput: bind("name") }),
              "Also the AppSpace/AppNode name. Letters, digits, _ - .", "TSI_COMPONENT", { required: true }),
            field("Category", h("div", {}, input({ value: v.category, list: "cats", oninput: bind("category") }),
              h("datalist", { id: "cats" }, categories.map((c) => h("option", { value: c })))), "Folder under suites/ - engine or migration/..."),
            field("Type", select([["", "automatic (migration/* = migration)"], ["bw_engine", "Engine (deploy EAR)"], ["bw_migration", "Migration (BW5 project → bwmigrator)"]], "",
              { onchange: bind("type") }), "", "Types of testing: BW_ENGINE / BW_MIGRATION"),
            field("Owner", input({ value: v.owner, oninput: bind("owner") })),
            field("Default verification", select([["text", "text (gold file)"], ["xml", "xml"], ["json", "json"], ["binary", "binary"]], "text",
              { onchange: bind("verify") }), "How outputs are compared with the gold files. Each test can override."),
            field("Tags", input({ placeholder: "rest, smoke", oninput: bind("tags") }), "Comma separated.")),
          field("Description", textarea({ rows: 2, placeholder: "what this suite covers", oninput: bind("description") })),
          field("Test case folders (optional)", pathInput({ kind: "folder", placeholder: "${assets_root}/func/engine/rest_json",
            onchange: (x) => { v.assets_dir = x; } }),
            "Where the bw.XXXX/ folders with EAR + gold live. Empty = next to the suite file. ${assets_root} = Test case location from Preferences.",
            "test case location by product"),
          error,
          h("div", { class: "row" }, button("Create suite", create, "primary"), h("a", { href: "#/suites" }, "Cancel"))),
        h("div", { class: "stack" },
          card({ title: "File that will be created" }, preview),
          card({ title: "After creating" }, h("ol", { style: { paddingLeft: "18px", margin: 0 } },
            h("li", {}, "Add test cases (button on the suite page)."),
            h("li", {}, "Optional: add variables, .cfg files, drivers in the Edit YAML tab."),
            h("li", {}, "Run once with “Update gold” to create the expected results."),
            h("li", {}, "Commit suites/… and the case folders to git."))))));
  },
};
