"""Regression: runs started from the desktop app (pythonw, no console) failed on the first bwadmin call with
`OSError: [WinError 6] The handle is invalid` (pytest swaps stdin; the child inherited a dead handle).

The test starts a helper under pythonw.exe (no console - exactly like start-bwtest.bat); the helper starts a run
through the UI's RunManager on a project wired to the fake bwadmin and reports the outcomes.
"""

import json
import os
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

from tests.conftest import make_case

pytestmark = pytest.mark.skipif(os.name != "nt", reason="Windows console handling")

HELPER = textwrap.dedent("""
    import json, sys, time
    from pathlib import Path
    from bwtest.ui.context import UiContext
    from bwtest.ui.services.runs import RunRequest

    root, out = Path(sys.argv[1]), Path(sys.argv[2])
    ctx = UiContext(root, root / "config")
    run_id = ctx.runs.start(RunRequest(suites=["demo"]), ctx.suite_files())
    for _ in range(240):
        detail = ctx.runs.detail(run_id)
        if detail["state"] not in ("running", "stopping"):
            break
        time.sleep(0.5)
    console = ctx.runs.console(run_id)["text"]
    out.write_text(json.dumps({"state": detail["state"], "console": console[-3000:],
                               "tests": {t["id"]: t["outcome"] for t in detail["tests"]}}))
""")


def test_run_started_without_console(fake_project: Path, tmp_path: Path):
    pythonw = Path(sys.executable).with_name("pythonw.exe")
    if not pythonw.is_file():
        pytest.skip("pythonw.exe not available")
    assets = fake_project / "assets" / "demo"
    assets.mkdir(parents=True)
    make_case(assets, "bw.1", "same\n", "same\n")
    (fake_project / "suites").mkdir(exist_ok=True)
    (fake_project / "suites" / "demo.suite.yaml").write_text("suite: demo\nassets_dir: ${assets_root}/demo\n"
                                                             "tests: [bw.1]\n")
    helper = tmp_path / "helper.py"
    helper.write_text(HELPER)
    result_file = tmp_path / "result.json"
    env = {**os.environ, "PYTHONPATH": str(Path(__file__).resolve().parents[1])}
    subprocess.run([str(pythonw), str(helper), str(fake_project), str(result_file)], env=env, timeout=180,
                   stdin=subprocess.DEVNULL, check=False)
    result = json.loads(result_file.read_text())
    assert "WinError 6" not in result["console"], result["console"]
    assert result["tests"] == {"bw.1": "passed"}, result["console"]
