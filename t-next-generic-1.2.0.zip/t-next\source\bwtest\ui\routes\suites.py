"""Browse and edit suites, add suites and test cases, saved selections."""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Request
from pydantic import BaseModel, Field

from ...errors import ConfigError
from ...models import load_suite
from ...scaffold import NewSuite, NewTest, add_test, create_suite
from ..services import selections

router = APIRouter(prefix="/api", tags=["suites"])


def _ctx(request: Request):
    return request.app.state.ctx


def _entry(request: Request, name: str):
    entry = _ctx(request).catalog.find(name)
    if entry is None:
        raise ConfigError(f"suite '{name}' not found")
    return entry


@router.get("/suites")
def list_suites(request: Request) -> list[dict]:
    ctx = _ctx(request)
    return [ctx.catalog.summary(e) for e in ctx.catalog.entries()]


@router.get("/suites/{name}")
def suite_detail(name: str, request: Request) -> dict:
    return _ctx(request).catalog.detail(_entry(request, name))


@router.get("/suites/{name}/source")
def suite_source(name: str, request: Request) -> dict:
    entry = _entry(request, name)
    return {"file": _ctx(request).catalog.rel(entry.file), "text": entry.file.read_text(encoding="utf-8")}


class SourceBody(BaseModel):
    text: str


def _validate(text: str, near: Path, assets_root) -> dict:
    """Parse the YAML exactly like a run would, next to the real file so relative paths resolve the same."""
    probe = near.parent / f"~validate-{near.name}.tmp"
    probe.write_text(text, encoding="utf-8")
    try:
        suite = load_suite(probe, assets_root)
        return {"ok": True, "suite": suite.name, "tests": len(suite.tests), "error": ""}
    except ConfigError as exc:
        return {"ok": False, "error": str(exc).replace(str(probe.resolve()), near.name).replace(str(probe), near.name)}
    finally:
        probe.unlink(missing_ok=True)


@router.post("/suites/{name}/validate")
def validate_source(name: str, body: SourceBody, request: Request) -> dict:
    entry = _entry(request, name)
    return _validate(body.text, entry.file, _ctx(request).catalog.assets_root)


@router.put("/suites/{name}/source")
def save_source(name: str, body: SourceBody, request: Request) -> dict:
    entry = _entry(request, name)
    result = _validate(body.text, entry.file, _ctx(request).catalog.assets_root)
    if not result["ok"]:
        raise ConfigError(result["error"])
    entry.file.write_text(body.text.replace("\r\n", "\n"), encoding="utf-8")
    return result


class NewSuiteBody(BaseModel):
    category: str = "engine"
    name: str
    owner: str = ""
    description: str = ""
    assets_dir: str = ""
    tags: list[str] = Field(default_factory=list)
    type: str = ""
    verify: str = "text"


@router.post("/suites")
def new_suite(body: NewSuiteBody, request: Request) -> dict:
    ctx = _ctx(request)
    target = create_suite(ctx.root / "suites", NewSuite(
        path=f"{body.category.strip('/') or 'engine'}/{body.name}", owner=body.owner, description=body.description,
        assets_dir=body.assets_dir.replace("\\", "/"), tags=body.tags, type=body.type, verify=body.verify))
    suite = load_suite(target, ctx.catalog.assets_root)
    return {"name": suite.name, "file": ctx.catalog.rel(target)}


class NewTestBody(BaseModel):
    test_id: str
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    ear: str = ""
    project_dir: str = ""
    known_to_fail: str = ""
    skip: str = ""
    verify: str = ""
    timeout: int | None = None


@router.post("/suites/{name}/tests")
def new_test(name: str, body: NewTestBody, request: Request) -> dict:
    entry = _entry(request, name)
    result = add_test(entry.file, NewTest(
        test_id=body.test_id.strip(), description=body.description, tags=body.tags,
        ear=Path(body.ear.strip().strip('"')) if body.ear.strip() else None,
        project_dir=Path(body.project_dir.strip().strip('"')) if body.project_dir.strip() else None,
        known_to_fail=body.known_to_fail, skip=body.skip, verify=body.verify, timeout=body.timeout),
        _ctx(request).catalog.assets_root)
    return {"suite_file": _ctx(request).catalog.rel(result.suite_file), "case_dir": result.case_dir.as_posix(),
            "copied": result.copied}


# -- sync with the user's own test folder: new suites + new test cases (existing tests are never changed) -----------
def _func_dir(request: Request) -> Path:
    return Path(_ctx(request).settings().paths.assets_root) / "func"


def _sync_plan(request: Request):
    from ...legacy import sync

    settings = _ctx(request).settings()
    drivers = {k: v.suites for k, v in settings.drivers.items()}
    dbs = {k: v.suites for k, v in settings.databases.items()}
    func = _func_dir(request)
    plan = sync.plan(func, _ctx(request).root / "suites", settings.paths.assets_root, drivers, dbs)
    return plan, settings, drivers, dbs


@router.get("/import/pending")
def import_pending(request: Request) -> dict:
    """What 'Sync with test folder' would do: new suites and new test cases in <assets_root>/func."""
    ctx = _ctx(request)
    func = _func_dir(request)
    if not func.is_dir():
        return {"source": func.as_posix(), "source_exists": False, "suites": [], "updates": []}
    plan, *_ = _sync_plan(request)
    return {"source": func.as_posix(), "source_exists": True,
            "suites": [{"name": p.stem, "folder": p.parent.relative_to(func).as_posix()} for p in plan.new_suites],
            "updates": [{"name": u.name, "file": ctx.catalog.rel(u.suite_file), "new_tests": u.new_tests,
                         "gone_tests": u.gone_tests} for u in plan.updates]}


class ImportBody(BaseModel):
    names: list[str] = Field(default_factory=list)  # suites to import / update; empty = everything pending


@router.post("/import")
def import_suites(body: ImportBody, request: Request) -> dict:
    """Import new suites and append new test cases to existing suites (only appends - nothing is rewritten)."""
    from ...legacy import sync
    from ...legacy.importer import report_path, write_report

    ctx = _ctx(request)
    plan, settings, drivers, dbs = _sync_plan(request)
    wanted = {n.lower() for n in body.names} or None
    todo = [p.stem for p in plan.new_suites] + [u.name for u in plan.updates if u.new_tests]
    if not [n for n in todo if wanted is None or n.lower() in wanted]:
        raise ConfigError("nothing to import - every suite and test case of the test folder is already in T-Next")
    out = ctx.root / "suites"
    result = sync.apply(plan, out, settings.paths.assets_root, drivers, dbs, wanted)
    report = None
    if result.imported:
        report = report_path(out, skipped=[True])  # dated report: keeps IMPORT_REPORT.md of the first import
        write_report(result.imported, report)
    return {
        "imported": [{"name": r.suite_name, "tests": r.tests, "file": ctx.catalog.rel(r.target),
                      "bridged": len(r.bridged_tests) if not r.bridged_suite else r.tests} for r in result.imported],
        "added": [{"name": name, "tests": ids} for name, ids in result.added.items()],
        "gone": [{"name": name, "tests": ids} for name, ids in result.gone.items()],
        "failed": [{"name": name, "error": error} for name, error in result.failed],
        "tests": sum(r.tests for r in result.imported),
        "added_tests": result.added_tests,
        "report": ctx.catalog.rel(report) if report else "",
    }


@router.get("/tags")
def tags(request: Request) -> list[dict]:
    counts: dict[str, int] = {}
    for e in _ctx(request).catalog.entries():
        if not e.suite:
            continue
        for t in e.suite.tests:
            for tag in {*e.suite.tags, *t.tags, e.suite.type}:
                counts[tag] = counts.get(tag, 0) + 1
    return [{"tag": k, "tests": v} for k, v in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))]


# -- saved selections (old .testcmd files) -------------------------------------------------------
@router.get("/selections")
def list_selections(request: Request) -> list[dict]:
    return selections.list_all(_ctx(request).config_dir)


class SelectionBody(BaseModel):
    description: str = ""
    suites: list[str] = Field(default_factory=list)
    tests: list[str] = Field(default_factory=list)
    marker: str = ""
    keyword: str = ""


@router.put("/selections/{name}")
def save_selection(name: str, body: SelectionBody, request: Request) -> dict:
    selections.save(_ctx(request).config_dir, name, body.model_dump())
    return {"name": name}


@router.delete("/selections/{name}")
def delete_selection(name: str, request: Request) -> dict:
    selections.delete(_ctx(request).config_dir, name)
    return {"deleted": name}
