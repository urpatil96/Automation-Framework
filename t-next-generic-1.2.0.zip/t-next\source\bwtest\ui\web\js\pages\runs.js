// Run history: every folder in results/ (runs from the UI, the command line and Jenkins alike).
import { api } from "../core/api.js";
import { h, mount } from "../core/dom.js";
import { RUN_STATES } from "../core/format.js";
import {
  card, countsBar, countsText, empty, input, linkButton, pageHeader, runStatePill, select,
} from "../components/ui.js";

export default {
  title: "Runs & reports",
  async render(view) {
    const data = await api.runs(300);
    const filters = { state: "all", text: "" };
    const host = h("div", { class: "table-wrap" });

    function draw() {
      const q = filters.text.toLowerCase();
      const rows = data.runs.filter((r) => (filters.state === "all" || r.state === filters.state)
        && (!q || `${r.id} ${r.name} ${r.tester} ${r.profile} ${r.build} ${(r.targets || []).join(" ")}`.toLowerCase().includes(q)));
      mount(host, rows.length ? h("table", { class: "table" },
        h("thead", {}, h("tr", {}, ["Started", "Run", "Profile / build", "Tester", "Result", "", "Status", ""].map((t) => h("th", {}, t)))),
        h("tbody", {}, rows.map((r) => h("tr", { class: "clickable", onclick: () => view.navigate(`/runs/${r.id}`) },
          h("td", { class: "nowrap" }, r.started, h("div", { class: "muted small mono" }, r.id)),
          h("td", {}, r.name || h("span", { class: "muted" }, "(no name)"),
            h("div", { class: "muted small" }, (r.targets || []).map((t) => t.split("/").pop().replace(".suite.yaml", "")).join(", "))),
          h("td", { class: "nowrap" }, [r.profile, r.build].filter(Boolean).join(" · ") || "—", r.dry_run ? h("div", {}, h("span", { class: "tag" }, "dry run")) : null),
          h("td", {}, r.tester || "—"),
          h("td", { style: { minWidth: "160px" } }, countsBar(r.counts)),
          h("td", {}, countsText(r.counts)),
          h("td", {}, runStatePill(r.state)),
          h("td", { class: "right", onclick: (e) => e.stopPropagation() },
            r.has_report ? h("a", { href: api.rawUrl(r.id, "report.html"), target: "_blank", rel: "noopener", class: "small" }, "report ↗") : null)))))
        : empty("No runs found", data.runs.length ? "Change the filters." : "Start your first run.",
          linkButton("▶  New run", "#/run/new", "primary")));
    }

    draw();
    return h("div", { class: "stack" },
      pageHeader("Runs & reports", "All runs in the results folder - started here, from the command line or from Jenkins.",
        linkButton("▶  New run", "#/run/new", "primary")),
      card({ class: "flush" },
        h("div", { style: { padding: "12px 14px" } },
          h("div", { class: "row", style: { marginBottom: "10px" } },
            input({ class: "input search", placeholder: "Search name, tester, build, suite…", oninput: (e) => { filters.text = e.target.value; draw(); } }),
            select([["all", "All results"], ...Object.entries(RUN_STATES).map(([k, v]) => [k, v.label])], "all",
              { style: { width: "auto" }, onchange: (e) => { filters.state = e.target.value; draw(); } }),
            h("span", { class: "spacer" }), h("span", { class: "muted small" }, `${data.runs.length} runs`)),
          host)));
  },
};
