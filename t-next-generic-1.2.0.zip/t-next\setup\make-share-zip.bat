@echo off
rem ============================================================================================
rem  bwtest - make a clean zip to give to a colleague.
rem
rem    setup\make-share-zip.bat                 zip of the project (small)
rem    setup\make-share-zip.bat --with-wheels   + setup\wheels with all Python packages, so the colleague
rem                                               can install WITHOUT internet (same Python version needed)
rem
rem  Left out automatically (personal / machine-specific / large):
rem    .venv  results  config\local.yaml  .env  __pycache__  .pytest_cache  .ruff_cache  *.pyc
rem  The zip is written next to the project folder:  ..\bwtest-share-<version>-<date>.zip
rem  The colleague unzips it anywhere and double-clicks setup\setup-bwtest.bat.
rem ============================================================================================
setlocal EnableExtensions EnableDelayedExpansion
for %%R in ("%~dp0..") do set "ROOT=%%~fR"
cd /d "%ROOT%"
title bwtest share zip

set "WHEELS="
if /i "%~1"=="--with-wheels" set "WHEELS=1"

set "VER=unknown"
if exist ".venv\Scripts\bwtest.exe" for /f "tokens=2" %%V in ('".venv\Scripts\bwtest.exe" --version') do set "VER=%%V"
for /f %%D in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmm"') do set "STAMP=%%D"
for %%P in ("%ROOT%\..") do set "OUTDIR=%%~fP"
set "NAME=bwtest-share-%VER%-%STAMP%"
set "STAGE=%TEMP%\%NAME%\bw6-autotest"
set "ZIP=%OUTDIR%\%NAME%.zip"

echo.
echo  Making %ZIP%
echo  ------------------------------------------------------------------
if exist "%TEMP%\%NAME%" rmdir /s /q "%TEMP%\%NAME%"

rem robocopy: /E sub-folders, /XD folders to skip, /XF files to skip. Exit codes below 8 = success.
robocopy "%ROOT%" "%STAGE%" /E /NFL /NDL /NJH /NJS /NP ^
  /XD .venv results __pycache__ .pytest_cache .ruff_cache .git .desktop-webview wheels ^
  /XF local.yaml .env *.pyc *.pyo >nul
if errorlevel 8 ( echo  [X] Copying the project failed. & goto :fail )

rem safety net: never ship personal settings or passwords
if exist "%STAGE%\config\local.yaml" del /q "%STAGE%\config\local.yaml"
if exist "%STAGE%\.env" del /q "%STAGE%\.env"
echo  [OK] project copied ^(without .venv, results, local.yaml, .env, caches^)

if defined WHEELS (
  if not exist ".venv\Scripts\python.exe" ( echo  [X] --with-wheels needs the .venv of this project. & goto :fail )
  echo  Downloading all Python packages into setup\wheels ^(for offline install^) ...
  ".venv\Scripts\python.exe" -m pip download --timeout 60 -d "%STAGE%\setup\wheels" "source[report,parallel,desktop]" setuptools wheel
  if errorlevel 1 ( echo  [X] Downloading the packages failed ^(internet / proxy?^). & goto :fail )
  for /f "delims=" %%I in ('".venv\Scripts\python.exe" -c "import platform; print(platform.python_version())"') do set "PYV=%%I"
  > "%STAGE%\setup\wheels\README.txt" echo These packages were downloaded for Python !PYV! on Windows. setup-bwtest.bat installs
  >>"%STAGE%\setup\wheels\README.txt" echo from here automatically. The colleague needs the same Python version ^(major.minor^).
  echo  [OK] packages downloaded for Python !PYV!
)

if exist "%ZIP%" del /q "%ZIP%"
powershell -NoProfile -Command "Compress-Archive -Path '%TEMP%\%NAME%\bw6-autotest' -DestinationPath '%ZIP%' -CompressionLevel Optimal"
if errorlevel 1 ( echo  [X] Creating the zip failed. & goto :fail )
rmdir /s /q "%TEMP%\%NAME%"

for %%Z in ("%ZIP%") do set "SIZE=%%~zZ"
set /a SIZEKB=SIZE/1024
echo  [OK] %ZIP%   (!SIZEKB! KB)
echo.
echo  Give your colleague:
echo    1. this zip  -  they unzip it anywhere
echo    2. the DB / EMS passwords they need ^(they put them into .env - do not send your .env^)
echo    3. the instruction: double-click setup\setup-bwtest.bat - it asks where to install
echo.
echo  Not in the zip ^(they need their own^): BW installs, the test case folder
echo  C:\D\Automation\tests\bw, Python 3.12/3.13 and Git for Windows. See docs\USER_GUIDE.md.
echo.
pause
exit /b 0

:fail
if exist "%TEMP%\%NAME%" rmdir /s /q "%TEMP%\%NAME%"
echo.
pause
exit /b 1
