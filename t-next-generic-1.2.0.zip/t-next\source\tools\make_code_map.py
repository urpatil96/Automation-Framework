"""Generate docs/CODE_MAP.md: folder tree + one line per source file from its own docstring / header comment.

    python source\\tools\\make_code_map.py
"""
import ast
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]  # project root
SKIP = {".venv", "results", "__pycache__", ".pytest_cache", ".ruff_cache", ".git", "wheels"}


def first_line(path: Path) -> str:
    text = path.read_text(encoding="utf-8", errors="replace")
    if path.suffix == ".py":
        try:
            doc = ast.get_docstring(ast.parse(text)) or ""
        except SyntaxError:
            doc = ""
        line = doc.strip().splitlines()[0] if doc.strip() else ""
    elif path.suffix in (".js", ".css"):
        m = re.match(r"\s*(?://|/\*)\s*(.+)", text)
        line = m.group(1).rstrip("*/ ").strip() if m else ""
    elif path.suffix in (".sh", ".bat", ".yaml", ".yml", ".toml") or path.name in ("Jenkinsfile", ".gitignore"):
        line = ""
        for raw in text.splitlines()[:15]:
            s = raw.strip()
            s = re.sub(r"^(@echo off|rem|::|#!.*|#|//)\s*", "", s, flags=re.I)
            if s and not set(s) <= set("=-") and not s.lower().startswith(("setlocal", "echo off")):
                line = s
                break
    else:
        line = ""
    line = line.replace("|", "/")
    return (line[:110] + "…") if len(line) > 110 else line


def tree(folder: Path, prefix: str = "", depth: int = 0, max_depth: int = 6, lines=None):
    lines = [] if lines is None else lines
    items = sorted((p for p in folder.iterdir() if p.name not in SKIP and not p.name.endswith(".pyc")),
                   key=lambda p: (p.is_file(), p.name.lower()))
    for i, p in enumerate(items):
        last = i == len(items) - 1
        branch = "└─ " if last else "├─ "
        if p.is_dir():
            n_files = sum(1 for f in p.rglob("*") if f.is_file() and not any(s in f.parts for s in SKIP))
            if p.name in ("suites", "docker", "data") or (depth >= max_depth):
                lines.append(f"{prefix}{branch}{p.name}/  ({n_files} files)")
                continue
            lines.append(f"{prefix}{branch}{p.name}/")
            tree(p, prefix + ("   " if last else "│  "), depth + 1, max_depth, lines)
        else:
            desc = first_line(p) if p.suffix in (".py", ".js", ".css", ".sh", ".bat") else ""
            lines.append(f"{prefix}{branch}{p.name}" + (f"  — {desc}" if desc else ""))
    return lines


def count(pattern: str, base: str = "source/bwtest") -> tuple[int, int]:
    files = [f for f in (ROOT / base).rglob(pattern) if "__pycache__" not in f.parts]
    return len(files), sum(len(f.read_text(encoding="utf-8", errors="replace").splitlines()) for f in files)


py_n, py_l = count("*.py")
js_n, js_l = count("*.js")
t_n, t_l = count("*.py", "source/tests")
suites = list((ROOT / "suites").rglob("*.suite.yaml"))

out = [
    "# T-Next code map",
    "",
    "Folder structure and the job of every source file, for developers. Generated from the files' own header",
    "comments, so it matches the code. Regenerate after adding files: `python source/tools/make_code_map.py`.",
    "How it fits together:",
    "[ARCHITECTURE.md](ARCHITECTURE.md) · rules for changes: [CONTRIBUTING.md](CONTRIBUTING.md).",
    "",
    "| | Files | Lines |",
    "|---|---|---|",
    f"| Python framework (`source/bwtest`) | {py_n} | {py_l:,} |",
    f"| UI JavaScript (`source/bwtest/ui/web`) | {js_n} | {js_l:,} |",
    f"| Self-tests (`source/tests`) | {t_n} | {t_l:,} |",
    f"| Suites (`suites`, YAML) | {len(suites)} | - |",
    "",
    "## Open it as a developer",
    "",
    "* **VS Code** (recommended): *File → Open Folder → `C:\\D\\bw6-autotest\\source`* - only the code.",
    "  Settings come with it (`source/.vscode/`): interpreter `..\\.venv`, self-tests in the Testing panel,",
    "  debug configurations (desktop app, dry run, run a suite, doctor) under *Run and Debug*, CI checks under",
    "  *Terminal → Run Task*, and recommended extensions (Python, Ruff, YAML).",
    "* **Eclipse**: only with the PyDev plugin (Python support). Do not add PyDev to Business Studio - use a",
    "  separate Eclipse IDE, or VS Code.",
    "",
    "## Where to start reading",
    "",
    "1. `source/bwtest/cli.py` - the commands (`bwtest run`, `desktop`, `setup` …)",
    "2. `source/bwtest/pytest_plugin.py` - suite YAML → pytest tests; suite setup/teardown",
    "3. `source/bwtest/executor.py` - one test: prepare → deploy → action → cleanup → verify",
    "4. `source/bwtest/runtime.py` + `bwcli.py` - domain / AppSpace / AppNode / app via bwadmin",
    "5. `source/bwtest/ui/` - desktop/web app: `server.py` (REST API) + `web/` (screens)",
    "",
    "## Folder tree",
    "",
    "```",
    "bw6-autotest/",
    *tree(ROOT),
    "```",
    "",
]
(ROOT / "docs" / "CODE_MAP.md").write_text("\n".join(out), encoding="utf-8")
print("\n".join(out[:20]))
print(f"... {len(out)} lines")
