"""Importer: legacy .testset + bash scripts -> suite.yaml."""

import re
import shutil
from pathlib import Path

import pytest
import yaml

from bwtest.legacy.bridge import find_bash, run_script
from bwtest.legacy.importer import import_testset
from bwtest.models import load_suite

TESTSET = """<?xml version="1.0" encoding="UTF-8"?>
<TestsDoc><TestSet><Owner>QA</Owner><Description>demo</Description><TestCases>
 <TestCase><ID>bw.1</ID><TestSequence>1</TestSequence><KnownToFail>false</KnownToFail><Project>bw_1</Project>
   <Description>one</Description><SetupScript>t_setup.sh</SetupScript><ActionScript>t_action.sh</ActionScript>
   <VerifyScript>t_verify.sh </VerifyScript></TestCase>
 <TestCase><ID>bw.2</ID><TestSequence>2</TestSequence><KnownToFail>true</KnownToFail><Project>bw_2</Project>
   <Description>two</Description><SetupScript>t_setup.sh</SetupScript><ActionScript>t_action.sh</ActionScript>
   <VerifyScript>t_verify.sh</VerifyScript></TestCase>
 <TestCase><ID>#bw.3</ID><TestSequence>1</TestSequence><KnownToFail>false</KnownToFail><Project>bw_3</Project>
   <Description>disabled</Description><SetupScript>t_setup.sh</SetupScript><ActionScript>t_action.sh</ActionScript>
   <VerifyScript>t_verify.sh</VerifyScript></TestCase>
 <TestCase><ID>bw.4</ID><TestSequence>1</TestSequence><KnownToFail>false</KnownToFail><Project>bw_4</Project>
   <Description>needs ems</Description><SetupScript>t_setup.sh</SetupScript><ActionScript>t_action.sh</ActionScript>
   <VerifyScript>t_verify.sh</VerifyScript></TestCase>
</TestCases></TestSet></TestsDoc>
"""

SETUP = r"""
t_set_txt() {
    export TSI_TEST_OUTPUT_FILE="${TSI_LOG_DIR}/${TSI_TEST_ID}_output.$1"
}
t-testsSetAdvanceVerify true
if [ -d "${TIB_BW_HOME}/bin" ]; then
    t_bw_ver=`bwadmin version`
    if [ -n "${t_dbg}" ]; then
        echo x
    fi
fi
export TSI_TEST_OUTPUT_FILE="${TSI_LOG_DIR}/${TSI_TEST_ID}_output.log"
export TSI_TEST_GOLD_FILE="${TSI_REPO_DIR}/${TSI_TEST_ID}_gold.log"
export KEYSTORE=${TSI_TESTPLAN_DIR}/JKS/server.jks
rm -f ${TSI_TEST_DIFF_FILE}
case ${TSI_TEST_ID} in
    bw_1 ) t_set_txt txt ;;
    bw_2 )
        export TSI_TEST_GOLD_FILE="${TSI_REPO_DIR}/${TSI_TEST_ID}_gold_${TSI_TEST_SEQUENCE}.log"
        case ${TSI_TEST_SEQUENCE} in
            1 ) export METHOD=GET ;;
            2 ) export METHOD=POST ;;
        esac
        ;;
    bw_4 )
        ${TSI_JMS_HOME}/bin/tibemsadmin.exe -script ${TSI_TESTPLAN_DIR}/purge.scr
        ;;
esac
if [ "${TSI_PROD_VERSION_3DIGIT}" == "681" ] || [ "${TSI_PROD_VERSION_3DIGIT}" == "690" ] ;
then
    case ${TSI_TEST_ID} in
        bw_1 ) export TSI_TEST_GOLD_FILE="${TSI_REPO_DIR}/${TSI_TEST_ID}_gold_681.log" ;;
    esac
fi
case ${NPORT} in
    i86-winnt50 ) export SEP=win ;;
    * ) export SEP=unix ;;
esac
"""

ACTION = """
case ${TSI_TID} in
    bw.1 ) t_sleep 40 ;;
esac
"""

VERIFY = """
diff -b ${TSI_TEST_OUTPUT_FILE} ${TSI_TEST_GOLD_FILE} > ${TSI_TEST_DIFF_FILE}
"""


@pytest.fixture
def legacy(tmp_path: Path) -> Path:
    suite = tmp_path / "bw" / "func" / "engine" / "demo"
    suite.mkdir(parents=True)
    (suite / "demo.testset").write_text(TESTSET)
    (suite / "t_setup.sh").write_text(SETUP)
    (suite / "t_action.sh").write_text(ACTION)
    (suite / "t_verify.sh").write_text(VERIFY)
    (suite / "demo.cfg").write_text("app.clientVar.A=1\n")
    for tid in ("bw.1", "bw.2", "bw.4"):
        (suite / tid).mkdir()
    return suite / "demo.testset"


def test_import_translates_scripts(legacy, tmp_path):
    result = import_testset(legacy, tmp_path / "out", assets_root=tmp_path / "bw",
                            driver_map={"oracle-19c": ["demo"]})
    data = yaml.safe_load(result.target.read_text())
    tests = {t["id"]: t for t in data["tests"]}

    assert data["assets_dir"] == "${assets_root}/func/engine/demo"
    assert data["client_vars_files"] == ["demo.cfg"]
    assert data["drivers"] == ["oracle-19c"]
    assert data["vars"] == {"KEYSTORE": "${suite_dir}/JKS/server.jks", "SEP": "win"}
    assert data["defaults"]["verify"] == {"type": "text", "ignore_whitespace": True}
    assert "legacy" not in data  # suite-level parts were all translatable

    assert tests["bw.1"]["output"] == "${id}_output.txt"  # function inlined with $1=txt
    assert tests["bw.1"]["gold_by_version"] == {"681": "${id}_gold_681.log", "690": "${id}_gold_681.log"}
    assert tests["bw.1"]["action"] == [{"wait_for_output": 40.0}]  # setup has t-testsSetAdvanceVerify true
    assert tests["bw.2"]["sequences"] == 2
    assert tests["bw.2"]["sequence_vars"] == {1: {"METHOD": "GET"}, 2: {"METHOD": "POST"}}
    assert tests["bw.2"]["gold"] == "${id}_gold_${seq}.log"
    assert tests["bw.2"]["known_to_fail"]
    assert "skip" in tests["bw.3"]
    assert tests["bw.4"]["legacy"] == {"setup": "t_setup.sh"}  # tibemsadmin call -> bash bridge
    assert "tibemsadmin" in result.bridged_tests["bw.4"][0]

    load_suite(result.target, tmp_path / "bw")  # generated file is valid


def test_reimport_keeps_moved_suite_in_its_folder_and_doctor_lists_new_suites(legacy, tmp_path):
    from bwtest.doctor import not_imported

    out = tmp_path / "out"
    assert [p.stem for p in not_imported(tmp_path / "bw", [])] == ["demo"]  # in the test folder, not imported
    moved = out / "engine" / "area" / "demo.suite.yaml"  # suite moved into a folder after the first import
    result = import_testset(legacy, out, assets_root=tmp_path / "bw", target=moved)
    assert result.target == moved and moved.is_file()
    assert not (out / "engine" / "demo").exists()  # no second copy in the t-tests layout
    assert not_imported(tmp_path / "bw", [moved]) == []
    (legacy.parent / "bw.1" / "nested.testset").write_text(TESTSET)  # inside a test case folder: ignored
    assert not_imported(tmp_path / "bw", [moved]) == []


@pytest.mark.skipif(shutil.which("bash") is None, reason="bash not available")
def test_legacy_bridge_captures_exports(tmp_path):
    script = tmp_path / "t_setup.sh"
    script.write_text('t-testsSetAdvanceVerify true\nexport TSI_TEST_GOLD_FILE="${TSI_REPO_DIR}/g.log"\n'
                      'export NEW_VAR="x-${TSI_TID}"\nt_sleep 0\n')
    result = run_script(script, {"TSI_REPO_DIR": "/r", "TSI_TID": "bw.1"}, bash=find_bash(), cwd=tmp_path,
                        capture_exports=True)
    assert result.returncode == 0, result.output
    assert result.exported["TSI_TEST_GOLD_FILE"] == "/r/g.log"
    assert result.exported["NEW_VAR"] == "x-bw.1"


def test_new_suites_are_grouped_like_the_existing_ones(tmp_path):
    out = tmp_path / "out"
    (out / "engine" / "http" / "http_2_0").mkdir(parents=True)  # existing group folder
    func = tmp_path / "bw" / "func" / "engine"
    cases = {"http_URLencoded": func / "http_URLencoded",
             "jdbc_postgres17": func / "jdbc" / "jdbc_postgreSQL",
             "jdbc_ora23c_objcoll": func / "jdbc" / "jdbc_oracle_obj_coll",
             "mail2": func / "mail2"}
    for name, folder in cases.items():
        folder.mkdir(parents=True)
        (folder / f"{name}.testset").write_text(TESTSET)
    placed = {name: import_testset(folder / f"{name}.testset", out, tmp_path / "bw").target.relative_to(out).parent
              for name, folder in cases.items()}
    assert placed == {"http_URLencoded": Path("engine/http/http_URLencoded"),
                      "jdbc_postgres17": Path("engine/jdbc/postgres"),
                      "jdbc_ora23c_objcoll": Path("engine/jdbc/oracle"),
                      "mail2": Path("engine/mail2")}  # no matching group: t-tests folder as before


def test_sync_adds_new_test_cases_and_keeps_hand_made_changes(legacy, tmp_path):
    from bwtest.legacy import sync

    out, assets = tmp_path / "out", tmp_path / "bw"
    func = assets / "func"
    plan = sync.plan(func, out, assets)
    assert [p.stem for p in plan.new_suites] == ["demo"] and not plan.updates
    result = sync.apply(plan, out, assets)
    suite_file = result.imported[0].target
    edited = suite_file.read_text(encoding="utf-8").replace("description: one", "description: one (fixed by hand)")
    suite_file.write_text("# my note\n" + edited, encoding="utf-8")

    # the user's test folder gets a new test case bw.5, and bw.2 is removed from the .testset
    new_case = "<TestCase><ID>bw.5" + TESTSET.split("<TestCase><ID>bw.4")[1].split("</TestCase>")[0] + "</TestCase>"
    text = TESTSET.replace("</TestCases>", new_case + "</TestCases>")
    text = re.sub(r"<TestCase><ID>bw.2</ID>.*?</TestCase>", "", text, flags=re.S)
    legacy.write_text(text)
    (legacy.parent / "bw.5").mkdir()

    plan = sync.plan(func, out, assets)
    assert not plan.new_suites
    assert [(u.name, u.new_tests, u.gone_tests) for u in plan.updates] == [("demo", ["bw.5"], ["bw.2"])]
    result = sync.apply(plan, out, assets)
    assert result.added == {"demo": ["bw.5"]} and result.gone == {"demo": ["bw.2"]}
    after = suite_file.read_text(encoding="utf-8")
    assert after.startswith("# my note\n") and "one (fixed by hand)" in after  # nothing rewritten
    assert [t.id for t in load_suite(suite_file, assets).tests] == ["bw.1", "bw.2", "bw.3", "bw.4", "bw.5"]
    assert not sync.plan(func, out, assets).new_test_count  # in sync now (bw.2 is only reported)
