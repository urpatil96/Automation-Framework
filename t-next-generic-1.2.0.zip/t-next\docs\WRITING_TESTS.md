# Writing tests and suites

## Add a test case to an existing suite (5 steps)

1. **Build the BW application** in Studio. Have it write its result to the file given by the module
   property `TSI_TEST_OUTPUT_FILE` (add that property to the application, as in all existing tests).
2. **Export the EAR**.
3. **Register the test** (creates `bw.9001/` in the suite's assets folder and copies the EAR):
   ```
   bwtest new-test suites/engine/http/http_Attachments_comp/http_Attachments_comp.suite.yaml bw.9001 ^
          --ear C:\work\bw_9001.application.ear --project-dir C:\work\bw_9001 ^
          --description "HTTP POST with chunked body" --tags http,smoke
   ```
4. **Create the gold file from a known-good run** and review it:
   ```
   bwtest run http_Attachments_comp -k bw.9001 --update-gold
   ```
5. **Run again without `--update-gold`** → must pass. Commit the suite file + case folder.

## Add a new suite (4 steps)

1. `bwtest new-suite engine/rest_json` → `suites/engine/rest_json/rest_json.suite.yaml`
2. Set `assets_dir` (where the `bw.XXXX/` folders live), `client_vars_files`, `vars`, `drivers`.
3. Add tests with `bwtest new-test ...` (above).
4. `bwtest doctor` (validates the YAML), then `bwtest run rest_json`.

## Suite file reference

```yaml
suite: rest_json                 # name = AppSpace/AppNode name (old TSI_COMPONENT)
type: bw_engine                  # bw_engine | bw_migration
owner: Umesh Patil
description: REST + JSON palette
assets_dir: ${assets_root}/func/engine/rest_json   # holds bw.XXXX/ case folders
tags: [engine, rest]             # every test gets these pytest markers  (-m rest)
enabled: true

client_vars_files: [rest_json.cfg]   # legacy .cfg: app.clientVar.X -> module property X,
                                     #              other keys        -> AppNode config.ini
vars:                                # module properties / ${NAME} placeholders for all tests
  HOST_NAME: 192.0.2.15
  KEYSTORE: ${suite_dir}/JKS/server.jks
  DB_PASSWORD: ${env:BWTEST_PW_ORACLE}       # secret from .env / CI
appnode_properties:                  # extra lines in the AppNode config.ini
  bw.plugin.http.server.defaultHost: localhost
appspace_config_ini: rest_json.ini   # copied as the AppSpace config.ini (old <suite>.ini)
drivers: [oracle-19c]                # from config/drivers.yaml
databases: [checkpoint_oracle]       # from config/databases.yaml (reset before the suite)

defaults:                            # any test key; each test can override
  output: ${id}_output.json          # relative to the test's results folder
  gold: ${id}_gold.json              # relative to the case folder
  verify: {type: json, ignore_keys: [timestamp]}

tests:
  - bw.9001                          # shortest form: everything from defaults
  - id: bw.9002
    description: POST returns 201
    tags: [smoke]
    vars: {METHOD: POST}             # test-only module property
    action:
      - http: {method: POST, url: 'http://localhost:${http_port}/orders', json: {id: 1},
               expect_status: 201, save_to: '${output}'}
    verify: json
  - id: bw.9003
    known_to_fail: BUG-58468        # xfail with the Jira key as reason
  - id: bw.9004
    skip: needs Kerberos KDC
  - id: bw.9005
    gold_by_version: {"6121": "${id}_gold_6121.json"}  # output changed in 6.12.1
  - id: bw.9006
    sequences: 3                     # run 3 times, ${seq} = 1..3 (old TestSequence)
    gold: ${id}_gold_${seq}.log
    sequence_vars: {1: {METHOD: GET}, 2: {METHOD: POST}, 3: {METHOD: PUT}}
```

### Placeholders available in any string

`${id}` (bw_9001 – project / old TSI_TEST_ID) · `${tid}` (bw.9001) · `${project}` · `${seq}` ·
`${suite}` · `${suite_dir}` · `${case_dir}` · `${log_dir}` · `${output}` · `${gold}` · `${input}` ·
`${http_port}` · `${domain}` · `${appspace}` · `${appnode}` · `${bw_home}` · `${bw_version}` ·
`${bw_build}` · `${assets_root}` · any variable from `vars` · `${env:NAME}` / `${env:NAME:-default}`.

### Action steps (run in order; default = `wait_for_file`)

| Step | Example |
|---|---|
| `wait` | `- wait: 5` |
| `wait_for_file` | `- wait_for_file: {path: '${log_dir}/x.txt', timeout: 60, stable_for: 2, required: true}` |
| `wait_for_output` | `- wait_for_output: 40` — t-tests *Advance Verify*: wait up to 40 s, continue as soon as the output (CR stripped) is as big as the gold file |
| `wait_for_log` | `- wait_for_log: {pattern: 'THOR-FRWK-300006: Started BW Application \[${project}', timeout: 60}` |
| `http` | `- http: {method: GET, url: ..., headers: {}, body: ..., json: {}, auth: [u, p], expect_status: 200, save_to: '${output}'}` |
| `shell` | `- shell: {cmd: ['tibemsadmin', '-script', '${suite_dir}/purge.scr'], timeout: 60}` |
| `copy` | `- copy: {src: '${case_dir}/in.xml', dst: 'C:/inbox/in.xml'}` |
| `legacy` | `- legacy: t_action.sh` (old script, unchanged) |
| `python` | `- python: mypkg.steps:send_order` (function receives the test context) |

### Verifiers (all listed must pass)

| Type | Options |
|---|---|
| `text` | `ignore_whitespace`, `ignore_case`, `sort_lines`, `ignore_lines: [regex]`, `masks: [{pattern, replace}]`, `ignore_blank_lines` (default true) |
| `xml` | canonical compare (attribute order, formatting, prefixes ignored); `ignore_attributes`, `masks` |
| `json` | structural compare; `ignore_keys` |
| `binary` | byte-exact (images, zips) |
| `contains` | `patterns: [regex]`, `absent: [regex]`, optional `file` |
| `log` | same options, checked against this test's slice of `bwappnode.log` |
| `exists` | `files: [...]`, `non_empty` |
| `legacy` | `script: t_verify.sh` (exit code 0 = pass) |
| `python` | `function: mypkg.checks:check_total`, `args: {}` |

Volatile values (timestamps, UUIDs, host names) → use `masks` rather than editing gold files by hand:
```yaml
verify:
  type: text
  masks:
    - {pattern: '\d{4}-\d{2}-\d{2}T[\d:.]+Z?', replace: '<TIMESTAMP>'}
    - {pattern: '[0-9a-f]{8}-[0-9a-f-]{27}', replace: '<UUID>'}
```

## Python tests

For logic that does not fit YAML, write normal pytest tests with the `bw_suite` / `bw_session` fixtures —
see `suites/examples/test_python_style.py`.

## Tips

* `bwtest run ... --dry-run` prints every bwadmin command without running BW — good for reviewing a new suite.
* A failing test's folder has everything: `diff.txt`, `module_properties.txt` (what the app received),
  `bwappnode.log` (only this test), `test.log`, `t-tests.substvar`.
* Keep tests independent: each test is deployed, run and undeployed on its own.
