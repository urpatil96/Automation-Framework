"""Regressions found with real bw-bat runs on BW 6.12.0 HF5 (2026-11-17):

* t_verify.sh options of ONE branch (t-xmldiff for bw.618) were applied to the whole suite -> text outputs
  compared as XML ("not well-formed XML").
* helper functions (`*) new_verify`) and t-testsDefaultDiff were not understood.
* TSI_TEST_ID / ${id} were taken from <Project> instead of the ID (petstore_sample vs bw_6983).
* outputs that are folders (old `diff OUTPUT_DIR GOLD_DIR`).
* t-xmldiff / t-stripcr missing in the legacy shim.
"""

import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

from bwtest.errors import VerificationFailed
from bwtest.legacy.importer import _verify_plan, parse_script
from bwtest.models import TestSpec as Spec
from bwtest.verify import run_verifications

TESTS = [{"id": i, "project": i.replace(".", "_")} for i in ("bw.617", "bw.618", "bw.620", "bw.700")]
TESTS.append({"id": "bw.6983", "project": "petstore_sample"})

VERIFY_BAT = """
t_util=${TSI_SCRIPTS}/t_util.sh
if [ -e ${t_util} ]; then
    . ${t_util}
    tu_init
fi
TSI_EXIT_CODE=-1
case ${TSI_TID} in
  bw.617 )
    if [ -e "${TSI_TEST_OUTPUT_FILE}" -a -e "${TSI_TEST_GOLD_FILE}" ]; then
      sort ${TSI_TEST_GOLD_FILE} -o f1.txt
      sort ${TSI_TEST_OUTPUT_FILE} -o f2.txt
      diff -b f1.txt f2.txt >>  ${TSI_TEST_DIFF_FILE} 2>&1
      TSI_EXIT_CODE=$?
    else
      echo "missing" >> ${TSI_TEST_ERROR_FILE}
    fi
  ;;
  bw.618 )
    echo "t-xmldiff ${TSI_TEST_OUTPUT_FILE} ${TSI_TEST_GOLD_FILE}" > ${TSI_TEST_DIFF_FILE}
    t-xmldiff ${TSI_TEST_OUTPUT_FILE} ${TSI_TEST_GOLD_FILE} >> ${TSI_TEST_DIFF_FILE} 2>&1
    TSI_EXIT_CODE=$?
  ;;
  bw.700 )
    java -jar checker.jar ${TSI_TEST_OUTPUT_FILE}
  ;;
  * )
    if [ -e "${TSI_TEST_OUTPUT_FILE}" -a -e "${TSI_TEST_GOLD_FILE}" ]; then
      diff ${TSI_TEST_OUTPUT_FILE} ${TSI_TEST_GOLD_FILE} >> ${TSI_TEST_DIFF_FILE} 2>&1
      TSI_EXIT_CODE=$?
    fi
  ;;
esac
exit ${TSI_EXIT_CODE}
"""


def test_verify_branches_are_converted_one_by_one():
    default, per_test, legacy = _verify_plan(parse_script(VERIFY_BAT), TESTS)
    assert default == {"type": "text"}  # from `*)` - NOT xml
    assert per_test == {"bw.617": {"type": "text", "ignore_whitespace": True, "sort_lines": True},
                        "bw.618": {"type": "xml"}}
    assert legacy == {"bw.700"}  # unknown command -> keeps the original script


def test_helper_function_and_default_diff_are_understood():
    script = """
new_verify()
{
  if [ -e ${TSI_TEST_OUTPUT_FILE} -a -e ${TSI_TEST_GOLD_FILE} ]; then
      diff -b ${TSI_TEST_OUTPUT_FILE} ${TSI_TEST_GOLD_FILE} >> ${TSI_TEST_DIFF_FILE} 2>&1
      TSI_EXIT_CODE=$?
  fi
}
case ${TSI_TID} in
  * )
    new_verify
esac
"""
    assert _verify_plan(parse_script(script), TESTS)[0] == {"type": "text", "ignore_whitespace": True}
    plain = "t-testsDefaultDiff ${TSI_TEST_GOLD_FILE} ${TSI_TEST_OUTPUT_FILE}\nTSI_EXIT_CODE=$?\n"
    assert _verify_plan(parse_script(plain), TESTS)[0] == {"type": "text"}


def test_test_id_comes_from_the_id_not_the_project():
    spec = Spec(id="bw.6983", project="petstore_sample")
    assert spec.test_id == "bw_6983"  # bw_6983_gold.log, `bw_6983 )` labels in t_setup.sh


def _ctx(output: Path, gold: Path, log_dir: Path):
    return SimpleNamespace(output_file=output, gold_file=gold, update_gold=False, render=lambda s: s,
                           write_artifact=lambda name, text, **_: (log_dir / name).write_text(text))


def test_output_folder_is_compared_with_gold_folder(tmp_path):
    out, gold = tmp_path / "OUTPUT", tmp_path / "golden_output"
    for d in (out, gold):
        d.mkdir()
        (d / "a.txt").write_text("same\r\n")
    (gold / "b.txt").write_text("expected\n")
    with pytest.raises(VerificationFailed) as exc:
        run_verifications({"type": "text"}, _ctx(out, gold, tmp_path))
    assert "missing in output: b.txt" in exc.value.details
    (out / "b.txt").write_text("expected\n")
    run_verifications({"type": "text"}, _ctx(out, gold, tmp_path))  # passes


@pytest.mark.parametrize(("output", "rc"), [("<a><b x='1' y='2'/></a>", 0), ("<a><b x='1' y='3'/></a>", 1),
                                           ("not xml", 2)])
def test_t_xmldiff_command(tmp_path, output, rc):
    gold = tmp_path / "gold.xml"
    gold.write_text('<?xml version="1.0"?>\n<a>\n  <b y="2" x="1"/>\n</a>\n')
    out = tmp_path / "out.xml"
    out.write_text(output)
    result = subprocess.run([sys.executable, "-m", "bwtest.legacy.xmldiff", str(out), str(gold)],
                            capture_output=True, text=True, stdin=subprocess.DEVNULL, check=False)
    assert result.returncode == rc, result.stdout + result.stderr


# ---- t-tests run flow (report bw-6120-V188-HF05 / BW_ENGINE.jar DefaultEngineRun) -----------------------
ACTION_BAT = """
case ${TSI_TID} in
    bw.620 | bw.617)
        t_sleep 20
    ;;
    bw.1673)
    t_sleep 30
    ;;
esac
t_sleep 20
"""


def test_action_waits_add_up_like_bash_and_use_advance_verify():
    from bwtest.legacy.importer import Translator, _wait_steps

    tr = Translator(TESTS + [{"id": "bw.1673", "project": "bw_1673"}])
    tr.walk(parse_script(ACTION_BAT))
    assert tr.suite.waits == [20.0]
    assert [*tr.per_test["bw.620"].waits, *tr.suite.waits] == [20.0, 20.0]  # case sleep + common sleep
    assert _wait_steps([30.0, 20.0], advance=True) == [{"wait_for_output": 50.0}]
    assert _wait_steps([30.0, 20.0], advance=False) == [{"wait": 30.0}, {"wait": 20.0}]
    setup = Translator(TESTS)
    setup.walk(parse_script("t-testsSetAdvanceVerify true\n"))
    assert setup.suite.advance_verify is True


def test_wait_for_output_returns_once_output_reaches_gold_size(tmp_path):
    import time

    from bwtest.actions import act_wait_for_output

    gold, out = tmp_path / "gold.log", tmp_path / "out.log"
    gold.write_bytes(b"line1\nline2\n")
    out.write_bytes(b"line1\r\nline2\r\n")  # bigger with CRs, equal after stripping -> complete
    ctx = SimpleNamespace(output_file=out, gold_file=gold, render=lambda s: s, log=lambda m: None,
                          settings=SimpleNamespace(timeouts=SimpleNamespace(output_file=60, stable_for=0.5)))
    start = time.monotonic()
    act_wait_for_output(30, ctx)
    assert time.monotonic() - start < 5  # did not wait the full 30 s
    out.write_bytes(b"line1\n")  # incomplete output -> waits the full timeout
    start = time.monotonic()
    act_wait_for_output(1.5, ctx)
    assert time.monotonic() - start >= 1.4


def test_verification_runs_after_undeploy(monkeypatch, tmp_path):
    """t-tests stops + undeploys the app before comparing (files are closed and final)."""
    import bwtest.executor as ex

    calls: list[str] = []
    monkeypatch.setattr(ex, "run_actions", lambda steps, ctx: calls.append("action"))
    monkeypatch.setattr(ex, "run_verifications", lambda spec, ctx: calls.append("verify"))
    runtime = SimpleNamespace(deploy=lambda *a: calls.append("deploy") or "dep",
                              undeploy=lambda dep: calls.append("undeploy"))
    ctx = SimpleNamespace(case_dir=tmp_path, render=lambda s: s, vars={}, log=lambda m: None, mark_log=lambda: None,
                          timings={}, write_artifact=lambda *a, **k: None, appnode_log_slice=lambda: "")
    (tmp_path / "app.ear").write_bytes(b"")
    executor = ex.TestExecutor.__new__(ex.TestExecutor)
    executor.runtime, executor.last_ctx = runtime, None
    executor.settings = SimpleNamespace(dry_run=False, bw=SimpleNamespace(app_version="1.0"))
    executor.suite = SimpleNamespace(type="bw_engine", legacy={}, name="s")
    executor.prepare = lambda test, seq: ctx
    executor.write_profile = lambda *a: tmp_path / "p.substvar"
    test = SimpleNamespace(id="bw.1", description="", ear="app.ear", app_name="app", action=[], legacy={},
                           verify={"type": "text"})
    executor.run_once(test)
    assert calls == ["deploy", "action", "undeploy", "verify"]
