"""End-to-end: pytest -> suite.yaml -> domain/appspace/appnode -> deploy -> action -> verify, using the
fake bwadmin. Proves the whole pipeline (incl. module properties and reporting) without BusinessWorks."""

import json
from pathlib import Path

from tests.conftest import make_case

SUITE = """
suite: demo
assets_dir: ${assets_root}/demo
client_vars_files: [demo.cfg]
vars: {GREETING: hello, ATTACH_DIR: '${assets_dir}/attachments'}
tests:
  - id: bw.1
    description: passes - output echoes module properties
    input: ${ATTACH_DIR}/in.gif   # file name built from a suite var (http_Attachments_comp)
  - id: bw.2
    description: fails - output differs from gold
  - id: bw.3
    known_to_fail: BUG-99999
  - id: bw.4
    skip: needs external server
  - id: bw.5
    description: version specific gold + log check
    verify:
      - text
      - {type: log, patterns: ['Started application bw_5']}
"""


def _write_project(root: Path) -> None:
    assets = root / "assets" / "demo"
    assets.mkdir(parents=True)
    (assets / "demo.cfg").write_text("app.clientVar.HOST_NAME=10.1.1.1\nbw.plugin.http.x=true\n")
    make_case(assets, "bw.1", "{GREETING} from {HOST_NAME}\n", "hello from 10.1.1.1\n")
    make_case(assets, "bw.2", "actual\n", "expected\n")
    make_case(assets, "bw.3", "bug\n", "fixed\n")
    make_case(assets, "bw.4", "x", "x")
    case5 = make_case(assets, "bw.5", "new behaviour\n", "old behaviour\n")
    (case5 / "bw_5_gold_6991.log").write_text("new behaviour\n")  # fake BW reports 6.99.1
    (root / "suites").mkdir()
    (root / "suites" / "demo.suite.yaml").write_text(SUITE)


def test_full_pipeline(pytester, fake_project):
    _write_project(fake_project)
    pytester.chdir()
    result = pytester.runpytest_subprocess(str(fake_project / "suites"), "--rootdir", str(fake_project),
                                           "--bw-config", str(fake_project / "config"), "--bw-keep-domain",
                                           "-p", "no:cacheprovider")
    result.assert_outcomes(passed=2, failed=1, xfailed=1, skipped=1)
    result.stdout.fnmatch_lines(["*bw.2*output differs from gold*", "*-expected*", "*+actual*"])

    run_dir = Path((fake_project / "results" / "LATEST").read_text())
    props = (run_dir / "demo" / "bw.1" / "module_properties.txt").read_text()
    assert "GREETING = hello" in props and "HOST_NAME = 10.1.1.1" in props
    commands = (run_dir / "worker-0" / "commands.log").read_text()
    for step in ("create domain", "create appspace demo", "deploy bw_1.application.ear", "undeploy bw_1",
                 "stop appnode demo", "delete appspace demo"):
        assert step in commands
    # all bwadmin commands ran in ONE bwadmin shell (no JVM per command); the version came from its banner
    assert commands.count("bwadmin shell started") == 1
    assert "detect BW version" not in commands
    # time breakdown for the Run page: phases per test, suite setup time, bwadmin command count/time
    from bwtest.ui.services.runs import RunManager

    detail = RunManager(fake_project, fake_project / "config", run_dir.parent).detail(run_dir.name)
    assert set(detail["timing"]["phases"]) == {"deploy", "action", "cleanup", "verify"}
    assert detail["timing"]["suite_setup"] >= 0 and detail["timing"]["wall"] is not None
    assert detail["timing"]["bwadmin"]["calls"] == detail["timing"]["bwadmin"]["shell_calls"] > 10
    # --bw-keep-domain: domain stays, so we can check the engine property from .cfg reached config.ini
    config_ini = next((fake_project / "domains" / "bwtest-0").rglob("config.ini")).read_text()
    assert "bw.plugin.http.x=true" in config_ini
    assert (fake_project / "domains" / "bwtest-0" / ".bwtest-owned").exists()
    summary = json.loads((run_dir / "summary.json").read_text())
    assert summary["passed"] == 2
    # bw.2 failed on the gold comparison: its new output is kept and can be accepted as gold without a re-run
    from bwtest import gold

    assert detail["gold_changes"] == 1
    assert [t["id"] for t in detail["tests"] if t["gold_change"]] == ["bw.2"]
    [change] = gold.changes(run_dir)
    gold.accept(run_dir, change.key)
    assert (fake_project / "assets" / "demo" / "bw.2" / "bw_2_gold.log").read_text() == "actual\n"


def test_update_gold_blesses_output(pytester, fake_project):
    _write_project(fake_project)
    pytester.chdir()
    result = pytester.runpytest_subprocess(str(fake_project / "suites"), "--rootdir", str(fake_project),
                                           "--bw-config", str(fake_project / "config"), "-k", "bw.2",
                                           "--update-gold", "-p", "no:cacheprovider")
    result.assert_outcomes(passed=1)
    assert (fake_project / "assets" / "demo" / "bw.2" / "bw_2_gold.log").read_text() == "actual\n"


def test_dry_run_executes_nothing(pytester, fake_project):
    _write_project(fake_project)
    pytester.chdir()
    result = pytester.runpytest_subprocess(str(fake_project / "suites"), "--rootdir", str(fake_project),
                                           "--bw-config", str(fake_project / "config"), "--bw-dry-run",
                                           "-k", "bw.1", "-p", "no:cacheprovider")
    result.assert_outcomes(passed=1)
    assert not (fake_project / "domains").exists()


def _commands(run_dir: Path) -> list[str]:
    """bwadmin command lines of a run, without timings and notes."""
    lines = (run_dir / "worker-0" / "commands.log").read_text().splitlines()
    cmds = [line.split("  # rc=")[0].split("bwagent.ini", 1)[-1].strip() for line in lines
            if line and not line.startswith(("::", "#")) and "bwagent.ini" in line]
    cmds = [c for c in cmds if c and c.split()[0] != "version"]  # "" = the line that started the shell
    # the fake bwadmin leaves the domain folder behind, so a 2nd run first removes the "stale" domain
    return cmds[1:] if cmds and cmds[0].startswith("delete -force domain") else cmds


def test_shell_runs_exactly_the_same_bw_steps_as_one_jvm_per_command(pytester, fake_project, monkeypatch):
    """The bwadmin shell only changes HOW commands reach bwadmin - never WHICH commands or their order
    (create domain / appspace / appnode, start, upload, deploy, stop, undeploy, delete ...)."""
    _write_project(fake_project)
    pytester.chdir()
    runs = []
    for shell in ("true", "false"):
        monkeypatch.setenv("BWTEST__BW__ADMIN_SHELL", shell)
        pytester.runpytest_subprocess(str(fake_project / "suites"), "--rootdir", str(fake_project),
                                      "--bw-config", str(fake_project / "config"), "-p", "no:cacheprovider")
        runs.append(Path((fake_project / "results" / "LATEST").read_text()))
    with_shell, one_shot = (_commands(r) for r in runs)
    assert "bwadmin shell started" in (runs[0] / "worker-0" / "commands.log").read_text()
    assert "bwadmin shell" not in (runs[1] / "worker-0" / "commands.log").read_text()
    normalize = lambda cmds, run: [c.replace(str(run.name), "<run>") for c in cmds]  # noqa: E731
    assert normalize(with_shell, runs[0]) == normalize(one_shot, runs[1])
    assert len(with_shell) > 15


def test_second_run_at_the_same_time_uses_its_own_domain_and_ports(pytester, fake_project, monkeypatch):
    """Slot 1 (another run is going): same BW steps, but domain bwtest-s1-0 and the next port blocks."""
    _write_project(fake_project)
    pytester.chdir()
    monkeypatch.setenv("BWTEST_SLOT", "1")  # what `bwtest run` sets when slot 0 is taken
    result = pytester.runpytest_subprocess(str(fake_project / "suites"), "--rootdir", str(fake_project),
                                           "--bw-config", str(fake_project / "config"), "-k", "bw.1",
                                           "-p", "no:cacheprovider")
    result.assert_outcomes(passed=1)
    run_dir = Path((fake_project / "results" / "LATEST").read_text())
    commands = (run_dir / "worker-0" / "commands.log").read_text()
    assert "create -home" in commands and "domain bwtest-s1-0" in commands
    assert "bwtest-0" not in commands.replace("bwtest-s1-0", "")
    import re

    http, osgi = (int(re.search(rf"-{k}Port (\d+)", commands).group(1)) for k in ("http", "osgi"))
    assert 51000 <= http < 51250 and 61000 <= osgi < 61250  # port block 50000 + 250 * (4 * slot + worker)


def test_missing_git_bash_fails_fast_before_anything_is_deployed(pytester, fake_project, monkeypatch):
    """A test with an old .sh step fails at once when Git Bash is missing - no AppSpace/AppNode/deploy first."""
    _write_project(fake_project)
    suite = fake_project / "suites" / "demo.suite.yaml"
    suite.write_text(SUITE.replace("  - id: bw.2\n", "  - id: bw.2\n    legacy: {setup: t_setup.sh}\n"))
    monkeypatch.setenv("BWTEST__PATHS__BASH", str(fake_project / "no-git" / "bash.exe"))
    pytester.chdir()
    result = pytester.runpytest_subprocess(str(suite), "--rootdir", str(fake_project), "-k", "bw.2",
                                           "--bw-config", str(fake_project / "config"), "-p", "no:cacheprovider")
    result.assert_outcomes(errors=1)
    result.stdout.fnmatch_lines(["*does not exist*", "*old t-tests .sh step*Install Git for Windows*"])
    assert not (fake_project / "domains").exists()  # no domain / AppSpace / AppNode was created, nothing deployed


def test_old_scripts_get_the_platform_variables_of_ttests(pytester, fake_project):
    """http-pcm_comp/t_setup.sh: `case ${NPORT} in i86-win*) Linux_Var=1` -> BW gets the Windows value."""
    import os
    import shutil

    import pytest

    if not shutil.which("bash") and os.name != "nt":
        pytest.skip("bash not available")
    _write_project(fake_project)
    (fake_project / "assets" / "demo" / "t_setup.sh").write_text(
        'case ${NPORT} in\n  i86-win* ) export GREETING=win ;;\n  * ) export GREETING=linux ;;\nesac\n')
    suite = fake_project / "suites" / "demo.suite.yaml"
    text = SUITE.replace("GREETING: hello, ", "")  # set only by t_setup.sh, like Linux_Var in http-pcm_comp
    suite.write_text(text.replace("  - id: bw.1\n", "  - id: bw.1\n    legacy: {setup: t_setup.sh}\n"))
    expected = "win" if os.name == "nt" else "linux"
    (fake_project / "assets" / "demo" / "bw.1" / "bw_1_gold.log").write_text(f"{expected} from 10.1.1.1\n")
    pytester.chdir()
    result = pytester.runpytest_subprocess(str(suite), "--rootdir", str(fake_project), "-k", "bw.1",
                                           "--bw-config", str(fake_project / "config"), "-p", "no:cacheprovider")
    result.assert_outcomes(passed=1)
    run_dir = Path((fake_project / "results" / "LATEST").read_text())
    assert f"GREETING = {expected}" in (run_dir / "demo" / "bw.1" / "module_properties.txt").read_text()
