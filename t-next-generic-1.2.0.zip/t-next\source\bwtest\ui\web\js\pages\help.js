// Help & guide for new users: the 5 steps, a glossary, old t-tests -> new mapping, FAQ.
import { h } from "../core/dom.js";
import { card, grid, linkButton, pageHeader } from "../components/ui.js";

const STEPS = [
  ["1. Preferences", "Once per machine: test case location, BW installs folder, tools.", "#/preferences"],
  ["2. Doctor", "Check the BW build and the setup are OK.", "#/doctor"],
  ["3. New run", "Profile → build → test cases → report details → Start.", "#/run/new"],
  ["4. Follow live", "Progress, current test, console. Stop safely at any time.", "#/runs"],
  ["5. Review", "Failed tests show the diff, the app log and its properties. HTML report.", "#/runs"],
];

const GLOSSARY = [
  ["Profile", "One BW version (6.12.1, 6.13.0 …). File: config/profiles/<version>.yaml. Old: *.profile / product profile."],
  ["Build", "One installed BW of that version (V12, GA …), i.e. the BW home folder. Old: INSTALL_HOME."],
  ["Suite", "One *.suite.yaml file. All its tests share one AppSpace + AppNode. Old: .testset + case blocks in t_setup/t_action/t_verify.sh."],
  ["Test case", "A BW application (EAR) + an expected result (gold file) in a folder bw.XXXX/."],
  ["Gold file", "The expected output. The test passes when the app's output matches it (masks can hide timestamps)."],
  ["Module properties / vars", "Values passed to the app at deploy time (output file, host names, ports). Old: vendor.clientVar in .cfg."],
  ["Known to fail", "A test linked to an open defect: shown as 'Known failure', not as failed. If it passes, you see 'Fixed? (XPASS)'."],
  [".sh script step (legacy bridge)", "Some imported tests keep one step as the original .sh script (it calls real tools such as tibemsadmin). T-Next runs that script itself with Git Bash. Shown as '.sh step'."],
  ["Error vs Failed", "Error = environment problem (AppNode did not start, deploy failed). Failed = the product output was wrong."],
  ["Dry run", "Shows every bwadmin command that would run, without touching BW."],
];

const MAPPING = [
  ["t-tests.bat → main window", "bwtest ui (this page) or bwtest run in a terminal"],
  ["User profile: JRE, Tibrv, BW5 HOME", "Preferences → Tools"],
  ["Preferences → Test Case Location by Product", "Preferences → Test case location"],
  ["Product profile → INSTALL_HOME", "New run → Build (found automatically per profile)"],
  ["Types of testing: BW_ENGINE / BW_MIGRATION", "Suite type; filter on New run → Test cases"],
  ["Preferences → Report: product, version, build", "New run → Report details (version/build also detected from bwadmin)"],
  ["File → New TestCmd / .testcmd file", "New run → Save as selection (config/selections/*.yaml)"],
  ["Edit → Select test cases", "New run → Test cases (tick suites or single tests)"],
  ["Run button", "New run → Start run"],
  ["reports/<platform>/ HTML", "Runs & reports → Open HTML report (results/<run>/report.html)"],
  ["t_sleep 40", "wait for the output file / a log line (event based, with timeout)"],
  ["Copy gold files by hand", "Run with 'Update gold files', then review"],
];

const FAQ = [
  ["The first test takes minutes - is it stuck?", "No. The AppNode of each suite needs about 3 minutes to start on Windows (antivirus, licence check). The run page says 'Preparing suite …' meanwhile."],
  ["How do I stop a run?", "'Stop after current test' finishes the running test and cleans BW up. 'Force kill' is immediate but may leave an AppNode process (end bwappnode-*.exe in Task Manager)."],
  ["A test failed - where do I look?", "Open the run, click the test: diff.txt shows expected vs actual, bwappnode.log only the log lines of that test, module_properties.txt what the app received."],
  ["Can I start a second run while one is going?", "Yes, up to 4 runs at the same time. Each run gets its own domains (bwtest-s1-0 ...) and ports. Not allowed: the same suite in two runs at once (shared DB tables / mailbox). Each run needs RAM for its AppNodes."],
  ["Is my own BW domain safe?", "Yes. T-Next only creates and deletes domains named bwtest-N that carry its marker file."],
  ["How do I run this from Jenkins?", "Every run page shows the command. source/ci/Jenkinsfile has a ready pipeline."],
];

export default {
  title: "Help & guide",
  render() {
    return h("div", { class: "stack help" },
      pageHeader("Help & guide", "Everything a new user needs to run and add BW regression tests.",
        linkButton("▶  Start a run", "#/run/new", "primary")),
      card({ title: "How a run works - 5 steps" },
        h("div", { class: "steps-visual" }, STEPS.map(([t, d, href]) => h("div", {}, h("b", {}, h("a", { href }, t)), d))),
        h("p", { class: "muted small", style: { marginTop: "12px" } },
          "Under the hood for every suite: create domain → AppSpace → AppNode (start, wait until Running) → for each test: deploy EAR with module properties → wait for output → compare with gold file → undeploy → stop AppNode → delete AppSpace.")),
      grid(2,
        card({ title: "Words you will see" }, h("dl", { class: "kv" }, GLOSSARY.flatMap(([k, v]) => [h("dt", {}, h("b", {}, k)), h("dd", {}, v)]))),
        card({ title: "Coming from t-tests 4.0?" }, h("table", { class: "table" },
          h("thead", {}, h("tr", {}, h("th", {}, "Old t-tests"), h("th", {}, "New T-Next"))),
          h("tbody", {}, MAPPING.map(([a, b]) => h("tr", {}, h("td", {}, a), h("td", {}, b))))))),
      grid(2,
        card({ title: "Add a new test case (5 steps)" }, h("ol", {},
          h("li", {}, "Build the BW app in Studio; write the result to the module property ", h("code", {}, "TSI_TEST_OUTPUT_FILE"), "."),
          h("li", {}, "Export the EAR."),
          h("li", {}, h("a", { href: "#/suites" }, "Suites"), " → open the suite → ", h("b", {}, "+ Add test case"), " (id, EAR path, description)."),
          h("li", {}, "Run it once with ", h("b", {}, "Update gold files"), " → check the new gold file."),
          h("li", {}, "Run normally → must pass. Commit the suite file + case folder."))),
        card({ title: "Questions" }, h("dl", { class: "kv", style: { gridTemplateColumns: "1fr" } },
          FAQ.flatMap(([q, a]) => [h("dt", {}, h("b", {}, q)), h("dd", { style: { marginBottom: "8px" } }, a)])))),
      card({ title: "More documentation (in the project folder)" }, h("ul", {},
        h("li", {}, h("code", {}, "docs/README.md"), " - start page: which document to read for your role"),
        h("li", {}, h("code", {}, "docs/USER_GUIDE.md"), " - install, run, results, troubleshooting"),
        h("li", {}, h("code", {}, "docs/ARCHITECTURE.md"), " - how it works, diagrams, how to explain it"),
        h("li", {}, h("code", {}, "docs/WRITING_TESTS.md"), " - every suite/test option"),
        h("li", {}, h("code", {}, "docs/UI.md"), " - this UI: pages, fields, how to extend it"),
        h("li", {}, h("a", { href: "/docs", target: "_blank" }, "REST API (Swagger)"), " - for scripts or another frontend"))));
  },
};
