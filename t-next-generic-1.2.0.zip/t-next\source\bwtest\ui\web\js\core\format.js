// Formatting helpers shared by all pages.

export function duration(seconds) {
  if (seconds === null || seconds === undefined || seconds === "") return "";
  const s = Math.round(Number(seconds));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ${String(s % 60).padStart(2, "0")}s`;
  return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, "0")}m`;
}

export function bytes(n) {
  if (n === null || n === undefined) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export function since(timestamp) {
  // "2026-11-17 10:15:00" -> "5 min ago"
  if (!timestamp) return "";
  const t = new Date(timestamp.replace(" ", "T")).getTime();
  if (Number.isNaN(t)) return timestamp;
  const diff = (Date.now() - t) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)} min ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} h ago`;
  return timestamp.slice(0, 16);
}

export const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;

export const OUTCOMES = {
  passed: { label: "Passed", tone: "ok" },
  failed: { label: "Failed", tone: "bad" },
  error: { label: "Error", tone: "warn" },
  skipped: { label: "Skipped", tone: "muted" },
  xfailed: { label: "Known failure", tone: "known" },
  xpassed: { label: "Fixed? (XPASS)", tone: "info" },
  running: { label: "Running", tone: "run" },
  pending: { label: "Waiting", tone: "muted" },
  not_run: { label: "Not run", tone: "muted" },
  unknown: { label: "Unknown", tone: "muted" },
};

export const RUN_STATES = {
  running: { label: "Running", tone: "run" },
  stopping: { label: "Stopping…", tone: "warn" },
  passed: { label: "Passed", tone: "ok" },
  failed: { label: "Failures", tone: "bad" },
  error: { label: "Error", tone: "warn" },
  stopped: { label: "Stopped", tone: "muted" },
  killed: { label: "Killed", tone: "bad" },
  aborted: { label: "Incomplete", tone: "muted" },
  empty: { label: "No tests", tone: "muted" },
};
