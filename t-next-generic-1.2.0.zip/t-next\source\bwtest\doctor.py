"""Environment checks - shared by `bwtest doctor` and the web UI's Settings page."""

from __future__ import annotations

import importlib.util
from dataclasses import asdict, dataclass
from pathlib import Path

from .config import Settings
from .errors import BwTestError
from .models import SUITE_GLOB, load_suite


@dataclass
class Check:
    label: str
    ok: bool
    detail: str = ""
    hint: str = ""  # what to do when it fails

    def as_dict(self) -> dict:
        return asdict(self)


def has_module(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


def bwadmin_path(settings: Settings) -> Path:
    return settings.bw.home / "bin" / ("bwadmin.exe" if settings.is_windows else "bwadmin")


def run_checks(settings: Settings, project_root: Path, detect_version: bool = True) -> list[Check]:
    from .bwcli import BwCli, CommandLog
    from .legacy.bridge import find_bash

    checks: list[Check] = []
    home = settings.bw.home
    exe = bwadmin_path(settings)
    checks.append(Check("BW home has bin/bwadmin", exe.is_file(), str(exe),
                        "bw.home must be the folder with bin/bwadmin.exe, i.e. <install>/bw/<x.y> (e.g. "
                        "C:/bw6/BW6121/bw/6.12). Pick another build, or fix it in Preferences / config/local.yaml"))
    if exe.is_file() and detect_version:
        tmp = settings.paths.results_dir / "_doctor"
        cli = BwCli(settings, CommandLog(tmp / "commands.log"), work_dir=tmp)
        try:
            version = cli.version(tmp)
        finally:
            cli.close()  # the version check may open a bwadmin shell: never leave it running (UI server)
        checks.append(Check("bwadmin version", version is not None,
                            str(version) if version else "could not parse the banner of `bwadmin version`",
                            "Run bwadmin version by hand and check for license / Java errors"))
    checks.append(Check("bwagent.ini present", (home / "config" / "bwagent.ini").is_file(),
                        str(home / "config" / "bwagent.ini"), "The BW install looks incomplete"))
    checks.append(Check("Test assets folder exists", settings.paths.assets_root.is_dir(),
                        str(settings.paths.assets_root), "Set paths.assets_root (old tests/bw folder)"))
    try:
        checks.append(Check("Bash for legacy bridge", True, find_bash(settings.paths.bash)))
    except BwTestError as exc:
        checks.append(Check("Bash for legacy bridge", False, str(exc),
                            "Install Git for Windows - only needed by imported suites that use old scripts"))
    checks.append(Check("Domain home writable", _writable(settings.bw.domain_home), str(settings.bw.domain_home),
                        "Set bw.domain_home to a folder you can write"))
    checks.append(Check("HTML report plugin", has_module("pytest_html"), "pytest-html",
                        "pip install -e source[report]"))
    checks.append(Check("Parallel run plugin", has_module("xdist"), "pytest-xdist", "pip install -e source[parallel]"))
    suites = sorted((project_root / "suites").rglob(SUITE_GLOB))
    bad = []
    for path in suites:
        try:
            load_suite(path, settings.paths.assets_root)
        except BwTestError as exc:
            bad.append(f"{path.name}: {exc}")
    checks.append(Check(f"{len(suites)} suite files are valid", not bad, "; ".join(bad[:3]),
                        "Open the suite in the Suites page and fix the YAML"))
    by_name: dict[str, list[Path]] = {}
    for path in suites:
        by_name.setdefault(path.name.removesuffix(".suite.yaml").lower(), []).append(path)
    twice = {name: files for name, files in by_name.items() if len(files) > 1}
    if twice:
        root = project_root / "suites"
        detail = "; ".join(" + ".join(f.relative_to(root).parent.as_posix() for f in files) for files in twice.values())
        checks.append(Check(f"{len(twice)} suite(s) exist twice in suites/", False, detail,
                            "Keep one file per suite: delete the extra copy (usually the folder in the old "
                            "t-tests layout, e.g. suites/engine/http_components when "
                            "suites/engine/http/http_components exists)"))
    checks.extend(sync_checks(settings, project_root / "suites"))
    return checks


def sync_checks(settings: Settings, suites_root: Path) -> list[Check]:
    """Is suites/ in step with the user's own test folder? New suites / new test cases there -> failed check."""
    from .legacy import sync

    func = Path(settings.paths.assets_root) / "func"
    if not func.is_dir():
        return []
    drivers = {k: v.suites for k, v in settings.drivers.items()}
    dbs = {k: v.suites for k, v in settings.databases.items()}
    p = sync.plan(func, suites_root, settings.paths.assets_root, drivers, dbs)
    hint = ("Suites > Sync with test folder (adds only what is new; existing tests are not changed), or:  "
            f"bwtest import {func.as_posix()}")
    out: list[Check] = []
    if p.new_suites:
        more = f" … (+{len(p.new_suites) - 8})" if len(p.new_suites) > 8 else ""
        names = ", ".join(t.stem for t in p.new_suites[:8]) + more
        out.append(Check(f"{len(p.new_suites)} t-tests suite(s) in the test folder are not imported yet",
                         False, names, hint))
    if p.new_test_count:
        detail = "; ".join(f"{u.name}: {', '.join(u.new_tests[:5])}{' …' if len(u.new_tests) > 5 else ''}"
                           for u in p.updates if u.new_tests)
        out.append(Check(f"{p.new_test_count} new test case(s) in the test folder are not in T-Next yet",
                         False, detail, hint))
    return out


def not_imported(assets_root: Path, suite_files: list[Path]) -> list[Path]:
    """t-tests .testset files under <assets_root>/func that have no suite file (by name) in suites/."""
    from .legacy.sync import find_testsets

    known = {f.name.removesuffix(".suite.yaml").lower() for f in suite_files}
    return [p for p in find_testsets(Path(assets_root) / "func") if p.stem.lower() not in known]


def _writable(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".bwtest_probe"
        probe.write_text("x")
        probe.unlink()
        return True
    except OSError:
        return False
