// All suites, grouped by category, with search and filters.
import { api } from "../core/api.js";
import { h, mount } from "../core/dom.js";
import { openImportDialog } from "../components/importDialog.js";
import { button, card, empty, input, linkButton, pageHeader, pill, select } from "../components/ui.js";

export default {
  title: "Suites",
  async render(view) {
    const suites = await api.suites();
    const categories = [...new Set(suites.map((s) => s.category || "(top)"))].sort();
    const f = { text: view.query.q || "", category: "all", type: "all", flag: "all" };
    const host = h("div", { class: "table-wrap" });
    const counter = h("span", { class: "muted small" });

    function draw() {
      const q = f.text.toLowerCase();
      const rows = suites.filter((s) => (f.category === "all" || (s.category || "(top)") === f.category)
        && (f.type === "all" || s.type === f.type)
        && (f.flag === "all" || (f.flag === "bridge" && s.bridged) || (f.flag === "native" && !s.bridged)
            || (f.flag === "known" && s.known_to_fail) || (f.flag === "invalid" && s.error) || (f.flag === "missing" && s.assets_exist === false))
        && (!q || `${s.name} ${s.description || ""} ${(s.tags || []).join(" ")} ${s.owner || ""}`.toLowerCase().includes(q)));
      mount(counter, `${rows.length} of ${suites.length} suites · ${rows.reduce((n, s) => n + s.tests, 0).toLocaleString()} tests`);
      mount(host, rows.length ? h("table", { class: "table" },
        h("thead", {}, h("tr", {}, ["Suite", "Category", "Type", "Tests", "Description", "Status", ""].map((t) => h("th", {}, t)))),
        h("tbody", {}, rows.map((s) => h("tr", { class: "clickable", onclick: () => view.navigate(`/suites/${encodeURIComponent(s.name)}`) },
          h("td", { class: "nowrap" }, h("b", {}, s.name)),
          h("td", {}, s.folder || s.category),
          h("td", {}, s.type === "bw_migration" ? pill("info", "migration") : pill("muted", "engine")),
          h("td", { class: "right" }, s.tests.toLocaleString()),
          h("td", { class: "desc" }, s.error ? h("span", { style: { color: "var(--bad)" } }, s.error) : s.description,
            h("div", {}, (s.tags || []).map((t) => h("span", { class: "tag" }, t)))),
          h("td", {}, h("div", { class: "row", style: { gap: "4px" } },
            s.error ? pill("bad", "invalid YAML") : null,
            s.assets_exist === false ? pill("warn", "assets missing", s.assets_dir) : null,
            s.bridged ? pill("info", `${s.bridged} with .sh step`, "one step of the test is a .sh script - T-Next runs it itself (Git Bash)") : pill("ok", "native"),
            s.known_to_fail ? pill("known", `${s.known_to_fail} known`) : null,
            s.enabled === false ? pill("muted", "disabled") : null)),
          h("td", { class: "right", onclick: (e) => e.stopPropagation() },
            linkButton("Run", `#/run/new?suite=${encodeURIComponent(s.name)}`, "small"))))))
        : empty("No suites match", "Change the filters."));
    }

    draw();
    if (view.query.import) setTimeout(() => openImportDialog(() => view.navigate("/suites")), 0); // File > Import
    return h("div", { class: "stack" },
      pageHeader("Suites", "A suite = one *.suite.yaml file = one AppSpace/AppNode. Each test case is a BW application (EAR) with a gold file.",
        button("⇩ Sync with test folder…", () => openImportDialog(() => view.navigate("/suites")), "",
          { title: "Take new suites and new test cases from your t-tests test folder", busy: false }),
        linkButton("+ New suite", "#/suites/new", "primary")),
      card({ class: "flush" }, h("div", { style: { padding: "12px 14px" } },
        h("div", { class: "row", style: { marginBottom: "10px" } },
          input({ class: "input search", placeholder: "Search name, description, tag, owner…", value: f.text,
            oninput: (e) => { f.text = e.target.value; draw(); } }),
          select([["all", "All categories"], ...categories], "all", { style: { width: "auto" }, onchange: (e) => { f.category = e.target.value; draw(); } }),
          select([["all", "Engine + migration"], ["bw_engine", "Engine"], ["bw_migration", "Migration"]], "all",
            { style: { width: "auto" }, onchange: (e) => { f.type = e.target.value; draw(); } }),
          select([["all", "Any status"], ["native", "Fully native"], ["bridge", "Has .sh script steps"], ["known", "Has known failures"],
                  ["missing", "Assets missing"], ["invalid", "Invalid YAML"]], "all",
            { style: { width: "auto" }, onchange: (e) => { f.flag = e.target.value; draw(); } }),
          h("span", { class: "spacer" }), counter),
        host)));
  },
};
