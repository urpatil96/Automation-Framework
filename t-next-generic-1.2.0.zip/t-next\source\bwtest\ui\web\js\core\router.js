// Hash router:  #/runs/20261117-101500?tab=console  ->  page module + params {id} + query {tab}
//
// A page module exports:  { title, render(view) }   where view = { params, query, onCleanup(fn), navigate }
// render() returns a Node (or a Promise of one). onCleanup registers timers etc. to stop on navigation.

export class Router {
  constructor(outlet, onChange) {
    this.outlet = outlet;
    this.onChange = onChange;
    this.routes = [];
    this.cleanups = [];
    this.token = 0;
    window.addEventListener("hashchange", () => this.resolve());
  }

  add(pattern, load) {
    const keys = [];
    // "*" = fallback route (used when nothing else matches) - it must not become a regex itself
    const regex = pattern === "*" ? /(?!)/ : new RegExp(
      "^" + pattern.replace(/:([a-zA-Z]+)/g, (_, key) => { keys.push(key); return "([^/]+)"; }) + "/?$");
    this.routes.push({ pattern, regex, keys, load });
    return this;
  }

  navigate(path) {
    if (location.hash === `#${path}`) this.resolve();
    else location.hash = path;
  }

  async resolve() {
    const hash = location.hash.slice(1) || "/";
    const [path, search = ""] = hash.split("?");
    const query = Object.fromEntries(new URLSearchParams(search));
    const route = this.routes.find((r) => r.regex.test(path)) || this.routes.find((r) => r.pattern === "*");
    const match = route.regex.exec(path) || [];
    const params = Object.fromEntries(route.keys.map((k, i) => [k, decodeURIComponent(match[i + 1])]));

    this.cleanups.forEach((fn) => { try { fn(); } catch { /* ignore */ } });
    this.cleanups = [];
    const token = ++this.token;
    const page = (await route.load()).default;
    this.onChange(route.pattern, page);
    const view = { params, query, onCleanup: (fn) => this.cleanups.push(fn), navigate: (p) => this.navigate(p),
                   isCurrent: () => token === this.token };
    try {
      const node = await page.render(view);
      if (token !== this.token) return; // user navigated away while loading
      this.outlet.replaceChildren(node);
      document.title = `${typeof page.title === "function" ? page.title(params) : page.title} · T-Next`;
      window.scrollTo(0, 0);
      this.outlet.scrollTop = 0; // desktop layout: the page area scrolls, not the window
    } catch (error) {
      if (token !== this.token) return;
      const { errorPanel } = await import("../components/ui.js");
      this.outlet.replaceChildren(errorPanel(error));
    }
  }
}
