"""Gold changes: accept the new output of a failed test as its gold file - without running it again.

When a gold comparison fails (text / xml / json / binary check, or the old t_verify.sh that diffs
TSI_TEST_OUTPUT_FILE with TSI_TEST_GOLD_FILE), the executor keeps a copy of the new output in the test's
result folder (new-output/) and lists it in gold-candidates.json. If the difference is expected - a
feature change - accept it on the run page ("Gold changes") or with `bwtest accept-gold <run>`:
the copy replaces the gold file, and the old gold file is kept in the result folder (gold-backup/).

Nothing here talks to BW and nothing is overwritten without being asked.
"""

from __future__ import annotations

import json
import shutil
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from .errors import ConfigError

if TYPE_CHECKING:
    from .executor import TestContext

CANDIDATES = "gold-candidates.json"
SNAPSHOT_DIR = "new-output"
BACKUP_DIR = "gold-backup"
MAX_DIFF_CHARS = 60_000


@dataclass
class GoldChange:
    key: str              # "<result folder relative to the run>#<n>" - stable id for the UI / CLI
    suite: str
    test: str
    kind: str             # text / xml / json / binary / legacy (.sh check)
    gold: str             # the gold file (or folder) in the test case folder
    snapshot: str         # copy of the new output, relative to the run folder
    gold_exists: bool
    accepted: str = ""    # time it was accepted, "" = still open
    diff: str = ""        # diff.txt of the test (relative to the run folder), "" if none

    def to_dict(self) -> dict:
        return asdict(self)


# ------------------------------------------------------------------------------------------ during the run
def offer(ctx: TestContext, output: Path, gold: Path, kind: str) -> None:
    """Called by a verifier just before it compares `output` with `gold`."""
    pending = getattr(ctx, "gold_candidates", None)
    if pending is not None and output.exists():
        pending.append({"output": Path(output), "gold": Path(gold), "kind": kind})


def save(ctx: TestContext) -> None:
    """The test failed on a gold comparison: keep the new output + write gold-candidates.json."""
    entries = []
    snap_dir = ctx.log_dir / SNAPSHOT_DIR
    for n, item in enumerate(ctx.gold_candidates):
        output, gold = item["output"], item["gold"]
        if not output.exists():
            continue
        snap = snap_dir / f"{n}-{gold.name}"
        snap.parent.mkdir(parents=True, exist_ok=True)
        if output.is_dir():
            shutil.copytree(output, snap, dirs_exist_ok=True)
        else:
            shutil.copyfile(output, snap)
        entries.append({"suite": ctx.suite.name, "test": ctx.test.id, "kind": item["kind"], "gold": str(gold),
                        "snapshot": snap.relative_to(ctx.log_dir).as_posix(), "accepted": ""})
    if entries:
        (ctx.log_dir / CANDIDATES).write_text(json.dumps(entries, indent=2), encoding="utf-8")
        ctx.log(f"output differs from gold - can be accepted as new gold: {len(entries)} file(s), see {CANDIDATES}")


# ------------------------------------------------------------------------------------------ after the run
def changes(run_dir: Path, include_accepted: bool = True) -> list[GoldChange]:
    """All gold changes recorded in a run folder."""
    found: list[GoldChange] = []
    for path in sorted(run_dir.rglob(CANDIDATES)):
        folder = path.parent
        rel = folder.relative_to(run_dir).as_posix()
        diff = folder / "diff.txt"
        for n, e in enumerate(_load(path)):
            change = GoldChange(key=f"{rel}#{n}", suite=e.get("suite", ""), test=e.get("test", ""),
                                kind=e.get("kind", "text"), gold=e.get("gold", ""),
                                snapshot=f"{rel}/{e.get('snapshot', '')}", gold_exists=Path(e.get("gold", "")).exists(),
                                accepted=e.get("accepted", ""),
                                diff=diff.relative_to(run_dir).as_posix() if diff.is_file() else "")
            if include_accepted or not change.accepted:
                found.append(change)
    return found


def diff_text(run_dir: Path, change: GoldChange) -> str:
    if not change.diff:
        return ""
    text = (run_dir / change.diff).read_text(encoding="utf-8", errors="replace")
    return text[:MAX_DIFF_CHARS] + ("\n... (cut)" if len(text) > MAX_DIFF_CHARS else "")


def accept(run_dir: Path, key: str) -> GoldChange:
    """Copy the kept output over the gold file; the old gold file goes to <result folder>/gold-backup/."""
    rel, _, index = key.rpartition("#")
    folder = (run_dir / rel).resolve()
    if run_dir.resolve() not in folder.parents and folder != run_dir.resolve():
        raise ConfigError(f"not a folder of this run: {rel}")
    path = folder / CANDIDATES
    if not path.is_file() or not index.isdigit():
        raise ConfigError(f"unknown gold change: {key}")
    entries = _load(path)
    if int(index) >= len(entries):
        raise ConfigError(f"unknown gold change: {key}")
    entry = entries[int(index)]
    snapshot, gold = folder / entry["snapshot"], Path(entry["gold"])
    if not snapshot.exists():
        raise ConfigError(f"the new output was not kept: {snapshot}")
    if gold.exists():
        backup = folder / BACKUP_DIR / f"{index}-{gold.name}"
        backup.parent.mkdir(parents=True, exist_ok=True)
        if gold.is_dir():
            shutil.copytree(gold, backup, dirs_exist_ok=True)
        else:
            shutil.copyfile(gold, backup)
    gold.parent.mkdir(parents=True, exist_ok=True)
    if snapshot.is_dir():
        shutil.copytree(snapshot, gold, dirs_exist_ok=True)
    else:
        shutil.copyfile(snapshot, gold)
    entry["accepted"] = time.strftime("%Y-%m-%d %H:%M:%S")
    path.write_text(json.dumps(entries, indent=2), encoding="utf-8")
    with (folder / "test.log").open("a", encoding="utf-8") as fh:
        fh.write(f"{time.strftime('%H:%M:%S')} gold accepted: {gold} (old one in {BACKUP_DIR}/)\n")
    return next(c for c in changes(run_dir) if c.key == key)


def _load(path: Path) -> list[dict]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    return data if isinstance(data, list) else []
