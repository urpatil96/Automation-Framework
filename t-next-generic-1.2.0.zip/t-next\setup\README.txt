bwtest - setup folder
=====================

setup-bwtest.bat     Install bwtest on a new machine (or repair / update an existing install).
                     Asks where to install (default C:\D\bw6-autotest), checks Python and Git Bash,
                     installs the packages, asks for this machine's settings (BW installs, default
                     build, test case location, domain home, your name) and runs Doctor.
                     Your config\local.yaml, .env and results\ are never overwritten.

make-share-zip.bat   Make a clean zip to give to a colleague: no .venv, no results, no personal
                     settings, no passwords. Written next to the project folder.
                     --with-wheels  also packs all Python packages (setup\wheels) for an install
                                    without internet (colleague needs the same Python version).

backup-bwtest.bat    Full backup of the framework in ONE zip, including your settings, your .env
                     passwords and results\. Written to <parent folder>\bwtest-backups\.
                     --no-results   smaller backup without results\.
                     Keep backups private (they contain your passwords).
                     Restore: unzip, then run setup-bwtest.bat (re-creates .venv).

allow-firewall.bat   Stops the Windows Firewall pop-up "Java Launcher" during runs. Adds:
                     - one rule for the bwtest port ranges (all workers + parallel runs), any program
                     - one rule per AppNode program: every suite x every bwtest domain, plus every
                       bwappnode-*.exe already in the domain home (also t-tests bwdomain-*).
                     Domain + private networks only. Needs Administrator rights (asks, or let IT run it).
                     New test cases in existing suites: nothing to do. New suite: run it again once.
                     --remove  deletes all these rules again.

Daily use is NOT here: start the app with ..\start-bwtest.bat
Full guide: ..\docs\USER_GUIDE.md
