// One run: live progress while it runs, then results. Tabs: Tests · Console · Files · Details.
// While running, the page polls the server every 2 s (status) and reads the console incrementally.
import { api } from "../core/api.js";
import { h, mount } from "../core/dom.js";
import { bytes, duration, OUTCOMES, since } from "../core/format.js";
import {
  button, callout, card, checkbox, codeView, confirmDialog, countsBar, empty, grid, kv, linkButton, loading, modal,
  outcomePill, pageHeader, progress, runStatePill, select, stat, tabs, toast,
} from "../components/ui.js";

const LIVE = new Set(["running", "stopping"]);

export default {
  title: (p) => `Run ${p.id}`,
  async render(view) {
    const id = view.params.id;
    let run = await api.run(id);
    const root = h("div", { class: "stack" });
    const header = h("div");
    const live = h("div");
    const tabsHost = h("div");
    root.append(header, live, tabsHost);

    // console state survives re-renders
    const consoleState = { text: "", offset: 0, pre: null, follow: true };
    let filter = "all";
    let testsTable = null;

    function drawHeader() {
      const info = run.info || {};
      const isLive = LIVE.has(run.state);
      mount(header, pageHeader(
        h("span", {}, info.name || `Run ${id}`, "  ", runStatePill(run.state)),
        [info.profile && `BW ${info.profile}`, info.build, info.tester && `by ${info.tester}`, run.started && `started ${since(run.started)}`,
         info.dry_run && "DRY RUN"].filter(Boolean).join("  ·  "),
        isLive ? button("Stop after current test", stopRun, "danger", { title: "Graceful: finishes the current test and cleans up BW" }) : null,
        isLive ? button("Force kill", killRun, "ghost", { title: "Last resort - may leave an AppNode running" }) : null,
        !isLive && run.has_report ? linkButton("Open HTML report", api.rawUrl(id, "report.html"), "", { target: "_blank", rel: "noopener" }) : null,
        !isLive && (run.counts.failed || run.counts.error) ? button("Re-run failed", () => rerun(true), "primary") : null,
        !isLive ? button("Run again", () => rerun(false)) : null,
        !isLive && run.gold_changes ? button(`Gold changes (${run.gold_changes})`, () => goldChanges(), "",
          { title: "Failed tests whose output differs from the gold file - review the diff and accept the new output as gold" }) : null,
        !isLive && run.tests.length ? button("t-tests .sql", ttestsSql, "", { title: "Create the old t-tests .sql report (t_func_engine_report_<time>.sql) to upload the results to the QA results DB" }) : null,
        !isLive ? button("Delete", deleteRun, "ghost danger") : null));
    }

    async function stopRun() {
      if (!(await confirmDialog("Stop the run?", "The current test finishes, then AppNode/AppSpace/domain are cleaned up. "
        + "Remaining tests are not started. This can take a few minutes.", "Stop run", "danger-solid"))) return;
      await api.stopRun(id);
      toast("Stop requested - finishing the current test and cleaning up.", "info");
      refresh();
    }

    async function killRun() {
      if (!(await confirmDialog("Force kill?", "Kills the run immediately without cleanup. An AppNode that was already started "
        + "may keep running (end it in Task Manager: bwappnode-<suite>.exe) and the domain folder stays. "
        + "Use 'Stop after current test' if you can wait.", "Kill now", "danger-solid"))) return;
      await api.killRun(id);
      toast("Run killed.", "warn");
      refresh();
    }

    async function rerun(failedOnly) {
      const r = await api.rerun(id, failedOnly);
      toast(`Run ${r.id} started`);
      view.navigate(`/runs/${r.id}`);
    }

    async function ttestsSql() {
      const r = await api.ttestsReport(id);
      const openFolder = window.pywebview?.api?.open_path
        ? button("Open folder", () => window.pywebview.api.open_path(r.path), "") : null;
      modal({ title: "t-tests .sql report created", body: h("div", { class: "stack" },
        h("p", {}, "Same format as the t-tests file - upload it to the QA results DB the same way as before ",
          h("span", { class: "muted" }, "(e.g. sqlplus @<file>)"), "."),
        kv(r.sql.map((f) => [f.split("/").pop(), h("a", { href: api.rawUrl(id, f), target: "_blank" }, "open ↗")])),
        h("div", { class: "muted small mono" }, r.path),
        h("p", { class: "muted small" }, "Skipped / not-run tests are not included. Known failures are reported as FAILED with the Jira in NOTE.")),
        actions: [openFolder] });
      toast("t-tests .sql created");
    }

    // ---------------------------------------------------------------- gold changes (after a feature change)
    async function goldChanges(onlyTest) {
      const all = (await api.goldChanges(id)).changes;
      const list = all.filter((c) => !c.accepted && (!onlyTest || (c.suite === onlyTest.suite && c.test === onlyTest.id)));
      if (!list.length) { toast("No open gold changes in this run.", "info"); return; }
      const chosen = new Set(list.map((c) => c.key));
      const open = new Set(list.map((c) => c.key));  // not accepted yet in this dialog
      const boxes = new Map();  // key -> its check box
      const slots = new Map();  // key -> place of its "Accept as gold" button
      let dlg = null;
      const okBtn = h("button", { class: "btn primary" });
      const label = () => { okBtn.textContent = `Accept selected as gold (${chosen.size})`; okBtn.disabled = !chosen.size; };
      label();
      const refreshRun = async () => { run = await api.run(id); drawHeader(); drawLive(); };
      const markAccepted = (keys) => {
        for (const key of keys) {
          open.delete(key); chosen.delete(key);
          const box = boxes.get(key);
          if (box) { box.checked = false; box.disabled = true; }
          const slot = slots.get(key);
          if (slot) mount(slot, h("span", { class: "pill tone-ok" }, "✓ accepted as gold"));
        }
        label();
      };
      const selectAll = (on) => {
        for (const key of open) { boxes.get(key).checked = on; if (on) chosen.add(key); else chosen.delete(key); }
        label();
      };
      const rows = list.map((c) => {
        const box = checkbox(h("span", {}, h("b", {}, c.suite), " · ", h("span", { class: "mono" }, c.test),
          h("span", { class: "muted small" }, `  (${c.kind === "legacy" ? ".sh check" : c.kind})`)), true,
          (on) => { if (on) chosen.add(c.key); else chosen.delete(c.key); label(); });
        boxes.set(c.key, box.querySelector("input"));
        const acceptOne = button("Accept as gold", async () => {
          await api.acceptGold(id, [c.key]);
          markAccepted([c.key]);
          toast(`Gold file of ${c.test} updated - run the test again to confirm`, "ok", 6000);
          await refreshRun();
          if (!open.size && dlg) dlg.close();
        }, "small", { title: "Accept only this test's new output as its gold file" });
        return h("div", { class: "card stack", style: { padding: "10px" } },
          h("div", { class: "row space" }, box,
            h("div", { class: "row", style: { gap: "12px" } },
              h("a", { href: api.rawUrl(id, c.snapshot), target: "_blank", class: "small" }, "new output ↗"),
              slots.set(c.key, h("span", {}, acceptOne)).get(c.key))),
          h("div", { class: "muted small mono" }, "gold: ", c.gold, c.gold_exists ? "" : "  (does not exist yet - will be created)"),
          c.diff_text ? h("details", { open: list.length === 1 }, h("summary", { class: "small" }, "Show the difference"),
            codeView(c.diff_text, { kind: "diff" })) : h("div", { class: "muted small" }, "No diff recorded (binary file or .sh check) - open the new output to check it."));
      });
      const selectBar = list.length > 1 ? h("div", { class: "row", style: { gap: "8px" } },
        button("Select all", () => selectAll(true), "small ghost", { busy: false }),
        button("Select none", () => selectAll(false), "small ghost", { busy: false }),
        h("span", { class: "muted small" }, "Tick the tests to accept together, or use Accept as gold on a single test.")) : null;
      dlg = modal({ title: onlyTest ? `Gold change · ${onlyTest.id}` : `Gold changes · ${list.length} file(s)`, wide: true,
        body: h("div", { class: "stack" },
          callout("info", "Only accept a change you expect", "(e.g. a feature change). The new output replaces the gold file in the test case folder; "
            + "the old gold file is kept in the test's result folder (gold-backup/). Then run the tests again to confirm they pass."),
          selectBar, rows),
        actions: [okBtn] });
      okBtn.onclick = async () => {
        okBtn.disabled = true;
        try {
          const keys = [...chosen];
          const r = await api.acceptGold(id, keys);
          markAccepted(keys);
          toast(`${r.accepted.length} gold file(s) updated - run the tests again to confirm`, "ok", 8000);
          await refreshRun();
          if (!open.size) dlg.close();
        } catch (e) { label(); throw e; }
      };
    }

    async function deleteRun() {
      if (!(await confirmDialog("Delete run", `Delete results folder ${id} with all logs and reports?`, "Delete", "danger-solid"))) return;
      await api.deleteRun(id);
      toast("Run deleted");
      view.navigate("/runs");
    }

    // ---------------------------------------------------------------- live panel
    function drawLive() {
      const total = run.tests.length;
      const finished = run.tests.filter((t) => !["pending", "running", "not_run"].includes(t.outcome)).length;
      const counts = {};
      for (const t of run.tests) counts[t.outcome] = (counts[t.outcome] || 0) + 1;
      const isLive = LIVE.has(run.state);
      const current = run.tests.find((t) => t.nodeid === run.current);
      const suitePhases = Object.entries(run.suites || {});
      const starting = suitePhases.find(([, s]) => s.phase === "setup");
      const failedSuites = suitePhases.filter(([, s]) => s.phase === "failed");

      mount(live,
        isLive ? card({},
          progress(finished, total, "run"),
          h("div", { style: { marginTop: "12px" } },
            current ? h("div", { class: "run-current" }, h("span", { class: "spinner" }),
              h("span", {}, "Running ", h("b", { class: "mono" }, current.id), ` (${current.suite})`, current.description ? ` - ${current.description}` : ""),
              current.started ? h("span", { class: "muted small", style: { marginLeft: "auto" } }, `for ${duration(Date.now() / 1000 - current.started)}`) : null)
              : starting ? h("div", { class: "run-current" }, h("span", { class: "spinner" }),
                h("span", {}, "Preparing suite ", h("b", {}, starting[0]), ": installing drivers, creating AppSpace and starting the AppNode. ",
                  h("span", { class: "muted" }, "This can take ~3 minutes on Windows.")))
                : h("div", { class: "run-current" }, h("span", { class: "spinner" }),
                  run.state === "stopping" ? "Stopping: finishing the current step and cleaning up BW…" : "Starting: detecting BW version and creating the domain…"))) : null,
        grid(5,
          stat("Passed", counts.passed || 0, "ok"),
          stat("Failed", counts.failed || 0, "bad"),
          stat("Errors", (counts.error || 0), "warn", "setup / environment"),
          stat("Known failures", (counts.xfailed || 0) + (counts.xpassed ? ` +${counts.xpassed} fixed?` : ""), "known"),
          stat(isLive ? "Remaining" : "Skipped / not run", isLive ? total - finished : (counts.skipped || 0) + (counts.not_run || 0))),
        !isLive && run.tests.length ? card({}, countsBar(counts)) : null,
        failedSuites.map(([name, s]) => callout("bad", `Suite ${name} could not start:`, h("div", { class: "mono small" }, s.message))),
        !isLive && run.gold_changes ? callout("warn", `${run.gold_changes} failed test(s): the output differs from the gold file.`,
          "If that is expected (feature change), review the difference and accept the new output as gold - no re-run needed. ",
          button("Review gold changes", () => goldChanges(), "small")) : null,
        run.state === "aborted" ? callout("warn", "This run did not finish normally.",
          "The process ended without a summary (closed window, reboot or crash). Results below are what was recorded.") : null,
        run.state === "killed" ? callout("warn", "This run was killed.",
          "Check Task Manager for bwappnode-*.exe processes left over and delete the bwtest-N folder in the domain home.") : null);
    }

    // ---------------------------------------------------------------- tests table
    function testsView() {
      const wrap = h("div");
      const options = [["all", "All tests"], ["problems", "Failed + errors"], ...Object.entries(OUTCOMES).map(([k, v]) => [k, v.label])];
      const filterSel = select(options, filter, { style: { width: "auto" }, onchange: (e) => { filter = e.target.value; drawTable(); } });
      const tableHost = h("div", { class: "table-wrap" });
      function drawTable() {
        const rows = run.tests.filter((t) => filter === "all" || t.outcome === filter
          || (filter === "problems" && ["failed", "error"].includes(t.outcome)));
        mount(tableHost, rows.length ? h("table", { class: "table" },
          h("thead", {}, h("tr", {}, h("th", {}, "Result"), h("th", {}, "Suite"), h("th", {}, "Test"), h("th", {}, "Description"),
            h("th", { class: "right" }, "Time"), h("th", {}, ""))),
          h("tbody", {}, rows.map((t) => h("tr", { class: ["clickable", t.outcome === "running" && "is-running"], onclick: () => openTest(t) },
            h("td", {}, outcomePill(t.outcome), t.teardown_error ? h("div", {}, h("span", { class: "pill tone-warn", title: t.teardown_error }, "cleanup error")) : null),
            h("td", {}, t.suite),
            h("td", { class: "mono nowrap" }, t.id),
            h("td", { class: "desc" }, t.description || "", t.message && ["failed", "error"].includes(t.outcome)
              ? h("div", { class: "small", style: { color: "var(--bad)" } }, firstLine(t.message)) : null,
              t.outcome === "xfailed" && t.message ? h("div", { class: "small muted" }, `known: ${t.message}`) : null),
            h("td", { class: "right nowrap" }, duration(t.duration)),
            h("td", { class: "right" }, h("span", { class: "muted small" }, "details ›"))))))
          : empty(run.tests.length ? "No tests with this result" : LIVE.has(run.state) ? "Collecting tests…" : "No tests recorded"));
      }
      testsTable = drawTable;
      drawTable();
      mount(wrap, h("div", { class: "row space", style: { marginBottom: "10px" } }, filterSel,
        h("span", { class: "muted small" }, "Click a test to see its diff, logs and the module properties it received.")), tableHost);
      return card({ class: "flush" }, h("div", { style: { padding: "12px 14px" } }, wrap));
    }

    function firstLine(message) {
      const line = String(message).split("\n").find((l) => l.trim() && !l.startsWith("FAILED") && !l.startsWith("ERROR")) || String(message).split("\n")[0];
      return line.length > 160 ? `${line.slice(0, 160)}…` : line;
    }

    // ---------------------------------------------------------------- one test (dialog)
    async function openTest(t) {
      const fileList = h("ul", { class: "file-list" });
      const viewer = h("div", {}, t.message ? codeView(t.message, { kind: "diff" }) : empty("Select a file on the left"));
      const body = h("div", { class: "stack" },
        kv([["Result", outcomePill(t.outcome)], ["Suite", t.suite], ["Test", h("span", { class: "mono" }, t.id)],
            ["Description", t.description || "—"], ["Duration", duration(t.duration) || "—"],
            t.phases && Object.keys(t.phases).length ? ["Time per phase", Object.entries(t.phases)
              .map(([k, v]) => `${k} ${duration(v) || "0s"}`).join("  ·  ")] : null,
            ["Artifacts", t.artifacts ? h("span", { class: "mono" }, `results/${id}/${t.artifacts}`) : "—"]]),
        h("div", { class: "test-detail" }, fileList, viewer));
      modal({ title: `${t.suite} · ${t.id}`, body, wide: true,
        actions: [t.gold_change && !LIVE.has(run.state) ? button("Accept new output as gold…", () => goldChanges(t), "",
          { title: "The output differs from the gold file - review the difference and make the new output the gold file" }) : null,
          linkButton("Run this test again", `#/run/new?suite=${encodeURIComponent(t.suite)}&test=${encodeURIComponent(t.id)}`, "")] });

      const show = async (name, btn) => {
        fileList.querySelectorAll("button").forEach((b) => b.classList.toggle("active", b === btn));
        if (name === "__message") { mount(viewer, codeView(t.message, { kind: "diff" })); return; }
        mount(viewer, loading());
        const f = await api.files(id, `${t.artifacts}/${name}`);
        if (f.binary) { mount(viewer, h("a", { href: api.rawUrl(id, f.path), target: "_blank" }, `Open ${name} (binary, ${bytes(f.size)})`)); return; }
        const kind = name.endsWith("diff.txt") ? "diff" : name.endsWith(".log") ? "log" : "text";
        mount(viewer, h("div", { class: "row space", style: { marginBottom: "6px" } }, h("b", {}, name),
          h("a", { href: api.rawUrl(id, f.path), target: "_blank", class: "small" }, "open raw ↗")),
          f.text ? codeView(f.text, { kind }) : empty("(empty file)"), f.truncated ? h("p", { class: "muted small" }, "Showing the first 2 MB.") : null);
      };
      const items = [];
      if (t.message) items.push(["__message", t.outcome === "xfailed" ? "Known failure reason" : "Failure message", null]);
      if (t.artifacts) {
        try {
          const listing = await api.files(id, t.artifacts);
          const order = ["diff.txt", "test.log", "bwappnode.log", "module_properties.txt"];
          listing.items.filter((i) => !i.dir).sort((a, b) => ((order.indexOf(a.name) + 1) || 99) - ((order.indexOf(b.name) + 1) || 99))
            .forEach((i) => items.push([i.name, i.name, i.size]));
        } catch { /* artifacts folder not written (e.g. dry run) */ }
      }
      mount(fileList, items.length ? items.map(([name, label, size]) => {
        const btn = h("button", { onclick: () => show(name, btn) }, h("span", {}, label), size !== null ? h("span", { class: "muted small" }, bytes(size)) : null);
        return h("li", {}, btn);
      }) : h("li", { class: "muted small", style: { padding: "10px" } }, "No files recorded for this test."));
      const first = fileList.querySelector("button");
      const diff = [...fileList.querySelectorAll("button")].find((b) => b.textContent.startsWith("diff.txt"));
      if (diff) show("diff.txt", diff); else if (first) first.classList.add("active");
    }

    // ---------------------------------------------------------------- console
    function consoleView() {
      consoleState.pre = h("pre", { class: "code console" });
      consoleState.pre.textContent = consoleState.text;
      const followBox = h("input", { type: "checkbox", checked: consoleState.follow, onchange: (e) => { consoleState.follow = e.target.checked; } });
      setTimeout(() => { if (consoleState.follow) consoleState.pre.scrollTop = consoleState.pre.scrollHeight; }, 0);
      return card({ title: "Console output", subtitle: "What `bwtest run` printed - the same as running it in a terminal.",
        actions: [h("label", { class: "check small" }, followBox, "Follow"),
                  linkButton("Open raw", api.rawUrl(id, "console.log"), "small ghost", { target: "_blank" })] },
        consoleState.pre);
    }

    async function pullConsole() {
      try {
        const c = await api.console(id, consoleState.offset);
        if (c.offset < consoleState.offset) consoleState.text = "";
        if (c.text) {
          consoleState.text += c.text;
          if (consoleState.text.length > 600000) consoleState.text = consoleState.text.slice(-500000);
          if (consoleState.pre && consoleState.pre.isConnected) {
            consoleState.pre.textContent = consoleState.text;
            if (consoleState.follow) consoleState.pre.scrollTop = consoleState.pre.scrollHeight;
          }
        }
        consoleState.offset = c.offset;
      } catch { /* run folder gone */ }
    }

    // ---------------------------------------------------------------- files + details
    function filesView(path = "") {
      const host = h("div");
      const load = async (p) => {
        mount(host, loading());
        const f = await api.files(id, p);
        if (f.type === "file") {
          mount(host, h("div", { class: "row space" }, h("button", { class: "btn small", onclick: () => load(p.split("/").slice(0, -1).join("/")) }, "← Back"),
            h("a", { href: api.rawUrl(id, f.path), target: "_blank" }, "open raw ↗")),
          f.binary ? empty("Binary file", bytes(f.size)) : codeView(f.text, { kind: p.endsWith("diff.txt") ? "diff" : p.endsWith(".log") ? "log" : "text" }));
          return;
        }
        mount(host, h("div", { class: "muted small", style: { marginBottom: "8px" } }, `results/${id}/${f.path}`),
          h("table", { class: "table" }, h("tbody", {},
            f.path ? h("tr", { class: "clickable", onclick: () => load(f.path.split("/").slice(0, -1).join("/")) }, h("td", {}, "📁 .."), h("td", {})) : null,
            f.items.map((i) => h("tr", { class: "clickable", onclick: () => load(f.path ? `${f.path}/${i.name}` : i.name) },
              h("td", {}, i.dir ? "📁 " : "📄 ", i.name), h("td", { class: "right muted small" }, bytes(i.size)))))));
      };
      load(path);
      return card({ title: "Run folder", subtitle: "Everything T-Next wrote: per-test folders, commands.log (every bwadmin call), reports." }, host);
    }

    function timingCard() {
      const tm = run.timing || {};
      const ph = tm.phases || {};
      if (!tm.wall && !Object.keys(ph).length) return null;
      const LABEL = { deploy: "Deploy (upload + deploy + app Running)", action: "Waiting for the test output",
                      cleanup: "Cleanup (stop + undeploy + delete archive)", verify: "Compare with gold" };
      const rows = [["Whole run (wall clock)", h("b", {}, duration(tm.wall) || "—")],
                    ["Suite setup (AppSpace + AppNode start)", duration(tm.suite_setup) || "—"],
                    ...Object.entries(LABEL).filter(([k]) => ph[k] !== undefined).map(([k, label]) => [label, duration(ph[k])])];
      const b = tm.bwadmin;
      if (b) {
        rows.push(["bwadmin commands", `${b.calls} commands, ${duration(b.seconds) || "0s"} in total`
          + (b.shell_calls ? ` - run in one bwadmin shell (t-tests started a new JVM for each, ~3-8 s per command)` : " - one JVM per command")]);
      }
      return card({ title: "Where the time went", help: "From the timings T-Next records for every phase of every test. t-tests did not show this." },
        kv(rows));
    }

    function detailsView() {
      const info = run.info || {};
      const env = run.environment || {};
      return h("div", { class: "stack" }, timingCard(), grid(2,
        card({ title: "Run" }, kv([
          ["Run id", id], ["Name", info.name], ["Tester", info.tester], ["Jira", info.jira], ["Notes", info.notes],
          ["Started", info.started || run.started], ["Ended", info.ended], ["Exit code", info.exit_code ?? "—"],
          ["Command", info.ui_command || info.command ? h("code", {}, info.ui_command || info.command) : "—"],
          ["T-Next version", info.bwtest_version || "—"]])),
        card({ title: "Environment" }, kv([
          ["Profile", info.profile], ["BW home", h("span", { class: "mono" }, info.bw_home || env.bw_home || "—")],
          ["BW version (detected)", env.bw_version ? `${env.bw_version} build ${env.bw_build}` : "—"],
          ["Domain", env.domain], ["Selection", (info.targets || []).join(", ")], ["Tag expression", info.marker],
          ["Keyword", info.keyword], ["Workers", info.workers || 1], ["Dry run", info.dry_run ? "yes" : "no"],
          ["Update gold", info.update_gold ? "yes" : "no"]]))));
    }

    function drawTabs(active) {
      mount(tabsHost, tabs([
        { id: "tests", label: "Tests", badge: run.tests.length, render: testsView },
        { id: "console", label: "Console", render: consoleView },
        { id: "files", label: "Files", render: () => filesView() },
        { id: "details", label: "Details", render: detailsView },
      ], active || (LIVE.has(run.state) && !run.tests.length ? "console" : view.query.tab || "tests"),
      (tab) => { currentTab = tab; }));
    }

    let currentTab = null;
    drawHeader();
    drawLive();
    drawTabs();
    await pullConsole();
    if (consoleState.pre) consoleState.pre.textContent = consoleState.text;

    // ---------------------------------------------------------------- polling while live
    async function refresh() {
      const wasLive = LIVE.has(run.state);
      try { run = await api.run(id); } catch { return; }
      await pullConsole();
      drawHeader();
      drawLive();
      if (currentTab === "tests" && testsTable) testsTable();
      if (wasLive && !LIVE.has(run.state)) {
        toast(`Run ${id} finished: ${run.state}`, run.state === "passed" ? "ok" : "warn", 8000);
        drawTabs(currentTab || "tests");
      }
    }
    if (LIVE.has(run.state)) {
      const timer = setInterval(() => { if (LIVE.has(run.state)) refresh(); else clearInterval(timer); }, 2000);
      view.onCleanup(() => clearInterval(timer));
    }
    return root;
  },
};
