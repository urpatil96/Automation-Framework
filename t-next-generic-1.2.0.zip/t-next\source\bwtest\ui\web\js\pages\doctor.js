// Doctor: check that a profile/build is ready to run, and show the effective configuration.
import { api } from "../core/api.js";
import { h, mount } from "../core/dom.js";
import { openImportDialog } from "../components/importDialog.js";
import { button, callout, card, codeView, field, loading, pageHeader, select, tabs } from "../components/ui.js";

export default {
  title: "Doctor",
  async render() {
    const profiles = await api.profiles();
    const state = { profile: profiles.default, bw_home: "" };
    const results = h("div");
    const buildSelect = h("div");

    const drawBuilds = () => {
      const p = profiles.profiles.find((x) => x.name === state.profile);
      const builds = p ? p.builds : [];
      state.bw_home = (builds.find((b) => b.is_profile_default) || builds[0] || {}).bw_home || "";
      mount(buildSelect, field("Build", select(builds.map((b) => [b.bw_home, `${b.label}  -  ${b.bw_home}`]), state.bw_home,
        { onchange: (e) => { state.bw_home = e.target.value; } })));
    };
    drawBuilds();

    const run = async () => {
      mount(results, loading("Checking… (runs bwadmin version, a few seconds)"));
      const r = await api.doctor({ profile: state.profile, bw_home: state.bw_home, detect_version: true });
      mount(results, card({ title: r.ok ? "Everything is ready" : "Some checks failed" },
        h("ul", { class: "checklist" }, r.checks.map((c) => h("li", {},
          h("span", { class: `check-icon ${c.ok ? "ok" : "bad"}` }, c.ok ? "✓" : "✗"),
          h("div", {}, h("b", {}, c.label), h("div", { class: "muted small mono" }, c.detail),
            !c.ok && c.hint ? h("div", { class: "small", style: { color: "var(--warn)" } }, `→ ${c.hint}`) : null,
            !c.ok && (c.label.includes("not imported") || c.label.includes("not in T-Next")) ? h("div", { style: { marginTop: "6px" } },
              button("⇩ Sync with test folder…", () => openImportDialog(() => run()), "small", { busy: false })) : null))))));
    };

    const configView = async () => {
      const c = await api.config(state.profile);
      return h("div", { class: "stack" },
        callout("info", "How settings are combined (later wins):", h("ol", { style: { margin: "6px 0 0 18px", padding: 0 } }, c.layers.map((l) => h("li", {}, l)))),
        codeView(JSON.stringify({ bw: c.bw, paths: c.paths, ports: c.ports, timeouts: c.timeouts, ui: c.ui, vars: c.vars }, null, 2)),
        h("h3", {}, "Drivers (config/drivers.yaml)"), codeView(JSON.stringify(c.drivers, null, 2), { maxHeight: "280px" }),
        h("h3", {}, "Databases (config/databases.yaml - passwords hidden)"), codeView(JSON.stringify(c.databases, null, 2), { maxHeight: "280px" }));
    };

    return h("div", { class: "stack" },
      pageHeader("Doctor", "Checks BW home, bwadmin, test case location, bash, domain folder, report plugins and all suite files."),
      card({ title: "Check an environment" },
        h("div", { class: "form-grid" },
          field("Profile", select(profiles.profiles.map((p) => p.name), state.profile,
            { onchange: (e) => { state.profile = e.target.value; drawBuilds(); } })),
          buildSelect),
        button("Run checks", run, "primary")),
      results,
      tabs([{ id: "config", label: "Effective configuration", render: configView }], "config"));
  },
};
