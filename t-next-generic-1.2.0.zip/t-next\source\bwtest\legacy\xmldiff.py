"""`t-xmldiff OUTPUT GOLD` for legacy scripts - python -m bwtest.legacy.xmldiff a.xml b.xml

Compares two XML files ignoring formatting, attribute order and namespace prefixes (same rules as the
`xml` verifier). Prints a unified diff of the canonical forms; exit code 0 = equal, 1 = different,
2 = a file is missing or not well-formed - the same contract the old t-tests t-xmldiff had for scripts.
"""

from __future__ import annotations

import difflib
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

from ..verify import _canonical_xml, _read_text


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: t-xmldiff OUTPUT_FILE GOLD_FILE", file=sys.stderr)
        return 2
    canon = []
    for name in argv:
        path = Path(name)
        if not path.is_file():
            print(f"t-xmldiff: file not found: {name}", file=sys.stderr)
            return 2
        try:
            canon.append(_canonical_xml(_read_text(path).lstrip("﻿"), {}))
        except ET.ParseError as exc:
            print(f"t-xmldiff: {name} is not well-formed XML: {exc}", file=sys.stderr)
            return 2
    if canon[0] == canon[1]:
        return 0
    diff = difflib.unified_diff(canon[1], canon[0], argv[1], argv[0], lineterm="")
    sys.stdout.writelines(line + "\n" for line in diff)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
