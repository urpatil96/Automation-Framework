"""Dashboard, profiles/builds, preferences, doctor, effective configuration."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Request
from pydantic import BaseModel

from ... import __version__
from ...doctor import bwadmin_path, run_checks
from ..services import preferences
from ..services.builds import list_profiles

router = APIRouter(prefix="/api", tags=["system"])


def _ctx(request: Request):
    return request.app.state.ctx


@router.get("/overview")
def overview(request: Request) -> dict:
    ctx = _ctx(request)
    s = ctx.settings()
    entries = ctx.catalog.entries()
    suites = [e.suite for e in entries if e.suite]
    tests = sum(len(x.tests) for x in suites)
    bridged = sum(len(x.tests) if x.legacy else sum(1 for t in x.tests if t.legacy) for x in suites)
    checklist = [
        {"label": "Personal settings saved (Preferences)", "ok": (ctx.config_dir / "local.yaml").is_file(),
         "link": "#/preferences"},
        {"label": "Test case location found", "ok": s.paths.assets_root.is_dir(), "link": "#/preferences"},
        {"label": f"BW install of profile {s.profile} found", "ok": bwadmin_path(s).is_file(),
         "link": "#/preferences"},
        {"label": "Environment check passed (Doctor)", "ok": None, "link": "#/doctor"},
    ]
    return {
        "version": __version__,
        "profile": s.profile, "bw_home": s.bw.home.as_posix(), "assets_root": s.paths.assets_root.as_posix(),
        "results_dir": s.paths.results_dir.as_posix(), "default_tester": s.ui.default_tester,
        "counts": {"suites": len(suites), "tests": tests, "bridged": bridged,
                   "native": tests - bridged, "invalid": sum(1 for e in entries if e.error),
                   "engine": sum(1 for x in suites if x.type == "bw_engine"),
                   "migration": sum(1 for x in suites if x.type == "bw_migration"),
                   "known_to_fail": sum(1 for x in suites for t in x.tests if t.known_to_fail)},
        "recent_runs": ctx.runs.history(8), "active_run": ctx.runs.active_id(),
        "active_runs": ctx.runs.active_ids(), "checklist": checklist,
    }


@router.get("/profiles")
def profiles(request: Request) -> dict:
    ctx = _ctx(request)
    base = ctx.settings()
    return {"default": base.profile, "builds_root": base.ui.builds_root.as_posix(),
            "default_tester": base.ui.default_tester,
            "profiles": [p.as_dict() for p in list_profiles(ctx.config_dir, base)]}


@router.get("/preferences")
def get_preferences(request: Request) -> dict:
    ctx = _ctx(request)
    return preferences.read(ctx.config_dir, ctx.settings())


class PreferencesBody(BaseModel):
    values: dict[str, Any]


@router.put("/preferences")
def put_preferences(body: PreferencesBody, request: Request) -> dict:
    ctx = _ctx(request)
    preferences.save(ctx.config_dir, body.values)
    return preferences.read(ctx.config_dir, ctx.settings())


class DoctorBody(BaseModel):
    profile: str = ""
    bw_home: str = ""
    detect_version: bool = True


@router.post("/doctor")
def doctor(body: DoctorBody, request: Request) -> dict:
    ctx = _ctx(request)
    s = ctx.settings(body.profile, body.bw_home)
    checks = run_checks(s, ctx.root, detect_version=body.detect_version)
    return {"profile": s.profile, "bw_home": s.bw.home.as_posix(), "ok": all(c.ok for c in checks),
            "checks": [c.as_dict() for c in checks]}


@router.get("/config")
def config(request: Request, profile: str = "") -> dict:
    """Effective configuration (all layers merged). Database passwords are never returned."""
    ctx = _ctx(request)
    s = ctx.settings(profile)

    def plain(obj) -> dict:
        return {k: (v.as_posix() if hasattr(v, "as_posix") else v) for k, v in vars(obj).items()}

    files = [p for p in ("bwtest.yaml", f"profiles/{s.profile}.yaml", "local.yaml", "drivers.yaml",
                         "databases.yaml") if (ctx.config_dir / p).is_file()]
    return {
        "profile": s.profile, "config_dir": ctx.config_dir.as_posix(), "files": files,
        "layers": ["config/bwtest.yaml", f"config/profiles/{s.profile}.yaml", "config/local.yaml",
                   ".env + BWTEST__* environment variables", "options of the run"],
        "bw": plain(s.bw), "paths": plain(s.paths), "ports": plain(s.ports), "timeouts": plain(s.timeouts),
        "ui": plain(s.ui), "vars": s.vars,
        "drivers": {k: {"jars": v.jars, "target": v.target, "suites": v.suites} for k, v in s.drivers.items()},
        "databases": {k: {"url": v.get("url", "") if isinstance(v, dict) else getattr(v, "url", ""),
                          "user": v.get("user", "") if isinstance(v, dict) else getattr(v, "user", "")}
                      for k, v in s.databases.items()},
    }
