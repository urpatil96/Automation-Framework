"""Find BW installs ("builds") for a profile - replaces typing the build on the old t-tests main page.

Layout on the QA machines:   <builds_root>/<version>/<build>/bw/<x.y>/bin/bwadmin.exe
                     e.g.    C:/D/6.12.1/V12/bw/6.12
Any other layout works too (C:/Users/me/bw6/BW6setup/BW6121/bw/6.12 ...): every BW install below
builds_root is found, its version is read from <install>/_installInfo (or a folder name like 6.12.1 /
BW6121), see bwtest/bwhome.py.
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from pathlib import Path

from ...bwhome import guess_version, has_bwadmin, scan
from ...config import Settings, load_settings
from ...errors import BwTestError


@dataclass
class Build:
    label: str  # V12, GA, GA_3HF1GA ...
    bw_home: str
    has_bwadmin: bool
    is_profile_default: bool = False

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass
class Profile:
    name: str
    bw_home: str
    builds: list[Build]
    error: str = ""

    def as_dict(self) -> dict:
        return {"name": self.name, "bw_home": self.bw_home, "error": self.error,
                "builds": [b.as_dict() for b in self.builds]}


def _natural_key(text: str) -> list:
    return [int(p) if p.isdigit() else p.lower() for p in re.split(r"(\d+)", text)]


def _bwadmin(home: Path) -> bool:
    return has_bwadmin(home)


def discover_builds(builds_root: Path, version: str, default_home: Path | None = None,
                    known: list[str] | None = None) -> list[Build]:
    """Builds of `version` below builds_root (any folder layout). `known` = all profile names, so a BW home
    is given to the right one (6.12 could be 6.12.0 or 6.12.1)."""
    builds: dict[str, Build] = {}
    if str(builds_root) not in ("", ".") and Path(builds_root).is_dir():
        for home in scan(builds_root):
            if guess_version(home, known or [version]) == version:
                key = home.as_posix().lower()
                builds[key] = Build(label=home.parent.parent.name, bw_home=home.as_posix(), has_bwadmin=True)
    if default_home and str(default_home) not in ("", "."):
        key = default_home.as_posix().lower()
        if key in builds:
            builds[key].is_profile_default = True
        else:
            parts = default_home.parts
            label = parts[-3] if len(parts) >= 3 and parts[-2].lower() == "bw" else default_home.name
            builds[key] = Build(label=label, bw_home=default_home.as_posix(), has_bwadmin=_bwadmin(default_home),
                                is_profile_default=True)
    return sorted(builds.values(), key=lambda b: _natural_key(b.label), reverse=True)


def list_profiles(config_dir: Path, base: Settings) -> list[Profile]:
    profiles = []
    known = [f.stem for f in (config_dir / "profiles").glob("*.yaml")]
    for file in sorted((config_dir / "profiles").glob("*.yaml"), key=lambda p: _natural_key(p.stem), reverse=True):
        try:
            settings = load_settings(config_dir, file.stem)
            home = settings.bw.home
            profiles.append(Profile(file.stem, home.as_posix(),
                                    discover_builds(base.ui.builds_root, file.stem, home, known)))
        except BwTestError as exc:
            profiles.append(Profile(file.stem, "", [], error=str(exc)))
    return profiles
