@echo off
rem ============================================================================================
rem  bwtest - allow the test AppNodes in Windows Firewall ONCE, so the "Java Launcher"
rem  pop-up does not come back during runs.
rem
rem  Needs Administrator rights (asks for them, or let IT run it).
rem
rem    setup\allow-firewall.bat            add / refresh the rules (domain + private networks)
rem    setup\allow-firewall.bat --remove   delete all rules this script added
rem
rem  Two kinds of rules (all read from bwtest's config and suites - nothing is hard-coded):
rem   1. "bwtest AppNode ports"  - the bwtest port ranges (HTTP + OSGi of all workers and parallel
rem      runs, e.g. 50000-53999 and 60000-63999), inbound TCP, any program. Generic: covers every
rem      suite and domain, also suites added later.
rem   2. "bwtest AppNode"        - one rule per AppNode program (Windows asks per program path):
rem      every suite x every bwtest domain, plus every bwappnode-*.exe already in the domain home
rem      (any domain, also t-tests bwdomain-*).
rem  New test cases in an existing suite need nothing: they run in the same AppNode.
rem  After adding a NEW SUITE, run this again once (adds its AppNode program).
rem  Public networks (hotel / cafe Wi-Fi) are not included.
rem ============================================================================================
setlocal EnableExtensions EnableDelayedExpansion
for %%R in ("%~dp0..") do set "ROOT=%%~fR"
cd /d "%ROOT%"
title bwtest firewall rules
set "RULE=bwtest AppNode"
set "PORT_RULE=bwtest AppNode ports"

rem -- administrator? (net session only works elevated) - otherwise ask Windows to elevate this script
net session >nul 2>&1
if errorlevel 1 (
    echo Administrator rights are needed - Windows will ask for them now.
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%*' -WorkingDirectory '%ROOT%' -Verb RunAs"
    if errorlevel 1 (
        echo.
        echo Could not get Administrator rights. Ask IT to run this file as Administrator:
        echo   %~f0
        pause
    )
    exit /b
)

echo Removing earlier bwtest rules ...
netsh advfirewall firewall delete rule name="%RULE%" >nul 2>&1
netsh advfirewall firewall delete rule name="%PORT_RULE%" >nul 2>&1
if /i "%~1"=="--remove" (
    echo Done - all "%RULE%" and "%PORT_RULE%" rules removed.
    pause
    exit /b 0
)

if not exist ".venv\Scripts\python.exe" (
    echo bwtest is not installed here ^(.venv missing^). Run setup\setup-bwtest.bat first.
    pause
    exit /b 1
)

rem -- 1. port ranges, any program
set "PORTS="
for /f "usebackq delims=" %%P in (`".venv\Scripts\python.exe" "setup\firewall_paths.py" --ports`) do set "PORTS=%%P"
if not defined PORTS (
    echo Could not read the bwtest configuration - see the error above.
    pause
    exit /b 1
)
netsh advfirewall firewall add rule name="%PORT_RULE%" dir=in action=allow protocol=TCP localport=%PORTS% enable=yes profile=domain,private >nul
if errorlevel 1 (echo Could not add the port rule.) else (echo Ports allowed: %PORTS%)

rem -- 2. one rule per AppNode program
set "LIST=%TEMP%\bwtest-firewall-paths.txt"
".venv\Scripts\python.exe" "setup\firewall_paths.py" > "%LIST%"
if errorlevel 1 (
    echo Could not read the bwtest configuration - see the error above.
    pause
    exit /b 1
)
set /a N=0
set /a FAILED=0
for /f "usebackq delims=" %%P in ("%LIST%") do (
    netsh advfirewall firewall add rule name="%RULE%" dir=in action=allow program="%%P" enable=yes profile=domain,private >nul 2>&1
    if errorlevel 1 (set /a FAILED+=1) else (set /a N+=1)
    set /a SHOWN=!N! %% 50
    if !SHOWN!==0 echo   !N! program rules added ...
)
del "%LIST%" >nul 2>&1

echo.
echo Added: port rule "%PORT_RULE%" and %N% program rules "%RULE%" (inbound, allow, domain + private networks).
if not %FAILED%==0 echo %FAILED% program rules could not be added.
echo New test cases in existing suites: nothing to do. After adding a NEW suite: run this file again once.
echo Remove everything again with:  setup\allow-firewall.bat --remove
pause
