"""Suite catalog for the UI: every *.suite.yaml, parsed once and re-parsed only when a file changes."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from pathlib import Path

from ...errors import BwTestError
from ...models import SUITE_GLOB, SuiteSpec, load_suite


@dataclass
class Entry:
    file: Path
    mtime: float
    suite: SuiteSpec | None
    error: str = ""


class SuiteCatalog:
    def __init__(self, suites_root: Path, assets_root: Path | str):
        self.root = suites_root
        self.assets_root = assets_root
        self._cache: dict[Path, Entry] = {}
        self._lock = threading.Lock()

    def entries(self) -> list[Entry]:
        with self._lock:
            files = sorted(self.root.rglob(SUITE_GLOB)) if self.root.is_dir() else []
            fresh: dict[Path, Entry] = {}
            for file in files:
                mtime = file.stat().st_mtime
                cached = self._cache.get(file)
                if cached is None or cached.mtime != mtime:
                    try:
                        cached = Entry(file, mtime, load_suite(file, self.assets_root))
                    except BwTestError as exc:
                        cached = Entry(file, mtime, None, str(exc))
                fresh[file] = cached
            self._cache = fresh
            return list(fresh.values())

    def find(self, name: str) -> Entry | None:
        for entry in self.entries():
            if (entry.suite and entry.suite.name.lower() == name.lower()) or entry.file.stem.removesuffix(
                    ".suite").lower() == name.lower():
                return entry
        return None

    def rel(self, file: Path) -> str:
        try:
            return file.relative_to(self.root.parent).as_posix()
        except ValueError:
            return file.as_posix()

    def category(self, file: Path) -> str:
        """suites/engine/http/http_components/x.suite.yaml -> engine"""
        try:
            parts = file.relative_to(self.root).parts
        except ValueError:
            return ""
        return parts[0] if len(parts) > 1 else ""

    def folder(self, file: Path, name: str) -> str:
        """Folder of the suite in the explorer tree (a suite's own folder is not shown as an extra level).

        suites/engine/jdbc/oracle/jdbc_oracle19c.suite.yaml -> engine/jdbc/oracle
        suites/engine/http/http_2_0/http_2_0.suite.yaml     -> engine/http
        """
        try:
            parts = list(file.relative_to(self.root).parent.parts)
        except ValueError:
            return ""
        if parts and parts[-1].lower() == name.lower():
            parts.pop()
        return "/".join(parts)

    # -- serialisation ----------------------------------------------------------------------------
    def summary(self, entry: Entry) -> dict:
        s = entry.suite
        base = {"file": self.rel(entry.file), "category": self.category(entry.file), "error": entry.error}
        stem = entry.file.name.removesuffix(".suite.yaml")
        base["folder"] = self.folder(entry.file, stem)
        if s is None:
            return {**base, "name": stem, "tests": 0}
        bridged = len(s.tests) if s.legacy else sum(1 for t in s.tests if t.legacy)
        return {**base, "name": s.name, "type": s.type, "owner": s.owner, "description": s.description,
                "tags": s.tags, "enabled": s.enabled, "tests": len(s.tests),
                "known_to_fail": sum(1 for t in s.tests if t.known_to_fail),
                "skipped": sum(1 for t in s.tests if t.skip), "bridged": bridged,
                "assets_dir": s.assets_dir.as_posix(), "assets_exist": s.assets_dir.is_dir()}

    def detail(self, entry: Entry) -> dict:
        data = self.summary(entry)
        s = entry.suite
        if s is None:
            return data
        data.update({
            "vars": s.vars, "drivers": s.drivers, "databases": s.databases, "notes": s.notes,
            "client_vars_files": [p.as_posix() for p in s.client_vars_files],
            "appnode_properties": s.appnode_properties, "legacy": s.legacy,
            "test_list": [{
                "id": t.id, "project": t.project, "description": t.description, "tags": t.tags,
                "known_to_fail": t.known_to_fail, "skip": t.skip, "legacy": bool(t.legacy or s.legacy),
                "verify": _verify_label(t.verify), "action": [_step_label(a) for a in t.action],
                "sequences": t.sequences, "case_exists": (s.assets_dir / t.id).is_dir(), "vars": t.vars,
                "timeout": t.timeout,
            } for t in s.tests],
        })
        return data


def _verify_label(verify) -> str:
    items = verify if isinstance(verify, list) else [verify]
    labels = []
    for v in items:
        if isinstance(v, str):
            labels.append(v)
        elif isinstance(v, dict):
            labels.append(str(v.get("type", "text")))
    return ", ".join(labels) or "text"


def _step_label(step) -> str:
    if isinstance(step, dict) and step:
        return next(iter(step))
    return str(step)
