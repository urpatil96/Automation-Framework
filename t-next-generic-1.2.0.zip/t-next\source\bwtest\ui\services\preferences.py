"""Preferences page - the old t-tests 'user profile' + 'Preferences' dialog, stored in config/local.yaml.

Each field below is one row on the page. `key` is the dotted path in the YAML config, so every value the
UI saves can also be edited by hand in config/local.yaml (git-ignored, personal to this machine).

    old t-tests                                    new field (key)
    Preferences > Test Case Location by Product    paths.assets_root
    Preferences > Product to Test (profile)        profile
    Product profile > INSTALL_HOME                   chosen per run as "Build" (ui.builds_root + profile)
    User profile > JRE location                    vars.JAVA_HOME
    User profile > Tibrv location                  vars.TIBRV_HOME
    User profile > BW5 HOME                        vars.BW5_HOME
    Preferences > Report > tester                  ui.default_tester
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import yaml

from ...config import Settings, load_settings
from ...errors import BwTestError, ConfigError


@dataclass
class Field:
    key: str  # dotted path in the config
    label: str
    group: str
    kind: str = "text"  # text | path | number | select | bool | profile
    help: str = ""
    old: str = ""  # where this lived in t-tests
    options: list[str] | None = None

    def as_dict(self) -> dict:
        return asdict(self)


FIELDS: list[Field] = [
    # -- what to test ---------------------------------------------------------------------------
    Field("profile", "Default profile (BW version)", "Product", "profile",
          "Preselected on the New run page. One file per version in config/profiles/.",
          "Preferences > Product to Test"),
    Field("ui.builds_root", "BW installs folder", "Product", "path",
          "Every BW install below this folder is found, any layout: C:/D/6.12.1/V12/bw/6.12, "
          "C:/bw6/BW6121/bw/6.12 ... The version comes from the install (or a folder name like 6.12.1 / BW6121).",
          "Product profile > INSTALL_HOME"),
    Field("paths.assets_root", "Test case location", "Product", "path",
          "Folder with the EARs and gold files (old tests/bw).", "Preferences > Test Case Location by Product"),
    Field("paths.driver_jars_root", "Driver jars folder", "Product", "path",
          "JDBC / JMS driver jars for the jdbc, jms ... suites (old tests/bw/lib).", "BW_ENGINE.sh"),
    # -- BW runtime -----------------------------------------------------------------------------
    Field("bw.domain_home", "Domain home", "BW runtime", "path",
          "Where bwtest creates its temporary domain bwtest-N.", "win.cfg DomainHome"),
    Field("bw.admin_mode", "Admin mode", "BW runtime", "select", "local = no bwagent needed.",
          "win.cfg AdminMode", ["local", "enterprise"]),
    Field("bw.cleanup_domain", "Delete domain after the run", "BW runtime", "bool",
          "Switch off to inspect the domain after a run.", "win.cfg CleanUpDomain"),
    Field("ports.http_base", "First HTTP port", "BW runtime", "number",
          "Each suite gets its own port from here (parallel workers get +250).", "fixed ports in .cfg"),
    Field("timeouts.appnode_start", "AppNode start timeout (s)", "BW runtime", "number",
          "AppNode boot can take 90 s+ on Windows with antivirus.", "t_sleep"),
    Field("timeouts.output_file", "Wait for output file (s)", "BW runtime", "number",
          "Default wait for a test's output file.", "t_sleep 40"),
    # -- tools (old user profile) ---------------------------------------------------------------
    Field("vars.JAVA_HOME", "JRE location", "Tools", "path",
          "Passed to legacy scripts and apps as JAVA_HOME (BW itself uses its own JRE).",
          "User profile > JRE location"),
    Field("vars.TIBRV_HOME", "Tibrv location", "Tools", "path", "Needed by suites that call tibrvsend etc.",
          "User profile > Tibrv location"),
    Field("vars.BW5_HOME", "BW5 HOME (optional)", "Tools", "path", "Only for BW5 -> BW6 migration suites.",
          "User profile > BW5 HOME"),
    Field("paths.bash", "Bash for old scripts", "Tools", "path",
          "Empty = find Git Bash automatically. Only imported suites that still use t_*.sh scripts need it.",
          "Cygwin"),
    # -- report ---------------------------------------------------------------------------------
    Field("ui.default_tester", "Default tester name", "Report", "text", "Prefilled on the New run page.",
          "Preferences > Report"),
]


def _get(data: Any, dotted: str) -> Any:
    node = data
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            if hasattr(node, part):
                node = getattr(node, part)
                continue
            return None
        node = node[part]
    return node


def _set(data: dict, dotted: str, value: Any) -> None:
    parts = dotted.split(".")
    node = data
    for part in parts[:-1]:
        node = node.setdefault(part, {})
    if value in (None, ""):
        node.pop(parts[-1], None)
    else:
        node[parts[-1]] = value


def _plain(value: Any) -> Any:
    return value.as_posix() if isinstance(value, Path) else value


def read(config_dir: Path, settings: Settings) -> dict:
    local = _read_local(config_dir)
    rows = []
    for f in FIELDS:
        effective = _plain(_get(settings, f.key)) if not f.key.startswith("vars.") else \
            settings.vars.get(f.key.split(".", 1)[1], "")
        if f.key == "profile":
            effective = settings.profile
        rows.append({**f.as_dict(), "value": _plain(_get(local, f.key)), "effective": effective,
                     "in_local": _get(local, f.key) is not None})
    return {"fields": rows, "file": (config_dir / "local.yaml").as_posix()}


def save(config_dir: Path, values: dict[str, Any]) -> None:
    known = {f.key: f for f in FIELDS}
    local = _read_local(config_dir)
    for key, value in values.items():
        field = known.get(key)
        if field is None:
            raise ConfigError(f"unknown preference '{key}'")
        if isinstance(value, str):
            value = value.strip().replace("\\", "/") if field.kind == "path" else value.strip()
        if field.kind == "number" and value not in (None, ""):
            try:
                value = int(value) if float(value).is_integer() else float(value)
            except (TypeError, ValueError):
                raise ConfigError(f"{field.label}: '{value}' is not a number") from None
        if field.kind == "bool" and isinstance(value, str):
            value = value.lower() in ("1", "true", "yes", "on")
        if field.kind == "select" and value not in (None, "") and value not in (field.options or []):
            raise ConfigError(f"{field.label}: must be one of {field.options}")
        _set(local, key, value)
    path = config_dir / "local.yaml"
    previous = path.read_text(encoding="utf-8") if path.is_file() else None
    header = ("# Personal settings of this machine (git-ignored). Edited by the bwtest UI Preferences page -\n"
              "# you can also edit it by hand. Values here override config/bwtest.yaml and the profiles.\n")
    path.write_text(header + yaml.safe_dump(local, sort_keys=False, allow_unicode=True), encoding="utf-8")
    try:
        load_settings(config_dir)  # never leave a config behind that cannot be loaded
    except BwTestError:
        if previous is None:
            path.unlink()
        else:
            path.write_text(previous, encoding="utf-8")
        raise


def _read_local(config_dir: Path) -> dict:
    path = config_dir / "local.yaml"
    if not path.is_file():
        return {}
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ConfigError(f"{path}: top level must be a mapping")
    return data
