@echo off
rem bwtest desktop application - the successor of t-tests\4.0\bin\t-tests.bat. Double-click it.
rem Opens the bwtest window (menus, toolbar, test tree). Close the window to exit.
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo T-Next is not installed yet. Double-click setup\setup-bwtest.bat - or in this folder:
  echo     python -m venv .venv
  echo     .venv\Scripts\pip install -e "source[report,parallel,desktop]"
  pause
  exit /b 1
)
rem pythonw = no console window behind the application
start "" ".venv\Scripts\pythonw.exe" -m bwtest.cli desktop %*
