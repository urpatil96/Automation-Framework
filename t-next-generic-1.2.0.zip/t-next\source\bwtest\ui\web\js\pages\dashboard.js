// Dashboard: where am I, is the setup OK, what ran recently, what can I do next.
import { api } from "../core/api.js";
import { h } from "../core/dom.js";
import { since } from "../core/format.js";
import {
  callout, card, countsBar, countsText, empty, grid, kv, linkButton, pageHeader, runStatePill, stat,
} from "../components/ui.js";

export default {
  title: "Dashboard",
  async render() {
    const o = await api.overview();
    const c = o.counts;
    const firstTime = o.checklist.some((i) => i.ok === false) || !o.recent_runs.length;

    return h("div", { class: "stack" },
      pageHeader("Dashboard", "Run BusinessWorks regression suites, follow them live and review the results.",
        linkButton("Help & guide", "#/help", "ghost"),
        linkButton("▶  Start a new run", "#/run/new", "primary big")),

      (o.active_runs || []).length > 1 ? callout("run", `${o.active_runs.length} runs are in progress.`,
        o.active_runs.map((r, i) => [i ? "  ·  " : "", h("a", { href: `#/runs/${r}` }, `Open run ${r} →`)]))
      : o.active_run ? callout("run", "A run is in progress.",
        h("a", { href: `#/runs/${o.active_run}` }, `Open run ${o.active_run} to follow it live →`)) : null,

      grid(4,
        stat("Suites", c.suites, "", `${c.engine} engine · ${c.migration} migration`),
        stat("Test cases", c.tests.toLocaleString(), "", `${c.native.toLocaleString()} native YAML`),
        stat("With a .sh script step", c.bridged.toLocaleString(), "", "run by T-Next itself"),
        stat("Known to fail", c.known_to_fail.toLocaleString(), "known", "reported as expected failures")),

      h("div", { class: "grid grid-side" },
        card({ title: "Recent runs", actions: [linkButton("All runs", "#/runs", "small ghost")] },
          o.recent_runs.length ? recentTable(o.recent_runs)
            : empty("No runs yet", "Start your first run - it takes about 5 minutes for a small suite.",
              linkButton("▶  New run", "#/run/new", "primary"))),
        h("div", { class: "stack" },
          card({ title: firstTime ? "Getting started" : "Setup", help: "Green = ready. Click an item to fix it." },
            h("ul", { class: "checklist" }, o.checklist.map((i) => h("li", {},
              h("span", { class: `check-icon ${i.ok === true ? "ok" : i.ok === false ? "bad" : "unknown"}` },
                i.ok === true ? "✓" : i.ok === false ? "!" : "?"),
              h("a", { href: i.link }, i.label))))),
          card({ title: "Current defaults", actions: [linkButton("Change", "#/preferences", "small ghost")] },
            kv([["Profile", h("b", {}, o.profile)], ["BW home", h("span", { class: "mono" }, o.bw_home)],
                ["Test cases", h("span", { class: "mono" }, o.assets_root)],
                ["Results", h("span", { class: "mono" }, o.results_dir)]])),
          card({ title: "Quick actions" },
            h("div", { class: "row" },
              linkButton("Browse suites", "#/suites"), linkButton("Add a suite", "#/suites/new"),
              linkButton("Check environment", "#/doctor"))))),
    );
  },
};

function recentTable(runs) {
  return h("div", { class: "table-wrap" }, h("table", { class: "table" },
    h("thead", {}, h("tr", {}, h("th", {}, "Started"), h("th", {}, "Run"), h("th", {}, "Build"), h("th", {}, "Result"), h("th", {}, ""))),
    h("tbody", {}, runs.map((r) => h("tr", { class: "clickable", onclick: () => { location.hash = `#/runs/${r.id}`; } },
      h("td", { class: "nowrap" }, since(r.started)),
      h("td", {}, h("div", {}, r.name || (r.targets || []).join(", ") || r.id), h("div", { class: "muted small" }, r.tester || "")),
      h("td", { class: "nowrap" }, [r.profile, r.build].filter(Boolean).join(" ") || "—"),
      h("td", { style: { minWidth: "180px" } }, countsBar(r.counts), countsText(r.counts)),
      h("td", { class: "right" }, runStatePill(r.state)))))));
}
