@echo off
rem ============================================================================================
rem  bwtest - setup on a new machine. Double-click it (or run it again to repair / update).
rem
rem    1. asks WHERE to install bwtest (default C:\D\bw6-autotest) and copies it there
rem    2. finds Python 3.11+ (3.12 / 3.13 recommended) and checks Git for Windows (Git Bash)
rem    3. creates the Python environment .venv and installs bwtest
rem         - offline from setup\wheels if that folder exists, otherwise from the internet (PyPI)
rem    4. asks for this machine's settings (BW installs, default build, test case location,
rem       domain home, your name) and writes config\local.yaml
rem    5. runs Doctor and offers to start bwtest
rem  Your own files are never overwritten: config\local.yaml, .env and results\ are kept.
rem ============================================================================================
setlocal EnableExtensions EnableDelayedExpansion
for %%R in ("%~dp0..") do set "ROOT=%%~fR"
cd /d "%ROOT%"
title T-Next setup
echo.
echo  T-Next setup  (command: bwtest)
echo  ------------------------------------------------------------------
echo.

rem ---------------------------------------------------------------- 1. install location
if /i "%~1"=="--here" goto :installed_here
set "DEFAULT_DIR=C:\D\bw6-autotest"
echo  Where do you want to install T-Next?  (press Enter for the default)
set "TARGET="
set /p "TARGET=  Folder [%DEFAULT_DIR%]: "
if not defined TARGET set "TARGET=%DEFAULT_DIR%"
set "TARGET=%TARGET:"=%"
for %%T in ("%TARGET%") do set "TARGET=%%~fT"
if "%TARGET:~-1%"=="\" set "TARGET=%TARGET:~0,-1%"
if /i "%TARGET%"=="%ROOT%" (
  echo  [OK] installing in %ROOT%
  goto :installed_here
)
if exist "%TARGET%\setup\setup-bwtest.bat" (
  echo  [!]  T-Next is already installed in %TARGET%.
  echo       Its program files will be updated; your config\local.yaml, .env and results\ are kept.
  choice /c YN /n /m "  Continue? [Y/N] "
  if errorlevel 2 goto :end
)
echo  Copying T-Next to %TARGET% ...
robocopy "%ROOT%" "%TARGET%" /E /NFL /NDL /NJH /NJS /NP ^
  /XD .venv results __pycache__ .pytest_cache .ruff_cache .git .desktop-webview ^
  /XF local.yaml .env *.pyc >nul
if errorlevel 8 ( echo  [X] Copying to %TARGET% failed - check the folder name and your permissions. & goto :fail )
echo  [OK] copied
echo.
call "%TARGET%\setup\setup-bwtest.bat" --here
exit /b %errorlevel%

:installed_here
echo.

rem ---------------------------------------------------------------- 2. Python + Git Bash
set "PY="
for %%V in (3.13 3.12 3.14 3.11) do (
  if not defined PY (
    py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
  )
)
if not defined PY (
  python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1 && set "PY=python"
)
if not defined PY (
  echo  [X] Python 3.11 or newer was not found.
  echo      Install Python 3.12 or 3.13 from https://www.python.org/downloads/windows/
  echo      and tick "Add python.exe to PATH" during the installation. Then run this file again.
  goto :fail
)
for /f "delims=" %%I in ('%PY% -c "import platform; print(platform.python_version())"') do set "PYVER=%%I"
echo  [OK] Python %PYVER%   (%PY%)
%PY% -c "import sys; sys.exit(0 if sys.version_info < (3, 14) else 1)" >nul 2>&1 || (
  echo  [!]  Python %PYVER% is very new: some packages may need a compiler. Python 3.12 or 3.13 is safest.
)

set "BASH="
if exist "%ProgramFiles%\Git\bin\bash.exe" set "BASH=%ProgramFiles%\Git\bin\bash.exe"
if not defined BASH if exist "%LocalAppData%\Programs\Git\bin\bash.exe" set "BASH=%LocalAppData%\Programs\Git\bin\bash.exe"
if not defined BASH for /f "delims=" %%B in ('where bash 2^>nul') do if not defined BASH set "BASH=%%B"
if defined BASH (
  echo  [OK] Git Bash   (!BASH!)
) else (
  echo  [!]  Git for Windows not found. Tests with a .sh script step need it.
  echo       Install it from https://git-scm.com/download/win  - setup continues.
)

rem ---------------------------------------------------------------- 3. environment + packages
if not exist ".venv\Scripts\python.exe" (
  echo.
  echo  Creating the Python environment .venv ...
  %PY% -m venv .venv || ( echo  [X] Could not create .venv & goto :fail )
)
echo.
if exist "setup\wheels\*.whl" (
  echo  Installing T-Next from setup\wheels ^(offline^) ...
  ".venv\Scripts\python.exe" -m pip install --no-index --find-links setup\wheels -e "source[report,parallel,desktop]"
) else (
  echo  Installing T-Next from the internet ^(PyPI^) - this can take a few minutes ...
  ".venv\Scripts\python.exe" -m pip install --timeout 60 --upgrade pip >nul 2>&1
  ".venv\Scripts\python.exe" -m pip install --timeout 60 -e "source[report,parallel,desktop]"
)
if errorlevel 1 (
  echo.
  echo  [X] Installing the packages failed - see the messages above.
  echo      No internet / proxy?  Ask a colleague for a share zip made with
  echo      "setup\make-share-zip.bat --with-wheels" ^(it contains setup\wheels for an offline install^).
  goto :fail
)
for /f "delims=" %%V in ('".venv\Scripts\bwtest.exe" --version') do echo  [OK] %%V installed in %ROOT%

rem ---------------------------------------------------------------- 4. settings of this machine
if not exist ".env" (
  copy /y "config\.env.example" ".env" >nul && echo  [OK] .env created - put the DB / EMS passwords you were given into it ^(never share this file^)
) else (
  echo  [OK] .env kept ^(already there^)
)
".venv\Scripts\bwtest.exe" setup
if errorlevel 1 echo  [!] Settings not saved - set them later in the app: Preferences.

rem ---------------------------------------------------------------- 5. Doctor + next steps
echo.
echo  Checking the setup ^(Doctor^) ...
echo  ------------------------------------------------------------------
".venv\Scripts\bwtest.exe" doctor
echo  ------------------------------------------------------------------
echo.
echo  Setup finished in %ROOT%
echo.
echo    Start the app:  %ROOT%\start-bwtest.bat
echo    First run:      New run -^> pick the build -^> tick a suite -^> Dry run, then a real run
echo    Guide:          %ROOT%\docs\USER_GUIDE.md
echo.
choice /c YN /n /m "  Start bwtest now? [Y/N] "
if errorlevel 2 goto :end
start "" "%ROOT%\start-bwtest.bat"
goto :end

:fail
echo.
echo  Setup did not finish. Fix the problem above and run setup\setup-bwtest.bat again.
echo.
pause
exit /b 1

:end
endlocal
exit /b 0
