// Reusable building blocks. Pages only combine these - change the look here once, it changes everywhere.
import { h, mount } from "../core/dom.js";
import { OUTCOMES, RUN_STATES } from "../core/format.js";

// ---------------------------------------------------------------------------------------------- layout
export function pageHeader(title, subtitle, ...actions) {
  return h("header", { class: "page-header" },
    h("div", {}, h("h1", {}, title), subtitle ? h("p", { class: "subtitle" }, subtitle) : null),
    h("div", { class: "actions" }, actions));
}

export function card({ title, subtitle, actions = [], help, body, class: cls } = {}, ...children) {
  return h("section", { class: ["card", cls] },
    title ? h("div", { class: "card-head" },
      h("div", {}, h("h2", {}, title, help ? helpTip(help) : null), subtitle ? h("p", { class: "muted small" }, subtitle) : null),
      h("div", { class: "actions" }, actions)) : null,
    h("div", { class: "card-body" }, body, children));
}

export function grid(cols, ...children) {
  return h("div", { class: `grid grid-${cols}` }, children);
}

export function kv(rows) {
  return h("dl", { class: "kv" }, rows.filter(Boolean).flatMap(([k, v]) => [h("dt", {}, k), h("dd", {}, v ?? "—")]));
}

export function stat(label, value, tone = "", hint = "") {
  return h("div", { class: ["stat", tone && `tone-${tone}`] },
    h("div", { class: "stat-value" }, value), h("div", { class: "stat-label" }, label),
    hint ? h("div", { class: "stat-hint" }, hint) : null);
}

// ---------------------------------------------------------------------------------------------- status
export function pill(tone, text, title) {
  return h("span", { class: `pill tone-${tone}`, title }, text);
}

export function outcomePill(outcome) {
  const o = OUTCOMES[outcome] || { label: outcome, tone: "muted" };
  return pill(o.tone, o.label);
}

export function runStatePill(state) {
  const s = RUN_STATES[state] || { label: state, tone: "muted" };
  return pill(s.tone, s.label);
}

/** Stacked bar: passed / failed / error / known failures / skipped. */
export function countsBar(counts = {}, total) {
  const parts = [["passed", "ok"], ["failed", "bad"], ["error", "warn"], ["xfailed", "known"], ["xpassed", "info"],
                 ["skipped", "muted"]];
  const sum = total || parts.reduce((n, [k]) => n + (counts[k] || 0), 0);
  if (!sum) return h("div", { class: "bar empty" });
  return h("div", { class: "bar", title: parts.filter(([k]) => counts[k]).map(([k]) => `${OUTCOMES[k].label}: ${counts[k]}`).join("  ·  ") },
    parts.filter(([k]) => counts[k]).map(([k, tone]) =>
      h("span", { class: `seg tone-${tone}`, style: { width: `${(100 * counts[k]) / sum}%` } })));
}

export function countsText(counts = {}) {
  const items = [["passed", "passed"], ["failed", "failed"], ["error", "errors"], ["xfailed", "known"],
                 ["xpassed", "xpass"], ["skipped", "skipped"]];
  const parts = items.filter(([k]) => counts[k]).map(([k, label]) =>
    h("span", { class: `count tone-${OUTCOMES[k].tone}` }, `${counts[k]} ${label}`));
  return parts.length ? h("span", { class: "counts" }, parts) : h("span", { class: "muted" }, "—");
}

export function progress(done, total, tone = "run") {
  const pct = total ? Math.round((100 * done) / total) : 0;
  return h("div", { class: "progress" },
    h("div", { class: `progress-fill tone-${tone}`, style: { width: `${pct}%` } }),
    h("span", { class: "progress-label" }, total ? `${done} / ${total} (${pct}%)` : "collecting tests…"));
}

// ---------------------------------------------------------------------------------------------- feedback
export function loading(text = "Loading…") {
  return h("div", { class: "loading" }, h("span", { class: "spinner" }), text);
}

export function empty(title, text, action) {
  return h("div", { class: "empty" }, h("div", { class: "empty-title" }, title),
    text ? h("p", {}, text) : null, action || null);
}

export function errorPanel(error) {
  return h("div", { class: "callout tone-bad" }, h("strong", {}, "Something went wrong: "), String(error.message || error));
}

export function callout(tone, title, ...children) {
  return h("div", { class: `callout tone-${tone}` }, title ? h("strong", {}, title, " ") : null, children);
}

let toastHost;
export function toast(message, tone = "ok", ms = 4500) {
  toastHost ||= document.body.appendChild(h("div", { class: "toasts", role: "status", "aria-live": "polite" }));
  const el = h("div", { class: `toast tone-${tone}` }, String(message));
  toastHost.appendChild(el);
  setTimeout(() => el.classList.add("hide"), ms);
  setTimeout(() => el.remove(), ms + 400);
}

export function helpTip(text) {
  return h("span", { class: "help-tip", tabindex: "0", "aria-label": text, "data-tip": text }, "?");
}

// ---------------------------------------------------------------------------------------------- dialogs
export function modal({ title, body, actions = [], wide = false, onClose }) {
  const close = () => { overlay.remove(); document.removeEventListener("keydown", onKey); onClose && onClose(); };
  const onKey = (e) => { if (e.key === "Escape") close(); };
  const overlay = h("div", { class: "overlay", onclick: (e) => { if (e.target === overlay) close(); } },
    h("div", { class: ["dialog", wide && "wide"], role: "dialog", "aria-modal": "true" },
      h("div", { class: "dialog-head" }, h("h2", {}, title), h("button", { class: "icon-btn", onclick: close, title: "Close" }, "✕")),
      h("div", { class: "dialog-body" }, body),
      actions.length ? h("div", { class: "dialog-actions" }, actions) : null));
  document.body.appendChild(overlay);
  document.addEventListener("keydown", onKey);
  const first = overlay.querySelector("input, select, textarea, button.primary");
  if (first) setTimeout(() => first.focus(), 30);
  return { close, overlay };
}

export function confirmDialog(title, message, okLabel = "OK", tone = "primary") {
  return new Promise((resolve) => {
    let done = false;
    const finish = (value) => { if (!done) { done = true; resolve(value); } dlg.close(); };
    const dlg = modal({
      title, body: h("p", {}, message), onClose: () => { if (!done) { done = true; resolve(false); } },
      actions: [h("button", { class: "btn", onclick: () => finish(false) }, "Cancel"),
                h("button", { class: `btn ${tone}`, onclick: () => finish(true) }, okLabel)],
    });
  });
}

export function promptDialog(title, label, initial = "", help = "") {
  return new Promise((resolve) => {
    const input = h("input", { class: "input", value: initial });
    let done = false;
    const finish = (value) => { done = true; resolve(value); dlg.close(); };
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") finish(input.value.trim()); });
    const dlg = modal({
      title, body: field(label, input, help), onClose: () => { if (!done) resolve(null); },
      actions: [h("button", { class: "btn", onclick: () => finish(null) }, "Cancel"),
                h("button", { class: "btn primary", onclick: () => finish(input.value.trim()) }, "Save")],
    });
  });
}

// ---------------------------------------------------------------------------------------------- forms
/** Label + control + help text (+ "was: …" for people who know t-tests). */
export function field(label, control, help, old, { required = false } = {}) {
  return h("label", { class: "field" },
    h("span", { class: "field-label" }, label, required ? h("span", { class: "req" }, " *") : null),
    control,
    help ? h("span", { class: "field-help" }, help) : null,
    old ? h("span", { class: "field-old" }, `t-tests: ${old}`) : null);
}

export function input(attrs = {}) { return h("input", { class: "input", ...attrs }); }

/** Text field for a file/folder path. In the desktop app it gets a native "Browse…" button.
 *  kind: "file" | "folder";  patterns: e.g. "EAR files (*.ear)"  ;  onchange(value) after typing or browsing */
export function pathInput({ value = "", placeholder = "", kind = "folder", patterns = "", onchange, mono = true } = {}) {
  const box = h("input", { class: ["input", mono && "mono"], value, placeholder, oninput: (e) => onchange && onchange(e.target.value) });
  if (!document.body.classList.contains("desktop")) return box;
  const browse = h("button", { class: "btn", type: "button", onclick: async () => {
    const native = window.pywebview && window.pywebview.api;
    if (!native) { toast("Browse is only available in the desktop app.", "info"); return; }
    const picked = await native.browse(kind, box.value || placeholder, patterns);
    if (picked) { box.value = picked; onchange && onchange(picked); }
  } }, "Browse…");
  return h("div", { class: "path-field" }, box, browse);
}

/** Tell the desktop explorer tree that suites/tests/selections changed. */
export function notifyChanged() { window.dispatchEvent(new Event("bw:changed")); }
export function textarea(attrs = {}) { return h("textarea", { class: "input", ...attrs }); }
export function select(options, value, attrs = {}) {
  return h("select", { class: "input", ...attrs },
    options.map((o) => {
      const [v, label] = Array.isArray(o) ? o : [o, o];
      return h("option", { value: v, selected: v === value }, label);
    }));
}
export function checkbox(label, checked, onchange, help) {
  const box = h("input", { type: "checkbox", checked, onchange: (e) => onchange(e.target.checked) });
  return h("label", { class: "check" }, box, h("span", {}, label, help ? h("span", { class: "field-help" }, help) : null));
}

export function button(label, onclick, tone = "", attrs = {}) {
  const btn = h("button", { class: `btn ${tone}`, type: "button", ...attrs }, label);
  btn.addEventListener("click", async (e) => {
    if (btn.disabled) return;
    btn.disabled = true;
    const original = [...btn.childNodes];
    if (attrs.busy !== false) mount(btn, h("span", { class: "spinner small" }), label);
    try { await onclick(e); } catch (error) { toast(error.message || error, "bad", 8000); }
    finally { if (btn.isConnected) { btn.disabled = false; mount(btn, ...original); } }
  });
  return btn;
}

export function linkButton(label, href, tone = "", attrs = {}) {
  return h("a", { class: `btn ${tone}`, href, ...attrs }, label);
}

// ---------------------------------------------------------------------------------------------- tabs
export function tabs(items, active, onChange) {
  const bar = h("div", { class: "tabs", role: "tablist" });
  const panel = h("div", { class: "tab-panel" });
  const show = async (id) => {
    for (const b of bar.children) b.classList.toggle("active", b.dataset.id === id);
    const item = items.find((i) => i.id === id) || items[0];
    mount(panel, loading());
    try { mount(panel, await item.render()); } catch (e) { mount(panel, errorPanel(e)); }
    onChange && onChange(id);
  };
  for (const item of items) {
    bar.appendChild(h("button", { class: "tab", role: "tab", dataset: { id: item.id }, onclick: () => show(item.id) },
      item.label, item.badge !== undefined && item.badge !== null ? h("span", { class: "tab-badge" }, item.badge) : null));
  }
  show(active || items[0].id);
  return h("div", { class: "tabs-wrap" }, bar, panel);
}

// ---------------------------------------------------------------------------------------------- code
/** Read-only text with optional diff colouring (lines starting with + / - / @@). */
export function codeView(text, { kind = "text", maxHeight } = {}) {
  const pre = h("pre", { class: ["code", kind === "diff" && "diff"], style: maxHeight ? { maxHeight } : null });
  if (kind === "diff" || kind === "log") {
    for (const line of String(text).split("\n")) {
      let cls = "";
      if (kind === "diff") {
        if (line.startsWith("+") && !line.startsWith("+++")) cls = "add";
        else if (line.startsWith("-") && !line.startsWith("---")) cls = "del";
        else if (line.startsWith("@@")) cls = "hunk";
      } else if (/\b(ERROR|SEVERE|FATAL)\b|-5\d{5}/.test(line)) cls = "del";
      else if (/\bWARN(ING)?\b/.test(line)) cls = "warnline";
      pre.appendChild(h("span", { class: cls }, line + "\n"));
    }
  } else {
    pre.textContent = text;
  }
  return pre;
}

export function copyButton(text, label = "Copy") {
  return button(label, async () => {
    await navigator.clipboard.writeText(typeof text === "function" ? text() : text);
    toast("Copied to clipboard");
  }, "small ghost", { busy: false });
}

// ---------------------------------------------------------------------------------------------- stepper
export function stepper(steps, current, onSelect) {
  return h("ol", { class: "stepper" }, steps.map((s, i) =>
    h("li", { class: [i === current && "current", i < current && "done"] },
      h("button", { type: "button", onclick: () => onSelect(i), disabled: i > current },
        h("span", { class: "step-num" }, i < current ? "✓" : String(i + 1)),
        h("span", { class: "step-text" }, h("span", { class: "step-title" }, s.title), h("span", { class: "step-sub" }, s.sub))))));
}
