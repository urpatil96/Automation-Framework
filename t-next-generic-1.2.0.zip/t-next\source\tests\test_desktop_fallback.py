"""Desktop start without a usable WebView2 window: T-Next opens in the browser instead of failing
(colleague's PC: pywebview fell back to the IE engine -> WinError 1021 on a temporary user profile)."""

import urllib.request

import pytest

pytest.importorskip("webview")
pytest.importorskip("uvicorn")

from bwtest import desktop  # noqa: E402


def _record(calls):
    def fallback(url, reason, app):
        with urllib.request.urlopen(url + "api/overview", timeout=10) as r:  # the server answers while we "wait"
            calls.append((url, reason, r.status))
    return fallback


def test_no_webview2_opens_the_browser(fake_project, monkeypatch):
    calls = []
    monkeypatch.setattr(desktop, "webview2_problem", lambda: "the Microsoft Edge WebView2 Runtime is not installed")
    monkeypatch.setattr(desktop, "_browser_fallback", _record(calls))
    monkeypatch.setattr(desktop, "_window", lambda *a: pytest.fail("must not try the window"))
    desktop.run_desktop(fake_project, fake_project / "config")
    [(url, reason, status)] = calls
    assert url.startswith("http://127.0.0.1:") and "desktop=1" not in url and status == 200
    assert "WebView2" in reason


def test_window_error_falls_back_to_the_browser(fake_project, monkeypatch):
    import webview

    calls = []
    monkeypatch.setattr(desktop, "webview2_problem", lambda: "")
    monkeypatch.setattr(desktop, "_browser_fallback", _record(calls))

    def broken_start(**kwargs):
        assert kwargs["gui"] == "edgechromium"  # never the Internet Explorer engine
        raise OSError("[WinError 1021] Cannot create a stable subkey under a volatile parent key")

    monkeypatch.setattr(webview, "start", broken_start)
    desktop.run_desktop(fake_project, fake_project / "config")
    [(_, reason, status)] = calls
    assert "WinError 1021" in reason and status == 200
