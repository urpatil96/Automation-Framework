# T-Next web UI

The UI is the successor of the t-tests 4.0 Swing window (`t-tests.bat`). It runs in the browser, on top of
the same framework the command line uses: every run started in the UI is a normal `bwtest run …`, and the
UI shows that command so people learn it.

## Start

| How | Command | Result |
|---|---|---|
| **Desktop app** (recommended) | double-click `C:\D\bw6-autotest\start-bwtest.bat`, or `bwtest desktop` | own window, like t-tests |
| Browser | `bwtest ui` (`--port 9000`, `--no-browser`) | http://127.0.0.1:8765 |

Both show the same screens. A run that is going keeps running when you close the app; it is shown again on
the next start. Closing the desktop app while a run is going asks for confirmation first.

One-time install: `pip install -e "source[desktop]"` (FastAPI, uvicorn, pywebview). The desktop window uses
Microsoft Edge WebView2, which is part of Windows 10/11 - nothing else to install.

## Desktop application layout (like t-tests 4.0)

```
┌ bwtest - BusinessWorks 6 regression ─────────────────────────────────────────── _ □ x ┐
│ File  Edit  Run  View  Help                                                            │
│ [▶ New run] [☑ Select tests] [■ Stop] │ [☰ Runs & reports] [▤ Suites] [+ New suite] │ [⚙ Preferences] [✚ Doctor]   [◧ Dashboard] [? Help] │
│ ┌ TEST EXPLORER ─────────┐ ┌──────────────────────────────────────────────────────────┐ │
│ │ [Filter suites…]       │ │                                                          │ │
│ │ ▾ 📂 Test suites    23 │ │   selected page: New run wizard, run progress, suite,    │ │
│ │    ▸ 📁 engine      22 │ │   preferences, ...                                       │ │
│ │    ▸ 📁 migration    1 │ │                                                          │ │
│ │ ▾ 📂 Saved selections  │ │                                                          │ │
│ │ ▾ 📂 Recent runs       │ │                                                          │ │
│ └────────────────────────┘ └──────────────────────────────────────────────────────────┘ │
│ Profile 6.12.1 │ C:/D/6.12.1/V12/bw/6.12 │ No run in progress │   23 suites · 1,665 tests │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

| Element | Use |
|---|---|
| **File** menu | New run, New suite, Open results folder (Explorer), Exit |
| **Edit** menu | Select test cases (New run at step 2), Suites, Preferences |
| **Run** menu | New run, Current run, Runs and reports, Check environment (Doctor) |
| **View / Help** | Dashboard, Refresh · Guide, About |
| Toolbar | the same actions with one click; **Stop** is enabled while a run is going |
| Test explorer | click a suite = open it · **double-click a suite = new run with that suite** · click a saved selection = new run with it (old `.testcmd`) · click a recent run = its results |
| Status bar | profile and BW home in use (click → Preferences), run in progress (click → follow it live), totals |
| Browse… | native Windows file/folder picker next to every path field (EAR file, test case location, BW home …) |

## Old t-tests flow → new UI

| t-tests 4.0 (Confluence: *Configure t-tests for Functional cases*) | bwtest UI |
|---|---|
| STEP 1 user profile: OS bit, JRE location, Tibrv location, BW5 HOME | **Preferences → Tools** (OS bit not needed) |
| Preferences → *Test Case Location by Product* | **Preferences → Product → Test case location** |
| Preferences → *Product to Test* → product profile name | **Preferences → Default profile**; profiles = `config/profiles/*.yaml` |
| Product profile → INSTALL_HOME + dependencies (bw, thor, tools, jre64) | **New run → step 1 → Build** (found automatically; BW's own JRE is used) |
| *Types of Testing*: BW_ENGINE / BW_MIGRATION | Suite **type**; filter in **New run → step 2** |
| Preferences → *Report*: product, version, build | **New run → step 3 Report details** (+ version/build detected from `bwadmin`) |
| File → New TestCmd (`.testcmd`) | **New run → step 2 → Save as selection** (`config/selections/*.yaml`) |
| Edit → Select test cases | **New run → step 2** (tick suites, or open ▶ and tick single tests) |
| Run button | **New run → step 4 → Start run** |
| `tests/bw/reports/<platform>/` | **Runs & reports** → run page → *Open HTML report* |

## Pages

| Page | What for |
|---|---|
| **Dashboard** | Counts, recent runs, "Getting started" checklist, defaults in use |
| **New run** | 4-step wizard: product & build → test cases → report details & options → review & start |
| **Runs & reports** | Every run in `results/` (from the UI, the CLI or Jenkins), search and filter |
| **Run page** | Live progress, current test, AppNode start phase, console; *Stop after current test* / *Force kill*; results per test with **diff**, the test's slice of **bwappnode.log**, **module properties**; re-run failed; HTML report |
| **Suites** | All suites with filters (category, engine/migration, has .sh script steps, known failures, missing assets) |
| **Suite page** | Test cases, overview (vars, .cfg, drivers, DB resets), **Edit YAML** (validated before saving), **+ Add test case** |
| **New suite** | Form → `suites/<category>/<name>/<name>.suite.yaml` |
| **Preferences** | Machine settings → `config/local.yaml` |
| **Doctor** | Checks a profile + build; shows the effective configuration and how it is layered |
| **Help & guide** | 5-step how-to, glossary, old → new mapping, FAQ |

## How every field is configured

The UI never stores anything of its own - every field reads/writes a normal framework file, so the CLI,
Jenkins and the UI always agree.

### New run wizard

| Field | Where the choices come from | Where the value goes |
|---|---|---|
| Product profile | one card per `config/profiles/<version>.yaml` | `--profile 6.12.1` |
| Build | folders `<ui.builds_root>/<version>/<build>/bw/<x.y>` that contain `bin/bwadmin.exe` (e.g. `C:/D/6.12.1/V12/bw/6.12`); the profile's own `bw.home` is marked *profile default* | `--bw-home C:/D/6.12.1/V12/bw/6.12` |
| Use another BW home | free text | `--bw-home …` |
| Check this build | runs the Doctor checks incl. `bwadmin version` | nothing stored |
| Test cases (tree) | all `suites/**/*.suite.yaml`; tests load when a suite is opened | whole suite → `http_Attachments_comp`; single test → `suites/…/http_Attachments_comp.suite.yaml::bw.3647` |
| Test type filter | suite `type:` (`bw_engine` / `bw_migration`) | filter only |
| Saved selection | `config/selections/*.yaml` | loads suites/tests |
| Run name / Tester / Jira / Notes | Tester prefilled from `ui.default_tester` | `--name/--tester/--jira/--notes` → `results/<run>/run_info.json` and the *Environment* table of `report.html` |
| Parallel workers | 1-4 | `-n 4` (each worker: own domain `bwtest-N` and port block) |
| Dry run / Update gold / Keep domain | check boxes | `--dry-run` / `--update-gold` / `--pytest=--bw-keep-domain` |

### Preferences (→ `config/local.yaml`)

| Field | Config key | Old t-tests |
|---|---|---|
| Default profile | `profile` | Product to Test |
| BW installs folder | `ui.builds_root` | INSTALL_HOME |
| Test case location | `paths.assets_root` | Test Case Location by Product |
| Driver jars folder | `paths.driver_jars_root` | `tests/bw/lib` in BW_ENGINE.sh |
| Domain home / Admin mode / Delete domain | `bw.domain_home` / `bw.admin_mode` / `bw.cleanup_domain` | win.cfg |
| First HTTP port | `ports.http_base` | fixed ports in .cfg |
| AppNode start timeout / Wait for output file | `timeouts.appnode_start` / `timeouts.output_file` | `t_sleep` |
| JRE / Tibrv / BW5 HOME | `vars.JAVA_HOME` / `vars.TIBRV_HOME` / `vars.BW5_HOME` | user profile |
| Bash for old scripts | `paths.bash` | Cygwin |
| Default tester name | `ui.default_tester` | Preferences → Report |

Empty field = the project default (shown in grey), which comes from `config/bwtest.yaml` or the profile.
Values are validated by loading the whole configuration before the file is kept.

**Add a preference field:** append a `Field(...)` to `FIELDS` in `source/bwtest/ui/services/preferences.py`
(key, label, group, kind, help, old). The page builds itself from that list - no JavaScript change.

### Add test case / New suite forms

They call the same code as `bwtest new-test` / `bwtest new-suite` (`source/bwtest/scaffold.py`): the test id is
validated, the EAR is copied to `<assets_dir>/<id>/<project>.application.ear`, the entry is appended to the
suite YAML and the suite is re-parsed - if that fails the file is restored.

## How a UI run works

```
New run  ──POST /api/runs──►  RunManager.start()
                                 └─ child process: python -m bwtest.cli run <selection> --run-dir results/<id> …
                                        └─ pytest + bwtest plugin ──writes──► results/<id>/events.jsonl   (live progress)
                                                                              results/<id>/console.log    (console)
                                                                              results/<id>/run_info.json  (report details)
Run page ──GET /api/runs/<id> every 2 s──► reads those files
Stop     ──POST /api/runs/<id>/stop──► creates results/<id>/STOP → the plugin skips the remaining tests,
                                        the running suite is torn down normally (AppNode stopped, AppSpace/domain deleted)
```

Several runs can go at the same time (up to 4), like several t-tests jobs: each run gets its own *slot* = its own domains (`bwtest-0` for the first run, `bwtest-s1-0` for the second …) and its own ports. Two runs may not run the **same suite** at the same time (they would share its database tables / mailbox) - bwtest refuses that with a clear message. With another run going, use at most 4 parallel workers. Every run needs RAM for its AppNodes.

## Code layout (to explain or extend)

```
source/bwtest/desktop.py   desktop app: local server on a free port + native window (pywebview/WebView2),
                        menu bar, Browse… dialogs, close confirmation
source/bwtest/ui/
├─ server.py            FastAPI app: /api routers + static files; API docs at /docs
├─ context.py           project root, config dir, fresh settings per request
├─ services/            plain Python, unit-tested
│  ├─ builds.py           profiles + builds discovery
│  ├─ catalog.py          suites (cached by file time)
│  ├─ runs.py             start/stop/kill, history, live status from events.jsonl
│  ├─ preferences.py      Preferences fields ↔ config/local.yaml
│  └─ selections.py       saved selections (old .testcmd)
├─ routes/              HTTP only: system.py · suites.py · runs.py
└─ web/                 browser app, no build step (plain ES modules)
   ├─ index.html · css/app.css (design tokens at the top)
   └─ js/
      ├─ app.js            route table; browser layout (sidebar) or desktop layout
      ├─ shell/desktop.js  desktop layout: toolbar, test explorer tree, status bar
      ├─ core/             dom.js (h() builder) · api.js (all endpoints) · router.js · format.js
      ├─ components/ui.js  cards, pills, tabs, modal, toast, form fields, code/diff viewer, stepper
      └─ pages/            one file per page: dashboard, newRun, runs, runDetail, suites, suiteDetail,
                           newSuite, preferences, doctor, help, notFound
```

**Add a page:** create `web/js/pages/<name>.js` exporting `{ title, render(view) }`, add one `.add(...)` line in
`app.js` (and a NAV entry). **Add an API call:** a function in `routes/*.py` + one line in `core/api.js`.

Why no Angular/React build? Node.js is not installed on the QA machines and the UI must work offline. The
frontend is split the same way an Angular app would be (core services, shared components, one module per
page), and the backend is a documented REST API (`/docs`), so an Angular frontend could replace `web/`
later without touching Python.

## Tests

| What | Command |
|---|---|
| API + a real run started from the UI (bwadmin stand-in) | `pytest source/tests/test_ui_api.py` |
| Every JS file compiles (V8) | `python source/tests/js_syntax_check.py` (needs `pip install mini-racer`) |
| Every page renders with real data, wizard clicked through, app boots in browser and desktop mode (V8) | `python source/tests/ui_smoke_v8.py` |
| The real desktop window opens, shows toolbar/tree/status bar and every page (window visible ~30 s) | `python source/tests/desktop_check.py` |

## Security

The UI has no login. It listens on 127.0.0.1 (this machine only) by default. Do not use `--host 0.0.0.0`
on a shared network: anyone who can reach the port could start runs or edit suite files.
