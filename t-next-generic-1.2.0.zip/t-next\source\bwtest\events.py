"""Run metadata and live progress events, shared by the pytest plugin, the CLI and the web UI.

Every run folder (results/<timestamp>/) can contain:

    run_info.json   who/what/why of the run: name, tester, notes, Jira, profile, BW home, targets, command
    events.jsonl    one JSON object per line, appended while the run is going:
                      {"event": "collected",   "tests": [{"nodeid", "suite", "id", "description"}]}
                      {"event": "environment", "bw_version": "6.12.1", "bw_build": "V12", "domain": ...}
                      {"event": "suite",       "suite": "http_components", "phase": "setup|ready|teardown"}
                      {"event": "start",       "nodeid": ...}
                      {"event": "result",      "nodeid", "outcome", "duration", "message", "artifacts"}
                      {"event": "finished",    "exit": 0, "stats": {...}}
    STOP            created by the UI (or by hand) to ask for a graceful stop: the current test finishes,
                    the AppNode/AppSpace/domain are cleaned up, remaining tests are not started.

The format is append-only and line-based so several processes (pytest-xdist workers) can write safely and
the UI can read it incrementally with an offset.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

RUN_INFO = "run_info.json"
EVENTS = "events.jsonl"
STOP_FILE = "STOP"


def run_dir_from_env() -> Path | None:
    value = os.environ.get("BWTEST_RUN_DIR")
    return Path(value) if value else None


def emit(event: str, run_dir: Path | None = None, **data: Any) -> None:
    """Append one event. Never raises: progress reporting must not break a test run."""
    run_dir = run_dir or run_dir_from_env()
    if run_dir is None:
        return
    record = {"event": event, "time": round(time.time(), 3), **data}
    try:
        run_dir.mkdir(parents=True, exist_ok=True)
        line = json.dumps(record, default=str) + "\n"
        with open(run_dir / EVENTS, "a", encoding="utf-8") as fh:
            fh.write(line)
    except OSError:
        pass


def read_events(run_dir: Path, offset: int = 0) -> tuple[list[dict], int]:
    """Events after byte `offset`; returns (events, new_offset). Incomplete last lines are left for later."""
    path = run_dir / EVENTS
    if not path.is_file():
        return [], offset
    with open(path, "rb") as fh:
        fh.seek(offset)
        data = fh.read()
    end = data.rfind(b"\n")
    if end < 0:
        return [], offset
    events = []
    for raw in data[: end + 1].splitlines():
        try:
            events.append(json.loads(raw))
        except ValueError:
            continue
    return events, offset + end + 1


def write_run_info(run_dir: Path, info: dict) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    existing = read_run_info(run_dir)
    (run_dir / RUN_INFO).write_text(json.dumps({**existing, **info}, indent=2, default=str), encoding="utf-8")


def read_run_info(run_dir: Path) -> dict:
    try:
        return json.loads((run_dir / RUN_INFO).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def stop_requested(run_dir: Path | None = None) -> bool:
    run_dir = run_dir or run_dir_from_env()
    return bool(run_dir and (run_dir / STOP_FILE).exists())
