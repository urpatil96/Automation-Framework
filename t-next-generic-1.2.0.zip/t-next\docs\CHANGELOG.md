# Changelog

Versions follow [semantic versioning](https://semver.org): MAJOR = incompatible change to suite files or commands,
MINOR = new features, PATCH = fixes. Shown by `bwtest --version`, in the desktop app and in every run.

## 1.2.0
First version in this repository. Main features:
- One-click setup, Doctor, BW installs found in any folder layout, versions written in any form.
- Import of classic `.testset` suites, legacy bridge for old `.sh` scripts, Sync with test folder.
- Desktop app with New run wizard, live progress, suites editor, Preferences, Doctor; browser fallback.
- One `bwadmin` shell per run, parallel workers, up to 4 runs at the same time, dry run.
- HTML / JUnit reports, time per phase, gold-change review with accept per test or in bulk, known failures.
