"""The shared bwadmin shell (bw.admin_shell): one JVM for all bwadmin commands instead of one JVM per command.

Real BW 6.12 (2026-11-19, idle machine): one-shot `bwadmin show domains` 2.8 s, the same command in the shell
0.00-0.04 s. On bw-bat, 243 one-shot calls took 28 of 38 minutes.
"""

import sys
from pathlib import Path

from bwtest.bwcli import BwCli, CommandLog, _shell_quote
from bwtest.config import Settings

FAKE = Path(__file__).parent / "fake_bw" / "bwadmin.py"

# exits at once when started without a command (= no interactive shell); answers one-shot calls normally
NO_SHELL = ("import sys; a=sys.argv[1:]; a=a[2:] if a[:1]==['-config'] else a; "
            "print('one-shot ' + ' '.join(a)) if a else None")


def _cli(tmp_path: Path, tool: list[str], admin_shell: bool = True) -> BwCli:
    settings = Settings()
    settings.bw.tool_overrides = {"bwadmin": tool}
    settings.bw.admin_shell = admin_shell
    settings.bw.home = tmp_path
    return BwCli(settings, CommandLog(tmp_path / "commands.log"), work_dir=tmp_path)


def test_commands_run_in_one_shell(tmp_path):
    cli = _cli(tmp_path, [sys.executable, str(FAKE)])
    try:
        assert cli.version(tmp_path).dotted == "6.99.1"  # from the shell banner, no extra JVM
        first = cli.bwadmin("show", "-d", "x", "appnodes", note="poll 1")
        pid = cli._shell.proc.pid
        cli.bwadmin("show", "-d", "x", "appnodes", note="poll 2")
        assert cli._shell.proc.pid == pid and cli.uses_shell  # same process for every command
        assert first.ok and "Name" in first.output and "show -d" not in first.output  # echo removed
        bad = cli.bwadmin("bogus", check=False)
        assert not bad.ok  # "Command not found" counts as a failure
    finally:
        cli.close()
    assert not cli.uses_shell
    log = (tmp_path / "commands.log").read_text()
    assert log.count("bwadmin shell started") == 1 and "poll 2" in log


def test_falls_back_to_one_call_per_command_when_no_shell(tmp_path):
    cli = _cli(tmp_path, [sys.executable, "-c", NO_SHELL])
    result = cli.bwadmin("show", "domains")
    assert result.ok and "one-shot show domains" in result.output
    assert "could not start" in (tmp_path / "commands.log").read_text()


def test_admin_shell_off_keeps_one_call_per_command(tmp_path):
    cli = _cli(tmp_path, [sys.executable, "-c", NO_SHELL], admin_shell=False)
    assert "one-shot show domains" in cli.bwadmin("show", "domains").output
    assert "shell" not in (tmp_path / "commands.log").read_text()


def test_quoting_for_the_shell():
    assert _shell_quote("C:/D/x.ear") == "C:/D/x.ear"
    assert _shell_quote("C:/Program Files/x.ear") == '"C:/Program Files/x.ear"'
