// All calls to the Python backend go through here. Errors from the server ({detail: "..."}) become
// ApiError with a readable message, which pages show in a toast or inline.

export class ApiError extends Error {}

async function request(method, url, body) {
  const options = { method, headers: {} };
  if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  let response;
  try {
    response = await fetch(url, options);
  } catch {
    throw new ApiError("The T-Next UI server is not reachable. Is `bwtest ui` still running?");
  }
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!response.ok) {
    let detail = data && data.detail !== undefined ? data.detail : text || response.statusText;
    if (Array.isArray(detail)) detail = detail.map((d) => `${(d.loc || []).slice(1).join(".")}: ${d.msg}`).join("; ");
    throw new ApiError(String(detail));
  }
  return data;
}

const q = (params) => {
  const s = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== ""));
  return s.toString() ? `?${s}` : "";
};
const enc = encodeURIComponent;

export const api = {
  // system
  overview: () => request("GET", "/api/overview"),
  profiles: () => request("GET", "/api/profiles"),
  preferences: () => request("GET", "/api/preferences"),
  savePreferences: (values) => request("PUT", "/api/preferences", { values }),
  doctor: (body) => request("POST", "/api/doctor", body),
  config: (profile) => request("GET", `/api/config${q({ profile })}`),
  // suites
  suites: () => request("GET", "/api/suites"),
  suite: (name) => request("GET", `/api/suites/${enc(name)}`),
  suiteSource: (name) => request("GET", `/api/suites/${enc(name)}/source`),
  validateSuite: (name, text) => request("POST", `/api/suites/${enc(name)}/validate`, { text }),
  saveSuite: (name, text) => request("PUT", `/api/suites/${enc(name)}/source`, { text }),
  createSuite: (body) => request("POST", "/api/suites", body),
  addTest: (name, body) => request("POST", `/api/suites/${enc(name)}/tests`, body),
  importPending: () => request("GET", "/api/import/pending"),
  importSuites: (body) => request("POST", "/api/import", body),
  tags: () => request("GET", "/api/tags"),
  selections: () => request("GET", "/api/selections"),
  saveSelection: (name, body) => request("PUT", `/api/selections/${enc(name)}`, body),
  deleteSelection: (name) => request("DELETE", `/api/selections/${enc(name)}`),
  // runs
  runs: (limit) => request("GET", `/api/runs${q({ limit })}`),
  previewRun: (body) => request("POST", "/api/runs/preview", body),
  startRun: (body) => request("POST", "/api/runs", body),
  run: (id) => request("GET", `/api/runs/${enc(id)}`),
  console: (id, offset) => request("GET", `/api/runs/${enc(id)}/console${q({ offset })}`),
  stopRun: (id) => request("POST", `/api/runs/${enc(id)}/stop`),
  killRun: (id) => request("POST", `/api/runs/${enc(id)}/kill`),
  rerun: (id, failedOnly) => request("POST", `/api/runs/${enc(id)}/rerun`, { failed_only: failedOnly }),
  ttestsReport: (id) => request("POST", `/api/runs/${enc(id)}/ttests-report`),
  goldChanges: (id) => request("GET", `/api/runs/${enc(id)}/gold-changes`),
  acceptGold: (id, keys) => request("POST", `/api/runs/${enc(id)}/gold-changes/accept`, { keys }),
  deleteRun: (id) => request("DELETE", `/api/runs/${enc(id)}`),
  files: (id, path) => request("GET", `/api/runs/${enc(id)}/files${q({ path })}`),
  rawUrl: (id, path) => `/api/runs/${enc(id)}/raw/${path.split("/").map(enc).join("/")}`,
};
