"""What allow-firewall.bat allows. Values come from bwtest itself (config + suites), so they match what runs create.

    python setup\\firewall_paths.py            AppNode programs, one per line
    python setup\\firewall_paths.py --ports    the bwtest port ranges, e.g. 50000-53999,60000-63999

Windows Firewall asks once per program path ("Java Launcher"), and every AppNode has its own copy:
    <domain_home>\\<domain>\\appnodes\\<appspace>\\<appnode>\\bin\\bwappnode-<appnode>.exe
Firewall rules cannot use wildcards in paths, so the list is:
  * every suite x every bwtest domain (bwtest-0..3 = workers, bwtest-s1-0 .. bwtest-s3-3 = runs at the same time)
  * every AppNode program already in the domain home (any domain - also t-tests bwdomain-*)
The port ranges (all workers and slots) are allowed for any program, so traffic to an AppNode of a suite added
later also works before the script is run again.
"""

import sys
from pathlib import Path

from bwtest import slots
from bwtest.config import load_settings
from bwtest.models import discover_suites

ROOT = Path(__file__).resolve().parents[1]
settings = load_settings(ROOT / "config")
home = Path(settings.bw.domain_home)

if "--ports" in sys.argv:
    blocks = slots.MAX_SLOTS * slots.WORKERS_PER_SLOT  # port blocks of all slots and workers
    span = settings.ports.stride * blocks - 1
    print(",".join(f"{base}-{base + span}" for base in (settings.ports.http_base, settings.ports.osgi_base)))
    sys.exit(0)

paths: dict[str, Path] = {}
names = sorted({s.name for s in discover_suites(ROOT / "suites", settings.paths.assets_root)})
for slot in range(slots.MAX_SLOTS):
    for worker in range(slots.WORKERS_PER_SLOT):
        domain = slots.domain_name(settings.bw.domain_prefix, slot, worker)
        for name in names:
            path = home / domain / "appnodes" / name / name / "bin" / f"bwappnode-{name}.exe"
            paths[str(path).lower()] = path
if home.is_dir():  # AppNodes that exist now, whatever created them (other domains, t-tests, manual tests)
    for path in home.glob("*/appnodes/*/*/bin/bwappnode-*.exe"):
        paths.setdefault(str(path).lower(), path)
for path in sorted(paths.values(), key=lambda p: str(p).lower()):
    print(path)
