"""Start, follow and stop runs; read run history from results/<timestamp>/.

A run started from the UI is just `bwtest run ...` in a child process (exactly what you would type), with
its console written to console.log. Progress comes from events.jsonl written by the pytest plugin, so the
UI shows the same information for runs started from the command line or Jenkins.

Only ONE run at a time: two runs on one machine would use the same domain name (bwtest-0) and ports.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

from ... import events
from ...bwcli import NO_CONSOLE
from ...errors import ConfigError

CONSOLE = "console.log"


@dataclass
class RunRequest:
    """Everything the New Run wizard collects (old t-tests: profile + Preferences/Report + TestCmd)."""

    profile: str = ""
    bw_home: str = ""  # the selected build
    suites: list[str] = field(default_factory=list)  # suite names; empty = all
    tests: list[str] = field(default_factory=list)  # "suite::test_id" - narrow to single tests
    marker: str = ""  # tag expression, e.g. "smoke and not jdbc"
    keyword: str = ""  # pytest -k
    workers: int = 0
    dry_run: bool = False
    update_gold: bool = False
    keep_domain: bool = False
    # report details
    name: str = ""
    tester: str = ""
    notes: str = ""
    jira: str = ""


@dataclass
class ActiveRun:
    id: str
    process: subprocess.Popen
    log: object  # open console file
    suites: list[str] | None = None  # suite files (None = all) - checked against the next run (slots.py)
    workers: int = 0


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":  # os.kill(pid, 0) would TERMINATE the process on Windows - use the Win32 API
        import ctypes

        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return False
        try:
            code = ctypes.c_ulong()
            kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
            return code.value == 259  # STILL_ACTIVE
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


class RunManager:
    def __init__(self, project_root: Path, config_dir: Path, results_dir: Path):
        self.root = project_root
        self.config_dir = config_dir
        self.results_dir = results_dir
        self._active: dict[str, ActiveRun] = {}  # several runs at the same time: see slots.py
        self._lock = threading.Lock()

    # -- starting ---------------------------------------------------------------------------------
    def build_command(self, req: RunRequest, suite_files: dict[str, str]) -> list[str]:
        """The `bwtest run` arguments for a request (also shown in the UI so users learn the CLI)."""
        args = ["run"]
        selected = {t.split("::", 1)[0].lower() for t in req.tests}
        for suite in req.suites:
            if suite.lower() in selected:
                continue  # the suite is narrowed to single tests below
            args.append(suite)
        for test in req.tests:
            suite, _, test_id = test.partition("::")
            file = suite_files.get(suite.lower())
            if not file or not test_id:
                raise ConfigError(f"unknown test '{test}'")
            args.append(f"{file}::{test_id}")
        if req.profile:
            args += ["--profile", req.profile]
        if req.bw_home:
            args += ["--bw-home", req.bw_home]
        if req.marker:
            args += ["-m", req.marker]
        if req.keyword:
            args += ["-k", req.keyword]
        if req.workers and req.workers > 1:
            args += ["-n", str(int(req.workers))]
        for flag, on in (("--dry-run", req.dry_run), ("--update-gold", req.update_gold)):
            if on:
                args.append(flag)
        if req.keep_domain:
            args += ["--pytest=--bw-keep-domain"]
        for opt, value in (("--name", req.name), ("--tester", req.tester), ("--notes", req.notes),
                           ("--jira", req.jira)):
            if value:
                args += [opt, value]
        return args

    def start(self, req: RunRequest, suite_files: dict[str, str], settings=None) -> str:
        with self._lock:
            if settings is not None and not req.dry_run:  # same check as `bwtest run` - but tell the user now
                from ... import slots

                pending = [{"run": a.id, "suites": a.suites, "workers": a.workers}
                           for a in list(self._active.values()) if a.process.poll() is None]
                slots.check(settings.bw.domain_home, self.request_suite_files(req, suite_files),
                            int(req.workers or 0), settings.bw.admin_mode, pending)
            args = self.build_command(req, suite_files)
            run_id = time.strftime("%Y%m%d-%H%M%S")
            run_dir = self.results_dir / run_id
            while run_dir.exists():  # two clicks within one second
                time.sleep(1)
                run_id = time.strftime("%Y%m%d-%H%M%S")
                run_dir = self.results_dir / run_id
            run_dir.mkdir(parents=True)
            args += ["--run-dir", str(run_dir), "--config", str(self.config_dir), "--pytest=--color=no"]
            env = {**os.environ, "PYTHONUNBUFFERED": "1", "NO_COLOR": "1", "TERM": "dumb", "COLUMNS": "160",
                   "PYTHONIOENCODING": "utf-8"}
            env.pop("BWTEST_RUN_DIR", None)
            log = open(run_dir / CONSOLE, "w", encoding="utf-8", errors="replace")  # noqa: SIM115
            log.write(f"$ bwtest {subprocess.list2cmdline(args)}\n\n")
            log.flush()
            # own process group (Ctrl+C in the UI console does not kill the run) and no console window
            flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            process = subprocess.Popen([sys.executable, "-m", "bwtest.cli", *args], cwd=self.root, env=env,
                                       stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                       creationflags=flags, start_new_session=os.name != "nt")
            events.write_run_info(run_dir, {"pid": process.pid, "started_from": "ui",
                                            "ui_command": "bwtest " + subprocess.list2cmdline(args)})
            self._active[run_id] = ActiveRun(run_id, process, log, self.request_suite_files(req, suite_files),
                                             int(req.workers or 0))
            threading.Thread(target=self._reap, args=(self._active[run_id],), daemon=True).start()
            return run_id

    def request_suite_files(self, req: RunRequest, suite_files: dict[str, str]) -> list[str] | None:
        """Suite files a request runs; None = all suites (only a tag / keyword given)."""
        names = {s.lower() for s in req.suites} | {t.split("::", 1)[0].lower() for t in req.tests}
        if not names:
            return None
        return [str((self.root / suite_files[n]).resolve()) for n in sorted(names) if n in suite_files]

    def _reap(self, active: ActiveRun) -> None:
        code = active.process.wait()
        active.log.close()  # type: ignore[attr-defined]
        run_dir = self.results_dir / active.id
        events.write_run_info(run_dir, {"exit_code": code, "ended": time.strftime("%Y-%m-%d %H:%M:%S")})
        with self._lock:
            if self._active.get(active.id) is active:
                del self._active[active.id]

    def active_ids(self) -> list[str]:
        """Runs going right now, newest first (also runs started from a terminal or an earlier UI process)."""
        found = {i for i, a in list(self._active.items()) if a.process.poll() is None}
        for run_dir in self._recent_dirs(20):
            info = events.read_run_info(run_dir)
            if info.get("pid") and "exit_code" not in info and not (run_dir / "summary.json").exists() \
                    and pid_alive(int(info["pid"])):
                found.add(run_dir.name)
        return sorted(found, reverse=True)

    def active_id(self) -> str | None:
        """Newest run going (None = none)."""
        ids = self.active_ids()
        return ids[0] if ids else None

    # -- stopping ---------------------------------------------------------------------------------
    def request_stop(self, run_id: str) -> None:
        run_dir = self.run_dir(run_id)
        (run_dir / events.STOP_FILE).write_text(time.strftime("%Y-%m-%d %H:%M:%S"), encoding="utf-8")

    def kill(self, run_id: str) -> None:
        """Last resort: kill the run's process tree. AppNodes already started may survive (see Help)."""
        info = events.read_run_info(self.run_dir(run_id))
        pid = int(info.get("pid") or 0)
        if not pid or not pid_alive(pid):
            raise ConfigError("run is not running")
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, check=False, **NO_CONSOLE)
        else:
            import signal

            os.killpg(pid, signal.SIGTERM)
        events.write_run_info(self.run_dir(run_id), {"killed": True})

    # -- history ----------------------------------------------------------------------------------
    def run_dir(self, run_id: str) -> Path:
        if not run_id or any(c in run_id for c in "/\\:") or run_id.startswith("."):
            raise ConfigError(f"invalid run id '{run_id}'")
        path = self.results_dir / run_id
        if not path.is_dir():
            raise ConfigError(f"run '{run_id}' not found")
        return path

    def _recent_dirs(self, limit: int | None = None) -> list[Path]:
        if not self.results_dir.is_dir():
            return []
        dirs = sorted((p for p in self.results_dir.iterdir() if p.is_dir() and p.name[:1].isdigit()),
                      key=lambda p: p.name, reverse=True)
        return dirs[:limit] if limit else dirs

    def history(self, limit: int = 200) -> list[dict]:
        active = set(self.active_ids())
        return [self._summary(d, active) for d in self._recent_dirs(limit)]

    def delete(self, run_id: str) -> None:
        if run_id in self.active_ids():
            raise ConfigError("cannot delete a running run")
        shutil.rmtree(self.run_dir(run_id))

    def _summary(self, run_dir: Path, active: set[str]) -> dict:
        info = events.read_run_info(run_dir)
        summary = _read_json(run_dir / "summary.json")
        counts = {k: int(summary.get(k, 0)) for k in ("passed", "failed", "error", "skipped", "xfailed", "xpassed")}
        if not summary:
            counts = _counts_from_events(run_dir) or _counts_from_junit(run_dir)
        state = _state(run_dir, info, summary, run_dir.name in active)
        return {"id": run_dir.name, "state": state, "counts": counts, "name": info.get("name", ""),
                "tester": info.get("tester", ""), "profile": info.get("profile", ""), "build": info.get("build", ""),
                "targets": info.get("targets", []), "started": info.get("started") or _ts(run_dir.name),
                "ended": info.get("ended", ""), "dry_run": info.get("dry_run", False),
                "has_report": (run_dir / "report.html").is_file()}

    def detail(self, run_id: str) -> dict:
        run_dir = self.run_dir(run_id)
        data = self._summary(run_dir, set(self.active_ids()))
        info = events.read_run_info(run_dir)
        evs, _ = events.read_events(run_dir)
        tests: dict[str, dict] = {}
        suites: dict[str, dict] = {}
        environment: dict = {}
        bwadmin = {"calls": 0, "seconds": 0.0, "shell_calls": 0}
        setup: dict[str, float] = {}
        current = None
        for ev in evs:
            kind = ev.get("event")
            if kind == "collected":
                for t in ev.get("tests", []):
                    tests.setdefault(t["nodeid"], {**t, "outcome": "pending", "duration": None, "message": ""})
            elif kind == "environment":
                environment = {k: v for k, v in ev.items() if k not in ("event", "time")}
            elif kind == "suite":
                suites[ev["suite"]] = {"phase": ev.get("phase"), "message": ev.get("message", ""),
                                       "time": ev.get("time")}
                if ev.get("setup_s") is not None:
                    setup[ev["suite"]] = float(ev["setup_s"])
            elif kind == "bwadmin":
                for key in bwadmin:
                    bwadmin[key] += ev.get(key) or 0
            elif kind == "start":
                t = tests.setdefault(ev["nodeid"], _from_nodeid(ev["nodeid"]))
                t["outcome"] = "running"
                t["started"] = ev.get("time")
                current = ev["nodeid"]
            elif kind == "result":
                t = tests.setdefault(ev["nodeid"], _from_nodeid(ev["nodeid"]))
                if ev["outcome"] == "teardown_error":
                    t["teardown_error"] = ev.get("message", "")
                    continue
                t.update(outcome=ev["outcome"], duration=ev.get("duration"), message=ev.get("message", ""),
                         artifacts=_relative(ev.get("artifacts", ""), run_dir), phases=ev.get("phases") or {})
                if current == ev["nodeid"]:
                    current = None
        if not tests:  # runs from before the UI existed: fall back to junit.xml, then to the folders
            for t in _tests_from_junit(run_dir) or _tests_from_folders(run_dir):
                tests[t["nodeid"]] = t
        if data["state"] not in ("running", "stopping"):
            for t in tests.values():
                if t["outcome"] in ("pending", "running"):
                    t["outcome"] = "not_run"
        phases: dict[str, float] = {}
        for t in tests.values():
            for key, value in (t.get("phases") or {}).items():
                phases[key] = round(phases.get(key, 0.0) + float(value), 1)
        timing = {"suite_setup": round(sum(setup.values()), 1), "phases": phases,
                  "bwadmin": {**bwadmin, "seconds": round(bwadmin["seconds"], 1)} if bwadmin["calls"] else None,
                  "wall": _wall_seconds(info) or _event_span(evs)}
        from ...gold import changes as gold_changes

        open_gold = {(c.suite, c.test) for c in gold_changes(run_dir, include_accepted=False)}
        for t in tests.values():
            t["gold_change"] = (t.get("suite"), t.get("id")) in open_gold
        data.update(info=info, environment=environment, suites=suites, tests=list(tests.values()), timing=timing,
                    gold_changes=len(open_gold),
                    current=current if data["state"] in ("running", "stopping") else None,
                    files=[p.name for p in sorted(run_dir.iterdir()) if p.is_file()])
        return data

    def console(self, run_id: str, offset: int = 0, limit: int = 256_000) -> dict:
        path = self.run_dir(run_id) / CONSOLE
        if not path.is_file():
            return {"text": "", "offset": 0, "size": 0}
        size = path.stat().st_size
        if offset > size:
            offset = 0
        if size - offset > limit:  # first load of a huge log: show the tail
            offset = size - limit
        with open(path, "rb") as fh:
            fh.seek(offset)
            data = fh.read(limit)
        return {"text": data.decode("utf-8", errors="replace"), "offset": offset + len(data), "size": size}


# ------------------------------------------------------------------------------------------------
def _wall_seconds(info: dict) -> float | None:
    from datetime import datetime

    try:
        start = datetime.strptime(str(info["started"])[:19], "%Y-%m-%d %H:%M:%S")
        end = datetime.strptime(str(info["ended"])[:19], "%Y-%m-%d %H:%M:%S")
    except (KeyError, ValueError):
        return None
    return (end - start).total_seconds()


def _event_span(evs: list[dict]) -> float | None:
    times = [ev["time"] for ev in evs if isinstance(ev.get("time"), (int, float))]
    return round(max(times) - min(times), 1) if len(times) > 1 else None


def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _ts(run_id: str) -> str:
    try:
        return time.strftime("%Y-%m-%d %H:%M:%S", time.strptime(run_id[:15], "%Y%m%d-%H%M%S"))
    except ValueError:
        return ""


def _state(run_dir: Path, info: dict, summary: dict, is_active: bool) -> str:
    stopping = (run_dir / events.STOP_FILE).exists()
    if is_active:
        return "stopping" if stopping else "running"
    if info.get("killed"):
        return "killed"
    if info.get("refused"):  # could not start: e.g. its suite was running in another run (slots.py)
        return "error"
    if not summary:
        return "aborted"
    code = int(summary.get("exit", 0))
    if stopping:
        return "stopped"
    return {0: "passed", 1: "failed", 5: "empty"}.get(code, "error")


def _counts_from_events(run_dir: Path) -> dict:
    evs, _ = events.read_events(run_dir)
    counts: dict[str, int] = {}
    for ev in evs:
        if ev.get("event") == "result" and ev.get("outcome") != "teardown_error":
            counts[ev["outcome"]] = counts.get(ev["outcome"], 0) + 1
    return counts


def _counts_from_junit(run_dir: Path) -> dict:
    counts: dict[str, int] = {}
    for t in _tests_from_junit(run_dir):
        counts[t["outcome"]] = counts.get(t["outcome"], 0) + 1
    return counts


def _tests_from_junit(run_dir: Path) -> list[dict]:
    path = run_dir / "junit.xml"
    if not path.is_file():
        return []
    try:
        root = ET.parse(path).getroot()
    except ET.ParseError:
        return []
    tests = []
    for case in root.iter("testcase"):
        outcome, message = "passed", ""
        for tag in ("failure", "error", "skipped"):
            node = case.find(tag)
            if node is not None:
                outcome = {"failure": "failed", "error": "error", "skipped": "skipped"}[tag]
                message = (node.get("message") or "") + "\n" + (node.text or "")
                if tag == "skipped" and "xfail" in (node.get("type") or ""):
                    outcome = "xfailed"
                break
        classname = case.get("classname", "")
        suite = classname.rsplit(".", 1)[-1].removesuffix(".suite") if classname else ""
        name = case.get("name", "")
        tests.append({"nodeid": f"{classname}::{name}", "suite": suite, "id": name, "description": "",
                      "outcome": outcome, "duration": round(float(case.get("time") or 0), 1),
                      "message": message.strip()[-6000:], "artifacts": _guess_artifacts(run_dir, suite, name)})
    return tests


def _tests_from_folders(run_dir: Path) -> list[dict]:
    """results/<run>/<suite>/<test>/ - outcome unknown, but the artifacts can still be browsed."""
    tests = []
    for suite_dir in sorted(p for p in run_dir.iterdir() if p.is_dir() and not p.name.startswith("worker-")):
        for case in sorted(p for p in suite_dir.iterdir() if p.is_dir()):
            tests.append({"nodeid": f"{suite_dir.name}::{case.name}", "suite": suite_dir.name, "id": case.name,
                          "description": "", "outcome": "unknown", "duration": None, "message": "",
                          "artifacts": case.relative_to(run_dir).as_posix()})
    return tests


def _guess_artifacts(run_dir: Path, suite: str, test_id: str) -> str:
    for candidate in run_dir.glob(f"*/{test_id}"):
        if candidate.is_dir():
            return candidate.relative_to(run_dir).as_posix()
    return ""


def _from_nodeid(nodeid: str) -> dict:
    path, _, name = nodeid.partition("::")
    suite = Path(path).name.removesuffix(".suite.yaml").removesuffix(".py")
    return {"nodeid": nodeid, "suite": suite, "id": name or nodeid, "description": "", "outcome": "pending",
            "duration": None, "message": ""}


def _relative(path: str, run_dir: Path) -> str:
    if not path:
        return ""
    try:
        return Path(path).resolve().relative_to(run_dir.resolve()).as_posix()
    except ValueError:
        return ""
