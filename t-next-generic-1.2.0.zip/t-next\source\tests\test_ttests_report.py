"""t-tests .sql report: same statements as t-tests 4.0 wrote (reference: reports/i86-winnt50/bw-6120-V188-HF05/
t_func_engine_report_2026-11-09_12.35.55.sql), so it can be uploaded to the QA results DB unchanged."""

from datetime import datetime

from bwtest.config import TtestsReportSettings
from bwtest.ttests_report import generate


def _ts(text: str) -> float:
    return datetime.strptime(text, "%Y-%m-%d %H:%M:%S").timestamp()


def test_sql_has_the_t_tests_format(tmp_path):
    detail = {
        "info": {"started": "2026-11-09 12:37:08", "ended": "2026-11-09 21:54:15", "tester": "Umesh Patil"},
        "environment": {"bw_version": "6.12.0 HF5", "bw_build": "V188"},
        "tests": [
            {"nodeid": "suites/engine/x/http_Attachments_comp.suite.yaml::bw.3638", "suite": "http_Attachments_comp",
             "id": "bw.3638", "description": "POST -OS: String, it's both ways", "outcome": "failed",
             "started": _ts("2026-11-09 12:37:34"), "duration": 30, "artifacts": "http_Attachments_comp/bw.3638"},
            {"nodeid": "suites/engine/x/http_Attachments_comp.suite.yaml::bw.3647", "suite": "http_Attachments_comp",
             "id": "bw.3647", "description": "ok", "outcome": "passed",
             "started": _ts("2026-11-09 12:38:10"), "duration": 20, "artifacts": "http_Attachments_comp/bw.3647"},
            {"nodeid": "suites/engine/x/http_Attachments_comp.suite.yaml::bw.3648", "suite": "http_Attachments_comp",
             "id": "bw.3648", "description": "known", "outcome": "xfailed", "message": "BUG-12345",
             "started": _ts("2026-11-09 12:39:00"), "duration": 10, "artifacts": "http_Attachments_comp/bw.3648"},
            {"nodeid": "suites/engine/x/http_Attachments_comp.suite.yaml::bw.3649", "suite": "http_Attachments_comp",
             "id": "bw.3649", "description": "disabled", "outcome": "skipped"},
            {"nodeid": "suites/migration/m/mig.suite.yaml::bw.1", "suite": "mig", "id": "bw.1", "description": "m",
             "outcome": "error", "started": _ts("2026-11-09 13:00:00"), "duration": 5, "artifacts": "mig/bw.1"},
        ],
    }
    files = generate(tmp_path, detail, TtestsReportSettings(hostname="MICPVDIPD2050"), tmp_path)
    names = sorted(p.name for p in files)
    assert names == ["t_func_engine_report_2026-11-09_12.37.08.sql", "t_func_migration_report_2026-11-09_12.37.08.sql"]

    engine = (tmp_path / "ttests-report" / names[0]).read_bytes()
    assert b"\r" not in engine  # LF like the t-tests file
    lines = engine.decode().split("\n")
    rid = "MICPVDIPD2050-2026/11/09-12:37:08"
    assert lines[0] == " "
    assert lines[1] == (
        "insert into tsi_tests_run(RUN_ID, HOSTNAME, PLATFORM, USER_NAME, START_TIME, END_TIME, PRODUCT_NAME, "
        "PRODUCT_VERSION, PRODUCT_BUILD, CATEGORY, STATUS, NUM_TC_STARTED, NUM_TC_PASSED, NUM_TC_FAILED, "
        "NUM_TC_MANUAL, NUM_TC_UNCERTAIN, LOG_URL, NOTE, T_TESTS_VERSION) "
        f"values('{rid}', 'MICPVDIPD2050', 'i86-winnt50', "
        "'superuser', to_date('2026/11/09-12:37:08', 'yyyy/mm/dd-hh24:mi:ss'), null, 'bw', '6.12', "
        "'BW 6.12.0 build V188 HF05', 'engine', null, 0, 0, 0, 0, 0, 'i86-winnt50/bw-6120-V188-HF05', "
        "null, '4.0' );")
    assert lines[2] == (
        "insert into tsi_tests_set(RUN_ID, SEQ_NO, SET_NAME, OWNER, START_TIME, END_TIME, NUM_TC_STARTED, "
        "NUM_TC_PASSED, NUM_TC_FAILED, NUM_TC_MANUAL, NUM_TC_UNCERTAIN, LOG_URL, NOTE) values"
        f"('{rid}', null, 'http_Attachments_comp', NULL, "
        "to_date('2026/11/09-12:37:34','yyyy/mm/dd-hh24:mi:ss'), null, 0, 0, 0, 0, 0, null, null );")
    assert lines[3] == ("insert into tsi_tests_case(RUN_ID, SET_NAME, CASE_ID, VARIANT_SEQ, TEST_RESULT, "
                        "IS_MANUAL, NOTE) "
                        f"values('{rid}', 'http_Attachments_comp', 'bw.3638', '1', 'FAILED', 'N', NULL );")
    assert lines[4] == ("delete from tsi_tests_tc_desc where product_name='bw' and category='func_engine' and "
                        "set_name='http_Attachments_comp' and case_id='bw.3638' and variant_seq=1 ;")
    assert lines[5] == ("insert into tsi_tests_tc_desc(PRODUCT_NAME, CATEGORY, SET_NAME, CASE_ID, VARIANT_SEQ, "
                        "CASE_DESC) "
                        "values( 'bw', 'func_engine', 'http_Attachments_comp', 'bw.3638',  1, "
                        "'POST -OS: String, it''s both ways' );")  # quote doubled
    assert "'bw.3648', '1', 'FAILED', 'N', 'known to fail: BUG-12345' );" in lines[9]
    assert "bw.3649" not in engine.decode()  # skipped tests are not reported
    assert lines[12] == (
        "update tsi_tests_set set seq_no=0, owner='Umesh Patil', end_time=to_date('2026/11/09-12:39:10',"
        "'yyyy/mm/dd-hh24:mi:ss'), num_tc_passed=1, num_tc_failed=2, num_tc_error=0, "
        f"log_url='http_Attachments_comp' where run_id = '{rid}' and set_name='http_Attachments_comp' ;")
    assert lines[13] == (
        "update tsi_tests_run set end_time=to_date('2026/11/09-21:54:15','yyyy/mm/dd-hh24:mi:ss'), status='COMPLETED', "
        f"NUM_TC_PASSED=1, NUM_TC_FAILED=2, num_tc_error=0 where run_id = '{rid}' ;")
    assert lines[14] == ""

    migration = (tmp_path / "ttests-report" / names[1]).read_text()
    assert "'migration', null" in migration and "category='func_migration'" in migration
    assert "'bw.1', '1', 'ERROR', 'N', NULL );" in migration
