# T-Next code map

Folder structure and the job of every source file, for developers. Generated from the files' own header
comments, so it matches the code. Regenerate after adding files: `python source/tools/make_code_map.py`.
How it fits together:
[ARCHITECTURE.md](ARCHITECTURE.md) · rules for changes: [CONTRIBUTING.md](CONTRIBUTING.md).

| | Files | Lines |
|---|---|---|
| Python framework (`source/bwtest`) | 39 | 7,424 |
| UI JavaScript (`source/bwtest/ui/web`) | 19 | 2,322 |
| Self-tests (`source/tests`) | 16 | 1,856 |
| Suites (`suites`, YAML) | 26 | - |

## Open it as a developer

* **VS Code** (recommended): *File → Open Folder → `C:\D\bw6-autotest\source`* - only the code.
  Settings come with it (`source/.vscode/`): interpreter `..\.venv`, self-tests in the Testing panel,
  debug configurations (desktop app, dry run, run a suite, doctor) under *Run and Debug*, CI checks under
  *Terminal → Run Task*, and recommended extensions (Python, Ruff, YAML).
* **Eclipse**: only with the PyDev plugin (Python support). Do not add PyDev to Business Studio - use a
  separate Eclipse IDE, or VS Code.

## Where to start reading

1. `source/bwtest/cli.py` - the commands (`bwtest run`, `desktop`, `setup` …)
2. `source/bwtest/pytest_plugin.py` - suite YAML → pytest tests; suite setup/teardown
3. `source/bwtest/executor.py` - one test: prepare → deploy → action → cleanup → verify
4. `source/bwtest/runtime.py` + `bwcli.py` - domain / AppSpace / AppNode / app via bwadmin
5. `source/bwtest/ui/` - desktop/web app: `server.py` (REST API) + `web/` (screens)

## Folder tree

```
bw6-autotest/
├─ .github/
│  └─ workflows/
│     └─ ci.yml
├─ config/
│  ├─ profiles/
│  │  ├─ 6.10.0.yaml
│  │  ├─ 6.11.0.yaml
│  │  ├─ 6.12.0.yaml
│  │  ├─ 6.12.1.yaml
│  │  └─ 6.13.0.yaml
│  ├─ .env.example
│  ├─ bwtest.yaml
│  ├─ databases.yaml
│  ├─ drivers.yaml
│  ├─ local.yaml.example
│  └─ pytest.ini
├─ docs/
│  ├─ ARCHITECTURE.md
│  ├─ bwtest_overview.pptx
│  ├─ CHANGELOG.md
│  ├─ CODE_MAP.md
│  ├─ CONTRIBUTING.md
│  ├─ MIGRATING_FROM_TTESTS.md
│  ├─ OVERVIEW.md
│  ├─ README.md
│  ├─ UI.md
│  ├─ UI_REFERENCE.md
│  ├─ USER_GUIDE.md
│  └─ WRITING_TESTS.md
├─ setup/
│  ├─ allow-firewall.bat  — bwtest - allow the test AppNodes in Windows Firewall ONCE, so the "Java Launcher"
│  ├─ backup-bwtest.bat  — bwtest - full backup of the framework into ONE zip file. Double-click it any time.
│  ├─ firewall_paths.py  — What allow-firewall.bat allows. Values come from bwtest itself (config + suites), so they match what runs crea…
│  ├─ make-share-zip.bat  — bwtest - make a clean zip to give to a colleague.
│  ├─ README.txt
│  └─ setup-bwtest.bat  — bwtest - setup on a new machine. Double-click it (or run it again to repair / update).
├─ source/
│  ├─ .vscode/
│  │  ├─ extensions.json
│  │  ├─ launch.json
│  │  ├─ settings.json
│  │  └─ tasks.json
│  ├─ bwtest/
│  │  ├─ legacy/
│  │  │  ├─ __init__.py
│  │  │  ├─ bridge.py  — Legacy bridge: run old t-tests bash scripts (t_setup.sh / t_action.sh / t_verify.sh) unchanged.
│  │  │  ├─ importer.py  — Import t-tests 4.0 suites (.testset + t_setup.sh + t_action.sh + t_verify.sh + .cfg) into *.suite.yaml.
│  │  │  ├─ sync.py  — Keep suites/ in step with a user's own t-tests test folder (<assets_root>/func).
│  │  │  ├─ t_tests_api.sh  — bwtest legacy bridge - minimal stand-in for t-tests 4.0 scripts/t_util.sh + t_tests_api.sh.
│  │  │  ├─ t_util.sh  — bwtest legacy bridge - minimal stand-in for t-tests 4.0 scripts/t_util.sh + t_tests_api.sh.
│  │  │  └─ xmldiff.py  — `t-xmldiff OUTPUT GOLD` for legacy scripts - python -m bwtest.legacy.xmldiff a.xml b.xml
│  │  ├─ ui/
│  │  │  ├─ routes/
│  │  │  │  ├─ __init__.py
│  │  │  │  ├─ runs.py  — Start runs, follow them live, stop them, browse their results.
│  │  │  │  ├─ suites.py  — Browse and edit suites, add suites and test cases, saved selections.
│  │  │  │  └─ system.py  — Dashboard, profiles/builds, preferences, doctor, effective configuration.
│  │  │  ├─ services/
│  │  │  │  ├─ __init__.py
│  │  │  │  ├─ builds.py  — Find BW installs ("builds") for a profile - replaces typing the build on the old t-tests main page.
│  │  │  │  ├─ catalog.py  — Suite catalog for the UI: every *.suite.yaml, parsed once and re-parsed only when a file changes.
│  │  │  │  ├─ preferences.py  — Preferences page - the old t-tests 'user profile' + 'Preferences' dialog, stored in config/local.yaml.
│  │  │  │  ├─ runs.py  — Start, follow and stop runs; read run history from results/<timestamp>/.
│  │  │  │  └─ selections.py  — Saved test selections - the successor of t-tests `.testcmd` files (File > New TestCmd).
│  │  │  ├─ web/
│  │  │  │  ├─ css/
│  │  │  │  │  └─ app.css  — bwtest UI - one stylesheet. Colours and spacing are tokens at the top: change them here only.
│  │  │  │  ├─ js/
│  │  │  │  │  ├─ components/
│  │  │  │  │  │  ├─ importDialog.js  — "Sync with test folder": take what is new in the user's own t-tests test folder (<assets_root>/func):
│  │  │  │  │  │  └─ ui.js  — Reusable building blocks. Pages only combine these - change the look here once, it changes everywhere.
│  │  │  │  │  ├─ core/
│  │  │  │  │  │  ├─ api.js  — All calls to the Python backend go through here. Errors from the server ({detail: "..."}) become
│  │  │  │  │  │  ├─ dom.js  — Tiny DOM builder. Every page is built with h(), so text is always escaped (no innerHTML with data).
│  │  │  │  │  │  ├─ format.js  — Formatting helpers shared by all pages.
│  │  │  │  │  │  └─ router.js  — Hash router:  #/runs/20261117-101500?tab=console  ->  page module + params {id} + query {tab}
│  │  │  │  │  ├─ pages/
│  │  │  │  │  │  ├─ dashboard.js  — Dashboard: where am I, is the setup OK, what ran recently, what can I do next.
│  │  │  │  │  │  ├─ doctor.js  — Doctor: check that a profile/build is ready to run, and show the effective configuration.
│  │  │  │  │  │  ├─ help.js  — Help & guide for new users: the 5 steps, a glossary, old t-tests -> new mapping, FAQ.
│  │  │  │  │  │  ├─ newRun.js  — New run wizard - the old t-tests main page as 4 guided steps:
│  │  │  │  │  │  ├─ newSuite.js  — Create a suite file from a form (same template as `bwtest new-suite`).
│  │  │  │  │  │  ├─ notFound.js
│  │  │  │  │  │  ├─ preferences.js  — Preferences - old t-tests user profile + Preferences dialog. Saved to config/local.yaml.
│  │  │  │  │  │  ├─ runDetail.js  — One run: live progress while it runs, then results. Tabs: Tests · Console · Files · Details.
│  │  │  │  │  │  ├─ runs.js  — Run history: every folder in results/ (runs from the UI, the command line and Jenkins alike).
│  │  │  │  │  │  ├─ suiteDetail.js  — One suite: overview, its test cases, the YAML file (edit + validate), and "Add test case".
│  │  │  │  │  │  └─ suites.js  — All suites, grouped by category, with search and filters.
│  │  │  │  │  ├─ shell/
│  │  │  │  │  │  └─ desktop.js  — Desktop layout (bwtest desktop / start-bwtest.bat) - modelled on the t-tests 4.0 window:
│  │  │  │  │  └─ app.js  — Application shell: sidebar navigation, top bar with the active run, and the route table.
│  │  │  │  └─ index.html
│  │  │  ├─ __init__.py  — Web UI for bwtest:  `bwtest ui`  ->  http://127.0.0.1:8765
│  │  │  ├─ context.py  — State shared by all API routes of one UI server.
│  │  │  └─ server.py  — FastAPI application: JSON API under /api, the single-page app under /.
│  │  ├─ __init__.py  — bwtest - pytest-based regression framework for BusinessWorks 6.
│  │  ├─ actions.py  — Action steps - what happens after the app is deployed and before verification.
│  │  ├─ bwcli.py  — Thin wrapper around the BW command-line tools.
│  │  ├─ cli.py  — `bwtest` command line.
│  │  ├─ config.py  — Framework settings.
│  │  ├─ desktop.py  — bwtest desktop application - a native Windows window, like the old t-tests 4.0 GUI.
│  │  ├─ doctor.py  — Environment checks - shared by `bwtest doctor` and the web UI's Settings page.
│  │  ├─ errors.py  — Framework exceptions. Each one maps to a clear failure category in reports.
│  │  ├─ events.py  — Run metadata and live progress events, shared by the pytest plugin, the CLI and the web UI.
│  │  ├─ executor.py  — Runs ONE test case:  prepare -> (migrate) -> deploy -> action -> verify -> undeploy.
│  │  ├─ gold.py  — Gold changes: accept the new output of a failed test as its gold file - without running it again.
│  │  ├─ models.py  — Suite and test-case definitions (`*.suite.yaml`).
│  │  ├─ pytest_plugin.py  — pytest integration.
│  │  ├─ runtime.py  — BW runtime lifecycle: Domain -> AppSpace -> AppNode -> Application.
│  │  ├─ scaffold.py  — Create suites and test cases - used by `bwtest new-suite` / `bwtest new-test` and by the web UI.
│  │  ├─ setup_wizard.py  — `bwtest setup` - asks for the machine settings once and writes config/local.yaml.
│  │  ├─ slots.py  — Run slots: several bwtest runs at the same time on one PC (t-tests: one instance ID per job).
│  │  ├─ substvar.py  — Module-property (substvar) handling.
│  │  ├─ templating.py  — `${name}` placeholder rendering, shared by config, suites, actions and verifiers.
│  │  ├─ ttests_report.py  — Old t-tests 4.0 .sql report for a finished bwtest run - for uploading the results to the QA results DB.
│  │  └─ verify.py  — Verifiers - decide PASS / FAIL.
│  ├─ ci/
│  │  └─ Jenkinsfile
│  ├─ docker/  (1 files)
│  ├─ tests/
│  │  ├─ data/  (0 files)
│  │  ├─ fake_bw/
│  │  │  └─ bwadmin.py  — Fake bwadmin for the framework's self-tests (no BusinessWorks needed).
│  │  ├─ __init__.py
│  │  ├─ conftest.py  — Shared helpers for the framework self-tests.
│  │  ├─ desktop_check.py  — Open the real desktop window (WebView2), visit every page, report what rendered, close it again.
│  │  ├─ js_syntax_check.py  — Syntax-check every UI JavaScript module with V8 (pip install mini-racer). No Node.js needed.
│  │  ├─ test_admin_shell.py  — The shared bwadmin shell (bw.admin_shell): one JVM for all bwadmin commands instead of one JVM per command.
│  │  ├─ test_e2e_fake_bw.py  — End-to-end: pytest -> suite.yaml -> domain/appspace/appnode -> deploy -> action -> verify, using the
│  │  ├─ test_gold.py  — Gold changes: a failed gold comparison keeps the new output, and it can be accepted as gold later
│  │  ├─ test_importer.py  — Importer: legacy .testset + bash scripts -> suite.yaml.
│  │  ├─ test_no_console.py  — Regression: runs started from the desktop app (pythonw, no console) failed on the first bwadmin call with
│  │  ├─ test_slots.py  — Several runs at the same time (slots.py): own domains + ports per run, same suite never twice at once.
│  │  ├─ test_ttests_report.py  — t-tests .sql report: same statements as t-tests 4.0 wrote (reference: reports/i86-winnt50/bw-6120-V188-HF05/
│  │  ├─ test_ui_api.py  — Web UI backend: API of every page, plus a complete run started from the UI with the fake bwadmin.
│  │  ├─ test_units.py  — Unit tests: templating, config, substvar, verifiers, gold resolution, version parsing.
│  │  ├─ test_verify_import.py  — Regressions found with real bw-bat runs on BW 6.12.0 HF5 (2026-11-17):
│  │  └─ ui_smoke_v8.py  — Render every UI page in V8 (pip install mini-racer) against real API data - no browser, no Node.js.
│  ├─ tools/
│  │  └─ make_code_map.py  — Generate docs/CODE_MAP.md: folder tree + one line per source file from its own docstring / header comment.
│  └─ pyproject.toml
├─ suites/  (29 files)
├─ .gitignore
└─ start-bwtest.bat  — bwtest desktop application - the successor of t-tests\4.0\bin\t-tests.bat. Double-click it.
```
