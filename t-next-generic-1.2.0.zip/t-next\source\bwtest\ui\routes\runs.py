"""Start runs, follow them live, stop them, browse their results."""

from __future__ import annotations

from dataclasses import fields

from fastapi import APIRouter, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from ... import events
from ...errors import ConfigError
from ..services.runs import RunRequest

router = APIRouter(prefix="/api/runs", tags=["runs"])

TEXT_LIMIT = 2_000_000
TEXT_SUFFIXES = (".log", ".txt", ".substvar", ".xml", ".json", ".ini", ".cfg", ".sql")  # shown as text in the browser


def _ctx(request: Request):
    return request.app.state.ctx


class RunBody(BaseModel):
    profile: str = ""
    bw_home: str = ""
    suites: list[str] = Field(default_factory=list)
    tests: list[str] = Field(default_factory=list)
    marker: str = ""
    keyword: str = ""
    workers: int = 0
    dry_run: bool = False
    update_gold: bool = False
    keep_domain: bool = False
    name: str = ""
    tester: str = ""
    notes: str = ""
    jira: str = ""

    def to_request(self) -> RunRequest:
        return RunRequest(**{f.name: getattr(self, f.name) for f in fields(RunRequest)})


@router.get("")
def history(request: Request, limit: int = 200) -> dict:
    ctx = _ctx(request)
    active = ctx.runs.active_ids()
    return {"active": active[0] if active else None, "active_runs": active, "runs": ctx.runs.history(limit)}


@router.post("/preview")
def preview(body: RunBody, request: Request) -> dict:
    """The exact command line the run will use - shown in the wizard so people learn the CLI."""
    ctx = _ctx(request)
    args = ctx.runs.build_command(body.to_request(), ctx.suite_files())
    import subprocess

    return {"command": "bwtest " + subprocess.list2cmdline(args)}


@router.post("")
def start(body: RunBody, request: Request) -> dict:
    ctx = _ctx(request)
    req = body.to_request()
    if not (req.suites or req.tests or req.marker or req.keyword):
        raise ConfigError("select at least one suite or test (or a tag / keyword)")
    return {"id": ctx.runs.start(req, ctx.suite_files(), ctx.settings())}


@router.get("/{run_id}")
def detail(run_id: str, request: Request) -> dict:
    return _ctx(request).runs.detail(run_id)


@router.get("/{run_id}/console")
def console(run_id: str, request: Request, offset: int = 0) -> dict:
    return _ctx(request).runs.console(run_id, offset)


@router.post("/{run_id}/stop")
def stop(run_id: str, request: Request) -> dict:
    _ctx(request).runs.request_stop(run_id)
    return {"stopping": run_id}


@router.post("/{run_id}/kill")
def kill(run_id: str, request: Request) -> dict:
    _ctx(request).runs.kill(run_id)
    return {"killed": run_id}


class RerunBody(BaseModel):
    failed_only: bool = True


@router.post("/{run_id}/rerun")
def rerun(run_id: str, body: RerunBody, request: Request) -> dict:
    ctx = _ctx(request)
    run_dir = ctx.runs.run_dir(run_id)
    info = events.read_run_info(run_dir)
    data = ctx.runs.detail(run_id)
    req = RunRequest(profile=info.get("profile", ""), bw_home=info.get("bw_home", ""),
                     tester=info.get("tester", ""), jira=info.get("jira", ""), notes=info.get("notes", ""),
                     name=f"re-run of {run_id}" + (" (failed only)" if body.failed_only else ""),
                     workers=int(info.get("workers") or 0))
    if body.failed_only:
        bad = [t for t in data["tests"] if t["outcome"] in ("failed", "error")]
        if not bad:
            raise ConfigError("no failed tests in this run")
        req.tests = [f"{t['suite']}::{t['id']}" for t in bad]
    else:
        targets = [t for t in info.get("targets", []) if t != "all"]
        req.marker, req.keyword = info.get("marker", ""), info.get("keyword", "")
        names = set(ctx.suite_files())
        req.suites = [t for t in targets if t.lower() in names]
        req.tests = [_test_target(t) for t in targets if "::" in t]
        if not (req.suites or req.tests or req.marker or req.keyword):
            req.suites = sorted({t["suite"] for t in data["tests"]})
    return {"id": ctx.runs.start(req, ctx.suite_files(), ctx.settings())}


def _test_target(target: str) -> str:
    """suites/engine/x/x.suite.yaml::bw.1 -> x::bw.1 (format of RunRequest.tests)"""
    path, _, test_id = target.partition("::")
    return f"{path.rsplit('/', 1)[-1].removesuffix('.suite.yaml')}::{test_id}"


@router.post("/{run_id}/ttests-report")
def ttests_report(run_id: str, request: Request) -> dict:
    """Old t-tests .sql report (t_func_<category>_report_<time>.sql) for uploading to the QA results DB."""
    from ...ttests_report import OUT_DIR, generate

    ctx = _ctx(request)
    detail = ctx.runs.detail(run_id)
    if detail["state"] in ("running", "stopping"):
        raise ConfigError("the run is still going - create the report when it has finished")
    run_dir = ctx.runs.run_dir(run_id)
    written = generate(run_dir, detail, ctx.settings().ttests_report, ctx.root)
    if not written:
        raise ConfigError("no executed tests in this run (skipped / not run tests are not reported)")
    rel = [p.relative_to(run_dir).as_posix() for p in written]
    return {"folder": OUT_DIR, "path": str(run_dir / OUT_DIR), "sql": rel}


class AcceptGoldBody(BaseModel):
    keys: list[str] = Field(default_factory=list)


@router.get("/{run_id}/gold-changes")
def gold_changes(run_id: str, request: Request) -> dict:
    """Failed gold comparisons of a run whose new output can be accepted as the gold file (see gold.py)."""
    from ...gold import changes, diff_text

    run_dir = _ctx(request).runs.run_dir(run_id)
    return {"changes": [{**c.to_dict(), "diff_text": diff_text(run_dir, c)} for c in changes(run_dir)]}


@router.post("/{run_id}/gold-changes/accept")
def accept_gold(run_id: str, body: AcceptGoldBody, request: Request) -> dict:
    from ...gold import accept

    ctx = _ctx(request)
    if ctx.runs.detail(run_id)["state"] in ("running", "stopping"):
        raise ConfigError("the run is still going - accept gold changes when it has finished")
    run_dir = ctx.runs.run_dir(run_id)
    return {"accepted": [accept(run_dir, key).to_dict() for key in body.keys]}


@router.delete("/{run_id}")
def delete(run_id: str, request: Request) -> dict:
    _ctx(request).runs.delete(run_id)
    return {"deleted": run_id}


def _safe_path(request: Request, run_id: str, rel: str):
    run_dir = _ctx(request).runs.run_dir(run_id).resolve()
    target = (run_dir / rel).resolve() if rel else run_dir
    if target != run_dir and run_dir not in target.parents:
        raise ConfigError("path outside the run folder")
    if not target.exists():
        raise ConfigError(f"'{rel}' not found")
    return run_dir, target


@router.get("/{run_id}/files")
def files(run_id: str, request: Request, path: str = "") -> dict:
    run_dir, target = _safe_path(request, run_id, path)
    if target.is_dir():
        items = sorted(target.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
        return {"type": "dir", "path": target.relative_to(run_dir).as_posix() if target != run_dir else "",
                "items": [{"name": p.name, "dir": p.is_dir(), "size": p.stat().st_size if p.is_file() else None}
                          for p in items]}
    size = target.stat().st_size
    with open(target, "rb") as fh:
        data = fh.read(TEXT_LIMIT)
    binary = b"\x00" in data[:8000]
    return {"type": "file", "path": target.relative_to(run_dir).as_posix(), "size": size, "binary": binary,
            "truncated": size > TEXT_LIMIT, "text": "" if binary else data.decode("utf-8", errors="replace")}


@router.get("/{run_id}/raw/{path:path}")
def raw(run_id: str, path: str, request: Request):
    _, target = _safe_path(request, run_id, path)
    if target.is_dir():
        raise ConfigError("is a folder")
    media = "text/html" if target.suffix.lower() in (".html", ".htm") else None
    if media is None and target.suffix.lower() in TEXT_SUFFIXES:
        media = "text/plain; charset=utf-8"
    return FileResponse(target, media_type=media)
