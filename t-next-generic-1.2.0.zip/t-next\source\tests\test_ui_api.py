"""Web UI backend: API of every page, plus a complete run started from the UI with the fake bwadmin."""

import time
from pathlib import Path

import pytest

pytest.importorskip("fastapi")
from fastapi.testclient import TestClient  # noqa: E402

from bwtest.ui.server import create_app  # noqa: E402
from tests.conftest import make_case  # noqa: E402

SUITE = """
suite: demo
assets_dir: ${assets_root}/demo
tests:
  - id: bw.1
    description: passes
  - id: bw.2
    description: fails - output differs from gold
  - id: bw.3
    known_to_fail: BUG-99999
"""


@pytest.fixture
def client(fake_project: Path) -> TestClient:
    assets = fake_project / "assets" / "demo"
    assets.mkdir(parents=True)
    make_case(assets, "bw.1", "same\n", "same\n")
    make_case(assets, "bw.2", "actual\n", "expected\n")
    make_case(assets, "bw.3", "bug\n", "fixed\n")
    (fake_project / "suites" / "engine" / "demo").mkdir(parents=True)
    (fake_project / "suites" / "engine" / "demo" / "demo.suite.yaml").write_text(SUITE)
    (fake_project / "config" / "profiles").mkdir()
    (fake_project / "config" / "profiles" / "6.99.1.yaml").write_text("{}\n")
    return TestClient(create_app(fake_project, fake_project / "config"))


def test_suites_and_overview(client):
    suites = client.get("/api/suites").json()
    assert [(s["name"], s["category"], s["tests"], s["known_to_fail"]) for s in suites] == [("demo", "engine", 3, 1)]
    detail = client.get("/api/suites/demo").json()
    assert [t["id"] for t in detail["test_list"]] == ["bw.1", "bw.2", "bw.3"]
    overview = client.get("/api/overview").json()
    assert overview["counts"]["tests"] == 3
    assert client.get("/api/suites/nope").status_code == 400


def test_edit_yaml_is_validated_before_saving(client, fake_project):
    file = fake_project / "suites" / "engine" / "demo" / "demo.suite.yaml"
    bad = SUITE.replace("description: passes", "descripton: typo")
    result = client.post("/api/suites/demo/validate", json={"text": bad}).json()
    assert not result["ok"] and "descripton" in result["error"]
    assert client.put("/api/suites/demo/source", json={"text": bad}).status_code == 400
    assert file.read_text() == SUITE  # unchanged
    good = SUITE + "  - bw.4\n"
    assert client.put("/api/suites/demo/source", json={"text": good}).json()["tests"] == 4
    assert not list(file.parent.glob("~validate*"))  # no probe files left behind


def test_new_suite_and_new_test(client, fake_project, tmp_path):
    r = client.post("/api/suites", json={"category": "engine", "name": "rest_json", "description": "REST: JSON",
                                         "tags": ["rest"]})
    assert r.status_code == 200, r.text
    assert client.post("/api/suites", json={"name": "rest_json"}).status_code == 400  # exists
    assert client.post("/api/suites", json={"name": "../evil"}).status_code == 400
    ear = tmp_path / "x.ear"
    ear.write_bytes(b"PK")
    r = client.post("/api/suites/rest_json/tests", json={"test_id": "bw.9001", "ear": str(ear), "tags": ["smoke"],
                                                         "known_to_fail": "BUG-1"})
    assert r.status_code == 200, r.text
    assert Path(r.json()["case_dir"], "bw_9001.application.ear").is_file()
    tests = client.get("/api/suites/rest_json").json()["test_list"]
    assert tests[0]["id"] == "bw.9001" and tests[0]["known_to_fail"] == "BUG-1" and tests[0]["tags"] == ["smoke"]
    assert client.post("/api/suites/rest_json/tests", json={"test_id": "bw.9001"}).status_code == 400  # duplicate


def test_preferences_and_selections(client, fake_project):
    prefs = client.get("/api/preferences").json()
    assert any(f["key"] == "paths.assets_root" for f in prefs["fields"])
    r = client.put("/api/preferences", json={"values": {"ui.default_tester": "qa1", "timeouts.output_file": "7"}})
    assert r.status_code == 200, r.text
    local = (fake_project / "config" / "local.yaml").read_text()
    assert "default_tester: qa1" in local and "output_file: 7" in local
    assert client.put("/api/preferences", json={"values": {"bw.admin_mode": "bogus"}}).status_code == 400
    assert client.put("/api/preferences", json={"values": {"nope": 1}}).status_code == 400

    assert client.put("/api/selections/http smoke", json={"suites": ["demo"]}).status_code == 200
    assert client.get("/api/selections").json()[0]["suites"] == ["demo"]
    assert client.put("/api/selections/empty", json={}).status_code == 400
    assert client.delete("/api/selections/http smoke").status_code == 200


def test_profiles_list_builds(client, fake_project):
    data = client.get("/api/profiles").json()
    assert [p["name"] for p in data["profiles"]] == ["6.99.1"]
    assert data["profiles"][0]["builds"][0]["is_profile_default"]


def _wait(client, run_id, timeout=120):
    end = time.time() + timeout
    while time.time() < end:
        run = client.get(f"/api/runs/{run_id}").json()
        if run["state"] not in ("running", "stopping"):
            return run
        time.sleep(0.5)
    raise AssertionError(f"run {run_id} did not finish: {run}")


def test_run_from_ui_end_to_end(client, fake_project):
    body = {"suites": ["demo"], "name": "ui smoke", "tester": "qa1", "jira": "BUG-1", "notes": "n"}
    preview = client.post("/api/runs/preview", json=body).json()["command"]
    assert preview.startswith("bwtest run demo") and "--tester qa1" in preview

    run_id = client.post("/api/runs", json=body).json()["id"]
    second = client.post("/api/runs", json=body)  # same suite while the first run is going -> refused at once
    assert second.status_code == 400 and "already running" in second.text
    run = _wait(client, run_id)
    outcomes = {t["id"]: t["outcome"] for t in run["tests"]}
    assert outcomes == {"bw.1": "passed", "bw.2": "failed", "bw.3": "xfailed"}, client.get(
        f"/api/runs/{run_id}/console").json()["text"]
    assert run["state"] == "failed" and run["info"]["name"] == "ui smoke" and run["info"]["tester"] == "qa1"
    failed = next(t for t in run["tests"] if t["id"] == "bw.2")
    assert "-expected" in failed["message"] and failed["artifacts"] == "demo/bw.2"
    files = client.get(f"/api/runs/{run_id}/files", params={"path": "demo/bw.2"}).json()
    assert "diff.txt" in [i["name"] for i in files["items"]]
    assert "bwtest run demo" in client.get(f"/api/runs/{run_id}/console").json()["text"]
    assert client.get(f"/api/runs/{run_id}/files", params={"path": "../.."}).status_code == 400
    assert client.get("/api/runs").json()["runs"][0]["id"] == run_id

    # re-run only the failed test -> a single-test target
    rerun_id = client.post(f"/api/runs/{run_id}/rerun", json={"failed_only": True}).json()["id"]
    rerun = _wait(client, rerun_id)
    assert [(t["id"], t["outcome"]) for t in rerun["tests"]] == [("bw.2", "failed")]


def test_stop_file_skips_remaining_tests(client, fake_project):
    run_id = client.post("/api/runs", json={"suites": ["demo"], "dry_run": True}).json()["id"]
    client.post(f"/api/runs/{run_id}/stop")  # requested before the first test starts
    run = _wait(client, run_id)
    assert run["state"] == "stopped"
    assert all(t["outcome"] in ("skipped", "not_run") for t in run["tests"])


def test_import_new_ttests_suites_from_the_test_folder(client, fake_project):
    from tests.test_importer import TESTSET

    ftp = fake_project / "assets" / "func" / "migration" / "ftp"
    ftp.mkdir(parents=True)
    (ftp / "ftp.testset").write_text(TESTSET)
    for tid in ("bw.1", "bw.2", "bw.4"):
        (ftp / tid).mkdir()
    pending = client.get("/api/import/pending").json()
    assert pending["source_exists"] and pending["suites"] == [{"name": "ftp", "folder": "migration/ftp"}]

    result = client.post("/api/import", json={"names": []}).json()
    assert [s["name"] for s in result["imported"]] == ["ftp"] and not result["failed"]
    assert (fake_project / "suites" / "migration" / "ftp" / "ftp.suite.yaml").is_file()
    assert (fake_project / result["report"]).is_file()
    assert client.get("/api/import/pending").json()["suites"] == []
    assert {s["name"] for s in client.get("/api/suites").json()} == {"demo", "ftp"}  # visible without restart
    again = client.post("/api/import", json={"names": []})
    assert again.status_code == 400 and "nothing to import" in again.json()["detail"]
