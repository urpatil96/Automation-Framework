"""`${name}` placeholder rendering, shared by config, suites, actions and verifiers.

Why `${...}` and not Python `{...}`? Suite files contain JSON/XML bodies full of braces;
`${...}` never collides with them.

Supported forms:
    ${id}                 value from the variables mapping
    ${var.HOST_NAME}      dotted lookup (nested dicts)
    ${env:ORACLE_PASS}    environment variable (error if missing)
    ${env:PORT:-8080}     environment variable with default
    $${literal}           escape -> "${literal}"
"""

from __future__ import annotations

import os
import re
from collections.abc import Mapping
from typing import Any

from .errors import ConfigError

_PATTERN = re.compile(r"\$\$\{|\$\{([^}]+)\}")


def _lookup(name: str, variables: Mapping[str, Any]) -> Any:
    if name in variables:
        return variables[name]
    current: Any = variables
    for part in name.split("."):
        if isinstance(current, Mapping) and part in current:
            current = current[part]
        else:
            raise KeyError(name)
    return current


def render(text: str, variables: Mapping[str, Any] | None = None, *, strict: bool = True) -> str:
    """Replace ${...} placeholders in `text`.

    strict=False leaves unknown placeholders untouched (used for multi-pass rendering).
    """
    if not isinstance(text, str) or "$" not in text:
        return text
    variables = variables or {}

    def replace(match: re.Match[str]) -> str:
        if match.group(0) == "$${":
            return "${"
        expr = match.group(1).strip()
        if expr.startswith("env:"):
            name, _, default = expr[4:].partition(":-")
            value = os.environ.get(name)
            if value is not None:
                return value
            if ":-" in expr:
                return default
            if strict:
                raise ConfigError(f"Environment variable '{name}' is not set (needed by '${{{expr}}}')")
            return match.group(0)
        try:
            value = _lookup(expr, variables)
        except KeyError:
            if strict:
                known = ", ".join(sorted(k for k in variables if not k.startswith("_")))
                raise ConfigError(f"Unknown placeholder '${{{expr}}}'. Known: {known}") from None
            return match.group(0)
        return str(value)

    return _PATTERN.sub(replace, text)


def render_deep(value: Any, variables: Mapping[str, Any] | None = None, *, strict: bool = True) -> Any:
    """Render every string inside nested dicts / lists."""
    if isinstance(value, str):
        return render(value, variables, strict=strict)
    if isinstance(value, list):
        return [render_deep(v, variables, strict=strict) for v in value]
    if isinstance(value, dict):
        return {k: render_deep(v, variables, strict=strict) for k, v in value.items()}
    return value
