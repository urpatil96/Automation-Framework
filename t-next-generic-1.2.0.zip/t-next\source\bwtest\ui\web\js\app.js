// Application shell: sidebar navigation, top bar with the active run, and the route table.
//
// To add a page:  1) create js/pages/<name>.js exporting { title, render(view) }
//                 2) add a route below   3) (optional) add it to NAV
import { api } from "./core/api.js";
import { h, mount } from "./core/dom.js";
import { Router } from "./core/router.js";
import { initDesktop } from "./shell/desktop.js";

const NAV = [
  { group: "Start", items: [
    { href: "#/", label: "Dashboard", icon: "◧", match: "/" },
    { href: "#/run/new", label: "New run", icon: "▶", match: "/run/new", primary: true },
    { href: "#/runs", label: "Runs & reports", icon: "☰", match: "/runs" },
  ]},
  { group: "Test cases", items: [
    { href: "#/suites", label: "Suites", icon: "▤", match: "/suites" },
    { href: "#/suites/new", label: "New suite", icon: "+", match: "/suites/new" },
  ]},
  { group: "Setup", items: [
    { href: "#/preferences", label: "Preferences", icon: "⚙", match: "/preferences" },
    { href: "#/doctor", label: "Doctor", icon: "✚", match: "/doctor" },
    { href: "#/help", label: "Help & guide", icon: "?", match: "/help" },
  ]},
];

const sidebar = document.getElementById("sidebar");
const topbar = document.getElementById("topbar");
const outlet = document.getElementById("outlet");

function activeHref() {
  // the nav item whose path is the longest prefix of the current location (#/runs/123 -> Runs)
  const path = (location.hash.slice(1) || "/").split("?")[0];
  const all = NAV.flatMap((g) => g.items);
  const hits = all.filter((i) => path === i.match || (i.match !== "/" && path.startsWith(`${i.match}/`)));
  const exact = hits.find((i) => i.match === path);
  return (exact || hits.sort((a, b) => b.match.length - a.match.length)[0] || {}).href;
}

function renderSidebar() {
  const active = activeHref();
  mount(sidebar,
    h("a", { class: "brand", href: "#/" },
      h("span", { class: "brand-logo" }, "✓"),
      h("span", {}, h("span", { class: "brand-name" }, "T-Next"), h("span", { class: "brand-sub" }, "BW6 regression"))),
    NAV.map((g) => h("nav", { class: "nav-group" },
      h("div", { class: "nav-title" }, g.group),
      g.items.map((i) => h("a", {
        href: i.href,
        class: ["nav-item", i.primary && "nav-primary", i.href === active && "active"],
      }, h("span", { class: "nav-icon" }, i.icon), i.label)))),
    h("div", { class: "sidebar-foot" }, h("a", { href: "/docs", target: "_blank", rel: "noopener" }, "REST API docs")));
}

let activeRun = null;
let activeRuns = [];
async function refreshTopbar() {
  try {
    const data = await api.runs(1);
    activeRun = data.active;
    activeRuns = data.active_runs || (activeRun ? [activeRun] : []);
  } catch {
    activeRun = undefined;
  }
  mount(topbar,
    h("div", { class: "topbar-left" }, h("span", { class: "muted small" }, "BusinessWorks 6 · automated regression")),
    h("div", { class: "topbar-right" },
      activeRun === undefined ? h("span", { class: "pill tone-bad" }, "server offline")
        : activeRuns.length > 1 ? h("a", { class: "live-run", href: "#/runs" }, h("span", { class: "pulse" }), `${activeRuns.length} runs in progress`)
        : activeRun ? h("a", { class: "live-run", href: `#/runs/${activeRun}` }, h("span", { class: "pulse" }), `Run ${activeRun} in progress`)
          : h("span", { class: "muted small" }, "No run in progress")));
}

// Desktop app (bwtest desktop) opens /?desktop=1: t-tests style layout instead of sidebar + top bar.
const DESKTOP = new URLSearchParams(location.search).has("desktop");
document.body.dataset.mode = DESKTOP ? "desktop" : "browser";

const router = new Router(outlet, () => { if (!DESKTOP) renderSidebar(); });
router
  .add("/", () => import("./pages/dashboard.js"))
  .add("/run/new", () => import("./pages/newRun.js"))
  .add("/runs", () => import("./pages/runs.js"))
  .add("/runs/:id", () => import("./pages/runDetail.js"))
  .add("/suites", () => import("./pages/suites.js"))
  .add("/suites/new", () => import("./pages/newSuite.js"))
  .add("/suites/:name", () => import("./pages/suiteDetail.js"))
  .add("/preferences", () => import("./pages/preferences.js"))
  .add("/doctor", () => import("./pages/doctor.js"))
  .add("/help", () => import("./pages/help.js"))
  .add("*", () => import("./pages/notFound.js"));

if (DESKTOP) {
  try {
    initDesktop({ toolbar: topbar, tree: sidebar, statusbar: document.getElementById("statusbar") });
  } catch (error) {
    document.body.dataset.shellError = String((error && error.stack) || error);
    console.error(error);
  }
} else {
  refreshTopbar();
  setInterval(refreshTopbar, 5000);
  window.addEventListener("hashchange", () => setTimeout(refreshTopbar, 300));
}
router.resolve();
