"""Thin wrapper around the BW command-line tools.

Replaces the copy-pasted `${TIB_BW_HOME}/bin/${t_admin_exe} --propFile ...` lines of BW_ENGINE.sh.

Every command is:
  * executed without a shell (no quoting bugs with spaces in paths),
  * time-limited,
  * checked (exit code + error codes in the output),
  * written to <run>/commands.log as a copy-paste-able line, so any failure can be replayed by hand
    (old setupCommands.bat / appCommands.bat).
"""

from __future__ import annotations

import contextlib
import os
import queue
import re
import shlex
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from .config import Settings
from .errors import BwCommandError, ConfigError

_WIN_PATH = re.compile(r"^[A-Za-z]:[\\/]")

# Use for EVERY child process the framework starts (bwadmin, bwagent, java, bash, shell steps):
#  * stdin=DEVNULL - pytest swaps the test process's stdin; in a process without a console (desktop app,
#    Jenkins service) Windows' recorded stdin handle is then invalid and a child that inherits it fails with
#    "OSError: [WinError 6] The handle is invalid". No BW tool reads stdin, so give it an empty one.
#  * CREATE_NO_WINDOW - otherwise every bwadmin call flashes a console window when started from the desktop app.
NO_CONSOLE: dict = {"stdin": subprocess.DEVNULL}
if os.name == "nt":
    NO_CONSOLE["creationflags"] = subprocess.CREATE_NO_WINDOW


def forward_slashes(arg: str) -> str:
    """'C:\\domains' -> 'C:/domains' (only for absolute Windows paths)."""
    return arg.replace("\\", "/") if _WIN_PATH.match(arg) else arg


# "... BusinessWorks version 6.12.1, build V12, 2026-10-28"
# "... BusinessWorks version 6.12.0, hotfix 5, build V188, 2026-11-06"   (hotfix builds)
_VERSION_RE = re.compile(
    r"BusinessWorks\s+version\s+(\d+)\.(\d+)\.(\d+)\s*,\s*(?:hotfix\s+(\d+)\s*,\s*)?build\s+([^,\s]+)", re.I)


@dataclass(frozen=True)
class BwVersion:
    major: int
    minor: int
    update: int
    build: str
    hotfix: int = 0  # 0 = GA / no hotfix

    @property
    def three_digit(self) -> str:
        """"6121" - same as old TSI_PROD_VERSION_3DIGIT, used for version-specific gold files."""
        return f"{self.major}{self.minor}{self.update}"

    @property
    def dotted(self) -> str:
        return f"{self.major}.{self.minor}.{self.update}"

    @property
    def label(self) -> str:
        """'6.12.0 HF5' / '6.12.1'"""
        return f"{self.dotted} HF{self.hotfix}" if self.hotfix else self.dotted

    def __str__(self) -> str:
        return f"{self.label} build {self.build}"


def parse_version(text: str) -> BwVersion | None:
    match = _VERSION_RE.search(text)
    if not match:
        return None
    major, minor, update, hotfix, build = match.groups()
    return BwVersion(int(major), int(minor), int(update), build, int(hotfix or 0))


@dataclass
class CmdResult:
    args: list[str]
    returncode: int
    output: str
    duration: float

    @property
    def ok(self) -> bool:
        return self.returncode == 0


class CommandLog:
    """Append-only, thread-safe log of every external command (for replay & debugging)."""

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def write(self, args: list[str], result: CmdResult | None = None, note: str = "") -> None:
        line = subprocess.list2cmdline(args) if os.name == "nt" else shlex.join(args)
        status = "" if result is None else f"  # rc={result.returncode} {result.duration:.1f}s"
        with self._lock, self.path.open("a", encoding="utf-8") as fh:
            if note:
                fh.write(f"\n:: {note}\n" if os.name == "nt" else f"\n# {note}\n")
            fh.write(line + status + "\n")


def unix_tools_dir(settings: Settings) -> str:
    """Folder for bw.unix_tools ('auto' = Git for Windows usr/bin next to Git Bash). '' if none."""
    value = (settings.bw.unix_tools or "").strip()
    if not value or not settings.is_windows:
        return ""
    if value.lower() != "auto":
        return value if Path(value).is_dir() else ""
    try:
        from .legacy.bridge import find_bash

        bash = Path(find_bash(settings.paths.bash))  # ...\Git\bin\bash.exe or ...\Git\usr\bin\bash.exe
    except (ConfigError, OSError):
        return ""
    for candidate in (bash.parent.parent / "usr" / "bin", bash.parent):
        if (candidate / "cat.exe").is_file():
            return str(candidate)
    return ""


def tibrv_home(settings: Settings) -> str:
    """Rendezvous home: vars.TIBRV_HOME (Preferences > Tools > Tibrv location), else the newest
    <bw.rv_root>/<version> (default: <install>/tibrv next to the BW install) that contains bin/rvd. '' if none."""
    configured = (settings.vars.get("TIBRV_HOME") or "").strip()
    if configured:
        return configured if Path(configured).is_dir() else ""
    install = Path(settings.bw.home).parent.parent
    roots = [Path(settings.bw.rv_root)] if settings.bw.rv_root else [install / "tibrv", install.parent / "tibrv"]
    rvd = "rvd.exe" if settings.is_windows else "rvd"
    for root in roots:
        if root.is_dir():
            versions = sorted((p for p in root.iterdir() if (p / "bin" / rvd).is_file()),
                              key=lambda p: [int(x) if x.isdigit() else x for x in re.split(r"(\d+)", p.name)])
            if versions:
                return str(versions[-1])
    return ""


_PROMPT = re.compile(r"bwadmin\[[^\]\r\n]*\]> $")
_SHELL_ERROR = re.compile(r"BW-ADMIN(?:-CLI)?-5\d{5}|^Command not found", re.M)


class AdminShell:
    """ONE long-running `bwadmin` shell (its interactive mode) that executes all commands of a run.

    Why: every `bwadmin` call starts a new JVM - 3 s on an idle machine, 5-8 s while an AppNode is running.
    t-tests (and bwtest before this) paid that for every upload, deploy, status poll, stop, undeploy and delete:
    on the bw-bat suite that was 243 calls = 28 of 38 minutes. In the shell a command takes milliseconds.

    The shell has no exit codes: a command counts as failed when its output contains a admin error code
    (BW-ADMIN-CLI-5xxxxx) or "Command not found" - the same check that is done on one-shot calls.
    If the shell dies or hangs it is killed; BwCli then starts a new one or falls back to one-shot calls.
    """

    def __init__(self, prefix: list[str], env: dict[str, str], cwd: Path, start_timeout: float = 180):
        self.proc = subprocess.Popen(prefix, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     cwd=cwd, env=env, creationflags=NO_CONSOLE.get("creationflags", 0))
        self._out: queue.Queue = queue.Queue()
        threading.Thread(target=self._read, daemon=True, name="bwadmin-shell").start()
        self.banner = self._wait_prompt(start_timeout)

    def _read(self) -> None:
        buf = b""
        stdout = self.proc.stdout
        assert stdout is not None
        while True:
            chunk = stdout.read1(65536)
            if not chunk:
                self._out.put(None)
                return
            buf += chunk
            text = buf.decode("utf-8", errors="replace")
            if _PROMPT.search(text):
                self._out.put(_PROMPT.sub("", text))
                buf = b""

    def _wait_prompt(self, timeout: float) -> str:
        try:
            text = self._out.get(timeout=timeout)
        except queue.Empty:
            self.close(force=True)
            raise TimeoutError(f"no bwadmin prompt within {timeout:.0f}s") from None
        if text is None:
            raise EOFError("bwadmin shell ended")
        return text.replace("\r\n", "\n")

    def run(self, args: list[str], timeout: float) -> str:
        line = " ".join(_shell_quote(a) for a in args)
        assert self.proc.stdin is not None
        self.proc.stdin.write((line + "\n").encode("utf-8"))
        self.proc.stdin.flush()
        out = self._wait_prompt(timeout)
        first, _, rest = out.partition("\n")  # the shell echoes the command line
        return rest if first.strip() == line.strip() else out

    def alive(self) -> bool:
        return self.proc.poll() is None

    def close(self, force: bool = False) -> None:
        if self.proc.poll() is not None:
            return
        try:
            if not force and self.proc.stdin:
                self.proc.stdin.write(b"exit\n")
                self.proc.stdin.flush()
                self.proc.wait(timeout=20)
                return
        except (OSError, subprocess.TimeoutExpired):
            pass
        self.proc.kill()
        with contextlib.suppress(subprocess.TimeoutExpired):
            self.proc.wait(timeout=10)


def _shell_quote(arg: str) -> str:
    """Quote an argument for the bwadmin shell (paths with spaces)."""
    if arg and not any(c in arg for c in " \t'\""):
        return arg
    return '"' + arg.replace('"', '\\"') + '"'


class BwCli:
    def __init__(self, settings: Settings, command_log: CommandLog, agent_ini: Path | None = None,
                 work_dir: Path | None = None):
        self.settings = settings
        self.log = command_log
        self.agent_ini = agent_ini
        self.work_dir = work_dir
        self._error_res = [re.compile(p) for p in settings.bw.error_patterns]
        self.bin = settings.bw.home / "bin"
        self.tools_dir = unix_tools_dir(settings)
        self.tibrv_home = tibrv_home(settings)
        self._shell: AdminShell | None = None
        self._shell_off = not settings.bw.admin_shell  # True = one JVM per command (old behaviour)
        self._shell_restarts = 0
        self._shell_lock = threading.Lock()
        self.shell_banner = ""
        self.stats = {"calls": 0, "seconds": 0.0, "shell_calls": 0}  # shown on the Run page (time breakdown)

    def child_env(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        """Environment for BW tools - inherited by the AppNode started by bwadmin/bwagent:
        * Unix tools first on PATH: test apps call `cat`, `ls` ... in External Command activities;
        * Rendezvous bin on PATH (+ TIBRV_HOME): RV activities auto-start `rvd` only if it is on the PATH
          (t-tests did this through its 'Tibrv location' setting)."""
        env = {**os.environ, **(extra or {})}
        key = next((k for k in env if k.upper() == "PATH"), "PATH")
        front = [d for d in (self.tools_dir, str(Path(self.tibrv_home) / "bin") if self.tibrv_home else "") if d]
        if front:
            env[key] = os.pathsep.join([*front, env.get(key, "")])
        if self.tibrv_home:
            env.setdefault("TIBRV_HOME", self.tibrv_home)
        return env

    # -- helpers ---------------------------------------------------------------------------------
    def tool(self, name: str) -> list[str]:
        """Command prefix for a BW tool, e.g. ['.../bwadmin.exe', '--propFile', '.../bwadmin.tra']."""
        override = self.settings.bw.tool_overrides.get(name)
        if override:
            return list(override)
        suffix = ".exe" if self.settings.is_windows else ""
        exe = self.bin / f"{name}{suffix}"
        if not self.settings.dry_run and not exe.exists():
            raise ConfigError(f"{exe} not found - check bw.home (currently '{self.settings.bw.home}')")
        prefix = [str(exe)]
        tra = self.bin / f"{name}.tra"
        if tra.exists() or self.settings.dry_run:
            prefix += ["--propFile", str(tra)]
        return prefix

    def run(
        self,
        args: list[str],
        *,
        check: bool = True,
        timeout: int | None = None,
        cwd: Path | None = None,
        note: str = "",
        env: dict[str, str] | None = None,
    ) -> CmdResult:
        args = [str(a) for a in args]
        if self.settings.dry_run:
            self.log.write(args, note=f"[dry-run] {note}")
            return CmdResult(args, 0, "", 0.0)
        start = time.monotonic()
        try:
            proc = subprocess.run(
                args,
                cwd=cwd,
                env=self.child_env(env),
                **NO_CONSOLE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout or self.settings.timeouts.command,
                check=False,
            )
            result = CmdResult(args, proc.returncode, proc.stdout or "", time.monotonic() - start)
            if Path(args[0]).stem.lower() == "bwadmin" or "bwadmin" in " ".join(args[:2]).lower():
                self._count(result.duration)
        except subprocess.TimeoutExpired as exc:
            out = exc.output if isinstance(exc.output, str) else (exc.output or b"").decode(errors="replace")
            self.log.write(args, note=f"TIMEOUT {note}")
            raise BwCommandError(f"Timed out after {exc.timeout}s: {note}", args, out) from None
        except FileNotFoundError:
            raise BwCommandError(f"Executable not found: {args[0]}", args) from None
        self.log.write(args, result, note)
        if check:
            self._check(result, note)
        return result

    def _check(self, result: CmdResult, note: str) -> None:
        if result.returncode != 0:
            raise BwCommandError(f"{note or 'command'} failed (exit code {result.returncode})",
                                 result.args, result.output)
        for pattern in self._error_res:
            if pattern.search(result.output):
                raise BwCommandError(f"{note or 'command'} reported an error ({pattern.pattern})",
                                     result.args, result.output)

    # -- bwadmin ---------------------------------------------------------------------------------
    def bwadmin(self, *args: str, check: bool = True, timeout: int | None = None, note: str = "",
                cwd: Path | None = None) -> CmdResult:
        config = ["-config", str(self.agent_ini)] if self.agent_ini else []
        # bwadmin stores some arguments in Java .properties files (e.g. DomainHomes.properties) where a
        # backslash is an escape: "C:\domains" would become "C:domains". Forward slashes are always safe.
        fixed = [forward_slashes(str(a)) for a in [*config, *args]]
        note = note or f"bwadmin {' '.join(args[:3])}"
        full = [*self.tool("bwadmin"), *fixed]
        if not self.settings.dry_run and not self._shell_off and cwd is None:
            result = self._via_shell(fixed[len(config):], full, timeout, note)
            if result is not None:
                if check:
                    self._check(result, note)
                return result
        return self.run(full, check=check, timeout=timeout, note=note, cwd=cwd)

    @property
    def uses_shell(self) -> bool:
        return self._shell is not None and self._shell.alive()

    def start_shell(self) -> bool:
        """Open the shared bwadmin shell now (it also prints the BW version). False = one-shot mode."""
        if self.settings.dry_run or self._shell_off:
            return False
        with self._shell_lock:
            return self._ensure_shell()

    def _ensure_shell(self) -> bool:
        if self._shell is not None and self._shell.alive():
            return True
        if self._shell_restarts >= 3:  # keeps dying: stop trying, one-shot calls always work
            self._shell_off = True
            return False
        prefix = [*self.tool("bwadmin")]
        if self.agent_ini:
            prefix += ["-config", forward_slashes(str(self.agent_ini))]
        start = time.monotonic()
        try:
            self._shell = AdminShell(prefix, self.child_env(), self.work_dir or Path.cwd(),
                                     start_timeout=max(180, self.settings.timeouts.command))
        except (OSError, TimeoutError, EOFError) as exc:
            self._shell, self._shell_off = None, True
            self.log.write(prefix, note=f"bwadmin shell could not start ({exc}) - using one call per command")
            return False
        self._shell_restarts += 1
        self.shell_banner = self._shell.banner
        self.log.write(prefix, CmdResult(prefix, 0, "", time.monotonic() - start),
                       note="bwadmin shell started - the commands below run inside it (each line can be replayed)")
        return True

    def _via_shell(self, cmd: list[str], full: list[str], timeout: int | None, note: str) -> CmdResult | None:
        """Run one command in the shared shell. None = shell not usable -> the caller runs it one-shot."""
        limit = timeout or self.settings.timeouts.command
        with self._shell_lock:
            if not self._ensure_shell():
                return None
            assert self._shell is not None
            start = time.monotonic()
            try:
                output = self._shell.run(cmd, limit)
            except TimeoutError:
                # The command hangs: the shell was killed; a new one is started for the next command.
                self._shell = None
                self.log.write(full, note=f"TIMEOUT {note} (bwadmin shell)")
                raise BwCommandError(f"Timed out after {limit}s: {note}", full, "") from None
            except (OSError, EOFError) as exc:
                self._shell = None
                self.log.write(full, note=f"bwadmin shell ended ({exc}) - running this command on its own")
                return None
            rc = 1 if _SHELL_ERROR.search(output) else 0
            result = CmdResult(full, rc, output, time.monotonic() - start)
            self.log.write(full, result, note)
            self._count(result.duration, shell=True)
            return result

    def _count(self, seconds: float, shell: bool = False) -> None:
        self.stats["calls"] += 1
        self.stats["seconds"] = round(self.stats["seconds"] + seconds, 2)
        if shell:
            self.stats["shell_calls"] += 1

    def close(self) -> None:
        """Exit the shared shell (end of the run / worker)."""
        with self._shell_lock:
            if self._shell is not None:
                self._shell.close()
                self._shell = None

    def version(self, workdir: Path) -> BwVersion | None:
        # The shell prints the version banner when it starts: no extra JVM needed.
        if self.start_shell():
            found = parse_version(self.shell_banner)
            if found:
                return found
        # `bwadmin version` prints the banner (and "Command not found" on some builds): parse banner only.
        workdir.mkdir(parents=True, exist_ok=True)
        result = self.run([*self.tool("bwadmin"), "version"], check=False, cwd=workdir,
                          note="detect BW version", timeout=180)
        return parse_version(result.output)

    # -- bwinstall (drivers) --------------------------------------------------------------------
    def bwinstall(self, target: str, *, uninstall: bool = False) -> CmdResult:
        name = "bwuninstall" if uninstall else "bwinstall"
        if not self.settings.bw.tool_overrides.get(name):
            suffix = ".exe" if self.settings.is_windows else ""
            if uninstall and not (self.bin / f"bwuninstall{suffix}").exists() and not self.settings.dry_run:
                # Newer BW builds have no bwuninstall; nothing to undo in that case.
                self.log.write([name, target], note="skipped: bwuninstall not present in this BW build")
                return CmdResult([name, target], 0, "", 0.0)
        return self.run([*self.tool(name), target], note=f"{name} {target}", timeout=900)

    # -- bwagent (enterprise mode) -------------------------------------------------------------------
    def start_agent(self, log_file: Path) -> subprocess.Popen | None:
        args = [*self.tool("bwagent"), "-config", str(self.agent_ini)]
        if self.settings.dry_run:
            self.log.write(args, note="[dry-run] start bwagent")
            return None
        self.log.write(args, note="start bwagent (background)")
        fh = log_file.open("w", encoding="utf-8")
        return subprocess.Popen(args, stdout=fh, stderr=subprocess.STDOUT, cwd=log_file.parent, env=self.child_env(),
                                **NO_CONSOLE)
