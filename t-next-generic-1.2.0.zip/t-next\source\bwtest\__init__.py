"""bwtest - pytest-based regression framework for BusinessWorks 6.

Layers (bottom to top):

    config.py      settings (YAML + profile + env vars), secrets via ${env:VAR}
    bwcli.py       thin, logged wrapper around bwadmin / bwagent / bwinstall
    runtime.py     Domain -> AppSpace -> AppNode -> Application lifecycle
    models.py      suite / test-case definitions loaded from *.suite.yaml
    actions.py     "action" steps (wait, http call, wait-for-file, shell ...)
    verify.py      verifiers (text/xml/json/binary diff, contains, log checks)
    executor.py    runs one test case: setup -> deploy -> action -> verify -> teardown
    pytest_plugin  turns *.suite.yaml files into pytest tests
    legacy/        importer for t-tests 4.0 .testset suites + bash bridge
    cli.py         `bwtest` command line (run, list, import, new-suite, doctor ...)
"""

__version__ = "1.2.0"
