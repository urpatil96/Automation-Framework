# suites/

Your suite files (`<name>.suite.yaml`) live here, grouped in folders (e.g. `engine/http/`, `engine/jdbc/oracle/`).

This folder is empty in the repository. Fill it from your own test case folder:
- desktop app: **Suites > Sync with test folder...**
- command line: `bwtest import <your test folder>/func`

Or write a new suite: desktop app **Suites > New suite**, or see `docs/WRITING_TESTS.md`.
