"""Keep suites/ in step with a user's own t-tests test folder (<assets_root>/func).

    new suite in the test folder        -> imported (grouped like the others, see importer.placement)
    new test case in a known .testset   -> its entry is appended to the existing suite file
    test case no longer in the .testset -> only reported (never deleted: it may be a T-Next-only test)

Existing suite files are never rewritten: hand-made fixes and comments stay. Used by setup, Doctor, the UI
("Sync with test folder") and `bwtest import`.
"""

from __future__ import annotations

import os
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from ..errors import BwTestError, ConfigError
from ..models import load_suite
from .importer import ImportResult, _dump, import_testset

SUFFIX = ".suite.yaml"


def find_testsets(func_dir: Path) -> list[Path]:
    """.testset files in the suite folders of a t-tests tree (func/engine/<suite>/, func/engine/jdbc/<db>/ ...).

    Skips the test case folders (bw.1234 / bw_1234 ...) and stays shallow, so a large tree takes well under a second.
    """
    func_dir = Path(func_dir)
    if not func_dir.is_dir():
        return []
    found: list[Path] = []
    for folder, dirs, files in os.walk(func_dir):
        depth = len(Path(folder).relative_to(func_dir).parts)
        dirs[:] = [] if depth >= 4 else [d for d in dirs if not d.lower().startswith(("bw.", "bw_"))]
        found += [Path(folder) / f for f in files if f.endswith(".testset")]
    return sorted(found, key=lambda p: p.stem.lower())


def suite_files(suites_root: Path) -> dict[str, Path]:
    root = Path(suites_root)
    files = sorted(root.rglob("*" + SUFFIX)) if root.is_dir() else []
    return {f.name.removesuffix(SUFFIX).lower(): f for f in files}


@dataclass
class SuiteUpdate:
    name: str
    testset: Path
    suite_file: Path
    new_tests: list[str] = field(default_factory=list)  # in the .testset, not in the suite file
    gone_tests: list[str] = field(default_factory=list)  # in the suite file, not in the .testset (report only)


@dataclass
class SyncPlan:
    func_dir: Path
    new_suites: list[Path] = field(default_factory=list)
    updates: list[SuiteUpdate] = field(default_factory=list)  # only suites with new or gone tests

    @property
    def new_test_count(self) -> int:
        return sum(len(u.new_tests) for u in self.updates)


def _ids(entries: list) -> list[str]:
    return [str(t["id"]) for t in entries or [] if isinstance(t, dict) and "id" in t]


def _fresh(testset: Path, assets_root: Path, drivers, dbs, tmp: Path) -> dict:
    """The suite as a fresh import of this .testset would write it (into a throw-away folder)."""
    result = import_testset(testset, tmp, assets_root, drivers, dbs, target=tmp / f"{testset.stem}{SUFFIX}")
    return yaml.safe_load(result.target.read_text(encoding="utf-8")) or {}


def plan(func_dir: Path, suites_root: Path, assets_root: Path, drivers=None, dbs=None,
         check_tests: bool = True) -> SyncPlan:
    """What a sync would do. check_tests=False: only look for new suites (no parsing, very fast)."""
    result = SyncPlan(Path(func_dir))
    known = suite_files(suites_root)
    with tempfile.TemporaryDirectory(prefix="tnext-sync-") as tmp:
        for testset in find_testsets(func_dir):
            suite_file = known.get(testset.stem.lower())
            if suite_file is None:
                result.new_suites.append(testset)
                continue
            if not check_tests:
                continue
            try:
                fresh = _ids(_fresh(testset, assets_root, drivers, dbs, Path(tmp)).get("tests"))
                current = _ids((yaml.safe_load(suite_file.read_text(encoding="utf-8")) or {}).get("tests"))
            except Exception:  # an unreadable .testset or suite file: Doctor / import report it elsewhere
                continue
            new = [i for i in fresh if i not in set(current)]
            gone = [i for i in current if i not in set(fresh)]
            if new or gone:
                result.updates.append(SuiteUpdate(testset.stem, testset, suite_file, new, gone))
    return result


def add_tests(update: SuiteUpdate, assets_root: Path, drivers=None, dbs=None) -> list[str]:
    """Append the entries of update.new_tests (as a fresh import writes them) to the existing suite file.

    The file is only appended to - comments and hand-made changes stay. Validated afterwards; restored on error.
    """
    if not update.new_tests:
        return []
    text = update.suite_file.read_text(encoding="utf-8")
    top_keys = re.findall(r"(?m)^([A-Za-z_][\w-]*):", text)
    if not top_keys or top_keys[-1] != "tests":
        raise ConfigError(f"{update.suite_file.name}: 'tests:' is not the last section - add "
                          f"{', '.join(update.new_tests)} by hand (Suites > open suite > Edit)")
    with tempfile.TemporaryDirectory(prefix="tnext-sync-") as tmp:
        fresh = _fresh(update.testset, assets_root, drivers, dbs, Path(tmp))
    wanted = set(update.new_tests)
    entries = [t for t in fresh.get("tests") or [] if isinstance(t, dict) and str(t.get("id")) in wanted]
    block = _dump(entries)
    addition = (f"# added from {update.testset.name} by T-Next sync\n" + block)
    new_text = text + ("" if text.endswith("\n") else "\n") + addition
    update.suite_file.write_text(new_text, encoding="utf-8")
    try:
        load_suite(update.suite_file, assets_root)
    except BwTestError:
        update.suite_file.write_text(text, encoding="utf-8")
        raise
    return [str(t["id"]) for t in entries]


@dataclass
class SyncResult:
    imported: list[ImportResult] = field(default_factory=list)
    added: dict[str, list[str]] = field(default_factory=dict)  # suite -> test ids added
    gone: dict[str, list[str]] = field(default_factory=dict)  # suite -> ids no longer in the .testset
    failed: list[tuple[str, str]] = field(default_factory=list)  # (suite, error)

    @property
    def added_tests(self) -> int:
        return sum(len(v) for v in self.added.values())


def apply(sync_plan: SyncPlan, suites_root: Path, assets_root: Path, drivers=None, dbs=None,
          suites: set[str] | None = None) -> SyncResult:
    """Import the new suites and add the new tests. suites: lower-case names to limit it to (None = all)."""
    out = SyncResult()
    pick = (lambda name: True) if suites is None else (lambda name: name.lower() in suites)
    for testset in sync_plan.new_suites:
        if not pick(testset.stem):
            continue
        try:
            out.imported.append(import_testset(testset, suites_root, assets_root, drivers, dbs))
        except Exception as exc:  # report and continue with the other suites
            out.failed.append((testset.stem, f"{type(exc).__name__}: {exc}"))
    for update in sync_plan.updates:
        if update.gone_tests:
            out.gone[update.name] = update.gone_tests
        if not update.new_tests or not pick(update.name):
            continue
        try:
            out.added[update.name] = add_tests(update, assets_root, drivers, dbs)
        except Exception as exc:
            out.failed.append((update.name, f"{type(exc).__name__}: {exc}"))
    return out
