"""Find the BW home and its version, whatever the folders are called.

BW home = the folder with bin/bwadmin(.exe), always <install>/bw/<x.y>. People install and name things
differently, e.g.

    C:/D/6.12.1/V12/bw/6.12                         (QA machines: <version>/<build>/bw/<x.y>)
    C:/Users/me/bw6/BW6setup/BW6121/bw/6.12       (INSTALL_HOME named after the version)
    C:/bw6/bw/6.12                                (default installer folder)

and type the version as 6.12.1, BW 6.12.1, BW6121, bw_6_12_1 ... This module turns any of those into the
real BW home and the profile name (config/profiles/<version>.yaml). It only finds paths - it never changes
which BW commands are run.
"""

from __future__ import annotations

import os
import re
import time
from pathlib import Path

_VERSION_RUN = re.compile(r"\d+(?:[._ -]?\d+)*")
# folders never worth looking into when searching for BW installs (big / unrelated / BW's own sub-folders)
_SKIP = {"appdata", "node_modules", "site-packages", "__pycache__", "results", "domains", "p2repos", "studio",
         "eclipse-platform", "tools", "release_notes", "thor", "windows", "$recycle.bin",
         "programdata", "system volume information", ".venv", "venv"}


def has_bwadmin(home: Path) -> bool:
    return (home / "bin" / "bwadmin.exe").is_file() or (home / "bin" / "bwadmin").is_file()


def _is_set(path: Path | str | None) -> bool:
    return path is not None and str(path) not in ("", ".")


def normalize_version(text: str, known: list[str] | tuple[str, ...] = ()) -> str | None:
    """'BW6121' / 'BW 6.12.1' / '6.12.1' / 'bw_6_12_1' / '6.12.1.000' -> '6.12.1' (hotfix level dropped).

    With `known` (profile names) the answer is always one of them, or None. Without, the dotted form is
    returned (needs at least major.minor.patch when written without separators)."""
    text = str(text or "").strip()
    if not text:
        return None
    if text in known:
        return text
    for run in _VERSION_RUN.findall(text):
        if re.search(r"[._ -]", run):
            parts = [str(int(p)) for p in re.split(r"[._ -]+", run) if p]
            parts = parts[:3]  # 6.12.1.000 / hotfix 6.11.0.006 -> the release 6.12.1 / 6.11.0
            if len(parts) < 2:
                continue
            dotted = ".".join(parts)
            if not known:
                return dotted if len(parts) >= 3 else None
            for k in known:
                kparts = [str(int(p)) for p in re.split(r"[._ -]+", k) if p.isdigit()]
                if kparts == parts or (len(parts) == 2 and kparts[:2] == parts and kparts[2:] in ([], ["0"])):
                    return k
        else:  # 6121 - only digits: compare with the profiles written without dots
            if len(run) < 3:
                continue
            if not known:
                return f"{run[0]}.{run[1:-1]}.{run[-1]}" if len(run) >= 3 else None
            for k in known:
                if re.sub(r"\D", "", k) == run:
                    return k
    return None


def install_version(home: Path) -> str | None:
    """Version recorded by the installer: <install>/_installInfo/BW_6.12.1_prodInfo.xml."""
    info = Path(home).parent.parent / "_installInfo"
    if not info.is_dir():
        return None
    for pattern in ("BW_*_prodInfo.xml", "bw-ent_*_prodInfo.xml"):
        for file in sorted(info.glob(pattern)):
            version = normalize_version(file.name.split("_", 1)[1].rsplit("_", 1)[0])
            if version:
                return version
    return None


def guess_version(home: Path, known: list[str] | tuple[str, ...]) -> str | None:
    """Profile for a BW home: installer info first, then a folder name on the path (6.12.1, BW6121 ...),
    then the bw/<x.y> folder when only one profile has that x.y."""
    home = Path(home)
    found = install_version(home)
    if found:
        return normalize_version(found, known) if known else found
    for part in reversed(home.parts[:-1]):
        if part.lower() == "bw":
            continue
        version = normalize_version(part, known)
        if version:
            return version
    same_minor = [k for k in known if k.startswith(home.name + ".")]  # bw/6.12 -> 6.12.x
    return same_minor[0] if len(same_minor) == 1 else None


def _homes_below(install_home: Path) -> list[Path]:
    bw = install_home / "bw"
    if not bw.is_dir():
        return []
    try:
        return sorted(p for p in bw.iterdir() if p.is_dir() and has_bwadmin(p))
    except OSError:
        return []


def find_bw_homes(folder: Path | str, max_depth: int = 5) -> list[Path]:
    """Every BW home in or below `folder` (the folder itself, <folder>/bw/<x.y>, deeper install folders ...)."""
    folder = Path(folder)
    if not folder.is_dir():
        return []
    if has_bwadmin(folder):
        return [folder]
    if folder.name.lower() == "bin" and has_bwadmin(folder.parent):
        return [folder.parent]
    if folder.name.lower() == "bw":  # <install>/bw
        return _homes_below(folder.parent)
    found: list[Path] = []
    stack = [(folder, 0)]
    while stack:
        current, depth = stack.pop()
        homes = _homes_below(current)
        if homes:  # a INSTALL_HOME - nothing more to find inside it
            found += homes
            continue
        if depth >= max_depth:
            continue
        try:
            children = [e for e in os.scandir(current) if e.is_dir(follow_symlinks=False)]
        except OSError:
            continue
        for entry in children:
            name = entry.name.lower()
            if name.startswith((".", "$")) or name in _SKIP or "jre" in name:
                continue
            stack.append((Path(entry.path), depth + 1))
    return sorted(set(found), key=lambda p: p.as_posix().lower())


def resolve_bw_home(path: Path | str) -> Path:
    """The BW home for what the user entered: unchanged when it already has bin/bwadmin; the one BW home
    inside it when they gave INSTALL_HOME, <install>/bw or .../bin; otherwise unchanged (Doctor reports it)."""
    path = Path(path)
    if not _is_set(path) or has_bwadmin(path) or not path.is_dir():
        return path
    homes = find_bw_homes(path, max_depth=2)
    return homes[0] if len(homes) == 1 else path


_SCAN_CACHE: dict[str, tuple[float, list[Path]]] = {}


def scan(root: Path | str, max_age: float = 15.0) -> list[Path]:
    """find_bw_homes(root), cached for a few seconds (the UI asks once per profile)."""
    key = Path(root).as_posix().lower()
    hit = _SCAN_CACHE.get(key)
    if hit and time.monotonic() - hit[0] < max_age:
        return hit[1]
    homes = find_bw_homes(root)
    _SCAN_CACHE[key] = (time.monotonic(), homes)
    return homes
