"""Runs ONE test case:  prepare -> (migrate) -> deploy -> action -> verify -> undeploy.

This is the heart of the framework and the part to explain on a whiteboard. It does not depend on
pytest (pytest_plugin.py only calls `TestExecutor.run`), so it can also be driven from a script.
"""

from __future__ import annotations

import re
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .actions import run_actions
from .errors import ConfigError, EnvironmentSetupError, VerificationFailed
from .gold import save as save_gold_changes
from .legacy.bridge import ScriptResult, find_bash, run_script
from .models import SuiteSpec, TestSpec
from .runtime import Deployment, SuiteEnvironment
from .substvar import build_profile, read_default_substvar
from .templating import render, render_deep
from .verify import resolve_gold, run_verifications

_IDENT = re.compile(r"[A-Za-z_]\w*")


def _posix(path: Path | str) -> str:
    return str(path).replace("\\", "/")


def _relative_posix(path: Path, base: Path) -> str:
    try:
        return Path(path).resolve().relative_to(Path(base).resolve()).as_posix()
    except ValueError:  # assets_dir outside assets_root's parent: no t-tests equivalent
        return ""


@dataclass
class TestContext:
    """Everything a step / verifier needs about the running test. Passed to custom Python hooks."""

    runtime: SuiteEnvironment
    suite: SuiteSpec
    test: TestSpec
    log_dir: Path
    case_dir: Path
    output_file: Path
    gold_file: Path
    input_file: Path
    vars: dict[str, str] = field(default_factory=dict)
    seq: int = 1
    _log_offset: int = 0
    timings: dict[str, float] = field(default_factory=dict)  # seconds per phase: deploy/action/cleanup/verify
    gold_candidates: list[dict] = field(default_factory=list)  # gold comparisons that failed -> gold.py

    # -- convenience ------------------------------------------------------------------------
    @property
    def settings(self):
        return self.runtime.settings

    @property
    def dry_run(self) -> bool:
        return self.settings.dry_run

    @property
    def update_gold(self) -> bool:
        return self.settings.update_gold

    def render(self, text: str) -> str:
        return render(text, self.vars)

    def render_deep(self, value: Any) -> Any:
        return render_deep(value, self.vars)

    def log(self, message: str) -> None:
        with (self.log_dir / "test.log").open("a", encoding="utf-8") as fh:
            fh.write(f"{time.strftime('%H:%M:%S')} {message}\n")

    def write_artifact(self, name: str, text: str, append: bool = False) -> Path:
        path = self.log_dir / name
        with path.open("a" if append else "w", encoding="utf-8") as fh:
            fh.write(text)
        return path

    def bless(self, output: Path, gold: Path) -> None:
        """--update-gold: accept the current output as the new expected result."""
        gold.parent.mkdir(parents=True, exist_ok=True)
        if output.is_dir():  # output folder (old `diff OUTPUT_DIR GOLD_DIR` tests)
            shutil.copytree(output, gold, dirs_exist_ok=True)
        else:
            shutil.copyfile(output, gold)
        self.log(f"gold updated: {gold}")

    # -- appnode log: only the part written during this test ---------------------------------
    def mark_log(self) -> None:
        log = self.runtime.appnode_log
        self._log_offset = log.stat().st_size if log.is_file() else 0

    def appnode_log_slice(self) -> str:
        log = self.runtime.appnode_log
        if not log.is_file():
            return ""
        with log.open("rb") as fh:
            fh.seek(self._log_offset)
            return fh.read().decode("utf-8", errors="replace")

    # -- environment for shell steps and legacy scripts (same names as t-tests 4.0) ----------
    def env_vars(self) -> dict[str, str]:
        s = self.settings
        version = self.runtime.session.version
        tsi = {
            "TSI_TID": self.test.id,
            "TSI_TEST_ID": self.test.test_id,  # bw.6983 -> bw_6983 (from the ID, as in t-tests)
            "TSI_REPO_NAME": self.test.project,
            "TSI_REPO_DIR": _posix(self.case_dir),
            "TSI_LOG_DIR": _posix(self.log_dir),
            "TSI_TESTPLAN_DIR": _posix(self.suite.assets_dir),
            "TSI_COMPONENT": self.suite.name,
            "TSI_TEST_CATEGORY": "migration" if self.suite.type == "bw_migration" else "engine",
            "TSI_TEST_SEQUENCE": str(self.seq),
            "TSI_TEST_OUTPUT_FILE": _posix(self.output_file),
            "TSI_TEST_GOLD_FILE": _posix(self.gold_file),
            "TSI_TEST_INPUT_FILE": _posix(self.input_file),
            "TSI_TEST_DIFF_FILE": _posix(self.log_dir / "diff.txt"),
            "TSI_TEST_ERROR_FILE": _posix(self.log_dir / "error.log"),
            "TSI_TEST_PRODUCT_ROOT": _posix(s.paths.assets_root),
            # t-tests: TSI_TESTS=C:/D/Automation/tests, TSI_COMPONENT_DIR=bw/func/engine/<suite> (relative to it),
            # TSI_LOG_HOME/TSI_LOG_ROOT = the report folder. Old t_setup.sh scripts build paths from them.
            "TSI_TESTS": _posix(Path(s.paths.assets_root).parent),
            "TSI_COMPONENT_DIR": _relative_posix(self.suite.assets_dir, Path(s.paths.assets_root).parent),
            "TSI_LOG_HOME": _posix(self.runtime.dir.parent),
            "TSI_LOG_ROOT": self.runtime.dir.name,
            "TSI_TDESCRIPTION": self.test.description,
            "TSI_TEST_OWNER": getattr(self.suite, "owner", "") or "",
            "TIB_BW_HOME": _posix(s.bw.home),
            "TSI_PROD_VERSION_3DIGIT": version.three_digit if version else "",
            "TSI_PROD_BUILD": str(version) if version else "",
            "OS_PLATFORM": "Windows" if s.is_windows else "Linux",
        }
        user = {k: str(v) for k, v in self.vars.items() if _IDENT.fullmatch(k)}
        return {**self._platform_vars(), **user, **tsi}

    def _platform_vars(self) -> dict[str, str]:
        """Fixed values every t-tests 4.0 job exported (t_tests_<id>_env_1.sh). Old scripts branch on them, e.g.
        http-pcm_comp/t_setup.sh: `case ${NPORT} in i86-win*) Linux_Var=1` - without NPORT the BW process ran its
        external `sort` the Linux way, the sorted output never appeared and t_verify.sh failed (exit -1 = 255).
        Lowest precedence: suite / test vars override them."""
        import socket

        s = self.settings
        win = s.is_windows
        nport = "i86-winnt50" if win else "linux_x86_64"
        try:
            ip = socket.gethostbyname(socket.gethostname())
        except OSError:
            ip = "127.0.0.1"
        test_type = "BW_MIGRATION" if self.suite.type == "bw_migration" else "BW_ENGINE"
        helpers = ({"CMD": "cmd /c", "x": ".exe", "t_sh": ".bat", "t_path_sep": ";", "t_set": "set ",
                    "t_sh_rem": "rem "} if win else
                   {"CMD": "", "x": "", "t_sh": ".sh", "t_path_sep": ":", "t_set": "export ", "t_sh_rem": "# "})
        return {
            "NPORT": nport, "REPORTING_NPORT": nport,
            "HOSTNAME": socket.gethostname(), "TSI_TEST_IPADDR": ip,
            "TSI_TEST_PRODUCT": s.ttests_report.product, "TSI_TEST_AREA": "func", "TSI_TEST_TYPE": test_type,
            "BW_ENGINE": "BW_ENGINE",
            "TSI_PROJECT_NAME": self.test.project, "TSI_TEST_RUNID": self.test.test_id,
            "T_TESTS_COMPONENT_WITHOUT_ITERATION_SUFFIX": self.suite.name,
            "TSI_TSETUP": "t_setup.sh", "TSI_TACTION": "t_action.sh", "TSI_TVERIFY": "t_verify.sh",
            "TSI_TEST_DIR_CMD": _posix(Path(self.suite.assets_dir).parent),
            "TSI_TEST_ENGINE_IDX": "1", "TSI_TEST_LOCALE": "en_US", "TSI_TEST_GLOBALIZATION_FLAG": "false",
            **{name: _posix(Path(s.bw.home).parent.parent) for name in s.bw.install_home_vars},  # <install>/bw/6.12
            "TIB_BW_VERSION": Path(s.bw.home).name,  # 6.12
            "T_TESTS_VERSION": "4.0", "TSI_PROG_NAME": "t-tests", "t_testsStripCR": "true",
            **helpers,  # Windows helpers the scripts use to build commands (t-tests: CMD, x, t_sh, t_path_sep ...)
        }

    def run_legacy_script(self, name: str, capture_exports: bool = False) -> ScriptResult:
        script = Path(name) if Path(name).is_absolute() else self.suite.assets_dir / name
        result = run_script(script, self.env_vars(), bash=find_bash(self.settings.paths.bash),
                            cwd=self.log_dir, capture_exports=capture_exports)
        self.write_artifact(f"legacy_{Path(name).stem}.log", result.output)
        return result


# ==============================================================================================
class TestExecutor:
    """Executes test cases of one suite inside an already started SuiteEnvironment."""

    def __init__(self, runtime: SuiteEnvironment, client_vars: dict[str, str]):
        self.runtime = runtime
        self.settings = runtime.settings
        self.suite = runtime.suite
        self.client_vars = client_vars
        self.last_ctx: TestContext | None = None

    # -- step 1: resolve paths and variables ------------------------------------------------
    def prepare(self, test: TestSpec, seq: int = 1) -> TestContext:
        s, suite, rt = self.settings, self.suite, self.runtime
        log_dir = rt.dir / test.safe_id / (f"seq-{seq}" if test.sequences > 1 else "")
        if log_dir.exists():
            shutil.rmtree(log_dir)
        log_dir.mkdir(parents=True)

        version = rt.session.version
        base = {
            # ${id} = old TSI_TEST_ID, derived from the test ID (bw.6983 -> bw_6983) - file names like
            # bw_6983_gold.log use it. ${project} = BW project / EAR name (may differ: petstore_sample).
            "id": test.test_id, "project": test.project, "tid": test.id, "suite": suite.name,
            "suite_dir": _posix(suite.assets_dir), "assets_dir": _posix(suite.assets_dir),
            "assets_root": _posix(s.paths.assets_root), "log_dir": _posix(log_dir),
            "http_port": str(rt.http_port), "domain": rt.session.domain, "appspace": rt.appspace,
            "appnode": rt.appnode, "bw_home": _posix(s.bw.home),
            "bw_version": version.dotted if version else "", "bw_build": version.build if version else "",
            "seq": str(seq),
        }
        case_dir = Path(render(test.case_dir, base))
        base["case_dir"] = _posix(case_dir)
        gold_name = test.gold
        if version and version.three_digit in test.gold_by_version:
            gold_name = test.gold_by_version[version.three_digit]
        # File names may use suite/test vars (e.g. input: ${TSI_TEST_ATTACHMENT_DIR}/a.gif); those are
        # rendered after the vars below. Absolute paths stay absolute (case_dir / "C:/x" == "C:/x").
        templates = {"output": (log_dir, test.output), "gold": (case_dir, gold_name), "input": (case_dir, test.input)}
        deferred: dict[str, tuple[Path, str]] = {}
        for key, (folder, template) in templates.items():
            try:
                base[key] = _posix(folder / render(template, base))
            except ConfigError:
                deferred[key] = (folder, template)

        # Precedence (low -> high): global vars < suite .cfg client vars < suite vars < test vars < framework
        user: dict[str, str] = {}
        for layer in (s.vars, self.client_vars, suite.vars, test.vars, test.sequence_vars.get(seq, {})):
            for key, value in layer.items():  # sequential: a var may reference one defined above it
                user[key] = render(value, {**base, **user}, strict=False)
        for key, (folder, template) in deferred.items():
            base[key] = _posix(folder / render(template, {**base, **user}))
        output, gold, input_file = Path(base["output"]), Path(base["gold"]), Path(base["input"])
        vars_ = {**user, **base, "var": user}
        ctx = TestContext(rt, suite, test, log_dir, case_dir, output, gold, input_file, vars_, seq)

        # Legacy setup script (bridge): its exports override everything above.
        setup = test.legacy.get("setup") or suite.legacy.get("setup")
        if setup and not s.dry_run:
            result = ctx.run_legacy_script(setup, capture_exports=True)
            if result.returncode != 0:
                ctx.log(f"legacy setup exited {result.returncode} (continuing, like t-tests did)")
            for key, value in result.exported.items():
                ctx.vars[key] = value
            if "TSI_TEST_OUTPUT_FILE" in result.exported:
                ctx.output_file = Path(result.exported["TSI_TEST_OUTPUT_FILE"])
            if "TSI_TEST_GOLD_FILE" in result.exported:
                ctx.gold_file = Path(result.exported["TSI_TEST_GOLD_FILE"])
            if "TSI_TEST_INPUT_FILE" in result.exported:
                ctx.input_file = Path(result.exported["TSI_TEST_INPUT_FILE"])

        gold_info = resolve_gold(ctx.gold_file, version.three_digit if version else None)
        ctx.gold_file = gold_info.path
        ctx.vars.update(output=_posix(ctx.output_file), gold=_posix(ctx.gold_file), input=_posix(ctx.input_file))
        ctx.output_file.parent.mkdir(parents=True, exist_ok=True)
        ctx.output_file.unlink(missing_ok=True)
        return ctx

    # -- step 2: module properties ---------------------------------------------------------
    def write_profile(self, ctx: TestContext, ear: Path, app_name: str) -> Path:
        values = {**{k: v for k, v in ctx.vars.items() if isinstance(v, str)}, **ctx.env_vars()}
        template = read_default_substvar(ctx.case_dir, app_name, ear)
        xml, applied, unset = build_profile(template, values)
        profile = ctx.log_dir / "t-tests.substvar"
        profile.write_bytes(xml)
        lines = [f"{k} = {v}" for k, v in sorted(applied.items())]
        lines += [f"{k} = <not set by T-Next - EAR default used>" for k in sorted(unset)]
        ctx.write_artifact("module_properties.txt", "\n".join(lines) + "\n")
        return profile

    # -- optional step: BW5 -> BW6 migration ------------------------------------------------
    def migrate(self, ctx: TestContext) -> Path:
        """bwmigrator + bwdesign export (old t-testsMigrateRepoTC + t-generateEarAtTC)."""
        cli = self.runtime.cli
        project = ctx.test.project
        migrated = ctx.log_dir / "migrated"
        workspace = ctx.log_dir / "workspace"
        args = [*cli.tool("bwmigrator"), "-projectDir", str(migrated)]
        classpath = self.suite.migration.get("classpath")
        if classpath:
            args += ["-classpath", ctx.render(str(classpath))]
        args.append(str(ctx.case_dir / project))
        cli.run(args, note=f"migrate {project}", timeout=int(self.suite.migration.get("timeout", 1200)))

        name = f"T{project}" if project[:1].isdigit() else project  # BW6 project names can't start with a digit
        ear_dir = ctx.log_dir / "ear"
        commands = ctx.write_artifact("ear-commands.txt", "\n".join([
            f"import -f {_posix(migrated)}",
            f"create application {name}.application {name}",
            f"export -ear -force {name}.application -name {name}.application {_posix(ear_dir)}",
            "quit", ""]))
        cli.run([*cli.tool("bwdesign"), "-data", str(workspace), "execute", str(commands)],
                note=f"build EAR {name}", timeout=1200)
        ctx.vars["app_name"] = f"{name}.application"
        return ear_dir / f"{name}.application.ear"

    # -- the whole test ---------------------------------------------------------------------
    def run(self, test: TestSpec) -> TestContext:
        """Run all sequences (old TestSequence) - the test fails on the first failing sequence."""
        ctx: TestContext | None = None
        for seq in range(1, test.sequences + 1):
            ctx = self.run_once(test, seq)
        assert ctx is not None
        return ctx

    def run_once(self, test: TestSpec, seq: int = 1) -> TestContext:
        ctx = self.prepare(test, seq)
        self.last_ctx = ctx
        ctx.log(f"START {self.suite.name}/{test.id} seq {seq} - {test.description}")
        if self.suite.type == "bw_migration":
            ear = self.migrate(ctx)
            app_name = ctx.vars["app_name"]
        else:
            ear = ctx.case_dir / ctx.render(test.ear)
            app_name = ctx.render(test.app_name)
        if not ear.is_file() and not self.settings.dry_run:
            raise EnvironmentSetupError(f"EAR not found: {ear}")

        profile = self.write_profile(ctx, ear, app_name)
        version = self.settings.bw.app_version or _app_version(ctx.case_dir / app_name, ear)
        ctx.mark_log()
        deployment: Deployment | None = None
        clock = time.monotonic()

        def lap(phase: str) -> None:
            nonlocal clock
            now = time.monotonic()
            ctx.timings[phase] = round(ctx.timings.get(phase, 0.0) + now - clock, 2)
            clock = now

        try:
            deployment = self.runtime.deploy(ear, profile, app_name, version)
            lap("deploy")
            steps = list(test.action)
            legacy_action = test.legacy.get("action") or self.suite.legacy.get("action")
            if legacy_action:
                steps.append({"legacy": legacy_action})
            run_actions(steps, ctx)
            lap("action")
        finally:
            # Same order as t-tests (DefaultEngineRun.tVerify): stop + undeploy the app FIRST, then compare -
            # the app has flushed/closed its output files and cannot append to them during the comparison.
            if deployment is not None:
                self.runtime.undeploy(deployment)
            ctx.write_artifact("bwappnode.log", ctx.appnode_log_slice())
            lap("cleanup")
            ctx.log("time: " + ", ".join(f"{k} {v:.1f}s" for k, v in ctx.timings.items()))
        if self.settings.dry_run:
            ctx.log("dry-run: verification skipped")
            return ctx
        verify = test.verify
        legacy_verify = test.legacy.get("verify") or self.suite.legacy.get("verify")
        if legacy_verify:
            verify = {"type": "legacy", "script": legacy_verify}
        try:
            run_verifications(verify, ctx)
        except VerificationFailed:
            # keep the new output - can be accepted as gold later (gold.py). Not for known failures: their
            # output is wrong because of an open bug, it must never become the expected result.
            if ctx.gold_candidates and not ctx.update_gold and not getattr(test, "known_to_fail", ""):
                save_gold_changes(ctx)
            raise
        finally:
            lap("verify")
        ctx.log("PASS")
        return ctx


def _app_version(app_dir: Path, ear: Path) -> str:
    """'1.0.0.qualifier' in the application MANIFEST -> '1.0' (what bwadmin expects)."""
    import zipfile

    text = ""
    manifest = app_dir / "META-INF" / "MANIFEST.MF"
    if manifest.is_file():
        text = manifest.read_text(encoding="utf-8", errors="replace")
    elif ear.is_file():
        try:
            with zipfile.ZipFile(ear) as zf:
                text = zf.read("META-INF/MANIFEST.MF").decode("utf-8", errors="replace")
        except (KeyError, zipfile.BadZipFile):
            text = ""
    match = re.search(r"^Bundle-Version:\s*(\d+)\.(\d+)", text, re.M)
    return f"{match.group(1)}.{match.group(2)}" if match else "1.0"
