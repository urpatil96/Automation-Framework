// "Sync with test folder": take what is new in the user's own t-tests test folder (<assets_root>/func):
//   new suites (.testset without a suite file)  -> imported, grouped like the others
//   new test cases in suites T-Next already has -> appended to the suite file (existing tests are not changed)
//   tests no longer in the .testset             -> only shown (never deleted)
// Used by the Suites page, the Doctor page and File > Sync with test folder.
import { api } from "../core/api.js";
import { h, mount } from "../core/dom.js";
import { plural } from "../core/format.js";
import { button, callout, kv, loading, modal, notifyChanged, toast } from "./ui.js";

export async function openImportDialog(onDone) {
  const body = h("div", {}, loading("Comparing T-Next with your test folder…"));
  const dlg = modal({ title: "Sync with test folder", body, wide: true });
  let pending;
  try {
    pending = await api.importPending();
  } catch (e) {
    mount(body, callout("bad", "Could not read the test folder:", e.message));
    return;
  }
  if (!pending.source_exists) {
    mount(body, callout("warn", "Test folder not found:", h("code", {}, pending.source),
      h("div", {}, "Set the test case location in Preferences (the folder that contains func).")));
    return;
  }
  const updates = pending.updates.filter((u) => u.new_tests.length);
  const goneOnly = pending.updates.filter((u) => u.gone_tests.length);
  if (!pending.suites.length && !updates.length) {
    mount(body, callout("ok", "Everything is in sync.", "T-Next has every suite and test case of ", h("code", {}, pending.source), "."),
      goneOnly.length ? goneList(goneOnly) : null);
    return;
  }

  const chosen = new Set([...pending.suites.map((s) => s.name), ...updates.map((u) => u.name)]);
  const startBtn = button("Sync", () => run(), "primary");
  const update = () => {
    mount(startBtn, `Sync selected (${chosen.size})`);
    startBtn.disabled = !chosen.size;
  };
  const box = (name) => h("input", { type: "checkbox", checked: true, "data-suite": name, onchange: (e) => {
    if (e.target.checked) chosen.add(name); else chosen.delete(name);
    update();
  } });
  const all = h("input", { type: "checkbox", checked: true, onchange: (e) => {
    body.querySelectorAll("input[data-suite]").forEach((b) => {
      b.checked = e.target.checked;
      if (e.target.checked) chosen.add(b.dataset.suite); else chosen.delete(b.dataset.suite);
    });
    update();
  } });

  const byFolder = {};
  for (const s of pending.suites) (byFolder[s.folder.split("/")[0] || "func"] ||= []).push(s);
  const newTests = updates.reduce((n, u) => n + u.new_tests.length, 0);

  mount(body,
    callout("info", "Your test folder has things T-Next does not have yet:",
      h("div", {}, "Source: ", h("code", {}, pending.source)),
      h("div", {}, "Only new files / new test entries are written to suites/. Existing tests and your changes to them stay, ",
        "the EARs, gold files and scripts stay where they are.")),
    h("label", { class: "check", style: { margin: "12px 0 6px" } }, all, h("span", {}, h("b", {}, "Select all"))),
    h("div", { class: "import-list" },
      pending.suites.length ? h("div", { class: "import-group" },
        h("div", { class: "import-group-title" }, `New suites (${pending.suites.length})`),
        Object.keys(byFolder).sort().map((group) => h("div", {},
          h("div", { class: "muted small", style: { margin: "4px 0 2px 14px" } }, `📁 ${group}`),
          byFolder[group].map((s) => h("label", { class: "check" }, box(s.name),
            h("span", {}, h("b", {}, s.name), "  ", h("span", { class: "muted small mono" }, s.folder))))))) : null,
      updates.length ? h("div", { class: "import-group" },
        h("div", { class: "import-group-title" }, `New test cases in existing suites (${newTests})`),
        updates.map((u) => h("label", { class: "check" }, box(u.name),
          h("span", {}, h("b", {}, u.name), "  +", plural(u.new_tests.length, "test"), ": ",
            h("span", { class: "muted small mono" }, u.new_tests.slice(0, 12).join(", ") + (u.new_tests.length > 12 ? " …" : "")))))) : null),
    goneOnly.length ? goneList(goneOnly) : null,
    h("div", { class: "dialog-actions", style: { padding: "14px 0 0" } },
      h("button", { class: "btn", onclick: () => dlg.close() }, "Cancel"), startBtn));
  update();

  async function run() {
    mount(body, loading(`Syncing ${plural(chosen.size, "suite")}…`));
    const r = await api.importSuites({ names: [...chosen] });
    notifyChanged();
    const parts = [r.imported.length ? `${plural(r.imported.length, "new suite")} (${r.tests.toLocaleString()} tests)` : "",
                   r.added_tests ? `${plural(r.added_tests, "new test case")} added` : ""].filter(Boolean);
    mount(body,
      callout(r.failed.length ? "warn" : "ok", `${parts.join(", ") || "Nothing changed"}.`,
        r.failed.length ? h("div", {}, `${r.failed.length} could not be synced - see below.`) : null),
      kv([
        ["New suites", r.imported.map((s) => `${s.name} (${s.tests})`).join(", ") || "—"],
        ["Tests added", r.added.map((a) => `${a.name}: ${a.tests.join(", ")}`).join("; ") || "—"],
        ...r.failed.map((f) => [`✗ ${f.name}`, f.error]),
        r.report ? ["Import report", h("span", { class: "mono" }, r.report)] : null,
      ].filter(Boolean)),
      h("h3", {}, "Next"),
      h("ol", {},
        h("li", {}, "Check them without BW: New run → tick the suites → ", h("b", {}, "Dry run"), "."),
        h("li", {}, "Then run one suite for real and compare with its last t-tests result."),
        h("li", {}, "Using Git for the suites? Commit the changed files in suites/.")),
      h("div", { class: "dialog-actions", style: { padding: "14px 0 0" } },
        h("button", { class: "btn primary", onclick: () => dlg.close() }, "Close")));
    toast(parts.join(", ") || "Nothing changed");
    if (onDone) onDone(r);
  }
}

function goneList(list) {
  return callout("info", "In T-Next but no longer in the .testset (kept - delete them on the suite page if unwanted):",
    h("ul", { style: { margin: "6px 0 0 18px", padding: 0 } },
      list.map((u) => h("li", {}, h("b", {}, u.name), ": ", h("span", { class: "mono small" }, u.gone_tests.join(", "))))));
}
