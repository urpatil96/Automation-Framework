@echo off
rem ============================================================================================
rem  bwtest - full backup of the framework into ONE zip file. Double-click it any time.
rem
rem  Contains everything needed to restore your bwtest exactly as it is now:
rem    program (src), suites, config INCLUDING your config\local.yaml, your .env (passwords!),
rem    docs, tests, setup, and results\ (runs, reports, suite backups).
rem  Left out (can be re-created): .venv (run setup\setup-bwtest.bat after a restore), caches.
rem
rem    setup\backup-bwtest.bat               backup with results
rem    setup\backup-bwtest.bat --no-results  smaller backup without results\
rem
rem  Written to:  <parent folder>\bwtest-backups\bwtest-backup-<version>-<date>.zip
rem  Restore:     unzip it, then run setup\setup-bwtest.bat (choose the same install folder).
rem  !! The backup contains your .env passwords - keep it private, do not share it.
rem ============================================================================================
setlocal EnableExtensions EnableDelayedExpansion
for %%R in ("%~dp0..") do set "ROOT=%%~fR"
cd /d "%ROOT%"
title bwtest backup

set "SKIP_RESULTS="
if /i "%~1"=="--no-results" set "SKIP_RESULTS=results"

set "VER=unknown"
if exist ".venv\Scripts\bwtest.exe" for /f "tokens=2" %%V in ('".venv\Scripts\bwtest.exe" --version') do set "VER=%%V"
for /f %%D in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmm"') do set "STAMP=%%D"
for %%P in ("%ROOT%\..") do set "OUTDIR=%%~fP\bwtest-backups"
if not exist "%OUTDIR%" mkdir "%OUTDIR%"
set "NAME=bwtest-backup-%VER%-%STAMP%"
set "STAGE=%TEMP%\%NAME%\bw6-autotest"
set "ZIP=%OUTDIR%\%NAME%.zip"

echo.
echo  Backing up %ROOT%
echo  to         %ZIP%
echo  ------------------------------------------------------------------
if exist "%TEMP%\%NAME%" rmdir /s /q "%TEMP%\%NAME%"
robocopy "%ROOT%" "%STAGE%" /E /NFL /NDL /NJH /NJS /NP ^
  /XD .venv __pycache__ .pytest_cache .ruff_cache .desktop-webview %SKIP_RESULTS% ^
  /XF *.pyc *.pyo >nul
if errorlevel 8 ( echo  [X] Copying failed. & goto :fail )
if defined SKIP_RESULTS ( echo  [OK] files collected ^(without results^) ) else ( echo  [OK] files collected ^(including results^) )

if exist "%ZIP%" del /q "%ZIP%"
powershell -NoProfile -Command "Compress-Archive -Path '%TEMP%\%NAME%\bw6-autotest' -DestinationPath '%ZIP%' -CompressionLevel Optimal"
if errorlevel 1 ( echo  [X] Creating the zip failed ^(disk full?^). & goto :fail )
rmdir /s /q "%TEMP%\%NAME%"

for %%Z in ("%ZIP%") do set "SIZE=%%~zZ"
set /a SIZEMB=SIZE/1048576
echo  [OK] %ZIP%   (!SIZEMB! MB)
echo.
echo  Restore: unzip it, then run setup\setup-bwtest.bat ^(it re-creates .venv^).
echo  The backup contains your passwords ^(.env^) - keep it private.
echo.
pause
exit /b 0

:fail
if exist "%TEMP%\%NAME%" rmdir /s /q "%TEMP%\%NAME%"
echo.
pause
exit /b 1
