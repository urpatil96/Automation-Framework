"""Old t-tests 4.0 .sql report for a finished bwtest run - for uploading the results to the QA results DB.

    results/<run>/ttests-report/t_func_engine_report_<yyyy-MM-dd_HH.mm.ss>.sql

Same file name and statements as t-tests wrote (tsi_tests_run / tsi_tests_set / tsi_tests_case /
tsi_tests_tc_desc), so it is uploaded the same way as before (e.g. sqlplus @t_func_engine_report_....sql).
Generated on demand (Run page > "t-tests .sql", or `bwtest ttests-report <run>`), never during a run.
Engine and migration suites go into separate files (func_engine / func_migration), as in t-tests.

Results: passed -> PASSED, failed -> FAILED, error -> ERROR, known failure -> FAILED (NOTE = the Jira),
fixed known failure -> PASSED; skipped / not run tests are not reported (t-tests did not report them either).
Values that are not part of a run (product name, platform, DB user ...) come from `ttests_report:` in
config/bwtest.yaml.

Format reference: tests/bw/reports/i86-winnt50/bw-6120-V188-HF05/t_func_engine_report_2026-11-09_12.35.55.sql
"""

from __future__ import annotations

import re
import socket
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from .config import TtestsReportSettings

OUT_DIR = "ttests-report"
_RESULT = {"passed": "PASSED", "xpassed": "PASSED", "failed": "FAILED", "xfailed": "FAILED", "error": "ERROR"}
_DATE = "yyyy/mm/dd-hh24:mi:ss"


@dataclass
class _Case:
    suite: str
    id: str
    description: str
    result: str  # PASSED | FAILED | ERROR
    note: str | None
    started: float | None
    ended: float | None


@dataclass
class _Set:
    name: str
    owner: str
    folder: str  # suite folder relative to the run folder (LOG_URL of the set)
    cases: list[_Case]

    def count(self, result: str) -> int:
        return sum(1 for c in self.cases if c.result == result)


# ---------------------------------------------------------------------------------------------------------
def generate(run_dir: Path, detail: dict, settings: TtestsReportSettings, project_root: Path) -> list[Path]:
    """Write the t-tests .sql file(s) for one run. `detail` = RunManager.detail(). Returns the files written."""
    info = detail.get("info") or {}
    env = detail.get("environment") or {}
    started = _parse_time(info.get("started")) or datetime.fromtimestamp(run_dir.stat().st_mtime)
    ended = _parse_time(info.get("ended")) or started
    version = _version(env, info, settings.product)
    host = (settings.hostname or socket.gethostname()).upper()
    run_id = f"{host}-{started:%Y/%m/%d-%H:%M:%S}"
    stamp = f"{started:%Y-%m-%d_%H.%M.%S}"
    owners = _suite_owners(project_root, detail.get("tests", []))
    out = run_dir / OUT_DIR
    out.mkdir(exist_ok=True)

    by_category: dict[str, list[_Set]] = {}
    for category, sets in _group(detail.get("tests", []), owners, info.get("tester") or "").items():
        if sets:
            by_category[category] = sets

    written: list[Path] = []
    for category, sets in sorted(by_category.items()):
        sql = out / f"t_func_{category}_report_{stamp}.sql"
        sql.write_text(_sql(sets, category, run_id, host, started, ended, version, settings), encoding="utf-8",
                       newline="\n")
        written.append(sql)
    return written


# ---------------------------------------------------------------------------------------------------------
@dataclass
class _Version:
    major_minor: str  # 6.12
    build_label: str  # BW 6.12.0 build V188 HF05
    log_label: str  # bw-6120-V188-HF05


def _version(env: dict, info: dict, product: str = "bw") -> _Version:
    label = str(env.get("bw_version") or info.get("profile") or "")  # "6.12.0 HF5" / "6.12.1"
    build = str(env.get("bw_build") or info.get("build") or "")
    m = re.match(r"(\d+)\.(\d+)\.(\d+)(?:\s+HF(\d+))?", label)
    if not m:
        return _Version(label, f"{product.upper()} {label} build {build}".strip(), f"{product}-{label}-{build}")
    major, minor, update, hf = m.groups()
    hf_part = f" HF{int(hf):02d}" if hf else ""
    return _Version(f"{major}.{minor}", f"{product.upper()} {major}.{minor}.{update} build {build}{hf_part}",
                    f"{product}-{major}{minor}{update}-{build}" + (f"-HF{int(hf):02d}" if hf else ""))


def _parse_time(value: Any) -> datetime | None:
    if not value:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(str(value)[:19], fmt)
        except ValueError:
            continue
    return None


def _suite_owners(project_root: Path, tests: list[dict]) -> dict[str, str]:
    """owner: of each suite file (the t-tests testset owner)."""
    from .models import load_suite

    owners: dict[str, str] = {}
    for t in tests:
        suite, nodeid = t.get("suite", ""), t.get("nodeid", "")
        if suite in owners or "::" not in nodeid:
            continue
        try:
            owners[suite] = load_suite(project_root / nodeid.split("::")[0]).owner or ""
        except Exception:  # noqa: BLE001 - suite file moved/renamed since the run: owner is optional
            owners[suite] = ""
    return owners


def _category(nodeid: str) -> str:
    parts = nodeid.replace("\\", "/").split("/")
    return "migration" if len(parts) > 1 and parts[0] == "suites" and parts[1] == "migration" else "engine"


def _group(tests: list[dict], owners: dict[str, str], tester: str) -> dict[str, list[_Set]]:
    result: dict[str, dict[str, _Set]] = {}
    for t in tests:
        res = _RESULT.get(t.get("outcome", ""))
        if res is None:  # skipped / not run: t-tests did not report disabled tests either
            continue
        folder = (Path(t["artifacts"]).parent.as_posix() if t.get("artifacts") else t["suite"]) or t["suite"]
        start = t.get("started")
        end = start + float(t.get("duration") or 0) if start else None
        note = f"known to fail: {t['message']}"[:1000] if t.get("outcome") == "xfailed" and t.get("message") else None
        cat = result.setdefault(_category(t.get("nodeid", "")), {})
        s = cat.setdefault(t["suite"], _Set(t["suite"], owners.get(t["suite"]) or tester, folder, []))
        s.cases.append(_Case(t["suite"], t["id"], t.get("description") or "", res, note, start, end))
    return {k: list(v.values()) for k, v in result.items()}


# ---------------------------------------------------------------------------------------------------------
def _q(value: Any) -> str:
    """SQL string literal content: one line, quotes doubled."""
    return re.sub(r"\s*[\r\n]+\s*", " ", str(value)).replace("'", "''")


def _lit(value: str | None) -> str:
    return "NULL" if value is None else f"'{_q(value)}'"


def _t(ts: float | datetime | None, fallback: datetime) -> str:
    if ts is None:
        return f"{fallback:%Y/%m/%d-%H:%M:%S}"
    dt = ts if isinstance(ts, datetime) else datetime.fromtimestamp(ts)
    return f"{dt:%Y/%m/%d-%H:%M:%S}"


def _sql(sets: list[_Set], category: str, run_id: str, host: str, started: datetime, ended: datetime,
         version: _Version, cfg: TtestsReportSettings) -> str:
    rid, prod, func = _q(run_id), _q(cfg.product), f"func_{category}"
    lines = [" ",
             "insert into tsi_tests_run(RUN_ID, HOSTNAME, PLATFORM, USER_NAME, START_TIME, END_TIME, PRODUCT_NAME, "
             "PRODUCT_VERSION, PRODUCT_BUILD, CATEGORY, STATUS, NUM_TC_STARTED, NUM_TC_PASSED, NUM_TC_FAILED, "
             "NUM_TC_MANUAL, NUM_TC_UNCERTAIN, LOG_URL, NOTE, T_TESTS_VERSION) "
             f"values('{rid}', '{_q(host)}', '{_q(cfg.platform)}', '{_q(cfg.db_user)}', "
             f"to_date('{_t(started, started)}', '{_DATE}'), null, '{prod}', '{_q(version.major_minor)}', "
             f"'{_q(version.build_label)}', '{category}', null, 0, 0, 0, 0, 0, "
             f"'{_q(cfg.platform)}/{_q(version.log_label)}', null, '{_q(cfg.t_tests_version)}' );"]
    for s in sets:
        first = min((c.started for c in s.cases if c.started), default=None)
        last = max((c.ended for c in s.cases if c.ended), default=None)
        name = _q(s.name)
        lines.append("insert into tsi_tests_set(RUN_ID, SEQ_NO, SET_NAME, OWNER, START_TIME, END_TIME, NUM_TC_STARTED, "
                     "NUM_TC_PASSED, NUM_TC_FAILED, NUM_TC_MANUAL, NUM_TC_UNCERTAIN, LOG_URL, NOTE) "
                     f"values('{rid}', null, '{name}', NULL, to_date('{_t(first, started)}','{_DATE}'), null, "
                     "0, 0, 0, 0, 0, null, null );")
        for c in s.cases:
            cid = _q(c.id)
            lines.append("insert into tsi_tests_case(RUN_ID, SET_NAME, CASE_ID, VARIANT_SEQ, TEST_RESULT, IS_MANUAL, "
                         f"NOTE) values('{rid}', '{name}', '{cid}', '1', '{c.result}', 'N', {_lit(c.note)} );")
            lines.append(f"delete from tsi_tests_tc_desc where product_name='{prod}' and category='{func}' "
                         f"and set_name='{name}' and case_id='{cid}' and variant_seq=1 ;")
            desc = _q(c.description)[:3900]
            lines.append("insert into tsi_tests_tc_desc(PRODUCT_NAME, CATEGORY, SET_NAME, CASE_ID, VARIANT_SEQ, "
                         f"CASE_DESC) values( '{prod}', '{func}', '{name}', '{cid}',  1, '{desc}' );")
        lines.append(f"update tsi_tests_set set seq_no=0, owner='{_q(s.owner)}', "
                     f"end_time=to_date('{_t(last, ended)}','{_DATE}'), num_tc_passed={s.count('PASSED')}, "
                     f"num_tc_failed={s.count('FAILED')}, num_tc_error={s.count('ERROR')}, log_url='{_q(s.folder)}' "
                     f"where run_id = '{rid}' and set_name='{name}' ;")
    passed = sum(s.count("PASSED") for s in sets)
    failed = sum(s.count("FAILED") for s in sets)
    error = sum(s.count("ERROR") for s in sets)
    lines.append(f"update tsi_tests_run set end_time=to_date('{_t(ended, ended)}','{_DATE}'), status='COMPLETED', "
                 f"NUM_TC_PASSED={passed}, NUM_TC_FAILED={failed}, num_tc_error={error} where run_id = '{rid}' ;")
    return "\n".join(lines) + "\n"
