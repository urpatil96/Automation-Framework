"""Module-property (substvar) handling.

How values reach a BW application (same contract as t-tests 4.0, so existing EARs work unchanged):

  1. The application's default.substvar lists its module properties, e.g. //bw_645//TSI_TEST_OUTPUT_FILE
  2. For every property whose short name (TSI_TEST_OUTPUT_FILE) matches a test variable, the value is
     replaced. Test variables = framework vars (TSI_TEST_OUTPUT_FILE, TSI_TEST_INPUT_FILE, ...)
     + client vars from .cfg files (app.clientVar.X) + suite/test `vars:`.
  3. The result is written as t-tests.substvar and passed to `bwadmin deploy -pf <file>`.
"""

from __future__ import annotations

import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

_CLIENT_VAR = re.compile(r"^[A-Za-z]\w*\.clientVar\.")  # <vendor>.clientVar.X=... in old .cfg files
_ns_seen = ""  # namespace of the last default.substvar read (used for an app without one)


def _ns(tag: str) -> str:
    return tag[1:].split("}", 1)[0] if tag.startswith("{") else ""


# ---------------------------------------------------------------------------------------------
# .cfg / .properties files (Java properties syntax: key=value, key: value, key value)
# ---------------------------------------------------------------------------------------------
def parse_properties(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    logical: list[str] = []
    buffer = ""
    for raw in text.splitlines():
        line = raw.lstrip()
        if not buffer and (not line or line[0] in "#!"):
            continue
        if line.endswith("\\") and not line.endswith("\\\\"):
            buffer += line[:-1]
            continue
        logical.append(buffer + line)
        buffer = ""
    if buffer:
        logical.append(buffer)
    for line in logical:
        match = re.match(r"((?:\\.|[^=:\s])+)\s*[=:\s]\s*(.*)$", line)
        if match:
            key, value = match.group(1), match.group(2)
        else:
            key, value = line.strip(), ""
        result[key.replace("\\", "")] = value.rstrip()
    return result


def split_cfg(props: dict[str, str]) -> tuple[dict[str, str], dict[str, str]]:
    """Split a legacy suite .cfg into (client vars, engine/appnode properties)."""
    client, engine = {}, {}
    for key, value in props.items():
        match = _CLIENT_VAR.match(key)
        if match:
            client[key[match.end():]] = value
        else:
            engine[key] = value
    return client, engine


def load_cfg_files(paths: list[Path]) -> tuple[dict[str, str], dict[str, str]]:
    client: dict[str, str] = {}
    engine: dict[str, str] = {}
    for path in paths:
        if not path.is_file():
            raise FileNotFoundError(f"client_vars_files: {path} does not exist")
        c, e = split_cfg(parse_properties(path.read_text(encoding="utf-8", errors="replace")))
        client.update(c)
        engine.update(e)
    return client, engine


# ---------------------------------------------------------------------------------------------
# substvar profile generation
# ---------------------------------------------------------------------------------------------
def read_default_substvar(case_dir: Path, app_name: str, ear: Path | None) -> bytes | None:
    """Find the application's default.substvar (project folder first, EAR as fallback)."""
    candidate = case_dir / app_name / "META-INF" / "default.substvar"
    if candidate.is_file():
        return candidate.read_bytes()
    if ear and ear.is_file():
        try:
            with zipfile.ZipFile(ear) as zf:
                names = [n for n in zf.namelist() if n.endswith("default.substvar")]
                if names:
                    return zf.read(sorted(names, key=len)[0])
        except zipfile.BadZipFile:
            return None
    return None


def short_name(gv_name: str) -> str:
    """'//bw_645//TSI_TEST_OUTPUT_FILE' -> 'TSI_TEST_OUTPUT_FILE'"""
    return gv_name.rstrip("/").split("//")[-1].split("/")[-1]


def build_profile(template: bytes | None, values: dict[str, str]) -> tuple[bytes, dict[str, str], list[str]]:
    """Return (profile xml, applied {name: value}, names in the app with no value)."""
    global _ns_seen
    ET.register_namespace("xsi", "http://www.w3.org/2001/XMLSchema-instance")
    applied: dict[str, str] = {}
    unset: list[str] = []
    if template is None:
        q = f"{{{_ns_seen}}}" if _ns_seen else ""
        if _ns_seen:
            ET.register_namespace("", _ns_seen)
        root = ET.Element(f"{q}repository")
        ET.SubElement(root, f"{q}globalVariables")
        return ET.tostring(root, encoding="utf-8", xml_declaration=True), applied, unset
    root = ET.fromstring(template)
    ns = _ns(root.tag)  # the namespace the application itself uses - written back unchanged
    if ns:
        _ns_seen = ns
        ET.register_namespace("", ns)
    q = f"{{{ns}}}" if ns else ""
    for gv in root.iter(f"{q}globalVariable"):
        name_el = gv.find(f"{q}name")
        if name_el is None or not name_el.text:
            continue
        name = short_name(name_el.text)
        value_el = gv.find(f"{q}value")
        if name in values:
            if value_el is None:
                value_el = ET.SubElement(gv, f"{q}value")
            value_el.text = values[name]
            applied[name] = values[name]
        elif (value_el is None or not (value_el.text or "").strip()) and not name.startswith("BW."):
            unset.append(name)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True), applied, unset
