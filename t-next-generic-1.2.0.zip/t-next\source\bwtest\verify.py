"""Verifiers - decide PASS / FAIL.

Replaces t_verify.sh (`diff output gold`, exit code 0 = pass) with typed comparisons that
understand the data and produce readable diffs in the report.

In a suite file:

    verify: text                                   # shorthand
    verify:
      type: text
      ignore_whitespace: true                      # old `diff -b`
      sort_lines: true                             # old `sort f1; sort f2; diff`
      ignore_lines: ['^Date:', 'JSESSIONID']       # drop volatile lines (regex)
      masks: [{pattern: '\\d{4}-\\d{2}-\\d{2}', replace: '<DATE>'}]
    verify:                                        # several checks, all must pass
      - {type: xml}
      - {type: log, absent: ['BW-.*-5\\d{5}']}    # no ERROR codes in the appnode log

Types: text, binary, xml, json, contains, log, exists, legacy (bash script), python (custom function).
Add your own with the @verifier("name") decorator.
"""

from __future__ import annotations

import difflib
import hashlib
import importlib
import json
import re
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any
from xml.etree import ElementTree as ET

from .errors import ConfigError, VerificationFailed
from .gold import offer

if TYPE_CHECKING:
    from .executor import TestContext

MAX_DIFF_LINES = 200
_VERIFIERS: dict[str, Callable[[dict, TestContext], None]] = {}


def verifier(name: str):
    def register(fn: Callable[[dict, TestContext], None]):
        _VERIFIERS[name] = fn
        return fn

    return register


def available() -> list[str]:
    return sorted(_VERIFIERS)


def run_verifications(spec: Any, ctx: TestContext) -> None:
    """Run every configured check; raise VerificationFailed listing all failures."""
    checks = spec if isinstance(spec, list) else [spec]
    failures: list[VerificationFailed] = []
    for check in checks:
        if isinstance(check, str):
            check = {"type": check}
        check = dict(check)
        kind = check.pop("type", "text")
        fn = _VERIFIERS.get(kind)
        if fn is None:
            raise ConfigError(f"Unknown verify type '{kind}'. Available: {available()}")
        pending = getattr(ctx, "gold_candidates", None)
        start = len(pending) if pending is not None else 0
        try:
            fn(check, ctx)
        except VerificationFailed as exc:
            failures.append(exc)
        else:
            if pending is not None:
                del pending[start:]  # this check passed - its output is not a gold change
    if failures:
        if len(failures) == 1:
            raise failures[0]
        raise VerificationFailed(
            f"{len(failures)} checks failed: " + "; ".join(str(f) for f in failures),
            "\n\n".join(f"[{i + 1}] {f}\n{f.details}" for i, f in enumerate(failures)),
        )


# ---------------------------------------------------------------------------------------------
def _need(path: Path, what: str) -> None:
    if not path.exists():
        hint = {
            "output": "the application did not write it - check bwappnode.log / the deploy step",
            "gold": "create it from a known-good run: bwtest run ... --update-gold",
        }[what]
        raise VerificationFailed(f"{what} file not found: {path} ({hint})")


def _read_text(path: Path) -> str:
    data = path.read_bytes()
    for enc in ("utf-8", "cp1252", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _normalise(text: str, opts: dict, ctx: TestContext) -> list[str]:
    text = text.replace("\r\n", "\n").replace("\r", "\n")  # old t-stripcr
    for mask in opts.get("masks", []) or []:
        text = re.sub(ctx.render(mask["pattern"]), ctx.render(mask.get("replace", "<MASKED>")), text)
    lines = text.split("\n")
    ignore = [re.compile(ctx.render(p)) for p in opts.get("ignore_lines", []) or []]
    if ignore:
        lines = [ln for ln in lines if not any(r.search(ln) for r in ignore)]
    if opts.get("ignore_whitespace"):
        lines = [" ".join(ln.split()) for ln in lines]
    if opts.get("ignore_case"):
        lines = [ln.lower() for ln in lines]
    if opts.get("ignore_blank_lines", True):
        lines = [ln for ln in lines if ln.strip()]
    if opts.get("sort_lines"):
        lines = sorted(lines)
    return lines


def _diff(expected: list[str], actual: list[str], ctx: TestContext) -> str:
    diff = list(difflib.unified_diff(expected, actual, "gold (expected)", "output (actual)", lineterm=""))
    text = "\n".join(diff[:MAX_DIFF_LINES])
    if len(diff) > MAX_DIFF_LINES:
        text += f"\n... {len(diff) - MAX_DIFF_LINES} more diff lines"
    ctx.write_artifact("diff.txt", text)
    return text


def _paths(opts: dict, ctx: TestContext) -> tuple[Path, Path]:
    output = Path(ctx.render(opts["output"])) if opts.get("output") else ctx.output_file
    gold = Path(ctx.render(opts["gold"])) if opts.get("gold") else ctx.gold_file
    return output, gold


# ---------------------------------------------------------------------------------------------
@verifier("text")
def verify_text(opts: dict, ctx: TestContext) -> None:
    output, gold = _paths(opts, ctx)
    _need(output, "output")
    offer(ctx, output, gold, "text")
    if ctx.update_gold:
        ctx.bless(output, gold)
        return
    _need(gold, "gold")
    if output.is_dir() or gold.is_dir():
        _verify_text_dirs(output, gold, opts, ctx)
        return
    expected = _normalise(_read_text(gold), opts, ctx)
    actual = _normalise(_read_text(output), opts, ctx)
    if expected != actual:
        raise VerificationFailed(f"output differs from gold {gold.name}", _diff(expected, actual, ctx))


def _verify_text_dirs(output: Path, gold: Path, opts: dict, ctx: TestContext) -> None:
    """Output and gold are folders (old `diff OUTPUT_DIR GOLD_DIR`): same file names, each file equal."""
    if not (output.is_dir() and gold.is_dir()):
        raise VerificationFailed(f"cannot compare a folder with a file: output={output} gold={gold}")
    out_files = {p.relative_to(output).as_posix() for p in output.rglob("*") if p.is_file()}
    gold_files = {p.relative_to(gold).as_posix() for p in gold.rglob("*") if p.is_file()}
    report: list[str] = []
    for name in sorted(gold_files - out_files):
        report.append(f"missing in output: {name}")
    for name in sorted(out_files - gold_files):
        report.append(f"not in gold (extra output): {name}")
    for name in sorted(out_files & gold_files):
        expected = _normalise(_read_text(gold / name), opts, ctx)
        actual = _normalise(_read_text(output / name), opts, ctx)
        if expected != actual:
            report.append(f"--- {name}")
            report += list(difflib.unified_diff(expected, actual, "gold (expected)", "output (actual)", lineterm=""))
    if report:
        text = "\n".join(report[:MAX_DIFF_LINES])
        ctx.write_artifact("diff.txt", text)
        raise VerificationFailed(f"output folder differs from gold folder {gold.name}", text)


@verifier("binary")
def verify_binary(opts: dict, ctx: TestContext) -> None:
    output, gold = _paths(opts, ctx)
    _need(output, "output")
    offer(ctx, output, gold, "binary")
    if ctx.update_gold:
        ctx.bless(output, gold)
        return
    _need(gold, "gold")
    a, b = output.read_bytes(), gold.read_bytes()
    if a != b:
        raise VerificationFailed(
            f"binary output differs from {gold.name}",
            f"output: {len(a)} bytes sha256={hashlib.sha256(a).hexdigest()[:16]}\n"
            f"gold:   {len(b)} bytes sha256={hashlib.sha256(b).hexdigest()[:16]}",
        )


def _canonical_xml(text: str, opts: dict) -> list[str]:
    root = ET.fromstring(text.encode("utf-8") if text.startswith("<?xml") else text)
    ignore_attrs = set(opts.get("ignore_attributes", []) or [])
    for el in root.iter():
        for attr in list(el.attrib):
            if attr in ignore_attrs or attr.split("}")[-1] in ignore_attrs:
                del el.attrib[attr]
        if el.text is not None and not el.text.strip():
            el.text = None
        if el.tail is not None and not el.tail.strip():
            el.tail = None
    canon = ET.canonicalize(ET.tostring(root, encoding="unicode"), strip_text=True)
    pretty = ET.fromstring(canon)
    ET.indent(pretty)
    return ET.tostring(pretty, encoding="unicode").splitlines()


@verifier("xml")
def verify_xml(opts: dict, ctx: TestContext) -> None:
    """Compare XML ignoring formatting, attribute order and namespace prefixes."""
    output, gold = _paths(opts, ctx)
    _need(output, "output")
    offer(ctx, output, gold, "xml")
    if ctx.update_gold:
        ctx.bless(output, gold)
        return
    _need(gold, "gold")
    try:
        actual = _canonical_xml(_read_text(output), opts)
    except ET.ParseError as exc:
        raise VerificationFailed(f"output is not well-formed XML: {exc}") from None
    expected = _canonical_xml(_read_text(gold), opts)
    expected = _normalise("\n".join(expected), opts, ctx)
    actual = _normalise("\n".join(actual), opts, ctx)
    if expected != actual:
        raise VerificationFailed(f"XML differs from {gold.name}", _diff(expected, actual, ctx))


def _strip_keys(value: Any, keys: set[str]) -> Any:
    if isinstance(value, dict):
        return {k: _strip_keys(v, keys) for k, v in value.items() if k not in keys}
    if isinstance(value, list):
        return [_strip_keys(v, keys) for v in value]
    return value


@verifier("json")
def verify_json(opts: dict, ctx: TestContext) -> None:
    output, gold = _paths(opts, ctx)
    _need(output, "output")
    offer(ctx, output, gold, "json")
    if ctx.update_gold:
        ctx.bless(output, gold)
        return
    _need(gold, "gold")
    keys = set(opts.get("ignore_keys", []) or [])
    try:
        actual = _strip_keys(json.loads(_read_text(output)), keys)
    except json.JSONDecodeError as exc:
        raise VerificationFailed(f"output is not valid JSON: {exc}") from None
    expected = _strip_keys(json.loads(_read_text(gold)), keys)
    if expected != actual:
        dump = lambda v: json.dumps(v, indent=2, sort_keys=True).splitlines()  # noqa: E731
        raise VerificationFailed(f"JSON differs from {gold.name}", _diff(dump(expected), dump(actual), ctx))


def _patterns_check(text: str, opts: dict, ctx: TestContext, source: str) -> None:
    missing = [p for p in opts.get("patterns", []) or [] if not re.search(ctx.render(p), text, re.M)]
    present = [p for p in opts.get("absent", []) or [] if re.search(ctx.render(p), text, re.M)]
    if missing or present:
        details = "".join(f"  missing : {p}\n" for p in missing) + "".join(f"  present : {p}\n" for p in present)
        raise VerificationFailed(f"{source}: {len(missing)} expected pattern(s) missing, "
                                 f"{len(present)} forbidden pattern(s) found", details)


@verifier("contains")
def verify_contains(opts: dict, ctx: TestContext) -> None:
    """Output must contain all `patterns` (regex) and none of `absent`."""
    output = Path(ctx.render(opts["file"])) if opts.get("file") else ctx.output_file
    _need(output, "output")
    _patterns_check(_read_text(output), opts, ctx, output.name)


@verifier("log")
def verify_log(opts: dict, ctx: TestContext) -> None:
    """Check the part of bwappnode.log written while THIS test ran."""
    _patterns_check(ctx.appnode_log_slice(), opts, ctx, "bwappnode.log")


@verifier("exists")
def verify_exists(opts: dict, ctx: TestContext) -> None:
    for pattern in opts.get("files", [str(ctx.output_file)]):
        path = Path(ctx.render(pattern))
        if not path.exists():
            raise VerificationFailed(f"expected file not created: {path}")
        if opts.get("non_empty", True) and path.is_file() and path.stat().st_size == 0:
            raise VerificationFailed(f"file is empty: {path}")


@verifier("legacy")
def verify_legacy(opts: dict, ctx: TestContext) -> None:
    """Run an old t_verify.sh unchanged through the bash bridge (exit code 0 = pass)."""
    script = opts.get("script", "t_verify.sh")
    # the old scripts compare TSI_TEST_OUTPUT_FILE with TSI_TEST_GOLD_FILE (= ctx.output_file / ctx.gold_file)
    if ctx.output_file.is_file():
        offer(ctx, ctx.output_file, ctx.gold_file, "legacy")
        if ctx.update_gold:
            ctx.bless(ctx.output_file, ctx.gold_file)
            ctx.log(f"update gold: {script} not run - output saved as gold")
            return
    result = ctx.run_legacy_script(script)
    if result.returncode != 0:
        raise VerificationFailed(f"legacy {script} returned {result.returncode}", result.output[-4000:])


@verifier("python")
def verify_python(opts: dict, ctx: TestContext) -> None:
    """Custom check: `function: mypackage.checks:check_order` - receives ctx, raises/returns False to fail."""
    target = opts.get("function", "")
    module_name, _, func_name = target.partition(":")
    if not func_name:
        raise ConfigError("python verify needs 'function: module:function'")
    fn = getattr(importlib.import_module(module_name), func_name)
    result = fn(ctx, **(opts.get("args") or {}))
    if result is False:
        raise VerificationFailed(f"{target} returned False")


@dataclass
class GoldInfo:
    path: Path
    version_specific: bool


def resolve_gold(gold: Path, three_digit: str | None) -> GoldInfo:
    """Version-specific gold files, same rule as old t_cond_set_goldfile_based_on_version:
    bw_645_gold.log + BW 6.12.1  ->  bw_645_gold_6121.log if that file exists."""
    if three_digit:
        candidate = gold.with_name(f"{gold.stem}_{three_digit}{gold.suffix}") if gold.suffix \
            else gold.with_name(f"{gold.name}_{three_digit}")
        if candidate.is_file():
            return GoldInfo(candidate, True)
    return GoldInfo(gold, False)
