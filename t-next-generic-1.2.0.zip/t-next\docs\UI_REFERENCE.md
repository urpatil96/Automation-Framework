# T-Next desktop UI reference: every button and field

This document describes every menu, button, field and indicator in the bwtest window
(`start-bwtest.bat`). For the step-by-step workflow see [USER_GUIDE.md](USER_GUIDE.md).

Every field reads or writes a normal framework file (`config/local.yaml`, `*.suite.yaml`,
`config/selections/*.yaml`, `results/<run>/`). The UI stores nothing of its own, so the UI, the command line and
Jenkins always agree.

---

## Contents

1. [Window layout](#1-window-layout)
2. [Menu bar](#2-menu-bar)
3. [Toolbar](#3-toolbar)
4. [Test explorer (left pane)](#4-test-explorer-left-pane)
5. [Status bar](#5-status-bar)
6. [Dashboard](#6-dashboard)
7. [New run wizard](#7-new-run-wizard)
8. [Run page (live progress and results)](#8-run-page)
9. [Runs & reports](#9-runs--reports)
10. [Suites](#10-suites)
11. [Suite page](#11-suite-page)
12. [New suite](#12-new-suite)
13. [Preferences](#13-preferences)
14. [Doctor](#14-doctor)
15. [Help & guide](#15-help--guide)
16. [Common controls and colours](#16-common-controls-and-colours)

---

## 1. Window layout

```
┌ bwtest - BusinessWorks 6 regression ─────────────────────────────────────────────── _ □ x ┐
│ File  Edit  Run  View  Help                                              ← 2. Menu bar      │
│ [▶ New run][☑ Select tests][■ Stop] │ [☰ Runs & reports][▤ Suites][+ New suite] │           │
│ [⚙ Preferences][✚ Doctor]                              [◧ Dashboard][? Help]  ← 3. Toolbar │
│ ┌ TEST EXPLORER ──────────┐ ┌──────────────────────────────────────────────────────────┐   │
│ │ [Filter suites…]        │ │                                                          │   │
│ │ ▾ 📂 Test suites     23 │ │        Page area: Dashboard, New run, Run page,          │   │
│ │    ▸ 📁 engine       22 │ │        Suites, Preferences, Doctor …                     │   │
│ │    ▸ 📁 migration     1 │ │                                                          │   │
│ │ ▾ 📂 Saved selections   │ │                                                          │   │
│ │ ▾ 📂 Recent runs        │ │                                                          │   │
│ └─ 4. Test explorer ──────┘ └──────────────────────────────────────────────────────────┘   │
│ Profile 6.12.1 │ C:/D/6.12.1/V12/bw/6.12 │ No run in progress │ 23 suites · 1,665 tests   │
└─ 5. Status bar ────────────────────────────────────────────────────────────────────────────┘
```

Minimum window size: 1000 × 640. **Ctrl + mouse wheel** zooms. Text can be selected and copied everywhere.

**Closing the window** while a run is going asks *"A run is in progress … Close bwtest now?"*. If you close
it, the run keeps going in the background and is shown again the next time you open bwtest.

---

## 2. Menu bar

| Menu | Item | What it does |
|---|---|---|
| **File** | New run… | Opens the New run wizard at step 1 |
| | New suite… | Opens the New suite form |
| | Open results folder | Opens `C:\D\bw6-autotest\results` in Windows Explorer |
| | Exit | Closes the window (asks first if a run is going) |
| **Edit** | Select test cases… | Opens New run at step 2 (test case picker); old *Edit → Select test cases* |
| | Suites | Opens the Suites list |
| | Preferences… | Opens Preferences |
| **Run** | New run… | Same as File → New run |
| | Current run | Opens the run in progress. If no run is going: message *"No run in progress"* |
| | Runs and reports | Opens the run history |
| | Check environment (Doctor) | Opens Doctor |
| **View** | Dashboard | Opens the Dashboard (start page) |
| | Refresh | Reloads the window (use it after editing files outside bwtest) |
| **Help** | Guide | Opens the Help & guide page |
| | About bwtest | Shows application, version info, project folder and doc file names |

---

## 3. Toolbar

| Button | Tooltip | What it does | Enabled |
|---|---|---|---|
| **▶ New run** (blue) | Start a new run | New run wizard, step 1 | always |
| **☑ Select tests** | Choose suites / test cases | New run wizard, step 2 | always |
| **■ Stop** (red) | Stop the run in progress after the current test | Asks *"Stop the run?"*. **Stop run** lets the current test finish, skips the remaining tests and cleans up BW (AppNode, AppSpace, domain). | only while a run is going |
| **☰ Runs & reports** | Run history and HTML reports | Runs & reports page | always |
| **▤ Suites** | Browse and edit suites | Suites page | always |
| **+ New suite** | Create a suite | New suite form | always |
| **⚙ Preferences** | Machine settings | Preferences page | always |
| **✚ Doctor** | Check the BW build and the setup | Doctor page | always |
| **◧ Dashboard** | Overview | Dashboard | always |
| **? Help** | Guide for new users | Help & guide page | always |

---

## 4. Test explorer (left pane)

| Element | What it shows / does |
|---|---|
| **Filter suites…** | Type to filter suites by name, description or tag. While filtering, all folders open automatically. |
| **📂 Test suites** *(count)* | All `suites/**/*.suite.yaml`, grouped by category folder (`engine`, `migration`, …). Count = suites shown. |
| Suite icon **▤** | Engine suite (`type: bw_engine`) |
| Suite icon **⇄** | Migration suite (`type: bw_migration`) |
| Suite icon **⚠** | The suite file is not valid YAML. Open it to see the error. |
| Number after a suite | Number of test cases in it |
| **Click** a suite | Opens the Suite page |
| **Double-click** a suite | Opens New run with that suite already ticked |
| **📂 Saved selections** | Files in `config/selections/` (old `.testcmd`). **Click** = New run at step 2 with the selection loaded. Empty: *"Save one on New run › Test cases"*. |
| **📂 Recent runs** | The last 8 runs, with state icon and age (*5 min ago*). **Click** = Run page. |
| Run state icons | ◔ running/stopping · ✔ passed · ✖ failed or killed · ⚠ error · ■ stopped · … incomplete · ∅ no tests |
| ▸ / ▾ on folders | Collapse / expand. The open/closed state is remembered. |

The highlighted row is the suite or run currently shown in the page area. The tree refreshes every 4 seconds.

---

## 5. Status bar

| Cell | Meaning | Click |
|---|---|---|
| **Profile 6.12.1** | Default BW version (Preferences) | opens Preferences |
| `C:/D/6.12.1/V12/bw/6.12` | BW home of that profile | — |
| **No run in progress** | Nothing is running | — |
| **● Run 20261119-101500 in progress** (pulsing) | A run is going | opens that run |
| **● server not reachable** (red) | The internal server stopped. Close the window and start `start-bwtest.bat` again. | — |
| **23 suites · 1,665 tests** | Totals of all suite files | — |

---

## 6. Dashboard

Start page (toolbar **◧ Dashboard**, menu **View → Dashboard**).

### Header
| Element | What it does |
|---|---|
| **Help & guide** | Opens the Help page |
| **▶ Start a new run** | Opens the New run wizard |
| Blue banner *"A run is in progress. Open run … to follow it live →"* | Shown only while a run is going. Click the link to open the run. |

### Counter tiles
| Tile | Value | Small text |
|---|---|---|
| **Suites** | number of suite files | *N engine · N migration* |
| **Test cases** | all test cases in all suites | *N native YAML* (every step written in YAML) |
| **With a .sh script step** | tests where one step is still the original t-tests `.sh` script (`t_setup.sh` / `t_action.sh` / `t_verify.sh`). **They run in bwtest like all others**: bwtest runs that script itself with Git Bash | *run by bwtest itself* |
| **Known to fail** (purple) | tests with `known_to_fail:` | *reported as expected failures* |

### Recent runs card
| Element | Meaning |
|---|---|
| **All runs** | Opens Runs & reports |
| Column **Started** | How long ago (*just now*, *5 min ago*, *3 h ago*, or the date) |
| Column **Run** | Run name (or the suites if no name), tester below |
| Column **Build** | Profile + build, e.g. *6.12.0 V188* |
| Column **Result** | Coloured bar (green passed / red failed / orange error / purple known / grey skipped) and counts |
| Last column | Run state pill: Running, Stopping…, Passed, Failures, Error, Stopped, Killed, Incomplete, No tests |
| Click a row | Opens that run |
| Empty state | *"No runs yet"* + **▶ New run** |

### Getting started / Setup card
Title is *Getting started* until the setup is complete and a run exists, then *Setup*.

| Item | Green ✓ when | Click goes to |
|---|---|---|
| Personal settings saved (Preferences) | `config/local.yaml` exists | Preferences |
| Test case location found | the *Test case location* folder exists | Preferences |
| BW install of profile X found | `bwadmin.exe` exists in the profile's BW home | Preferences |
| Environment check passed (Doctor) | always **?** (not checked automatically; it takes time) | Doctor |

Icons: **✓** green = ready, **!** red = needs fixing, **?** grey = not checked.

### Current defaults card
| Row | Source |
|---|---|
| Profile | Preferences → Default profile |
| BW home | profile's `bw.home` |
| Test cases | Preferences → Test case location (`paths.assets_root`) |
| Results | results folder |
| **Change** | Opens Preferences |

### Quick actions card
**Browse suites** (Suites page) · **Add a suite** (New suite) · **Check environment** (Doctor).

---

## 7. New run wizard

Opened by **▶ New run**, **☑ Select tests** (step 2), double-click on a suite, **Run** buttons on suite pages,
a saved selection, or **Run this test again**.

**Stepper (top):** *1 Product & build · 2 Test cases · 3 Report details · 4 Review & start*. Click a step
to jump to it. You can't go to step 2 without a build, or to step 3/4 without a selection. A yellow
message tells you what is missing.

**Bottom buttons:** **← Back** · **Next: <step name> →**.

### Step 1 – Product & build

| Field / button | What it is | Effect |
|---|---|---|
| **1. Product profile (BW version)** cards | One card per `config/profiles/<version>.yaml`. Shows *BW 6.12.1* and *N builds found* (or ⚠ error). The default profile has a blue **default** badge. | `--profile 6.12.1` |
| **2. Build to test** cards | Builds found under *BW installs folder*/`<version>/<build>/bw/<x.y>`. Title = build (*V12*), below = folder. Badge **profile default** = the profile's own `bw.home`. *(no bwadmin!)* = folder without `bin/bwadmin.exe`. | `--bw-home <folder>` |
| *No builds found for this profile* | Nothing under the installs folder for this version | install the build, or use the checkbox below |
| ☐ **Use another BW home folder** | Use a build outside the installs folder | shows the next field |
| **BW home (folder that contains bin/bwadmin)** + **Browse…** | Free path, e.g. `C:/D/6.12.1/V13/bw/6.12` | `--bw-home …` |
| **Check this build** | Runs the Doctor checks including `bwadmin version` (a few seconds) | Green *"Build looks good. bwadmin reports: …"* or yellow list of problems with hints. Nothing is saved. |

### Step 2 – Test cases

**Left card: Select test cases**

| Element | What it does |
|---|---|
| **Search suites or test ids** | Filters suites by name/description/tag/category, and tests of opened suites by id/description |
| **Type** dropdown | *All test types* / *Engine (BW_ENGINE)* / *Migration (BW_MIGRATION)* |
| **— load a saved selection —** | Loads a saved selection: suites, tests, tag expression, keyword. Unknown suites are ignored with a warning. |
| **Delete** | Deletes the saved selection chosen in the dropdown (asks first). Visible only if selections exist. |
| **▶ / ▼** in front of a suite | Opens / closes the suite's test list (loads on first open) |
| Suite checkbox | ☑ = whole suite · ▣ (partly) = some tests ticked · ☐ = none |
| Suite name / description | Click the name to open/close it |
| Pill **migration** | migration suite |
| *N with .sh step* | N tests have one step that is a t-tests `.sh` script (run by bwtest itself) |
| Pill **N known** | N tests are known to fail |
| *N tests* | test count |
| Test checkbox | Selects a single test. Ticking all tests of a suite turns it into "whole suite". Unticking one test of a whole suite switches to single tests. |
| Test pills | **BW-xxxxx** (known to fail) · **skip** · *.sh step* (one step is a t-tests `.sh` script, run by bwtest) |

**Right card: Your selection**

| Row / button | Meaning |
|---|---|
| Whole suites | suites ticked completely |
| Single tests | single tests ticked |
| **Test cases** | total number that will run |
| Yellow *Large run* | shown above 300 tests: suggests parallel workers |
| **Clear** | Unticks everything |
| **Save as selection…** | Asks for a **Name**, saves `config/selections/<name>.yaml` (old `.testcmd`). Appears in the Test explorer. Share it through git. |

Tag expression (`-m`) and keyword (`-k`) filters are not in the UI; use them on the command line if needed.

### Step 3 – Report details & options

**Report details** (shown in the run list and in `report.html`; old *Preferences → Report*)

| Field | Default | Stored as |
|---|---|---|
| **Run name** | empty (placeholder *6.12.1 V12 HTTP regression*) | `--name` |
| **Tester** | Preferences → Default tester name | `--tester` |
| **Jira** | empty, e.g. `BUG-58468` | `--jira` |
| **Notes** | empty, free text | `--notes` |

All four go to `results/<run>/run_info.json` and the *Environment* table of `report.html`.

**Run options**

| Field | Choices | Effect |
|---|---|---|
| **Parallel workers** | *1 - one suite after the other (safe default)* / 2 / 3 / 4 workers | `-n N`. Each worker gets its own domain `bwtest-N` and port block, and needs RAM for one AppNode. |
| ☐ **Dry run - only show the BW commands, run nothing** | off | `--dry-run`. Writes `commands.log`, no BW call, no verification. |
| ☐ **Update gold files with the new output** | off | `--update-gold`. Output overwrites gold. Only for new tests or intended changes; review the files afterwards. |
| ☐ **Keep the BW domain after the run** | off | `--bw-keep-domain`. The domain stays for inspection; delete it yourself. |

### Step 4 – Review & start

| Element | Meaning |
|---|---|
| **Review** card | Profile, Build (+ folder), Suites, Single tests, Test cases (*about N*), Run name, Tester, Jira, Options |
| Yellow *Update gold is on.* | Reminder that outputs will overwrite the gold files |
| Blue *Dry run.* | Reminder that nothing will run on BW |
| **Same run from a terminal** | The exact `bwtest run …` command for this choice |
| **Copy** | Copies the command to the clipboard (paste into a terminal or Jenkins) |
| **▶ Start run** | Starts the run and opens its Run page. Note: the first suite needs ~3 minutes to start its AppNode. |

If another run is going, this run gets its own domains and ports (see *Several runs at the same time* in the User Guide). Start run shows an error only if the other run has one of the same suites, all suites, more than 4 workers, or 4 runs are already going.

---

## 8. Run page

Opened after **Start run**, from Recent runs, Runs & reports, or the status bar.

### Header
Title = run name (or *Run <id>*) + state pill. Subtitle: *BW 6.12.0 · V188 · by jdoe · started 5 min ago · DRY RUN*.

| Button | When visible | What it does |
|---|---|---|
| **Stop after current test** (red) | run is going | Asks to confirm. The current test finishes, the remaining tests are not started, and AppNode/AppSpace/domain are cleaned up. Can take a few minutes; state shows *Stopping…*. |
| **Force kill** | run is going | Last resort. Kills at once, without cleanup. Afterwards end `bwappnode-<suite>.exe` in Task Manager and delete the `bwtest-N` domain folder. |
| **Open HTML report** | run finished and `report.html` exists | Opens the pytest-html report |
| **Re-run failed** (blue) | run finished with failures/errors | Starts a new run at once with only the Failed + Error tests. Keeps the same build, tester, Jira, notes and worker count. Name: *re-run of <id> (failed only)*. |
| **Run again** | run finished | Starts a new run at once with the same suites/tests, tag expression and keyword. Same build and report details. Dry run / Update gold / Keep domain are **not** carried over. |
| **Gold changes (N)** | run finished and failed tests have output that differs from the gold file | Lists each changed test with its diff (*Show the difference*) and *new output ↗*. Click **Accept as gold** on one test (accepts only that test; it is marked *accepted*, the others stay), or tick several (*Select all / Select none*) and click **Accept selected as gold**: the new output replaces the gold file in the test case folder; the old one goes to `gold-backup/` in the test's result folder. No re-run. Known failures are not listed. Same as `bwtest accept-gold <run-id>`. The yellow message *N failed test(s): the output differs from the gold file* above the counts has a **Review gold changes** button that opens the same dialog. In the test dialog: **Accept new output as gold…** for that test only. |
| **t-tests .sql** | run finished | Writes the old t-tests report `t_func_engine_report_<time>.sql` (and `t_func_migration_…` for migration suites) to `results/<id>/ttests-report/`, in exactly the t-tests format, for uploading to the QA results DB. The dialog shows **open ↗** per file and **Open folder**. Skipped / not-run tests are left out; known failures are FAILED with the Jira in NOTE. Values such as platform and DB user come from `ttests_report:` in `config/bwtest.yaml`. |
| **Delete** | run finished | Deletes `results/<id>/` with all logs (asks first) |

### Live panel (while running)
| Element | Meaning |
|---|---|
| Progress bar | finished / total tests |
| *Running **bw.3647** (http_Attachments_comp) - description … for 42s* | test currently running and its time so far |
| *Preparing suite X: installing drivers, creating AppSpace and starting the AppNode.* | suite setup (~3 min on Windows) |
| *Starting: detecting BW version and creating the domain…* | run start |
| *Stopping: finishing the current step and cleaning up BW…* | after Stop |

### Counter tiles
**Passed** (green) · **Failed** (red) · **Errors** (orange, *setup / environment*) · **Known failures** (purple; *+N fixed?* if
known failures passed) · **Remaining** (while running) or **Skipped / not run** (after).

### Banners
| Banner | Meaning |
|---|---|
| Red *Suite X could not start:* + message | AppSpace/AppNode creation or start failed. All tests of that suite are **Error**. |
| Yellow *This run did not finish normally.* | State **Incomplete**: the process ended without a summary (window closed, reboot, crash, low memory) |
| Yellow *This run was killed.* | After Force kill: check for leftover `bwappnode-*.exe` and the `bwtest-N` folder |

### Tab: Tests *(count)*
| Element | Meaning |
|---|---|
| Filter dropdown | *All tests*, *Failed + errors*, Passed, Failed, Error, Skipped, Known failure, Fixed? (XPASS), Running, Waiting, Not run, Unknown |
| Column **Result** | outcome pill; extra orange **cleanup error** if undeploy/stop failed after the test |
| Columns **Suite / Test / Description** | red first line of the failure message under the description; *known: BW-…* for known failures |
| Column **Time** | test duration |
| **details ›** / click a row | opens the test dialog |

**Test dialog** (*suite · test id*):

| Element | Meaning |
|---|---|
| Result, Suite, Test, Description, Duration | — |
| Time per phase | deploy · action · cleanup · verify for this test |
| Artifacts | folder of this test: `results/<id>/<suite>/<test>` |
| Left list: **Failure message** / *Known failure reason* | short reason + diff |
| `diff.txt` | unified diff gold ↔ output (opened automatically when present) |
| `test.log` | timeline of this test: deploy, action steps, waits, verify |
| `bwappnode.log` | only the AppNode log lines written during this test |
| `module_properties.txt` | every module property the app received (*not set by bwtest - EAR default used* for others) |
| other files | output, `t-tests.substvar`, legacy script logs … (sizes shown) |
| **open raw ↗** | opens the file unformatted (large files show the first 2 MB in the dialog) |
| **Run this test again** | New run with only this test selected |

### Tab: Console
What `bwtest run` printed. ☑ **Follow** = auto-scroll to the end. **Open raw** = `console.log` in full.

### Tab: Files
Browse the whole run folder: per-test folders, `commands.log` (every bwadmin call with exit code and duration),
`report.html`, `junit.xml`, `summary.json`. Click a folder to open it, **📁 ..** or **← Back** to go up,
**open raw ↗** to see a file unformatted.

### Tab: Details
| Card | Rows |
|---|---|
| **Where the time went** | Whole run (wall clock), Suite setup (AppSpace + AppNode start), Deploy, Waiting for the test output, Cleanup (stop + undeploy + delete archive), Compare with gold, and *bwadmin commands: N commands, X s in total - run in one bwadmin shell*. Use it to show how much faster than t-tests a run was. |
| **Run** | Run id, Name, Tester, Jira, Notes, Started, Ended, Exit code, Command |
| **Environment** | Profile, BW home, BW version (detected), Domain, Selection, Tag expression, Keyword, Workers, Dry run, Update gold |

When a running run finishes, a message *"Run <id> finished: <state>"* appears and the Tests tab is shown.

---

## 9. Runs & reports

All folders in `results/`: runs from the UI, the command line and Jenkins.

| Element | What it does |
|---|---|
| **▶ New run** | New run wizard |
| **Search name, tester, build, suite…** | Filters the table |
| State dropdown | *All results*, Running, Stopping…, Passed, Failures, Error, Stopped, Killed, Incomplete, No tests |
| *N runs* | total number of runs |
| Column **Started** | date/time + run id |
| Column **Run** | name (*(no name)*), suites below |
| Column **Profile / build** | e.g. *6.12.0 · V188*; tag **dry run** |
| Column **Tester** | — |
| Column **Result** | coloured bar + counts (*12 passed · 2 failed …*) |
| Column **Status** | state pill |
| **report ↗** | opens `report.html` directly |
| Click a row | Run page |

---

## 10. Suites

| Element | What it does |
|---|---|
| **⇩ Sync with test folder…** | Compares T-Next with *your* t-tests test folder (`<test case location>/func`). Lists **new suites** (`.testset` without a suite file; imported and grouped like the others: `http*` → `engine/http`, `jdbc/jdbc_<db>` → `engine/jdbc/<db>`) and **new test cases** in suites T-Next already has (appended to the suite file). Tick → **Sync selected (N)**. Existing tests and your edits are never changed; tests that are no longer in the `.testset` are only listed. EARs, gold files and scripts stay in the test folder. Changes appear at once - no restart. Also: *File → Sync with test folder…*, and a button on the Doctor checks *… not imported yet* / *… new test case(s) … not in T-Next yet*. Runs automatically at the end of `setup-bwtest.bat`. |
| **+ New suite** | New suite form |
| **Search name, description, tag, owner…** | text filter |
| Category dropdown | *All categories* or one folder (`engine`, `migration`, …) |
| Type dropdown | *Engine + migration* / *Engine* / *Migration* |
| Status dropdown | *Any status* / *Fully native* / *Has .sh script steps* / *Has known failures* / *Assets missing* / *Invalid YAML* |
| Counter | *N of M suites · N tests* |
| Column **Suite / Category / Type / Tests / Description** | tags shown under the description; red text = YAML error |
| Column **Status** pills | **invalid YAML** (red) · **assets missing** (orange: test case folder not found, hover shows the path) · **N with .sh step** (blue: tests with one t-tests `.sh` step, run by bwtest itself) or **native** (green) · **N known** (purple) · **disabled** (grey) |
| **Run** | New run with this suite ticked |
| Click a row | Suite page |

---

## 11. Suite page

### Header
Suite name + **engine** / **migration** pill, description.

| Button | What it does |
|---|---|
| **+ Add test case** | Opens the *Add test case* dialog |
| **▶ Run suite** | New run with this suite ticked |

Red banner *This suite file is not valid:* + error, if the YAML can't be parsed.

### Tab: Test cases *(count)*
| Element | Meaning |
|---|---|
| **Search test id, description, tag…** | filter |
| **+ Add test case** (small) | same dialog |
| Column **Test** | test id; orange **no folder** = case folder missing |
| Column **Description** | + tags |
| Column **Verify** | how output is compared (text, xml, legacy …) |
| Column **Action** | steps after deploy, e.g. `wait_for_output: 40.0`; *wait for output* = default |
| Column **Flags** | **BW-…** known to fail · **skip: reason** · **.sh step** · **×N** sequences |
| **Run** | New run with only this test |

### Tab: Overview
**About this suite:** File, Owner, Tests (*N known to fail, N skipped*), Test case folders (orange **missing** if not found), Tags,
Old scripts, Notes.

**Environment for every test:** Variables (module properties), `.cfg` files, Drivers, Databases reset,
AppNode properties, Legacy scripts.

### Tab: Edit YAML
| Element | What it does |
|---|---|
| Text editor | The suite file. **Tab** inserts two spaces. **Ctrl+S** = Save. |
| Blue *Unsaved changes.* | you edited something |
| **Validate** | Checks the text with the same parser a run uses: green *Valid. Suite 'x' with N test(s).* or red *Not valid:* + error |
| **Save** | Validates, then writes the file (an invalid file is never saved) |
| **Revert** | Discards your changes (asks first) |

Leaving the page with unsaved changes asks for confirmation.

### Dialog: Add test case
| Field | Required | Meaning |
|---|---|---|
| **Test id** | ✔ | Prefilled with the next free number (e.g. `bw.9002`). The BW project name becomes `bw_9002`. |
| **Description** | | what the test checks |
| **EAR file** + **Browse…** | | EAR exported from Studio; copied as `<assets_dir>/<id>/<project>.application.ear` |
| **Studio project folder (optional)** + **Browse…** | | copied for reference |
| **Tags** | | comma separated (`smoke, http`) |
| **Verify as** | | *suite default* / text / xml / json / binary / file exists |
| **Known to fail (optional)** | | Jira id; reported as known failure instead of failed |
| **Skip (optional)** | | reason; the test is skipped |
| **Cancel** / **Add test case** | | Add writes the suite file. If the result isn't valid, the file is restored and a red message is shown. |

After adding, the **<id> added** dialog shows the Case folder, the copied files and the next steps. **Create gold now ▶**
opens New run with this test (tick *Update gold files* in step 3). **Close** dismisses it.

---

## 12. New suite

| Field | Required | Meaning |
|---|---|---|
| **Name** | ✔ | e.g. `rest_json`. Also the AppSpace/AppNode name (old `TSI_COMPONENT`). Letters, digits, `_ - .` |
| **Category** | | folder under `suites/`, suggestions from existing ones (`engine`, `migration/…`) |
| **Type** | | *automatic (migration/\* = migration)* / *Engine (deploy EAR)* / *Migration (BW5 project → bwmigrator)* |
| **Owner** | | prefilled with the default tester |
| **Default verification** | | *text (gold file)* / xml / json / binary; each test can override |
| **Tags** | | comma separated |
| **Description** | | what the suite covers |
| **Test case folders (optional)** + **Browse…** | | where the `bw.XXXX/` folders live, e.g. `${assets_root}/func/engine/rest_json`. Empty = next to the suite file. |
| **File that will be created** | | live preview: `suites/<category>/<name>/<name>.suite.yaml` |
| **Create suite** | | creates the file and opens the Suite page |
| **Cancel** | | back to Suites |
| **After creating** card | | reminder: add tests → optional vars/.cfg/drivers in Edit YAML → run with Update gold → commit |

---

## 13. Preferences

Settings of this machine, saved to **`config/local.yaml`** (personal, not in git). An empty field means
the project default, shown in grey as *default: …*. Team defaults live in `config/bwtest.yaml`, and BW-version
defaults live in `config/profiles/<version>.yaml`.

| Button | What it does |
|---|---|
| **Check with Doctor** | opens Doctor |
| **Save** (top and bottom) | Saves only the fields you changed. The whole configuration is validated first. Green *Saved.*, or red *Not saved:* + reason. |

### Product
| Field | Config key | Old t-tests | Meaning |
|---|---|---|---|
| **Default profile (BW version)** | `profile` | Preferences > Product to Test | preselected on New run |
| **BW installs folder** + Browse… | `ui.builds_root` | Product profile > INSTALL_HOME | builds found as `<folder>/<version>/<build>/bw/<x.y>` |
| **Test case location** + Browse… | `paths.assets_root` | Test Case Location by Product | EARs and gold files (old `tests/bw`) |
| **Driver jars folder** + Browse… | `paths.driver_jars_root` | BW_ENGINE.sh | JDBC/JMS driver jars (old `tests/bw/lib`) |

### BW runtime
| Field | Config key | Old t-tests | Meaning |
|---|---|---|---|
| **Domain home** + Browse… | `bw.domain_home` | win.cfg DomainHome | where `bwtest-N` is created |
| **Admin mode** | `bw.admin_mode` | win.cfg AdminMode | `local` (no bwagent) / `enterprise` |
| **Delete domain after the run** | `bw.cleanup_domain` | win.cfg CleanUpDomain | Yes/No; No = keep it to inspect |
| **First HTTP port** | `ports.http_base` | fixed ports in .cfg | each suite gets its own port from here; parallel workers +250 |
| **AppNode start timeout (s)** | `timeouts.appnode_start` | t_sleep | raise it if AppNodes boot slowly (antivirus) |
| **Wait for output file (s)** | `timeouts.output_file` | t_sleep 40 | default wait for a test's output |

### Tools
| Field | Config key | Old t-tests | Meaning |
|---|---|---|---|
| **JRE location** + Browse… | `vars.JAVA_HOME` | User profile > JRE location | for legacy scripts / Java clients (BW uses its own JRE) |
| **Tibrv location** + Browse… | `vars.TIBRV_HOME` | User profile > Tibrv location | RV suites; its `bin` is put on the AppNode's PATH |
| **BW5 HOME (optional)** + Browse… | `vars.BW5_HOME` | User profile > BW5 HOME | migration suites only |
| **Bash for old scripts** + Browse… | `paths.bash` | Cygwin | empty = Git Bash found automatically |

### Report
| Field | Config key | Old t-tests | Meaning |
|---|---|---|---|
| **Default tester name** | `ui.default_tester` | Preferences > Report | prefilled on New run and New suite |

---

## 14. Doctor

| Element | What it does |
|---|---|
| **Profile** | BW version to check |
| **Build** | build of that profile (*V12 - C:/D/6.12.1/V12/bw/6.12*) |
| **Run checks** | Runs all checks (a few seconds, calls `bwadmin version`) |
| Result card | *Everything is ready* or *Some checks failed*; ✓ / ✗ per check, detail in grey, fix hint in orange (→ …) |

| Check | Meaning |
|---|---|
| BW home has bin/bwadmin | the build folder is correct |
| bwadmin version | bwadmin runs and reports a version |
| bwagent.ini present | BW config complete |
| Test assets folder exists | Test case location is right |
| Bash for legacy bridge | bwtest can run the `.sh` script steps (needs Git Bash) |
| Domain home writable | bwtest can create the domain |
| HTML report plugin | pytest-html installed |
| Parallel run plugin | pytest-xdist installed |
| N suite files are valid | every `*.suite.yaml` parses |

**Effective configuration** tab: the final merged settings (bw, paths, ports, timeouts, ui, vars), the order the
layers are applied (later wins), plus `config/drivers.yaml` and `config/databases.yaml` (passwords hidden).

---

## 15. Help & guide

A built-in short guide: the 5 steps to a first run, a glossary (suite, test case, gold file, profile, build,
legacy bridge …), the old t-tests → bwtest mapping, and an FAQ. For the full guide see [USER_GUIDE.md](USER_GUIDE.md).

---

## 16. Common controls and colours

| Control | Behaviour |
|---|---|
| **Browse…** next to path fields | native Windows file/folder picker (desktop app only; in the browser UI type the path) |
| Confirmation dialogs | red button = the destructive action (Stop run, Kill now, Delete, Discard); **Cancel** or Esc to abort |
| Toast messages (bottom right) | short confirmations: *Run … started*, *Suite saved*, *Command copied* |
| **?** / help text under fields | explains the field and the old t-tests name |

| Colour | Meaning |
|---|---|
| Green | passed / OK / ready |
| Red | failed / invalid / destructive action |
| Orange | error (environment), warning |
| Purple | known failure (`known_to_fail`) |
| Blue | info, running, migration, default |
| Grey | skipped, not run, stopped, disabled |
