import { h } from "../core/dom.js";
import { empty, linkButton } from "../components/ui.js";

export default {
  title: "Not found",
  render: () => h("div", {}, empty("Page not found", "The link may be old.", linkButton("Go to the dashboard", "#/", "primary"))),
};
