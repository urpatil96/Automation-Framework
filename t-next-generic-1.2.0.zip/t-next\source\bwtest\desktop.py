"""bwtest desktop application - a native Windows window, like the old t-tests 4.0 GUI.

    bwtest desktop          (or double-click start-bwtest.bat)

    ┌ bwtest - BusinessWorks 6 regression ───────────────────────────── _ □ x ┐
    │ File  Edit  Run  View  Help                                    (native menu)
    │ [New run] [Run selection] [Stop] | [Preferences] [Reports] [Doctor]  (toolbar)
    │ ┌ Test suites ──────┐┌──────────────────────────────────────────────────┐
    │ │ ▸ engine          ││  page: New run wizard / run progress / suite ... │
    │ │ ▸ migration       ││                                                  │
    │ │ Saved selections  ││                                                  │
    │ └───────────────────┘└──────────────────────────────────────────────────┘
    │ Profile 6.12.1 · V12 │ No run in progress │ 130 suites · 7,991 tests (status bar)
    └──────────────────────────────────────────────────────────────────────────┘

How: the same local server as `bwtest ui` runs on a free port inside this process; the window is
pywebview (Microsoft Edge WebView2, part of Windows 10/11) showing the UI in desktop layout. Native extras:
menu bar, file/folder pickers ("Browse..."), and a warning when closing while a run is going.
Closing the window stops the server; a run that is going continues and is shown again on the next start.

No WebView2 (or the window cannot open): T-Next opens in the web browser instead - same UI, browser layout -
and a small box "Click OK to stop T-Next" keeps the server running. pywebview's own fallback (the old Internet
Explorer engine) is never used: it cannot show this UI, and on a PC with a temporary user profile it fails with
WinError 1021 "Cannot create a stable subkey under a volatile parent key".
"""

from __future__ import annotations

import os
import socket
import threading
import time
from pathlib import Path

TITLE = "T-Next - BusinessWorks 6 regression"
WEBVIEW2_DOWNLOAD = "https://developer.microsoft.com/microsoft-edge/webview2/ (Evergreen Bootstrapper)"
_WEBVIEW2_CLIENTS = ("{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}",  # runtime
                     "{2CD8A007-E189-409D-A2C8-9AF4EF3C72AA}",  # beta
                     "{0D50BFEC-CD6A-4F9A-964C-C7416E3ACB10}",  # dev
                     "{65C35B14-6C1D-4122-AC46-7148CC9D6497}")  # canary


class DesktopApi:
    """Functions the page can call as window.pywebview.api.<name>(...)."""

    def __init__(self) -> None:
        self._window = None  # private: pywebview exposes public attributes to JavaScript

    def browse(self, kind: str = "file", start: str = "", patterns: str = "") -> str:
        """Native file / folder picker. kind = file | folder. Returns '' when cancelled."""
        import webview

        dialog = webview.FileDialog.FOLDER if kind == "folder" else webview.FileDialog.OPEN
        types = tuple(p for p in patterns.split("|") if p) if patterns else ()
        start_dir = start if start and Path(start).is_dir() else (str(Path(start).parent) if start else "")
        result = self._window.create_file_dialog(dialog, directory=start_dir, file_types=types)
        if not result:
            return ""
        return str(result[0] if isinstance(result, (list, tuple)) else result).replace("\\", "/")

    def open_path(self, path: str) -> bool:
        """Open a file or folder with Windows (Explorer / default app)."""
        if path and Path(path).exists():
            os.startfile(path)  # noqa: S606 - local desktop action requested by the user
            return True
        return False


def _free_port(preferred: int) -> int:
    for port in (preferred, 0):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return s.getsockname()[1]
            except OSError:
                continue
    raise RuntimeError("no free port")


def webview2_problem() -> str:
    """'' when the Edge WebView2 window can be used, else the reason (read-only registry checks, as pywebview)."""
    if os.name != "nt":
        return ""
    import winreg

    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full") as key:
            release, _ = winreg.QueryValueEx(key, "Release")
        if int(release) < 394802:
            return ".NET Framework 4.6.2 or newer is not installed"
    except OSError:
        return ".NET Framework 4.6.2 or newer is not installed"
    for client in _WEBVIEW2_CLIENTS:
        for hive, path in ((winreg.HKEY_CURRENT_USER, rf"SOFTWARE\Microsoft\EdgeUpdate\Clients\{client}"),
                           (winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{client}"),
                           (winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\Microsoft\EdgeUpdate\Clients\{client}")):
            try:
                with winreg.OpenKey(hive, path) as key:
                    build, _ = winreg.QueryValueEx(key, "pv")
            except OSError:
                continue
            if build and str(build) != "0.0.0.0":
                return ""
    return "the Microsoft Edge WebView2 Runtime is not installed"


def _browser_fallback(url: str, reason: str, app) -> None:
    """Show the UI in the web browser; keep the server running until the user clicks OK."""
    import webbrowser

    webbrowser.open(url)
    message = (f"T-Next opened in your web browser:\n{url}\n\n"
               f"(The T-Next window could not be used: {reason}.\n"
               f"To get the window, install the WebView2 Runtime: {WEBVIEW2_DOWNLOAD})\n\n"
               "Keep this box open while you use T-Next. Click OK to stop T-Next.")
    if os.name != "nt":
        print(message)
        input()
        return
    import ctypes

    box = ctypes.windll.user32.MessageBoxW
    while True:
        box(None, message, "T-Next", 0x40 | 0x40000)  # MB_ICONINFORMATION | MB_TOPMOST
        active = ", ".join(app.state.ctx.runs.active_ids())
        if not active:
            return
        answer = box(None, f"Run {active} keeps running in the background after you stop T-Next.\n"
                     "Open T-Next again to follow it.\n\nStop T-Next now?", "T-Next", 0x4 | 0x30)  # Yes/No, warning
        if answer == 6:  # IDYES
            return


def run_desktop(project_root: Path, config_dir: Path, port: int = 0, debug: bool = False) -> None:
    import uvicorn

    from .ui.server import create_app

    app = create_app(project_root, config_dir)
    port = _free_port(port or 8766)
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    for _ in range(100):  # wait until the API answers (max ~10 s)
        if server.started:
            break
        time.sleep(0.1)

    browser_url = f"http://127.0.0.1:{port}/"
    try:
        problem = webview2_problem()
        if problem:  # never let pywebview fall back to the Internet Explorer engine
            _browser_fallback(browser_url, problem, app)
            return
        _window(project_root, port, debug, app, browser_url)
    finally:
        server.should_exit = True
        thread.join(timeout=5)


def _window(project_root: Path, port: int, debug: bool, app, browser_url: str) -> None:
    import webview
    from webview.menu import Menu, MenuAction, MenuSeparator

    api = DesktopApi()
    url = f"http://127.0.0.1:{port}/?desktop=1"
    window = webview.create_window(TITLE, url, js_api=api, width=1440, height=900, min_size=(1000, 640),
                                   text_select=True, zoomable=True, background_color="#eef1f5",
                                   menu=_menu(lambda: window, Menu, MenuAction, MenuSeparator))
    api._window = window
    window.events.closing += lambda: _on_closing(window, app)
    shown: list[bool] = []
    window.events.shown += lambda: shown.append(True)
    try:
        webview.start(debug=debug, private_mode=False, gui="edgechromium",
                      storage_path=str(Path(project_root) / "results" / ".desktop-webview"))
    except Exception as exc:  # noqa: BLE001 - the window could not open: use the browser instead of failing
        if shown:
            raise
        _browser_fallback(browser_url, f"{type(exc).__name__}: {exc}", app)


def _on_closing(window, app) -> bool:
    """Warn when a run is going. Returning False keeps the window open."""
    active = ", ".join(app.state.ctx.runs.active_ids())
    if not active:
        return True
    return bool(window.create_confirmation_dialog(
        "A run is in progress",
        f"Run {active} keeps running in the background after you close T-Next.\n"
        "Open T-Next again to follow it, or stop it first from the run page.\n\nClose T-Next now?"))


def _menu(get_window, Menu, MenuAction, MenuSeparator):  # noqa: N803 - classes passed in (lazy import)
    def go(route: str):
        return lambda: get_window().evaluate_js(f"location.hash = {route!r}")

    def call(js: str):
        return lambda: get_window().evaluate_js(js)

    return [
        Menu("File", [
            MenuAction("New run...", go("#/run/new")),
            MenuAction("New suite...", go("#/suites/new")),
            MenuAction("Sync with test folder...", go("#/suites?import=1")),
            MenuSeparator(),
            MenuAction("Open results folder", call("window.bwDesktop && window.bwDesktop.openResults()")),
            MenuSeparator(),
            MenuAction("Exit", lambda: get_window().destroy()),
        ]),
        Menu("Edit", [
            MenuAction("Select test cases...", go("#/run/new?step=2")),
            MenuAction("Suites", go("#/suites")),
            MenuSeparator(),
            MenuAction("Preferences...", go("#/preferences")),
        ]),
        Menu("Run", [
            MenuAction("New run...", go("#/run/new")),
            MenuAction("Current run", call("window.bwDesktop && window.bwDesktop.openActive()")),
            MenuAction("Runs and reports", go("#/runs")),
            MenuSeparator(),
            MenuAction("Check environment (Doctor)", go("#/doctor")),
        ]),
        Menu("View", [
            MenuAction("Dashboard", go("#/")),
            MenuAction("Refresh", call("location.reload()")),
        ]),
        Menu("Help", [
            MenuAction("Guide", go("#/help")),
            MenuAction("About T-Next", call("window.bwDesktop && window.bwDesktop.about()")),
        ]),
    ]
