# Migrating from t-tests 4.0

## Status of the automatic import (run on 2026-11-16)

`bwtest import C:/D/Automation/tests/bw/func` converted **all 129 testsets (7,989 test cases, 0 errors)**.
On 2026-11-19 the active set was reduced to the suites whose test case folders are still in `tests/bw`:
the suites that have a `.testset` in `tests/bw/func`: **23 suites, 1,665 test cases** (the others are in
`results/_backup_suites_removed_20261119` and `..._20261119b`). The import did:

* 75 suites / 5,180 test cases are fully native YAML.
* 2,809 test cases still run part of their old bash script through the *legacy bridge* (they work; the
  exact commands are listed per suite in `suites/IMPORT_REPORT.md`).
* Verified on real BW 6.12.1 V12: `http_Attachments_comp` bw.3647 and bw.3648 pass end to end.

Re-run the import any time (e.g. after someone changes a legacy suite): it overwrites the generated
files, so do hand edits only after you stop maintaining the legacy copy of that suite.

## Mapping

| t-tests 4.0 | bwtest |
|---|---|
| `t-tests.bat` / `t_tests.bash` | `bwtest run` or `pytest` |
| `tests/bw/<ver>.profile` | `config/profiles/<ver>.yaml` (`bw.home`) |
| `config/win.cfg` DomainHome / AdminMode / CleanUpDomain | `bw.domain_home` / `bw.admin_mode` / `bw.cleanup_domain` |
| `.testset` `<TestCase>` | entry under `tests:` |
| `<KnownToFail>true` | `known_to_fail: <reason or Jira>` (xfail) |
| `<ID>#bw.1</ID>` (commented out) | `skip: disabled in legacy testset` |
| `<TestSequence>N` | `sequences: N`, `${seq}`, `sequence_vars` |
| `.testcmd` subsets | `-k "bw.1 or bw.2"`, `-m tag`, or a small suite file |
| `<suite>.cfg` `app.clientVar.X` | `client_vars_files: [<suite>.cfg]` (same file, unchanged) |
| `<suite>.ini` | `appspace_config_ini: <suite>.ini` |
| `export TSI_TEST_OUTPUT_FILE=...` in t_setup.sh | `output:` |
| `export TSI_TEST_GOLD_FILE=...` | `gold:` (+ `gold_by_version:` for `if [ ${TSI_PROD_VERSION_3DIGIT} == ...`) |
| other `export NAME=...` | `vars: {NAME: ...}` (module property) |
| `t_sleep N` in t_action.sh | `action: [{wait: N}]` — the test's own sleep **plus** the common sleeps after the `case` (bash order) |
| `t-testsSetAdvanceVerify true` in t_setup.sh | `action: [{wait_for_output: N}]` (N = total t_action.sh sleep; ends early when output >= gold size) |
| deploy → action → **stop + undeploy** → verify | same order (the app is stopped before the comparison) |
| `diff` in t_verify.sh / `diff -b` / `sort` | `verify: {type: text, ignore_whitespace, sort_lines}` |
| BW_ENGINE.sh driver `case` blocks | `config/drivers.yaml` + `drivers: [name]` |
| BW_ENGINE.sh `cleanDB.jar` blocks | `config/databases.yaml` + `databases: [name]` |
| `TSI_*` variables | `${id}`, `${tid}`, `${case_dir}`, `${log_dir}`, `${suite_dir}` ... (and still exported to legacy scripts) |
| `setupCommands.bat` / `appCommands.bat` | `results/<run>/worker-N/commands.log` |
| XSLT HTML report + SQL | `report.html`, `junit.xml`, `summary.json`; the `.sql` on demand (Run page → **t-tests .sql**, `bwtest ttests-report`) |

## Legacy bridge

Suites/tests with commands the importer will not guess (EMS/RV tools, TCP clients, loops) get

```yaml
legacy: {setup: t_setup.sh}        # or action: / verify:
```

The original script runs in Git Bash with the same `TSI_*` environment as before; variables it
`export`s become test variables (and module properties). The old helper functions (`t_sleep`,
`tu_init`, `t-tests*` API) are provided by a shim, so scripts run unchanged.

**To make a bridged test native:** open `suites/IMPORT_REPORT.md`, find the listed command, express it
as a step (`shell`, `http`, `wait_for_log`, `python`), delete the `legacy:` entry, run, commit.

## Points to check during the migration

1. **Platform constants.** `case ${NPORT}` / `${OS_PLATFORM}` branches were evaluated for Windows
   (`i86-winnt50`) at import time. Re-import on Linux if you need the Unix branches.
2. **`TEST_OUTPUT_FILE` vs `TSI_TEST_OUTPUT_FILE`** (older migration suites). The importer keeps
   `TEST_OUTPUT_FILE` / `TEST_GOLD_FILE` as module properties; verification uses `output:` / `gold:`.
   If a migration test compares the wrong file, set `output:` / `gold:` explicitly for that suite.
3. **cfg properties that are not client vars** (e.g. `bw.plugin.http.client.urlEncodeQueryString`) are
   written to the AppNode `config.ini`. Confirm this matches what t-tests did for your suites.
4. **Driver jars** are expected under `paths.driver_jars_root` (default `${assets_root}/lib`, the old
   `${TSI_TEST_PRODUCT_ROOT}/lib`). That folder is not present on this machine — copy it from the
   machine/share that ran the JDBC/JMS suites.
5. **Passwords** moved to `.env` (see `config/.env.example`). Rotate the ones that were committed in
   `BW_ENGINE.sh` — they are still in that file's history.
6. The importer's result for each suite is a starting point: review `notes:` in the generated files.
