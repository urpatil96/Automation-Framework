"""BW home + version in any form: BW6121 / BW 6.12.1 / 6.12.1, INSTALL_HOME instead of bw/<x.y>, any folder layout."""

from pathlib import Path

import pytest

from bwtest.bwhome import find_bw_homes, guess_version, normalize_version, resolve_bw_home
from bwtest.config import load_settings
from bwtest.ui.services.builds import discover_builds

KNOWN = ["6.10.0", "6.11.0", "6.12.0", "6.12.1", "6.13.0"]


def _install(install_home: Path, xy: str = "6.12", info: str | None = None) -> Path:
    home = install_home / "bw" / xy
    (home / "bin").mkdir(parents=True)
    (home / "bin" / "bwadmin.exe").write_text("")
    (home / "config").mkdir()
    (home / "config" / "bwagent.ini").write_text("")
    if info:
        (install_home / "_installInfo").mkdir()
        (install_home / "_installInfo" / f"BW_{info}_prodInfo.xml").write_text("")
    return home


@pytest.mark.parametrize("text", ["6.12.1", "BW6121", "BW 6.12.1", "bw_6_12_1", "BW6.12.1", "6121", "6.12.1.000",
                                  "BW_6.12.1_prodInfo.xml", "BusinessWorks 6.12.1"])
def test_every_way_of_writing_the_version_gives_the_profile(text):
    assert normalize_version(text, KNOWN) == "6.12.1"


@pytest.mark.parametrize("text", ["BW6setup", "V12", "GA_3HF1GA", "6.8.1", ""])
def test_folder_names_that_are_not_a_known_version(text):
    assert normalize_version(text, KNOWN) is None


def test_colleague_layout_install_home_named_bw6121(tmp_path):
    """C:/Users/x/bw6/BW6setup/BW6121 was entered as BW home -> the real one is .../BW6121/bw/6.12."""
    install_home = tmp_path / "vendor" / "BW6setup" / "BW6121"
    home = _install(install_home)
    for entered in (install_home, install_home / "bw", home / "bin", home, tmp_path / "vendor" / "BW6setup"):
        assert resolve_bw_home(entered) == home
    assert guess_version(home, KNOWN) == "6.12.1"  # no _installInfo: from the folder name BW6121
    builds = discover_builds(tmp_path / "vendor", "6.12.1", known=KNOWN)
    assert [(b.label, Path(b.bw_home)) for b in builds] == [("BW6121", home)]
    assert discover_builds(tmp_path / "vendor", "6.12.0", known=KNOWN) == []


def test_installer_info_wins_over_folder_names(tmp_path):
    """bw/6.12 alone could be 6.12.0 or 6.12.1 - _installInfo says which (hotfix level ignored)."""
    a = _install(tmp_path / "builds" / "latest", info="6.12.0.005")
    b = _install(tmp_path / "builds" / "qa" / "V12", info="6.12.1")
    assert guess_version(a, KNOWN) == "6.12.0" and guess_version(b, KNOWN) == "6.12.1"
    assert find_bw_homes(tmp_path / "builds") == sorted([a, b], key=lambda p: p.as_posix().lower())
    assert [Path(x.bw_home) for x in discover_builds(tmp_path / "builds", "6.12.1", known=KNOWN)] == [b]


def test_qa_machine_layout_still_works(tmp_path):
    home = _install(tmp_path / "6.12.1" / "V12")
    [build] = discover_builds(tmp_path, "6.12.1", known=KNOWN)
    assert build.label == "V12" and Path(build.bw_home) == home


def test_settings_accept_profile_bw6121_and_install_home(fake_project, tmp_path):
    config = fake_project / "config"
    (config / "profiles").mkdir()
    (config / "profiles" / "6.12.1.yaml").write_text("bw: {}\n")
    install_home = tmp_path / "BW6121"
    home = _install(install_home)
    settings = load_settings(config, "BW 6.12.1", {"bw": {"home": install_home.as_posix()}})
    assert settings.profile == "6.12.1" and settings.bw.home == home
    with pytest.raises(Exception, match="not found"):
        load_settings(config, "6.99.9")
