"""Syntax-check every UI JavaScript module with V8 (pip install mini-racer). No Node.js needed.

    python source/tests/js_syntax_check.py

ES module import/export lines are rewritten to plain declarations, then each file is compiled (not run)
inside a function, so V8 reports any syntax error with its line number.
"""

import re
import sys
from pathlib import Path

WEB = Path(__file__).resolve().parents[1] / "bwtest" / "ui" / "web" / "js"


def _import_to_let(match: re.Match) -> str:
    names = " ".join(match.group(1).split()).strip().rstrip(",")
    return f"let {names};" + "\n" * match.group(0).count("\n")  # keep line numbers stable


def to_script(source: str) -> str:
    source = re.sub(r"^import\s*\{([^}]*)\}\s*from\s*\"[^\"]*\";", _import_to_let, source, flags=re.M)
    source = re.sub(r"^import\s+[^;]*;", "", source, flags=re.M)
    out = []
    for line in source.splitlines():
        line = re.sub(r"^export default\s+", "const __default = ", line)
        line = re.sub(r"^export\s+(?=(async\s+)?function|const|let|class)", "", line)
        out.append(line)
    return "\n".join(out)


def main() -> int:
    from py_mini_racer import MiniRacer

    ctx = MiniRacer()
    failures = 0
    files = sorted(WEB.rglob("*.js"))
    for file in files:
        script = to_script(file.read_text(encoding="utf-8"))
        try:
            ctx.eval(f"new Function({script!r}); 1")
        except Exception as exc:  # noqa: BLE001 - report every engine error
            failures += 1
            print(f"FAIL {file.relative_to(WEB)}: {str(exc).splitlines()[0][:300]}")
    print(f"{len(files) - failures}/{len(files)} JavaScript files compile")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
