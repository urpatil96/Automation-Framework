"""Web UI for bwtest:  `bwtest ui`  ->  http://127.0.0.1:8765

    server.py            FastAPI app: mounts the API routers and the static single-page app
    context.py           shared state per server: project root, config dir, settings, run manager
    services/            plain Python, no HTTP - easy to unit-test and reuse
        builds.py          BW installs per profile  (any layout below ui.builds_root)
        catalog.py         suites and tests (cached by file modification time)
        runs.py            start / stop / follow runs, run history (results/<timestamp>/)
    routes/              thin HTTP layer, one file per page area
        system.py          /api/overview, /api/profiles, /api/config, /api/doctor
        suites.py          /api/suites ...  (browse, edit YAML, new suite, new test)
        runs.py            /api/runs ...    (start, live status, console, stop, files)
    web/                 the browser app (no build step, plain ES modules)
"""
